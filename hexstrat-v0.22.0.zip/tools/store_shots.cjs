// Скриншоты для карточки RuStore: node tools/store_shots.cjs  (нужен playwright; пишет store/screenshots/*.png, 1080x1920)
const { chromium } = require('playwright');
const { pathToFileURL } = require('node:url');
const { resolve } = require('node:path');
const OUT = resolve(__dirname, '../store/screenshots');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 540, height: 960 }, deviceScaleFactor: 2, hasTouch: true });
  const page = await ctx.newPage();
  const shot = async (name) => { await page.waitForTimeout(700); await page.screenshot({ path: `${OUT}/${name}.png` }); };
  await page.goto(pathToFileURL(resolve(__dirname, '../dist/index.html')).href);
  await page.waitForTimeout(3500); // заставка
  await shot('01-menu');
  await page.click('[data-act="newgame"]');
  await page.click('[data-act="scen"][data-arg="europe1939"]');
  await shot('02-scenarios');
  await page.click('[data-act="begin"]');
  await page.waitForTimeout(1500);
  await shot('03-map-1939');
  await page.click('#tools [data-act="diplo"]');
  await shot('04-diplomacy');
  await page.click('.pback');
  await page.click('#tools [data-act="tech"]');
  await shot('05-technologies');
  await page.click('.pback');
  await page.click('#whoName');
  await page.click('[data-act="ctab"][data-arg="focus"]');
  await shot('06-focuses');
  await browser.close();
})();
