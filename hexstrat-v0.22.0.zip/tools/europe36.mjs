// Генератор карты «Европа 1936»: node tools/europe36.mjs
// Пишет game/europe_data.js и tools/europe_preview.html (картинка для проверки).
import { writeFileSync } from 'node:fs';
import { LAND, HOLES, COUNTRIES } from './europe_geo.mjs';
import { PLACES } from './europe_places.mjs';

const RAD = Math.PI / 180;
const LON1 = 63.6, LAT_BOT = 25.2;
const W = 0.0092;                         // ширина гекса (радиус Земли = 1), ~60 км
// Равнопромежуточная проекция со стандартной параллелью 50°: меридианы вертикальны, север сверху,
// как на привычных политических картах; искажение площадей на севере умеренное.
const COSF = Math.cos(50 * RAD);
const proj = (lon, lat) => [(lon - 15) * RAD * COSF, -(lat - 48) * RAD];   // y растёт к югу
const unproj = (x, y) => [x / COSF / RAD + 15, -y / RAD + 48];
// рамка карты: по границам суши
let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
for (const poly of LAND) for (const [lon, lat] of poly) {
  if (lon > LON1 + 0.01 || lat < LAT_BOT) continue;
  const [x, y] = proj(lon, lat);
  minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y);
}
for (const [lon, lat] of [[LON1, 25], [LON1, 47.8], [LON1, 40], [-17, 24], [-9.6, 36.5], [32, 71], [46, 65]]) {
  const [x, y] = proj(lon, lat);
  minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y);
}
minX -= W; minY -= W; maxX += W; maxY += W;
const COLS = Math.ceil((maxX - minX) / W);
const ROWS = Math.ceil((maxY - minY - 0.577 * W) / (0.866 * W)) + 1;
const center = (c, r) => ({ x: (c + 0.5 * (r & 1) + 0.5) * W, y: (r * 0.866 + 0.577) * W });
const toLL = (x, y) => unproj(x + minX, y + minY);

function inPoly(poly, x, y) {
  let ins = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i], [xj, yj] = poly[j];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) ins = !ins;
  }
  return ins;
}
const inAny = (polys, x, y) => polys.some((p) => inPoly(p, x, y));

// ---------- рельеф ----------
const T = (type, ...polys) => ({ type, polys });
const TERR = [
  T('m', // Скандинавские горы, Урал
    [[12.2,60.5],[13,62.0],[14.2,63.3],[15.8,64.8],[17.5,66.2],[19,67.6],[21,68.6],[22.5,68.5],[20.5,67.3],[18.8,66.0],[17,64.5],[15.5,63.0],[14.0,61.5],[13.0,60.2]],
    [[58.5,52],[59.5,56],[60.5,60],[61,64],[62,66],[60.5,66],[59,62],[58,58],[57.5,54]],
  ),
  T('h', // нагорья севера
    [[13.5,56.8],[15.8,56.8],[16.2,57.8],[14.2,58.0]],
    [[24,67.8],[29,68.8],[28.5,70],[25,70],[22,69]],
    [[34,55.5],[38,56.5],[37,57.5],[33,57]],
    [[26,61.5],[30,62.5],[30,64],[27,63.5]],
  ),
  T('f', // тайга за Уралом
    [[62,56.5],[66,56.5],[66,66],[62,66]],
  ),
  T('f', // лесные пятна Прибалтики
    [[24,54.0],[26.5,54.0],[26.5,55.2],[24,55.0]],
    [[24.5,56.8],[27,56.8],[27,58.0],[25,58.0]],
    [[25.5,58.6],[28,58.6],[28,59.5],[25.5,59.3]],
  ),
  T('p', // равнины Швеции и Финляндии
    [[10.9,55.2],[14.5,55.2],[16.3,56.5],[17.2,58.5],[19.2,59.8],[18,60.4],[15,60.0],[12.5,60.2],[11.2,59.2],[11.6,57.5]],
    [[21.0,60.0],[27.5,60.3],[28.5,61.0],[26,61.5],[23,62.0],[21.5,61.5]],
    [[21,62.0],[23.5,62.5],[25,64.3],[25.5,65.4],[24,65.9],[21.8,64.2]],
    [[16.5,62.5],[18.5,63.0],[20.5,64.5],[20.5,65.8],[18,65.5],[16.8,64]],
  ),
  T('m', // горы
    [[6.5,44.0],[6.0,45.5],[6.5,46.5],[8.5,47.1],[10.0,47.4],[12.0,47.7],[13.8,47.6],[15.5,47.7],[15.4,46.8],[14.0,46.2],[12.5,46.2],[10.5,45.8],[8.5,45.7],[7.5,44.3]],
    [[-2.2,43.4],[-0.5,43.0],[3.3,42.7],[3.3,42.2],[-0.5,42.4],[-2.2,42.9]],
    [[-8.2,43.3],[-4.5,43.2],[-4.5,42.7],[-8.2,42.8]],
    [[8.5,44.6],[11.0,44.3],[13.5,42.8],[15.5,40.6],[16.5,39.0],[16.0,38.2],[15.7,39.0],[15.0,40.5],[13.0,42.2],[10.8,43.9],[8.8,44.2]],
    [[19.0,49.5],[21.0,49.55],[23.6,49.0],[25.0,48.5],[26.5,47.2],[26.5,46.0],[25.0,45.4],[23.0,45.4],[22.2,45.2],[23.5,46.0],[24.5,47.2],[23.3,48.1],[21.5,48.8],[19.5,48.9]],
    [[14.5,45.6],[16,44.9],[19.5,43.1],[20.6,42.0],[20.9,40.5],[20.5,39.8],[19.7,40.3],[19.4,42.2],[17.5,43.4],[15.5,44.6],[14.3,45.3]],
    [[22.4,43.4],[24.5,42.9],[26.2,42.9],[26.2,42.3],[23.5,41.8],[22.8,41.5]],
    [[20.5,40.6],[21.6,39.5],[22.3,38.5],[21.3,38.5],[20.5,39.5]],
    [[5,58.8],[6.5,61],[9,63],[13,66],[17,68.5],[20,69.8],[21,68.5],[16,66],[13,63.5],[11,61.5],[9,59.5],[7,58.5]],
    [[-6.2,57.8],[-3.5,57.5],[-3.5,56.5],[-5.5,56.0],[-6.2,56.8]],
    [[-5.2,53.3],[-3,53.0],[-3,51.8],[-5,52.0]],
    [[-5,37.2],[-2,37.4],[-2,36.9],[-5,36.7]],
    [[-5.5,41.0],[-3.5,41.0],[-3.5,40.7],[-5.5,40.5]],
    [[30,36.5],[33,37.2],[36,38],[36.5,37],[33,36.3]],
    [[37.5,44.5],[40,43.8],[43.5,42.5],[46.1,42.5],[46.1,41.4],[43,41.4],[40,42.8],[38,44.2]],
    [[38,40.8],[41,41.4],[44.3,40.2],[44.3,38.5],[40.5,38.5]],
  ),
  T('m',
    [[-10,31.5],[-6,33.5],[-2,34.5],[2,36.0],[6,36.2],[9,35.6],[9,34.8],[5,34.4],[0,33.6],[-4,32.2],[-8,30.5],[-10,30.0]], // Атлас
    [[35.6,33.0],[36.5,34.2],[36.9,34.6],[36.3,34.6],[35.7,33.8]], // Ливан
    [[44.3,37.4],[46.0,36.0],[47.8,33.8],[49.5,31.5],[51.5,29.5],[54.0,27.6],[56.5,27.0],[57.2,27.8],[54.5,29.6],[52.5,31.8],[50.0,34.3],[47.5,36.5],[45.5,38.2]], // Загрос
    [[49.0,37.4],[52.0,36.8],[55.0,37.0],[56.0,36.2],[53.0,35.9],[50.0,36.4]], // Эльбурс
    [[56,25.5],[60,25.5],[62,26.2],[61,27.8],[57,27.5]],
    [[32.5,28.2],[34.2,28.3],[34.5,29.8],[33.0,29.8]], // Синай
    [[36.5,18],[39.5,22],[40.5,23.8],[38.5,23.8]],
  ),
  T('d', // пустыни
    [[-17.5,23],[-4,23],[-3,26],[-1,29],[2,31],[6,31.6],[9.4,31.0],[10.2,29.5],[25,29.5],[25,23],[35,23],[35,26],[32.5,28],[30.8,29.7],[30.8,27],[33,25],[30,24],[30.5,23]],
    [[-6,28],[-1,31],[1,32.4],[3.5,32.8],[8,33.0],[8,31],[2,30],[-2,28]],
    [[12,29.5],[14.5,31.5],[19,31.0],[21.5,30.8],[25,29.5],[25,31.2],[21,32],[18.5,30.8],[16,30.6]],
    [[34.8,29.0],[36.5,29.4],[37.4,30.3],[39.2,32.3],[41,32.5],[42,31.5],[38.5,30.8],[36,26.5],[38,24.5],[40,25.5],[44,27],[48,29.5],[50,26.5],[50.5,24.5],[52,23],[38.5,23]],
    [[38.7,33.0],[41.5,33.8],[42.5,35.2],[40.5,35.5],[38.5,34.5],[37.2,33.2]],
    [[52,29.0],[58,29.0],[60.8,31],[60.8,35],[57,35.5],[55,34.8],[53,33],[52,31]],
    [[63.0,27.0],[63.6,27.0],[63.6,29.3],[62.3,29.3]],
    [[53.5,37.0],[63.6,37.0],[63.6,44.5],[57,44.5],[54,42],[53.2,39]], // Каракумы, Кызылкумы
    [[54,43],[58,45.5],[61,47],[63.6,47],[63.6,44.5],[57,44.5]], // Устюрт
  ),
  T('h', // холмы
    [[1.5,46.0],[4.5,46.2],[4.5,44.3],[2.5,43.8],[1.5,44.5]],
    [[5.8,47.8],[7.4,48.6],[7.0,46.8],[6.0,46.6]],
    [[7.5,47.8],[8.8,48.8],[8.5,49.0],[7.7,47.6]],
    [[9.5,50.8],[11.8,51.8],[12.0,50.5],[10,50.2]],
    [[12.5,49.2],[15.8,50.7],[16.8,49.5],[15.0,48.8],[13.5,48.7]],
    [[-7,42],[-1,42.5],[-1,38.5],[-4,38],[-7,39]],
    [[-8.5,42],[-7,42],[-7,40.5],[-8.5,40.5]],
    [[-3,55.0],[-1.8,55.0],[-1.8,53.2],[-2.5,53.3]],
    [[22,45.8],[23,47.2],[25,47.6],[26.2,46.5],[26,45.5],[24,45.3]],
    [[22.4,41.8],[22.9,42.8],[26,42.9],[26.2,41.6]],
    [[26,48.4],[29,48.8],[30,48],[27,47.0]],
    [[19.5,50.9],[21.5,51.0],[21.0,50.0],[19.5,50.0]],
    [[28.0,50.8],[31,50.0],[30.5,48.8],[27.8,49.2]],
    [[34.5,52.0],[38,52.2],[38,50.3],[34.8,50.0]],
    [[30,41.5],[44,41.5],[44,36.5],[30,36.5],[27,37.5],[27,40]],
    [[9.0,43.7],[10.2,44.4],[9.9,43.9]],
    [[-6.0,50.3],[-3.8,50.8],[-3.8,50.0]],
    [[8,40.0],[9.6,40.9],[9.6,39.3],[8.4,39.3]],
    [[14.0,37.2],[15.4,38.0],[13.5,38.2]],
    [[20.5,39.2],[24.3,38.5],[24.2,36.7],[22.0,36.5],[21,37.5]],
    [[3.5,50.0],[4.5,50.4],[6.5,50.2],[6.5,49.6],[4.5,49.5]],
    [[13,48],[14.5,48.5],[14.5,47.5],[13,47.4]],
    [[14.8,46.3],[16.2,46.8],[16.0,45.9],[14.8,45.9]],
  ),
  T('p', // северные равнины: долины рек, тундра у побережья, озёрный край (до тайги — приоритет выше)
    [[38,57.2],[42,57.2],[44,60],[42,62],[38,60.5]],
    [[40,61],[44,61],[46,64],[43,64.5],[40,63]],
    [[47,63],[56,64],[58,67],[52,68],[47,66]],
    [[28,67.6],[36,68.6],[44,67.2],[52,68.6],[60,68.2],[62,70],[28,70.4]],
    [[28,60.5],[33,60.5],[33,62.5],[29,62.5]],
    [[56,58],[62,58],[62,62],[56,62]],
    [[62,56],[66,56],[66,60],[62,60]],
  ),
  T('h', // возвышенности севера России
    [[30,64],[34,64.5],[35,66.5],[31,67]],
    [[31,56.5],[35,57.8],[36,58.8],[33,58.5],[31,57.5]],
    [[48,64],[52,65.5],[54,67.5],[51,67.5],[48,65.5]],
    [[44,59.5],[50,60],[52,61.5],[47,61.5]],
    [[36,60.5],[40,61.5],[40,62.8],[37,62.3]],
    [[54,60],[58,61],[58,64],[55,63]],
  ),
  T('f', // леса
    [[6.0,50.0],[8.0,50.0],[8.0,49.0],[6.0,49.0]],
    [[11,52.2],[15,52.2],[15,53.6],[11,53.6]],
    [[-1.4,43.6],[-0.4,44.8],[-1.2,44.9],[-1.3,44.0]],
    [[22.5,50.8],[28.5,50.8],[28.5,54.8],[22.5,54.8]],
    [[28,57.5],[46,57.0],[50,58],[50,66],[28,66]],
    [[28,63],[36,63],[36,70],[28,70]],
    [[31,53.5],[36,53.5],[36,55],[31,55]],
    [[14.5,53.0],[18.5,53.0],[18.5,54.5],[14.5,54.5]],
    [[14.5,48.5],[15.5,48.5],[15.5,49.3],[14.5,49.3]],
    [[9.5,47.7],[11.5,47.7],[11.5,49.8],[9.5,49.8]],
  ),
];
const FOREST_C = new Set(['W', 'K']);
const HILLS_C = new Set(['X']);

function terrainAt(lon, lat, ch) {
  for (const t of TERR) if (inAny(t.polys, lon, lat)) return t.type;
  if (ch === 'Sa' ) return 'd';
  if (FOREST_C.has(ch)) return 'f';
  if (HILLS_C.has(ch)) return 'h';
  if (ch === 'S' && lat > 57.5) return 'f';
  if (ch === 'S' && lat < 41.5) return 'h';
  return 'p';
}

// ---------- сетка ----------
const prj = (p) => p.map(([lon, lat]) => { const [x, y] = proj(lon, lat); return [x - minX, y - minY]; });
const landPolys = LAND.map(prj);
const holePolys = HOLES.map(prj);
const prio = [...COUNTRIES].sort((a, b) => (a[0] === 'S' || a[0] === 'E' ? 1 : 0) - (b[0] === 'S' || b[0] === 'E' ? 1 : 0));
const cPolys = [...COUNTRIES.filter((c) => c[6]).map((c) => ({ code: c[0], polys: c[6] })), ...prio.map((c) => ({ code: c[0], polys: c[5] }))];

const cells = [];
for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) {
  const { x, y } = center(c, r);
  const [lon, lat] = toLL(x, y);
  const isLand = (px, py) => inAny(landPolys, px, py) && !inAny(holePolys, px, py);
  // клетка — суша, если земля занимает заметную часть гекса: так узкие полуострова и острова не рвутся
  let sc = isLand(x, y) ? 2 : 0;
  for (let k = 0; k < 6; k++) if (isLand(x + 0.42 * W * Math.cos(k * Math.PI / 3), y + 0.42 * W * Math.sin(k * Math.PI / 3))) sc++;
  const land = sc >= 3 && lon <= LON1 && lat >= LAT_BOT;
  cells.push({ c, r, x, y, lon, lat, land, owner: null, terr: 'p', w: 0, name: null });
}
const at = (c, r) => (c < 0 || r < 0 || c >= COLS || r >= ROWS ? null : cells[r * COLS + c]);
const nbrs = (cell) => {
  const odd = cell.r & 1;
  const d = odd ? [[1, 0], [1, -1], [0, -1], [-1, 0], [0, 1], [1, 1]] : [[1, 0], [0, -1], [-1, -1], [-1, 0], [-1, 1], [0, 1]];
  return d.map(([dc, dr]) => at(cell.c + dc, cell.r + dr)).filter(Boolean);
};

// проливы: клетки разных земель (материк, Британия, Сицилия...) не должны соприкасаться — между ними море.
// Из двух соседних клеток убирается та, что принадлежит меньшей земле (крошечные острова не трогаем).
{
  const MAINLAND = new Set([0, 1, 3]);
  const grp = (i) => (MAINLAND.has(i) ? 0 : i);
  const sampleOffs = [[0, 0], ...[0, 1, 2, 3, 4, 5].map((k) => [0.42 * W * Math.cos(k * Math.PI / 3), 0.42 * W * Math.sin(k * Math.PI / 3)])];
  for (const cell of cells) {
    cell.g = -1;
    if (!cell.land) continue;
    for (const [dx, dy] of sampleOffs) {
      const i = landPolys.findIndex((poly) => inPoly(poly, cell.x + dx, cell.y + dy));
      if (i >= 0) { cell.g = grp(i); break; }
    }
  }
  const size = new Map();
  for (const cell of cells) if (cell.land) size.set(cell.g, (size.get(cell.g) || 0) + 1);
  const drop = new Set();
  for (const cell of cells) {
    if (!cell.land) continue;
    for (const n of nbrs(cell)) {
      if (!n.land || n.g === cell.g || cell.g < 0 || n.g < 0) continue;
      const sc = size.get(cell.g), sn = size.get(n.g);
      if (sc <= 4 || sc > sn) continue;       // убираем клетку меньшей земли
      drop.add(cell);
    }
  }
  for (const cell of drop) cell.land = false;
  // Зеландия: Эресунн должен быть морем — убираем клетки материка, касающиеся острова
  const zealand = landPolys[LAND.findIndex((pl) => pl.length === 5 && pl[0][0] === 11.1 && pl[0][1] === 55.6)];
  for (const cell of cells) {
    if (!cell.land || !zealand || !inPoly(zealand, cell.x, cell.y)) continue;
    for (const n of nbrs(cell)) if (n.land && !inPoly(zealand, n.x, n.y)) n.land = false;
  }
  console.log('убрано клеток у проливов:', drop.size);
}
for (const cell of cells) {
  if (!cell.land) continue;
  for (const cp of cPolys) if (inAny(cp.polys, cell.lon, cell.lat)) { cell.owner = cp.code; break; }
}
for (let guard = 0; guard < 50; guard++) {
  const todo = cells.filter((c) => c.land && !c.owner);
  if (!todo.length) break;
  const set = [];
  for (const cell of todo) {
    const cnt = new Map();
    for (const n of nbrs(cell)) if (n.land && n.owner) cnt.set(n.owner, (cnt.get(n.owner) || 0) + 1);
    if (cnt.size) set.push([cell, [...cnt.entries()].sort((a, b) => b[1] - a[1])[0][0]]);
  }
  if (!set.length) break;
  for (const [cell, o] of set) cell.owner = o;
}
// правка: клетка Южного Тироля разрывала Австрию на две части
{ const fix = at(44, 53); if (fix && fix.land && fix.owner !== 'A') fix.owner = 'A'; }
for (const cell of cells) if (cell.land) cell.terr = terrainAt(cell.lon, cell.lat, cell.owner);

// ---------- названия: ближайшие свободные места ----------
const dist2 = (cell, p) => {
  const dx = (cell.lon - p[1]) * Math.cos(cell.lat * RAD), dy = cell.lat - p[2];
  return dx * dx + dy * dy;
};
const landCells = cells.filter((c) => c.land);
const usedP = new Set();
// Столицы называются первыми: клетка страны, ближайшая к столице, получает её имя
// (иначе соседний чужой город мог занять клетку маленькой страны, а столица уехать за границу)
for (const c of COUNTRIES) {
  const p = PLACES.find((q) => q[0] === c[4] || q[0].startsWith(c[4]));
  if (!p) continue;
  let best = null, bd = 1e9;
  for (const cell of landCells) if (cell.owner === c[0] && !cell.name) { const d = dist2(cell, p); if (d < bd) { bd = d; best = cell; } }
  if (best) { best.name = p[0]; usedP.add(p); best.w = Math.max(best.w, p[3]); }
}
const pairs = [];
for (const cell of landCells) for (const p of PLACES) { const d = dist2(cell, p); if (d < 9) pairs.push([d, cell, p]); }
pairs.sort((a, b) => a[0] - b[0]);
for (const [, cell, p] of pairs) {
  if (cell.name || usedP.has(p)) continue;
  cell.name = p[0]; usedP.add(p);
  cell.w = Math.max(cell.w, p[3]);
}
for (const p of PLACES) {
  if (usedP.has(p) || p[3] < 3) continue;
  let best = null, bd = 1e9;
  for (const cell of landCells) { const d = dist2(cell, p); if (d < bd) { bd = d; best = cell; } }
  if (best && bd < 2) best.w = Math.max(best.w, p[3] - 1);
}
const DIRS = ['восток', 'северо-восток', 'север', 'северо-запад', 'запад', 'юго-запад', 'юг', 'юго-восток'];
const usedNames = new Set(landCells.map((c) => c.name).filter(Boolean));
for (const cell of landCells) {
  if (cell.name) continue;
  let best = null, bd = 1e9;
  for (const p of PLACES) { const d = dist2(cell, p); if (d < bd) { bd = d; best = p; } }
  const ang = Math.atan2(cell.lat - best[2], (cell.lon - best[1]) * Math.cos(cell.lat * RAD));
  const dir = DIRS[Math.round(((ang + 2 * Math.PI) % (2 * Math.PI)) / (Math.PI / 4)) % 8];
  let nm = `${best[0]} (${dir})`, k = 2;
  while (usedNames.has(nm)) nm = `${best[0]} (${dir} ${k++})`;
  cell.name = nm; usedNames.add(nm);
}

// ---------- столицы ----------
const caps = {};
for (const c of COUNTRIES) {
  const p = PLACES.find((q) => q[0] === c[4] || q[0].startsWith(c[4]));
  if (!p) throw new Error('нет столицы ' + c[4]);
  let best = null, bd = 1e9;
  for (const cell of landCells) if (cell.owner === c[0]) { const d = dist2(cell, p); if (d < bd) { bd = d; best = cell; } }
  if (!best) throw new Error('нет клеток у ' + c[1]);
  caps[c[0]] = best;
  best.w = Math.max(best.w, 7);
}

// ---------- месторождения топлива: [долгота, широта, тип] (o — нефть, O — крупная нефть, c — уголь) ----------
const DEPOSITS = [
  [26.0, 44.95, 'O'], [49.8, 40.4, 'O'], [45.7, 43.3, 'o'], [40.1, 44.6, 'o'], [44.4, 35.5, 'O'], [43.1, 36.3, 'o'],
  [48.5, 30.5, 'O'], [49.3, 31.9, 'o'], [49.9, 26.3, 'O'], [23.5, 49.3, 'o'], [10.0, 52.5, 'o'], [16.7, 48.5, 'o'],
  [16.9, 46.5, 'o'], [19.9, 40.8, 'o'], [33.0, 29.0, 'o'], [14.0, 44.8, 'c'],
  [7.2, 51.5, 'c'], [6.9, 51.4, 'c'], [7.0, 49.3, 'c'], [18.9, 50.2, 'c'], [12.5, 50.7, 'c'], [38.0, 48.0, 'c'], [39.5, 48.2, 'c'],
  [37.5, 54.0, 'c'], [-3.3, 51.7, 'c'], [-1.6, 54.9, 'c'], [-1.5, 53.0, 'c'], [-3.9, 55.8, 'c'], [6.0, 49.3, 'c'],
  [3.0, 50.4, 'c'], [5.6, 50.6, 'c'], [4.4, 50.4, 'c'], [18.3, 49.8, 'c'], [14.1, 50.15, 'c'], [18.2, 46.1, 'c'],
  [31.8, 41.45, 'c'], [-5.8, 43.3, 'c'], [8.5, 39.2, 'c'], [15.0, 46.1, 'c'], [23.0, 42.6, 'c'], [23.4, 45.4, 'c'], [5.9, 50.9, 'c'],
  [20.0, 52.0, 'c'], [27.0, 49.5, 'c'],
];
const depositOf = new Map();
for (const [lon, lat, t] of DEPOSITS) {
  let best = null, bd = 1e9;
  for (const cell of landCells) {
    if (depositOf.has(cell)) continue;
    const d = dist2(cell, [null, lon, lat]);
    if (d < bd) { bd = d; best = cell; }
  }
  if (best && bd < 1.2) depositOf.set(best, t);
}

// ---------- паромные связи между островами и материком ----------
const hexD = (A, B) => {
  const qa = A.c - ((A.r - (A.r & 1)) >> 1), qb = B.c - ((B.r - (B.r & 1)) >> 1);
  const dq = qa - qb, dr = A.r - B.r;
  return (Math.abs(dq) + Math.abs(dr) + Math.abs(dq + dr)) / 2;
};
// проливы: соседние клетки разных земель (остров и материк) не соприкасаются по суше, между ними только паром
const cutKey = (a, b) => (a.r * COLS + a.c < b.r * COLS + b.c ? a.r * COLS + a.c + '|' + (b.r * COLS + b.c) : b.r * COLS + b.c + '|' + (a.r * COLS + a.c));
const cutSet = new Set(), cutPairs = [];
for (const a of landCells) for (const b of nbrs(a)) {
  if (!b.land || a.g < 0 || b.g < 0 || a.g === b.g || a.r * COLS + a.c > b.r * COLS + b.c) continue;
  cutSet.add(cutKey(a, b)); cutPairs.push([a, b]);
}
console.log('проливы (разорваны по суше):', cutPairs.map(([a, b]) => `${a.name}|${b.name}`).join('; '));
const comp = new Map();
let nComp = 0;
for (const cell of landCells) {
  if (comp.has(cell)) continue;
  const id = nComp++, q = [cell]; comp.set(cell, id);
  for (let i = 0; i < q.length; i++) for (const n of nbrs(q[i])) if (n.land && !comp.has(n) && !cutSet.has(cutKey(q[i], n))) { comp.set(n, id); q.push(n); }
}
const links = [];
const parent = [...Array(nComp).keys()];
const find = (x) => (parent[x] === x ? x : (parent[x] = find(parent[x])));
for (;;) {
  let best = null;
  for (const a of landCells) for (const b of landCells) {
    if (find(comp.get(a)) === find(comp.get(b))) continue;
    const d = hexD(a, b) + (a.owner === b.owner ? 0 : 0.01) - (a.owner === 'Is' || b.owner === 'Is' ? 22 : 0);
    if (!best || d < best[0]) best = [d, a, b];
  }
  if (!best || best[0] > 6) break;
  links.push([best[1], best[2]]);
  parent[find(comp.get(best[1]))] = find(comp.get(best[2]));
}
const unlinked = new Set(landCells.map((c) => find(comp.get(c))));
console.log('связей паромами:', links.map(([a, b]) => `${a.name}↔${b.name}`).join('; '), '| групп суши:', unlinked.size);

// ---------- обрезка пустых краёв ----------
let rMin = 1e9, rMax = -1, cMin = 1e9, cMax = -1;
for (const c of landCells) { rMin = Math.min(rMin, c.r); rMax = Math.max(rMax, c.r); cMin = Math.min(cMin, c.c); cMax = Math.max(cMax, c.c); }
const r0 = Math.max(0, (rMin - 1) & ~1), r1 = Math.min(ROWS - 1, rMax + 1);
const c0 = Math.max(0, cMin - 1), c1 = Math.min(COLS - 1, cMax + 1);
const NC = c1 - c0 + 1, NR = r1 - r0 + 1;

// ---------- запись ----------
const rows = [];
for (let r = r0; r <= r1; r++) {
  let s2 = '';
  for (let c = c0; c <= c1; c++) {
    const cell = at(c, r);
    s2 += cell.land ? String.fromCharCode(48 + COUNTRIES.findIndex((q) => q[0] === cell.owner)) + cell.terr + Math.min(9, cell.w) : '...';
  }
  rows.push(s2);
}
const landIdx = new Map(landCells.map((c, i) => [c, i]));
// порядок земель в игре: ряд за рядом, слева направо (как идут клетки в строках)
const out = {
  cols: NC, rows: NR, hexSize: 18,
  countries: COUNTRIES.map((c) => ({ name: c[1], color: c[2], power: c[3], capital: [caps[c[0]].c - c0, caps[c[0]].r - r0] })),
  cells: rows, names: landCells.map((c) => c.name),
  deposits: landCells.map((c, i) => (depositOf.has(c) ? [i, depositOf.get(c)] : null)).filter(Boolean),
  links: links.map(([a, b]) => [landIdx.get(a), landIdx.get(b)]),
  // Скагеррак: Ютландия ↔ юг Норвегии — паромы открыты всегда (добавлено в europe_data.js вручную, см. README)
  cuts: cutPairs.map(([a, b]) => [landIdx.get(a), landIdx.get(b)]),
};
writeFileSync(new URL('../game/europe_data.js', import.meta.url),
  '// Создано tools/europe36.mjs — не править руками.\n// Клетка = 3 символа: страна (код 48+номер), рельеф (p/f/h/m), вес города 0-9; «...» — море.\n'
  + 'export const EUROPE_1936 = ' + JSON.stringify(out) + ';\n');

// ---------- картинка для проверки ----------
const PALETTE = Object.fromEntries(COUNTRIES.map((c) => [c[0], c[2]]));
const scale = 22 / W;
let svg = '';
const R = (W / Math.sqrt(3)) * scale;
for (const cell of cells) {
  const cx = cell.x * scale, cy = cell.y * scale;
  const pts = [0, 1, 2, 3, 4, 5].map((i) => { const a = (Math.PI / 180) * (60 * i - 30); return (cx + R * Math.cos(a)).toFixed(1) + ',' + (cy + R * Math.sin(a)).toFixed(1); }).join(' ');
  const fill = cell.land ? PALETTE[cell.owner] : '#13303f';
  const mark = cell.land ? { m: '▲', h: '∩', f: '♣', d: '·', p: '' }[cell.terr] : '';
  svg += `<polygon points="${pts}" fill="${fill}" stroke="#0006" stroke-width="0.6"/>`;
  if (mark) svg += `<text x="${cx}" y="${cy + 3}" font-size="9" text-anchor="middle" fill="#0008">${mark}</text>`;
}
for (const c of COUNTRIES) { const k = caps[c[0]]; svg += `<text x="${k.x * scale}" y="${k.y * scale + 4}" font-size="11" text-anchor="middle" fill="#fff" stroke="#000" stroke-width="2.5" paint-order="stroke" font-family="sans-serif">★${c[1]}</text>`; }
writeFileSync(new URL('./europe_preview.html', import.meta.url),
  `<meta charset="utf-8"><body style="margin:0;background:#13303f"><svg xmlns="http://www.w3.org/2000/svg" width="${Math.ceil(COLS * 22 + 30)}" height="${Math.ceil(ROWS * 19.1 + 30)}">${svg}</svg>`);
const cnt = {};
for (const c of landCells) cnt[c.owner] = (cnt[c.owner] || 0) + 1;
console.log(`сетка ${COLS}x${ROWS}, суши ${landCells.length}`);
console.log(COUNTRIES.map((c) => `${c[1]} ${cnt[c[0]] || 0}`).join(', '));
