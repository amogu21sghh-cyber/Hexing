// Сценарии «Европа 1939» и «Европа 1941»: node tools/make_starts.mjs
// Прогоняет историческую симуляцию ИИ с 1936 года, снимает состояние на 01.09.1939 и 22.06.1941,
// для 1941 правит расхождения с историей (оккупация Франции, Норвегия, Балканы, Шотландия),
// и пишет game/starts_data.js. Занимает около двух минут.
import { writeFileSync } from 'node:fs';
import { createGame, stepDay, eliminate, atWar, economyPreview, ensureCountry, addRel } from '../game/state.js';
import { applyStart } from '../game/starts.js';
import { aiTick } from '../game/ai.js';
import { BUILDINGS, TECHS } from '../game/data.js';
const BIDS = Object.keys(BUILDINGS);

const D0 = Date.UTC(1936, 0, 1);
const dayOf = (y, m, d) => Math.round((Date.UTC(y, m - 1, d) - D0) / 864e5);
const SEED = 5;
const g = createGame(SEED, { scenario: 'europe1936', difficulty: 2, historical: true });
const nm = (i) => g.countries[i].name;
const idOf = (n) => g.countries.find((c) => c.name === n).id;
const base = (n) => n.replace(/\s*\(.*\)$/, '');
const provs = () => [...g.world.provinces.values()].sort((a, b) => a.id - b.id);
const runTo = (day) => { while (g.day < day) { aiTick(g); stepDay(g); } };

// ---------- правки 1941 ----------
const set = (s) => new Set(s.split(/\s*,\s*/));
// Франция: оккупированная зона (Германия), итальянский уголок; остальное — Виши
const FR_GERMAN = set('Кале,Лилль,Амьен,Монс,Руан,Пикардия,Реймс,Арлон,Шербур,Кан,Париж,Верден,Мец,Нанси,Страсбург,Лотарингия,Эльзас,Мюлуз,Ренн,Нормандия,Шампань,Брест,Бретань,Орлеан,Тур,Дижон,Нант,Пуатье,Ла-Рошель,Бордо,Ландды,Гасконь,Пау,Памплона,Безансон,Бургундия');
const FR_ITALIAN = set('Ницца');
const YU = {
  Германия: set('Марибор,Загреб,Карловац,Хорватия,Славония,Осиек,Баня-Лука,Босния,Сараево,Белград,Вршац,Тимишоара,Шабац,Валево,Крагуевац,Турну-Северин,Сербия,Ниш'),
  Италия: set('Словения,Фиуме,Пола,Лика,Далмация,Сплит,Книн,Подгорица,Цетине,Мостар,Герцеговина,Дубровник,Приштина,Нови-Пазар,Санджак'),
  Венгрия: set('Суботица,Сомбор,Воеводина,Нови-Сад,Сегед'),
  Болгария: set('Скопье,Охрид,Македония,Битола,Кюстендил'),
};
const GR = {
  Германия: set('Салоники,Козани,Флорина,Македония,Ханья,Ираклион'),
  Болгария: set('Серре,Драма,Кавала,Александруполис'),
  Италия: set('Керкира,Янина,Эпир,Миссолонгион,Патры,Пиргос,Триполи,Пелопоннес,Каламата,Афины,Фивы,Эвбея,Лариса,Фессалия,Волос'),
};
const inTable = (T, b) => Object.keys(T).find((k) => T[k].has(b));

function fix1941() {
  const DE = idOf('Германия'), IT = idOf('Италия'), HU = idOf('Венгрия'), BG = idOf('Болгария');
  const FR = idOf('Франция'), GB = idOf('Великобритания');
  const changed = new Set();
  const give = (p, to) => { if (p.props.owner !== to) { p.props.owner = to; changed.add(p.id); } };
  for (const p of provs()) {
    const core = nm(p.props.core), own = p.props.owner, b = base(p.name);
    switch (core) {
      case 'Германия': give(p, DE); break;
      case 'Австрия': case 'Чехословакия': give(p, own === HU ? HU : DE); break;
      case 'Дания': case 'Норвегия': case 'Бельгия': case 'Нидерланды': case 'Люксембург': give(p, DE); break;
      case 'Великобритания': give(p, GB); break;
      case 'Италия': case 'Албания': give(p, IT); break;
      case 'Франция': {
        if (FR_GERMAN.has(b)) give(p, DE);
        else if (FR_ITALIAN.has(b)) give(p, IT);
        else give(p, FR);
        break;
      }
      case 'Югославия': { const k = inTable(YU, b); give(p, k ? idOf(k) : DE); break; }
      case 'Греция': { const k = inTable(GR, b); give(p, k ? idOf(k) : IT); break; }
      default: break;
    }
  }
  // Вишистская Франция: столица — Лион, режим авторитарный, вышла из Антанты
  const fr = g.countries[FR];
  const lyon = provs().find((p) => p.props.owner === FR && base(p.name) === 'Лион');
  for (const p of provs()) if (p.props.capital && p.props.owner === DE && p.props.core === FR) p.props.capital = false;
  lyon.props.capital = true; fr.capital = lyon.id;
  fr.ideo = 'aut';
  for (const f of g.factions) if (f.members.includes(FR)) { f.members = f.members.filter((m) => m !== FR); if (f.leader === FR) f.leader = f.members[0]; }
  fr.faction = null;
  g.factions = g.factions.filter((f) => f.members.length > 1);
  // павшие страны
  for (const n of ['Норвегия', 'Люксембург', 'Югославия', 'Греция']) if (g.countries[idOf(n)].alive) eliminate(g, idOf(n), DE);
  // перемирия: Франция выбыла из войн, остаются Германия и Италия против Британии
  for (const k of [...g.wars.keys()]) {
    const [a, b] = k.split('|').map(Number);
    if (a === FR || b === FR) g.wars.delete(k);
  }
  if (!atWar(g, DE, GB)) g.wars.set(DE < GB ? `${DE}|${GB}` : `${GB}|${DE}`, g.day);
  if (!atWar(g, IT, GB)) g.wars.set(IT < GB ? `${IT}|${GB}` : `${GB}|${IT}`, g.day);
  for (const k of Object.keys(g.warFor || {})) if (!g.wars.has(k)) delete g.warFor[k];
  for (const p of provs()) {
    if (p.props.owner === p.props.core) p.props.comp = 100;
    else if (changed.has(p.id)) p.props.comp = 55;
  }
  for (const p of provs()) { p.props.built = p.props.built || []; if (p.props.owner !== p.props.core && changed.has(p.id)) { p.props.project = null; } }
  return changed;
}

// Расстановка войск 1941: суммарная сила страны сохраняется, провинции взвешиваются (столица, границы, фронт против СССР)
const MOB41 = { 'Германия': 2.6, 'СССР': 2.4, 'Великобритания': 1.9, 'Италия': 1.9, 'Франция': 0.3, 'Румыния': 1.7, 'Венгрия': 1.7, 'Финляндия': 2.2, 'Болгария': 1.5, 'Турция': 1.4, 'Испания': 0.8 };
// totals39 — войска стран на 01.09.1939; в 1941 они выросли по таблице MOB41 (сырая симуляция даёт сотни тысяч: ИИ тратит накопленных людей)
function redeploy1941(totals39) {
  const total = g.countries.map((c) => Math.max(c.alive ? 3 : 0, Math.round((totals39[c.id] || 0) * (MOB41[c.name] ?? 1.3))));
  const USSR = idOf('СССР'), DE = idOf('Германия');
  const eastern = new Set(['Германия', 'Румыния', 'Венгрия', 'Финляндия', 'Болгария', 'Италия'].map(idOf));
  g.armies = []; g.nextArmyId = 1;
  for (const c of g.countries) {
    if (!c.alive || !total[c.id]) continue;
    const w = [];
    for (const p of provs()) {
      if (p.props.owner !== c.id) continue;
      let k = 0;
      const nb = p.neighbors.map((n) => g.world.provinces.get(n).props.owner);
      if (p.props.capital) k += 3;
      if (nb.some((o) => o !== c.id)) k += 1;
      if (eastern.has(c.id) && nb.includes(USSR)) k += (c.id === DE ? 8 : 5);
      if (c.id === USSR && nb.some((o) => eastern.has(o) && o !== idOf('Италия') && o !== idOf('Болгария'))) k += 6;
      if (k) w.push([p, k]);
    }
    if (!w.length) continue;
    const sum = w.reduce((s, [, k]) => s + k, 0);
    let left = total[c.id];
    for (const [p, k] of w) {
      const s = Math.max(1, Math.round(total[c.id] * k / sum));
      g.armies.push({ id: g.nextArmyId++, owner: c.id, at: p.id, strength: s, order: null, fighting: false, org: 100, dig: 0 });
      left -= s;
    }
  }
}

// ---------- снимок ----------
const cp = (o) => JSON.parse(JSON.stringify(o)); // глубокая копия: симуляция дальше меняет состояние
function snapshot(day, label, G = g) {
  const ps = [...G.world.provinces.values()].sort((a, b) => a.id - b.id);
  const ch = (n) => String.fromCharCode(48 + n);
  const extra = [];
  for (const p of ps) {
    const e = {};
    if (p.props.built && p.props.built.length) e.built = p.props.built.map((b) => String.fromCharCode(48 + BIDS.indexOf(b))).join('');
    if (p.props.project) e.project = p.props.project;
    if (p.props.air) e.air = p.props.air;
    if (p.props.treaty) e.treaty = p.props.treaty;
    if (Object.keys(e).length) extra.push([p.id, e]);
  }
  const countries = G.countries.map((c) => JSON.parse(JSON.stringify(c)));
  for (const c of countries) { delete c.plague; delete c.income; delete c.mod; delete c.mobBank; }
  return {
    label, day, bids: BIDS,
    owner: ps.map((p) => ch(p.props.owner)).join(''),
    core: ps.map((p) => ch(p.props.core)).join(''),
    comp: ps.map((p) => Math.round(p.props.comp ?? 100).toString(36).padStart(2, '0')).join(''),
    extra, countries,
    armies: G.armies.map((a) => ({ id: a.id, owner: a.owner, at: a.at, strength: a.strength, order: null, fighting: false, org: a.org ?? 100, dig: a.dig || 0 })),
    nextArmyId: G.nextArmyId,
    wars: [...G.wars], warFor: cp(G.warFor || {}),
    rel: cp(G.rel), factions: cp(G.factions), nextFactionId: G.nextFactionId,
    evFired: cp(G.evFired), claims: cp(G.claims || {}), guar: cp(G.guar || []), tension: G.tension,
    lend: cp(G.lend || []),
    pending: JSON.parse(JSON.stringify(G.pending.filter((x) => G.countries[x.cid] && G.countries[x.cid].alive))), nextPendingId: G.nextPendingId,
  };
}

const raw = {};
runTo(dayOf(1939, 9, 1));
raw['1939'] = snapshot(g.day, '1939');
const totals39 = g.countries.map(() => 0);
for (const a of g.armies) totals39[a.owner] += a.strength;
console.log('1939: day', g.day, 'armies', g.armies.length);
runTo(dayOf(1941, 6, 22));
const ch = fix1941();
console.log('1941: исправлено провинций', ch.size);
redeploy1941(totals39);
raw['1941'] = snapshot(g.day, '1941');
console.log('1941: day', g.day, 'armies', g.armies.length);

// ---------- нормализация: ИИ без игрока копит миллионы золота, изучает все технологии и застраивает всё до предела ----------

// ---------- Чехословакия: протекторат, Словакия, Венгрия, Польша ----------
const SK_NAMES = set('Тренчин,Словакия,Банска-Быстрица,Нитра,Прешов');
const HU_NAMES = set('Кошице,Ужгород,Закарпатье,Мукачево,Хуст,Рахов,Мишкольц');
function fixCzech(G, id) {
  const idIn = (n) => G.countries.find((c) => c.name === n).id;
  const DE = idIn('Германия'), HU = idIn('Венгрия'), PL = idIn('Польша'), CZ = idIn('Чехословакия');
  // новая страна: Словакия (клиентское государство Германии), создаётся копией Венгрии и чистится
  const hu = G.countries[HU], sk = JSON.parse(JSON.stringify(hu));
  Object.assign(sk, { id: G.countries.length, name: 'Словакия', base: 'Словакия', color: '#2f6fb5', alive: true, power: 0.35, ideo: 'fas', ideo0: 'fas', faction: null, overlord: DE,
    techs: [], focuses: [], focus: null, flags: {}, timed: [], lastEv: -999, slots: { eco: null, pol: null, mil: null, air: null, sci: null }, orgs: [], tax: 2, stability: 70 });
  delete sk.cands; delete sk.ministers; delete sk.doctrine; delete sk.income; delete sk.mod; delete sk.plague;
  G.countries.push(sk);
  const changed = new Set();
  for (const p of [...G.world.provinces.values()].sort((a, b) => a.id - b.id)) {
    if (p.props.core !== CZ) continue;
    const b = base(p.name);
    let to = DE;
    if (b === 'Острава') to = G.countries[PL].alive ? PL : DE; // Заользье: у Польши до её падения
    else if (HU_NAMES.has(b) || (p.props.owner === HU)) to = HU;
    else if (SK_NAMES.has(b)) to = sk.id;
    if (to === sk.id) p.props.core = sk.id;
    p.props.owner = to; p.props.comp = 100; changed.add(p.id);
  }
  const cap = [...G.world.provinces.values()].find((p) => p.props.owner === sk.id && p.name === 'Нитра');
  cap.props.capital = true; sk.capital = cap.id;
  // армии в переданных провинциях заменяем словацкими
  G.armies = G.armies.filter((a) => !changed.has(a.at) || G.world.provinces.get(a.at).props.owner === a.owner);
  const mine = [...G.world.provinces.values()].filter((p) => p.props.owner === sk.id);
  const w = mine.map((p) => [p, (p.props.capital ? 3 : 0) + (p.neighbors.some((n) => G.world.provinces.get(n).props.owner !== sk.id) ? 1 : 0)]).filter(([, k]) => k);
  const tot = id === '1939' ? 140 : 260, sum = w.reduce((a, [, k]) => a + k, 0);
  for (const [p, k] of w) G.armies.push({ id: G.nextArmyId++, owner: sk.id, at: p.id, strength: Math.max(1, Math.round(tot * k / sum)), order: null, fighting: false, org: 100, dig: 0 });
  // дипломатия: вассал Германии, в её блоке
  addRel(G, sk.id, DE, 40); addRel(G, sk.id, HU, -15); addRel(G, sk.id, PL, -10);
  const f = G.factions.find((x) => x.members.includes(DE));
  if (f) { f.members.push(sk.id); sk.faction = f.id; }
  return sk;
}
// Отрезанные клочки: финские земли у СССР без связи с его территорией (симуляция брала их россыпью) возвращаются Финляндии;
// провинции мёртвых стран переходят Германии
function fixEnclaves(G) {
  const idIn = (n) => G.countries.find((c) => c.name === n).id;
  const SU = idIn('СССР'), FI = idIn('Финляндия'), DE = idIn('Германия');
  const P = G.world.provinces;
  const seen = new Set(), q = [];
  for (const p of P.values()) if (p.props.owner === SU && p.props.core === SU) { seen.add(p.id); q.push(p.id); }
  while (q.length) for (const n of P.get(q.pop()).neighbors) if (!seen.has(n) && P.get(n).props.owner === SU) { seen.add(n); q.push(n); }
  let back = 0; const moved = new Set();
  for (const p of P.values()) if (p.props.owner === SU && p.props.core === FI && !seen.has(p.id)) { p.props.owner = FI; p.props.comp = 100; back++; moved.add(p.id); }
  for (const p of P.values()) if (!G.countries[p.props.owner].alive) { p.props.owner = DE; p.props.comp = 100; moved.add(p.id); }
  G.armies = G.armies.filter((a) => !moved.has(a.at) || P.get(a.at).props.owner === a.owner);
  return back;
}
const OCCUPIED_CORES = set('Норвегия,Дания,Бельгия,Нидерланды,Люксембург,Югославия,Греция,Франция');
const ANNEXED_FR = set('Мец,Страсбург,Лотарингия,Эльзас,Мюлуз,Нанси');
const NORM = {
  1939: { tier: 3, build: 3, doctrine: 1, stab: 80, pp: 100, days: { gold: 25, men: 20, res: 12, ind: 15, fuel: 25 } },
  1941: { tier: 4, build: 4, doctrine: 2, stab: 75, pp: 120, days: { gold: 25, men: 20, res: 12, ind: 15, fuel: 25 } },
};
function normalized(id) {
  const N = NORM[id];
  const g2 = createGame(SEED, { scenario: 'europe1936', difficulty: 1, historical: true });
  applyStart(g2, id, ensureCountry, raw[id]);
  fixCzech(g2, id);
  console.log(id, 'возвращено Финляндии:', fixEnclaves(g2));
  // оккупация (штриховка на карте) — только там, где земля действительно занята; присоединённое (Австрия, Чехия, Польша, Прибалтика, Эльзас и т. д.) — полностью своё
  for (const p of g2.world.provinces.values()) {
    const occupied = id === '1941' && p.props.owner !== p.props.core && OCCUPIED_CORES.has(g2.countries[p.props.core].name) && !(g2.countries[p.props.core].name === 'Франция' && ANNEXED_FR.has(base(p.name)));
    p.props.comp = occupied ? Math.min(p.props.comp ?? 55, 60) : 100;
  }
  for (const p of g2.world.provinces.values()) { p.props.built = (p.props.built || []).slice(0, N.build); p.props.project = null; }
  for (const c of g2.countries) {
    // потолок ярусов зависит от мощи страны: великие державы впереди, малые позади; на верхнем ярусе — примерно половина технологий
    const k = c.power ?? 1, cap = Math.max(1, N.tier - (k >= 1.1 ? 0 : k >= 0.6 ? 1 : 2));
    const hash = (str) => { let h = 7; for (const ch of str + c.id) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return h % 100; };
    let t = (c.techs || []).filter((x) => TECHS[x] && (TECHS[x].tier < cap || (TECHS[x].tier === cap && hash(x) < 55)));
    for (let again = true; again;) { const n = t.length; t = t.filter((x) => (TECHS[x].req || []).every((r) => t.includes(r))); again = t.length !== n; }
    c.techs = t;
    c.slots = { eco: null, pol: null, mil: null, air: null, sci: null };
    if (c.doctrine) { c.doctrine.lvl = Math.min(c.doctrine.lvl || 0, N.doctrine); c.doctrine.step = null; }
    c.stability = Math.min(c.stability ?? 65, N.stab);
    c.broke = false; c.noFuel = false; c.lowFuel = false; c.mobBank = 0;
    c.focus = null;
    c.timed = [];
  }
  for (const c of g2.countries) ensureCountry(c, g2);
  economyPreview(g2);
  for (const c of g2.countries) {
    if (!c.alive) continue;
    const i = c.income, k = c.power ?? 1;
    c.gold = Math.round(Math.max(i.gold, 0) * N.days.gold + 150 * k);
    c.manpower = Math.round(i.men * N.days.men + 10 * k);
    c.research = Math.round(i.res * N.days.res);
    c.industry = Math.round(i.ind * N.days.ind);
    c.fuel = Math.round(i.fuel * N.days.fuel + 30 * k);
    c.pp = N.pp;
  }
  return snapshot(g2.day, id, g2);
}
const out = { 1939: normalized('1939'), 1941: normalized('1941') };

const own = {};
for (const p of provs()) { const n = nm(p.props.owner); own[n] = (own[n] || 0) + 1; }
console.log(Object.entries(own).sort((a, b) => b[1] - a[1]).map(([k, v]) => k + ':' + v).join(', '));

writeFileSync(new URL('../game/starts_data.js', import.meta.url),
  '// Создано tools/make_starts.mjs. Не править вручную.\nexport const STARTS = ' + JSON.stringify(out) + ';\n');
console.log('готово');
