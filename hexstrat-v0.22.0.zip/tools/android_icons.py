# Значки приложения для Android из app/resources/emblem.png (знак игры из главного меню).
# Запуск из корня проекта: python3 tools/android_icons.py  (нужен Pillow). Результат: app/android-res/
# В CI папка копируется поверх созданного Capacitor проекта: android/app/src/main/res/
import os
from PIL import Image, ImageDraw
BG = (15, 26, 36, 255)
src = Image.open('app/resources/emblem.png').convert('RGBA')
src = src.crop(src.getchannel('A').getbbox())
out = 'app/android-res'
DENS = {'mdpi': 1, 'hdpi': 1.5, 'xhdpi': 2, 'xxhdpi': 3, 'xxxhdpi': 4}

def place(canvas, frac):
    s = canvas.width * frac / max(src.size)
    im = src.resize((max(1, round(src.width * s)), max(1, round(src.height * s))), Image.LANCZOS)
    canvas.alpha_composite(im, ((canvas.width - im.width) // 2, (canvas.height - im.height) // 2))

for d, k in DENS.items():
    path = f'{out}/mipmap-{d}'
    os.makedirs(path, exist_ok=True)
    # старые значки (до Android 8): скруглённый квадрат и круг
    n = round(48 * k)
    sq = Image.new('RGBA', (n, n), (0, 0, 0, 0))
    ImageDraw.Draw(sq).rounded_rectangle((0, 0, n - 1, n - 1), radius=n * 0.22, fill=BG)
    place(sq, 0.78); sq.save(f'{path}/ic_launcher.png')
    rd = Image.new('RGBA', (n, n), (0, 0, 0, 0))
    ImageDraw.Draw(rd).ellipse((0, 0, n - 1, n - 1), fill=BG)
    place(rd, 0.66); rd.save(f'{path}/ic_launcher_round.png')
    # переднего плана адаптивного значка: 108 dp, безопасная зона примерно 66%
    m = round(108 * k)
    fg = Image.new('RGBA', (m, m), (0, 0, 0, 0))
    place(fg, 0.56); fg.save(f'{path}/ic_launcher_foreground.png')
os.makedirs(f'{out}/values', exist_ok=True)
open(f'{out}/values/ic_launcher_background.xml', 'w').write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0F1A24</color>\n</resources>\n')
print('значки готовы:', out)
