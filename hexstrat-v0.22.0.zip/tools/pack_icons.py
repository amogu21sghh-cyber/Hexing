# Упаковка иконок: папка PNG с прозрачностью -> game/icons.js (WebP в data-URI).
# Запуск: python3 tools/pack_icons.py <папка_с_png>   (нужен Pillow)
# Имена файлов = ключи в ICONS; префиксы r_, u_, t_ — мелкие (64 px), остальные 96 px.
import sys, os, base64, io, glob
from PIL import Image
src = sys.argv[1]
small = ('r_', 'u_', 't_', 'te_', 'f_', 'g_')
out = {}
for f in sorted(glob.glob(os.path.join(src, '*.png'))):
    name = os.path.splitext(os.path.basename(f))[0]
    im = Image.open(f).convert('RGBA')
    if name.startswith('ev_'):  # иллюстрации событий: прямоугольные, без прозрачности, до 360 px по ширине
        im = im.convert('RGB')
        im.thumbnail((360, 240), Image.LANCZOS)
        buf = io.BytesIO(); im.save(buf, 'WEBP', quality=78, method=6)
        out[name] = 'data:image/webp;base64,' + base64.b64encode(buf.getvalue()).decode()
        continue
    bb = im.getchannel('A').point(lambda v: 255 if v > 8 else 0).getbbox()
    im = im.crop(bb)
    size = 64 if name.startswith(small) else 96
    s = size / max(im.size)
    im = im.resize((max(1, round(im.width * s)), max(1, round(im.height * s))), Image.LANCZOS)
    canvas = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    canvas.paste(im, ((size - im.width) // 2, (size - im.height) // 2))
    buf = io.BytesIO()
    canvas.save(buf, 'WEBP', quality=82, method=6)
    out[name] = 'data:image/webp;base64,' + base64.b64encode(buf.getvalue()).decode()
here = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(here, '..', 'game', 'icons.js'), 'w') as fh:
    fh.write('// Сгенерировано tools/pack_icons.py. Не править вручную.\nexport const ICONS = {\n')
    for k, v in out.items():
        fh.write(f"  {k}: '{v}',\n")
    fh.write('};\n')
print(len(out), 'иконок,', sum(len(v) for v in out.values()) // 1024, 'КБ')
