// Сборка без внешних зависимостей: склеивает ES-модули из game/ и engine/ в один скрипт.
//   dist/index.html    — полноценная страница, открывается где угодно
//   dist/artifact.html — тот же код без <html>/<head>/<body>, для публикации в Claude
// Шрифты подтягиваются с Google Fonts, у них есть запасные системные.
import { readFileSync, writeFileSync, mkdirSync, readdirSync, existsSync } from 'node:fs';
import { dirname, join, normalize } from 'node:path';

// Встроенные моды: всё из mods/*.hexmod.json попадает в game/bundled_mods.js (список «Встроенные моды» в меню)
{
  const list = readdirSync('mods').filter((f) => f.endsWith('.hexmod.json')).sort().map((f) => JSON.parse(readFileSync('mods/' + f, 'utf8')));
  writeFileSync('game/bundled_mods.js', '// Файл создаёт build.mjs из mods/*.hexmod.json, вручную не правится.\nexport const BUNDLED_MODS = ' + JSON.stringify(list) + ';\n');
}

const modules = new Map();

function resolveId(from, spec) {
  return normalize(join(dirname(from), spec)).replace(/\\/g, '/');
}

function transform(id) {
  if (modules.has(id)) return;
  modules.set(id, ''); // защита от циклов
  let src = readFileSync(id, 'utf8');
  const names = [];
  const deps = [];

  src = src.replace(/^import\s+\{([^}]*)\}\s+from\s+'([^']+)';?/gm, (_, list, spec) => {
    const dep = resolveId(id, spec);
    deps.push(dep);
    return `const {${list.replace(/\bas\b/g, ':')}} = __req(${JSON.stringify(dep)});`;
  });
  src = src.replace(/^export\s+\*\s+from\s+'([^']+)';?/gm, (_, spec) => {
    const dep = resolveId(id, spec);
    deps.push(dep);
    return `Object.assign(exports, __req(${JSON.stringify(dep)}));`;
  });
  src = src.replace(/^export\s+\{([^}]*)\}\s+from\s+'([^']+)';?/gm, (_, list, spec) => {
    const dep = resolveId(id, spec);
    deps.push(dep);
    const items = list.split(',').map((s) => s.trim()).filter(Boolean);
    return `{ const __m = __req(${JSON.stringify(dep)}); ${items.map((n) => `exports.${n} = __m.${n};`).join(' ')} }`;
  });
  src = src.replace(/^export\s+(async\s+function|function|class|const|let|var)\s+(\w+)/gm, (_, kw, name) => {
    names.push(name);
    return `${kw} ${name}`;
  });
  if (/^export\s/m.test(src)) throw new Error('Неподдерживаемый export в ' + id);

  for (const d of deps) transform(d);
  modules.set(id, `${JSON.stringify(id)}: function (exports, __req) {\n${src}\n${names.map((n) => `exports.${n} = ${n};`).join('\n')}\n}`);
}

const entry = 'game/main.js';
transform(entry);
// порядок не важен: модули вызываются лениво через __req
const js = `(function () {
const __defs = {
${[...modules.values()].join(',\n')}
};
const __cache = {};
function __req(id) {
  if (__cache[id]) return __cache[id].exports;
  const m = (__cache[id] = { exports: {} });
  __defs[id](m.exports, __req);
  return m.exports;
}
__req(${JSON.stringify(entry)});
})();`.replace(/<\/script/gi, '<\\/script');

const css = readFileSync('ui.css', 'utf8');
const body = readFileSync('body.html', 'utf8');
// Шрифты: если рядом лежит node_modules с @fontsource (его ставит сборка для магазина), вшиваем их в файл (woff2 в base64),
// и игра не обращается к интернету. Иначе — запасной вариант: Google Fonts (для локальной сборки и браузера).
// Свою сборку без интернета: npm install --no-save @fontsource/fira-sans @fontsource/forum && node build.mjs
function embeddedFonts() {
  const want = [['fira-sans', 'Fira Sans', [300, 400, 500]], ['forum', 'Forum', [400]]];
  const subsets = [['cyrillic', 'U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116'], ['latin', 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD']];
  let css = '', n = 0;
  for (const [pkg, family, weights] of want) for (const w of weights) for (const [sub, range] of subsets) {
    const f = `node_modules/@fontsource/${pkg}/files/${pkg}-${sub}-${w}-normal.woff2`;
    if (!existsSync(f)) { if (sub === 'cyrillic') return null; continue; }
    css += `@font-face{font-family:'${family}';font-style:normal;font-weight:${w};font-display:swap;src:url(data:font/woff2;base64,${readFileSync(f).toString('base64')}) format('woff2');unicode-range:${range}}\n`;
    n++;
  }
  return n ? css : null;
}
const fontCss = embeddedFonts();
const fonts = fontCss ? `<style>\n${fontCss}</style>`
  : '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
    + '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Fira+Sans:wght@300;400;500&family=Forum&display=swap">';
console.log(fontCss ? 'шрифты: вшиты (без интернета)' : 'шрифты: Google Fonts (нужен интернет)');
const title = 'Гексархия';

mkdirSync('dist', { recursive: true });
writeFileSync('dist/index.html',
  `<!doctype html>\n<html lang="ru"><head><meta charset="utf-8">`
  + `<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">`
  + `<meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="theme-color" content="#0f1a24">`
  + `<title>${title}</title>${fonts}<style>\nbody{margin:0}\n${css}</style></head><body>\n${body}<script>\n${js}\n</script></body></html>\n`);
writeFileSync('dist/artifact.html',
  `<title>${title}</title>\n<meta name="claude:viewport-fit-sides" content="cover">\n${fonts}\n<style>\n${css}</style>\n${body}<script>\n${js}\n</script>\n`);
console.log('собрано:', modules.size, 'модулей,', Math.round(js.length / 1024), 'КБ скрипта');
