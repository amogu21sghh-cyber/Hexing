// Ввод для карты: тап, перетаскивание, щипок двумя пальцами, колесо мыши.
export class MapInput {
  constructor(canvas, renderer, { onTap, onDouble } = {}) {
    this.canvas = canvas;
    this.r = renderer;
    this.onTap = onTap;
    this.onDouble = onDouble;
    this.lastTap = null;
    this.pointers = new Map();
    this.moved = false;
    this.downAt = 0;
    this.pinch = null;
    canvas.style.touchAction = 'none';
    canvas.addEventListener('pointerdown', (e) => this.down(e));
    canvas.addEventListener('pointermove', (e) => this.move(e));
    canvas.addEventListener('pointerup', (e) => this.up(e));
    canvas.addEventListener('pointercancel', (e) => this.cancel(e));
    canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      const p = this.local(e);
      this.r.zoomAt(p.x, p.y, Math.exp(-e.deltaY * 0.0015));
    }, { passive: false });
  }

  local(e) {
    const b = this.canvas.getBoundingClientRect();
    return { x: e.clientX - b.left, y: e.clientY - b.top };
  }

  down(e) {
    if (e.pointerType === 'mouse' && e.button !== 0) return; // правая кнопка не двигает карту
    try { this.canvas.setPointerCapture(e.pointerId); } catch (_) { /* не критично */ }
    const p = this.local(e);
    this.pointers.set(e.pointerId, { x: p.x, y: p.y, sx: p.x, sy: p.y });
    if (this.pointers.size === 1) { this.moved = false; this.downAt = performance.now(); }
    if (this.pointers.size === 2) { this.moved = true; this.pinch = this.pinchState(); }
  }

  pinchState() {
    const [a, b] = [...this.pointers.values()];
    return { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, mx: (a.x + b.x) / 2, my: (a.y + b.y) / 2 };
  }

  move(e) {
    const ptr = this.pointers.get(e.pointerId);
    if (!ptr) return;
    const p = this.local(e);
    const dx = p.x - ptr.x, dy = p.y - ptr.y;
    ptr.x = p.x; ptr.y = p.y;
    if (this.pointers.size === 1) {
      if (!this.moved && Math.hypot(p.x - ptr.sx, p.y - ptr.sy) > 8) this.moved = true;
      if (this.moved) this.r.panBy(dx, dy);
    } else if (this.pointers.size === 2 && this.pinch) {
      const s = this.pinchState();
      this.r.panBy(s.mx - this.pinch.mx, s.my - this.pinch.my);
      this.r.zoomAt(s.mx, s.my, s.d / this.pinch.d);
      this.pinch = s;
    }
  }

  up(e) {
    const ptr = this.pointers.get(e.pointerId);
    this.pointers.delete(e.pointerId);
    this.pinch = null;
    if (this.pointers.size === 1) this.moved = true;
    if (ptr && this.pointers.size === 0 && !this.moved && performance.now() - this.downAt < 700) {
      const now = performance.now(), lt = this.lastTap;
      // двойной тап/клик: второе касание рядом с первым в течение 380 мс
      if (lt && now - lt.t < 380 && Math.hypot(ptr.x - lt.x, ptr.y - lt.y) < 16 && this.onDouble) {
        this.lastTap = null;
        if (this.onDouble(ptr.x, ptr.y) === true) return;
      } else this.lastTap = { t: now, x: ptr.x, y: ptr.y };
      if (this.onTap) this.onTap(ptr.x, ptr.y);
    }
  }

  cancel(e) {
    this.pointers.delete(e.pointerId);
    this.pinch = null;
  }
}
