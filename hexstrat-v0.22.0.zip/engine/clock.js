// Игровые часы: фиксированный тик (1 тик = 1 игровой день), скорости и пауза.
// Симуляция идёт только из onTick, рендер от неё не зависит.
const MONTHS = ['янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];

export class Clock {
  // speeds: секунд реального времени на один тик для каждой скорости; 0 = пауза
  constructor({ speeds = [0, 1.0, 0.5, 0.25, 0.1, 0.04], start = [1936, 0, 1], maxTicksPerFrame = 6 } = {}) {
    this.speeds = speeds;
    this.speed = 0;
    this.dayIndex = 0;
    this.acc = 0;
    this.maxTicksPerFrame = maxTicksPerFrame;
    this.startMs = Date.UTC(start[0], start[1], start[2]);
    this.onTick = null;
    this.onChange = null;
  }

  setSpeed(i) {
    this.speed = Math.max(0, Math.min(this.speeds.length - 1, i));
    this.acc = 0;
    if (this.onChange) this.onChange();
  }

  get paused() { return this.speed === 0; }

  togglePause() { this.setSpeed(this.paused ? (this.lastSpeed || 1) : (this.lastSpeed = this.speed, 0)); }

  update(dtSeconds) {
    if (this.speed === 0) return;
    this.acc += dtSeconds;
    const step = this.speeds[this.speed];
    let n = 0;
    const t0 = typeof performance !== 'undefined' ? performance.now() : 0;
    // бюджет времени на кадр: если симуляция тяжёлая, время замедляется, но экран не замирает
    while (this.acc >= step && n < this.maxTicksPerFrame && (n === 0 || !t0 || performance.now() - t0 < 10)) {
      this.acc -= step;
      this.dayIndex++;
      n++;
      if (this.onTick) this.onTick(this.dayIndex);
      if (this.speed === 0) break;
    }
    if (this.acc >= step) this.acc = 0;
  }

  formatDate(dayIndex = this.dayIndex) {
    const d = new Date(this.startMs + dayIndex * 86400000);
    return `${d.getUTCDate()} ${MONTHS[d.getUTCMonth()]} ${d.getUTCFullYear()}`;
  }
}
