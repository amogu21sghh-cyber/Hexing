// Векторный контур областей: из сетки гексов строит гладкие границы и заливки.
// regionOf(hex) -> номер области (>= 0 — страна/группа, -2 — ничья суша, -1 — вода).
// Возвращает: fills (область -> Path2D в мировых координатах) и chains (участки границы между двумя областями).
// Участок границы сглаживается один раз и используется обеими соседними областями, поэтому швов нет.
import { hexToPixel, hexCorner, DIRS } from './hex.js';

const key = (x, y) => Math.round(x * 8) + ',' + Math.round(y * 8);

function laplace(pts, closed, passes) {
  let cur = pts;
  for (let p = 0; p < passes; p++) {
    const n = cur.length, out = new Array(n);
    for (let i = 0; i < n; i++) {
      if (!closed && (i === 0 || i === n - 1)) { out[i] = cur[i]; continue; }
      const a = cur[(i + n - 1) % n], b = cur[i], c = cur[(i + 1) % n];
      out[i] = [a[0] * 0.25 + b[0] * 0.5 + c[0] * 0.25, a[1] * 0.25 + b[1] * 0.5 + c[1] * 0.25];
    }
    cur = out;
  }
  return cur;
}

function chaikin(pts, closed, iters) {
  let cur = pts;
  for (let it = 0; it < iters; it++) {
    const n = cur.length, out = [];
    if (!closed) out.push(cur[0]);
    const last = closed ? n : n - 1;
    for (let i = 0; i < last; i++) {
      const a = cur[i], b = cur[(i + 1) % n];
      out.push([a[0] * 0.75 + b[0] * 0.25, a[1] * 0.75 + b[1] * 0.25], [a[0] * 0.25 + b[0] * 0.75, a[1] * 0.25 + b[1] * 0.75]);
    }
    if (!closed) out.push(cur[n - 1]);
    cur = out;
  }
  return cur;
}

export function buildOutline(world, size, regionOf) {
  const corners = [0, 1, 2, 3, 4, 5].map((k) => hexCorner(0, 0, size, k));
  const edges = [];                       // {p, q, a, b, x1, y1, x2, y2}
  for (const hex of world.hexes.values()) {
    const a = regionOf(hex);
    if (a === -1) continue;
    const c = hexToPixel(hex.q, hex.r, size);
    for (let k = 0; k < 6; k++) {
      const n = world.getHex(hex.q + DIRS[k][0], hex.r + DIRS[k][1]);
      const b = n ? regionOf(n) : -1;
      if (a === b) continue;
      if (b !== -1 && a > b) continue;    // каждое ребро между двумя землями записывает сторона с меньшим номером
      const c1 = corners[k], c2 = corners[(k + 1) % 6];
      const x1 = c.x + c1[0], y1 = c.y + c1[1], x2 = c.x + c2[0], y2 = c.y + c2[1];
      edges.push({ p: key(x1, y1), q: key(x2, y2), a, b, x1, y1, x2, y2, used: false });
    }
  }
  // степень вершин: вершина с тремя границами — узел, там участки заканчиваются
  const inc = new Map();
  for (const e of edges) {
    (inc.get(e.p) || inc.set(e.p, []).get(e.p)).push(e);
    (inc.get(e.q) || inc.set(e.q, []).get(e.q)).push(e);
  }
  const startsAt = new Map();             // вершина -> рёбра, начинающиеся в ней
  for (const e of edges) (startsAt.get(e.p) || startsAt.set(e.p, []).get(e.p)).push(e);
  const isNode = (v) => inc.get(v).length !== 2;
  const nextOf = (e) => {
    if (isNode(e.q)) return null;
    for (const f of startsAt.get(e.q) || []) if (!f.used && f.a === e.a && f.b === e.b) return f;
    return null;
  };

  const chains = [];
  const walk = (first) => {
    const pts = [[first.x1, first.y1]], keys = [first.p];
    let e = first;
    for (;;) {
      e.used = true;
      pts.push([e.x2, e.y2]); keys.push(e.q);
      const nx = nextOf(e);
      if (!nx || nx === first) break;
      e = nx;
    }
    return { a: first.a, b: first.b, pts, keys };
  };
  for (const e of edges) if (!e.used && isNode(e.p)) chains.push(walk(e));
  for (const e of edges) if (!e.used) chains.push(walk(e));  // замкнутые контуры без узлов

  for (const ch of chains) {
    const closed = ch.keys[0] === ch.keys[ch.keys.length - 1];
    let pts = ch.pts;
    if (closed) pts = pts.slice(0, -1);
    pts = laplace(pts, closed, 2);
    pts = chaikin(pts, closed, 2);
    if (closed) pts.push(pts[0]);
    ch.pts = pts;
    ch.closed = closed;
    ch.start = ch.keys[0];
    ch.end = ch.keys[ch.keys.length - 1];
  }

  // заливки: для каждой области сшиваем её участки в петли (область всегда справа по ходу)
  const segsBy = new Map();
  const add = (r, seg) => (segsBy.get(r) || segsBy.set(r, []).get(r)).push(seg);
  for (const ch of chains) {
    add(ch.a, { ch, rev: false, from: ch.start });
    if (ch.b !== -1) add(ch.b, { ch, rev: true, from: ch.end });
  }
  const fills = new Map();
  for (const [r, segs] of segsBy) {
    const byFrom = new Map();
    for (const s of segs) (byFrom.get(s.from) || byFrom.set(s.from, []).get(s.from)).push(s);
    const path = new Path2D();
    for (const s0 of segs) {
      if (s0.done) continue;
      let s = s0, first = true;
      for (let guard = 0; s && !s.done && guard < 100000; guard++) {
        s.done = true;
        const pts = s.rev ? [...s.ch.pts].reverse() : s.ch.pts;
        for (let i = first ? 0 : 1; i < pts.length; i++) {
          if (first && i === 0) path.moveTo(pts[0][0], pts[0][1]); else path.lineTo(pts[i][0], pts[i][1]);
        }
        first = false;
        const endKey = s.rev ? s.ch.start : s.ch.end;
        s = (byFrom.get(endKey) || []).find((t) => !t.done) || null;
      }
      path.closePath();
    }
    fills.set(r, path);
  }
  return { fills, chains };
}
