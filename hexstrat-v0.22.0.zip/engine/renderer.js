// Рендер гексовой карты на Canvas 2D: камера, заливка гексов, границы провинций, оверлей игры.
// Движок ничего не знает про игру: цвета, границы и оверлей приходят через hooks.
import { hexToPixel, pixelToHex, hexCorner, DIRS } from './hex.js';

export class HexRenderer {
  // hooks: { background, hexFill(hex, province) -> css, edgeStyle(hexA, hexB|null) -> {color,width}|null,
  //          drawOverlay(ctx, renderer, timeMs), animating() -> boolean }
  constructor(canvas, world, hooks = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');           // фон карты
    // оверлей (войска, стрелки, выделение) — второй холст поверх: фон не копируется каждый кадр
    this.ocanvas = document.createElement('canvas');
    this.ocanvas.style.cssText = 'position:absolute;left:0;top:0;display:block;pointer-events:none';
    canvas.insertAdjacentElement('afterend', this.ocanvas);
    this.octx = this.ocanvas.getContext('2d');
    this.world = world;
    this.hooks = hooks;
    this.size = world.hexSize;
    this.corners = [0, 1, 2, 3, 4, 5].map((k) => hexCorner(0, 0, this.size, k));
    this.cam = { x: 0, y: 0, zoom: 1 };
    this.minZoom = 0.3;
    this.maxZoom = 2.6;
    this.w = 1; this.h = 1; this.dpr = 1;
    this.dirty = true;
    this.visible = [];
    this.setWorld(world);
    this._observe();
    const loop = (t) => {
      // анимация без других изменений идёт ~20 кадров в секунду: карта большая, телефон не должен греться
      if (this.dirty || (hooks.animating && hooks.animating() && t - (this._lastAnim || 0) >= 48)) {
        this.dirty = false;
        this._lastAnim = t;
        this.draw(t);
      }
      this._raf = requestAnimationFrame(loop);
    };
    this._raf = requestAnimationFrame(loop);
  }

  setWorld(world) {
    this.world = world;
    this._worldStamp = (this._worldStamp || 0) + 1;
    this.size = world.hexSize;
    this.corners = [0, 1, 2, 3, 4, 5].map((k) => hexCorner(0, 0, this.size, k));
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const h of world.hexes.values()) {
      const c = hexToPixel(h.q, h.r, this.size);
      x0 = Math.min(x0, c.x); y0 = Math.min(y0, c.y);
      x1 = Math.max(x1, c.x); y1 = Math.max(y1, c.y);
    }
    const pad = this.size * 1.5;
    this.bounds = { x0: x0 - pad, y0: y0 - pad, x1: x1 + pad, y1: y1 + pad };
    this.requestDraw();
  }

  _observe() {
    const apply = () => this.resize();
    if (typeof ResizeObserver !== 'undefined') {
      this._ro = new ResizeObserver(apply);
      this._ro.observe(this.canvas.parentElement || this.canvas);
    } else window.addEventListener('resize', apply);
    this.resize();
  }

  resize() {
    const box = (this.canvas.parentElement || this.canvas).getBoundingClientRect();
    this.dpr = Math.min(window.devicePixelRatio || 1, this.maxDpr || 1.5); // карта большая: лишние пиксели дороже резкости
    this.w = Math.max(1, Math.floor(box.width));
    this.h = Math.max(1, Math.floor(box.height));
    this.canvas.style.width = this.w + 'px';
    this.canvas.style.height = this.h + 'px';
    this.canvas.width = Math.floor(this.w * this.dpr);
    this.canvas.height = Math.floor(this.h * this.dpr);
    this.ocanvas.style.width = this.w + 'px';
    this.ocanvas.style.height = this.h + 'px';
    this.ocanvas.width = this.canvas.width;
    this.ocanvas.height = this.canvas.height;
    this._layerKey = null;
    this.requestDraw();
  }

  requestDraw() { this.dirty = true; }

  // --- камера ---
  worldToScreen(x, y) {
    return { x: (x - this.cam.x) * this.cam.zoom + this.w / 2, y: (y - this.cam.y) * this.cam.zoom + this.h / 2 };
  }
  screenToWorld(sx, sy) {
    return { x: (sx - this.w / 2) / this.cam.zoom + this.cam.x, y: (sy - this.h / 2) / this.cam.zoom + this.cam.y };
  }
  hexAtScreen(sx, sy) {
    const p = this.screenToWorld(sx, sy);
    const { q, r } = pixelToHex(p.x, p.y, this.size);
    return this.world.getHex(q, r) || null;
  }
  provinceScreenCenter(id) {
    const p = this.world.provinces.get(id);
    return this.worldToScreen(p.center.x, p.center.y);
  }

  clampCamera() {
    const b = this.bounds, c = this.cam;
    c.x = Math.max(b.x0, Math.min(b.x1, c.x));
    c.y = Math.max(b.y0, Math.min(b.y1, c.y));
  }
  panBy(dx, dy) {
    this.cam.x -= dx / this.cam.zoom;
    this.cam.y -= dy / this.cam.zoom;
    this.clampCamera();
    this.requestDraw();
  }
  zoomAt(sx, sy, factor) {
    const before = this.screenToWorld(sx, sy);
    this.cam.zoom = Math.max(this.minZoom, Math.min(this.maxZoom, this.cam.zoom * factor));
    const after = this.screenToWorld(sx, sy);
    this.cam.x += before.x - after.x;
    this.cam.y += before.y - after.y;
    this.clampCamera();
    this.requestDraw();
  }
  centerOnProvince(id, zoom) {
    const p = this.world.provinces.get(id);
    if (!p) return;
    this.cam.x = p.center.x;
    this.cam.y = p.center.y;
    if (zoom) this.cam.zoom = zoom;
    this.clampCamera();
    this.requestDraw();
  }
  // Вписать карту в экран. filter(hex) позволяет вписывать только нужные гексы (например, без моря).
  // insets {top,bottom,left,right} — часть экрана, закрытая панелями.
  fit(filter, insets = {}) {
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const h of this.world.hexes.values()) {
      if (filter && !filter(h)) continue;
      const c = hexToPixel(h.q, h.r, this.size);
      x0 = Math.min(x0, c.x); y0 = Math.min(y0, c.y);
      x1 = Math.max(x1, c.x); y1 = Math.max(y1, c.y);
    }
    if (!isFinite(x0)) { const b = this.bounds; x0 = b.x0; y0 = b.y0; x1 = b.x1; y1 = b.y1; }
    const pad = this.size * 1.6;
    const bw = x1 - x0 + pad * 2, bh = y1 - y0 + pad * 2;
    const { top = 0, bottom = 0, left = 0, right = 0 } = insets;
    const aw = Math.max(60, this.w - left - right), ah = Math.max(60, this.h - top - bottom);
    this.cam.zoom = Math.max(this.minZoom, Math.min(this.maxZoom, Math.min(aw / bw, ah / bh)));
    const dx = left + aw / 2 - this.w / 2, dy = top + ah / 2 - this.h / 2;
    this.cam.x = (x0 + x1) / 2 - dx / this.cam.zoom;
    this.cam.y = (y0 + y1) / 2 - dy / this.cam.zoom;
    this.requestDraw();
  }

  // --- вспомогательные рисовалки для оверлея (экранные координаты) ---
  strokeProvince(id, color, width, dash) {
    const p = this.world.provinces.get(id);
    if (!p) return;
    const ctx = this.octx, z = this.cam.zoom;
    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    if (dash) ctx.setLineDash(dash);
    ctx.beginPath();
    for (const h of p.hexes) {
      const c = hexToPixel(h.q, h.r, this.size);
      const s = this.worldToScreen(c.x, c.y);
      for (let k = 0; k < 6; k++) {
        const [dq, dr] = DIRS[k];
        const n = this.world.getHex(h.q + dq, h.r + dr);
        if (n && n.provinceId === id) continue;
        const a = this.corners[k], b = this.corners[(k + 1) % 6];
        ctx.moveTo(s.x + a[0] * z, s.y + a[1] * z);
        ctx.lineTo(s.x + b[0] * z, s.y + b[1] * z);
      }
    }
    ctx.stroke();
    ctx.restore();
  }

  // Фон карты (гексы и границы) рисуется в отдельный холст и перерисовывается только при смене вида или
  // состояния карты (hooks.layerSig). Поверх каждый кадр дорисовываются войска и стрелки.
  drawBase(ctx) {
    const { w, h, dpr, cam, size, corners, world, hooks } = this;
    const z = cam.zoom;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = hooks.background || '#000';
    ctx.fillRect(0, 0, w, h);

    const tl = this.screenToWorld(0, 0), br = this.screenToWorld(w, h);
    const pad = size * 1.2;
    const visible = [];
    ctx.save();
    ctx.translate(w / 2 - cam.x * z, h / 2 - cam.y * z);
    ctx.scale(z, z);
    ctx.lineJoin = 'round';

    // издали игра может нарисовать карту гладкими векторными контурами вместо гексов
    if (hooks.drawFlat && hooks.drawFlat(ctx, this, z)) {
      if (hooks.drawOccupation) hooks.drawOccupation(ctx, this, z, true);
      ctx.restore();
      this.visible = [];
      return;
    }

    // гексы одного цвета собираются в один контур: десятки вызовов вместо тысяч
    const batches = new Map();
    for (const hex of world.hexes.values()) {
      const c = hexToPixel(hex.q, hex.r, size);
      if (c.x < tl.x - pad || c.x > br.x + pad || c.y < tl.y - pad || c.y > br.y + pad) continue;
      visible.push({ hex, x: c.x, y: c.y });
      const prov = hex.provinceId != null ? world.provinces.get(hex.provinceId) : null;
      if (z < 0.7 && !prov) continue; // издали узор моря не виден: заливка фоном дешевле
      const fill = hooks.hexFill ? hooks.hexFill(hex, prov, z) : '#444';
      let path = batches.get(fill);
      if (!path) { path = new Path2D(); batches.set(fill, path); }
      path.moveTo(c.x + corners[0][0] * 1.04, c.y + corners[0][1] * 1.04);
      for (let k = 1; k < 6; k++) path.lineTo(c.x + corners[k][0] * 1.04, c.y + corners[k][1] * 1.04);
      path.closePath();
    }
    ctx.lineWidth = 1 / z;
    for (const [fill, path] of batches) {
      ctx.fillStyle = fill;
      ctx.strokeStyle = fill;
      ctx.fill(path);
    }

    if (hooks.drawOccupation) hooks.drawOccupation(ctx, this, z, false);

    if (hooks.edgeStyle) {
      const buckets = new Map();
      for (const v of visible) {
        const { hex } = v;
        for (let k = 0; k < 6; k++) {
          const [dq, dr] = DIRS[k];
          const n = world.getHex(hex.q + dq, hex.r + dr);
          if (n && k >= 3) continue;
          const st = hooks.edgeStyle(hex, n || null, z);
          if (!st) continue;
          const key = st.width + '|' + st.color;
          let b = buckets.get(key);
          if (!b) { b = { st, segs: [] }; buckets.set(key, b); }
          const a = corners[k], c2 = corners[(k + 1) % 6];
          b.segs.push(v.x + a[0], v.y + a[1], v.x + c2[0], v.y + c2[1]);
        }
      }
      ctx.lineCap = 'round';
      for (const b of [...buckets.values()].sort((p, q) => p.st.width - q.st.width)) {
        ctx.strokeStyle = b.st.color;
        ctx.lineWidth = b.st.width / z;
        ctx.beginPath();
        const s = b.segs;
        for (let i = 0; i < s.length; i += 4) { ctx.moveTo(s[i], s[i + 1]); ctx.lineTo(s[i + 2], s[i + 3]); }
        ctx.stroke();
      }
    }
    ctx.restore();
    this.visible = visible;
  }

  draw(t = 0) {
    const { octx, w, h, dpr, cam, hooks } = this;
    // fastSig — то, что должно отразиться сразу (выделение, режим); slowSig — частые изменения мира
    // (смена владельцев), они перерисовываются не чаще раза в 250 мс
    const fast = `${hooks.layerSig ? hooks.layerSig() : Math.random()}|${cam.x}|${cam.y}|${cam.zoom}|${w}|${h}|${dpr}|${this._worldStamp || 0}`;
    const slow = hooks.layerSlowSig ? hooks.layerSlowSig() : '';
    let redraw = this._layerKey !== fast;
    if (!redraw && this._slowKey !== slow) {
      if (t - (this._lastBase || 0) >= (this.cam.zoom < 0.8 ? 900 : 250)) redraw = true;
      else this.dirty = true;
    }
    if (redraw) { this.drawBase(this.ctx); this._layerKey = fast; this._slowKey = slow; this._lastBase = t; }
    octx.setTransform(1, 0, 0, 1, 0, 0);
    octx.clearRect(0, 0, this.ocanvas.width, this.ocanvas.height);
    octx.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (hooks.drawOverlay) hooks.drawOverlay(octx, this, t);
  }
}
