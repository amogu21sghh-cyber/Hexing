// Гексовая математика. Гексы «острым углом вверх» (pointy-top), осевые координаты (q, r).
export const SQRT3 = Math.sqrt(3);

// Порядок направлений совпадает с порядком рёбер шестиугольника:
// ребро k лежит между углами k и k+1 и смотрит на соседа DIRS[k].
// ЮВ, ЮЗ, З, СЗ, СВ, В
export const DIRS = [[0, 1], [-1, 1], [-1, 0], [0, -1], [1, -1], [1, 0]];

export const hexKey = (q, r) => (q + 2048) * 4096 + (r + 2048);

export function hexToPixel(q, r, size) {
  return { x: size * SQRT3 * (q + r / 2), y: size * 1.5 * r };
}

export function pixelToHex(x, y, size) {
  const fq = (SQRT3 / 3 * x - y / 3) / size;
  const fr = (2 / 3 * y) / size;
  return cubeRound(fq, fr);
}

function cubeRound(fq, fr) {
  const fs = -fq - fr;
  let q = Math.round(fq), r = Math.round(fr);
  const s = Math.round(fs);
  const dq = Math.abs(q - fq), dr = Math.abs(r - fr), ds = Math.abs(s - fs);
  if (dq > dr && dq > ds) q = -r - s;
  else if (dr > ds) r = -q - s;
  return { q, r };
}

export function hexDistance(aq, ar, bq, br) {
  const dq = aq - bq, dr = ar - br;
  return (Math.abs(dq) + Math.abs(dr) + Math.abs(dq + dr)) / 2;
}

// Угол k шестиугольника с центром (cx, cy). Углы идут по часовой стрелке от 30° (экранные координаты).
export function hexCorner(cx, cy, size, k) {
  const a = (60 * k + 30) * Math.PI / 180;
  return [cx + size * Math.cos(a), cy + size * Math.sin(a)];
}

// Из «смещённых» координат (колонка, ряд) прямоугольной карты в осевые.
export function offsetToAxial(col, row) {
  return { q: col - ((row - (row & 1)) >> 1), r: row };
}
