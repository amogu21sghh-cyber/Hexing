// Мир: гексы и провинции хранятся раздельно.
// Гекс знает координаты, ландшафт и provinceId. Провинция знает свои гексы, соседей и свойства (props).
// Пока провинция = один гекс, но группировка (mergeProvinces) уже работает.
import { DIRS, hexKey, hexToPixel, hexDistance } from './hex.js';

export class MinHeap {
  constructor() { this.a = []; }
  get size() { return this.a.length; }
  push(p, v) {
    const a = this.a;
    a.push([p, v]);
    let i = a.length - 1;
    while (i > 0) {
      const j = (i - 1) >> 1;
      if (a[j][0] <= a[i][0]) break;
      [a[i], a[j]] = [a[j], a[i]];
      i = j;
    }
  }
  pop() {
    const a = this.a;
    const top = a[0];
    const last = a.pop();
    if (a.length) {
      a[0] = last;
      let i = 0;
      for (;;) {
        const l = 2 * i + 1, r = l + 1;
        let m = i;
        if (l < a.length && a[l][0] < a[m][0]) m = l;
        if (r < a.length && a[r][0] < a[m][0]) m = r;
        if (m === i) break;
        [a[i], a[m]] = [a[m], a[i]];
        i = m;
      }
    }
    return top;
  }
}

export class World {
  constructor(hexSize = 26) {
    this.hexSize = hexSize;
    this.hexes = new Map();
    this.provinces = new Map();
    this.links = []; // морские переправы: пары id провинций, которые считаются соседями
    this.ferryMax = Infinity; // самая широкая переправа (в клетках моря), доступная армиям
    this.ferries = []; // [a, b, ширина, открыта]
    this.cuts = [];  // проливы: пары соседних по гексам провинций, между которыми нет сухопутного прохода
  }

  addHex(q, r, terrain, provinceId = null) {
    const h = { q, r, terrain, provinceId };
    this.hexes.set(hexKey(q, r), h);
    return h;
  }

  getHex(q, r) { return this.hexes.get(hexKey(q, r)); }

  hexNeighbors(h) {
    const out = [];
    for (const [dq, dr] of DIRS) {
      const n = this.getHex(h.q + dq, h.r + dr);
      if (n) out.push(n);
    }
    return out;
  }

  addProvince(id, name, props = {}) {
    const p = { id, name, hexes: [], neighbors: [], center: { x: 0, y: 0 }, props };
    this.provinces.set(id, p);
    return p;
  }

  // Пересчитать списки гексов, соседей и центры. Вызывать после любых изменений provinceId.
  rebuild() {
    for (const p of this.provinces.values()) { p.hexes = []; p._nb = new Set(); }
    for (const h of this.hexes.values()) {
      if (h.provinceId == null) continue;
      const p = this.provinces.get(h.provinceId);
      if (p) p.hexes.push(h);
      else h.provinceId = null;
    }
    for (const [id, p] of [...this.provinces]) if (!p.hexes.length) this.provinces.delete(id);
    const cut = new Set(this.cuts.map(([a, b]) => (a < b ? a + '|' + b : b + '|' + a)));
    for (const h of this.hexes.values()) {
      if (h.provinceId == null) continue;
      const p = this.provinces.get(h.provinceId);
      for (const n of this.hexNeighbors(h)) {
        if (n.provinceId != null && n.provinceId !== h.provinceId && !(cut.size && cut.has(h.provinceId < n.provinceId ? h.provinceId + '|' + n.provinceId : n.provinceId + '|' + h.provinceId))) p._nb.add(n.provinceId);
      }
    }
    this.ferries = [];
    for (const [a, b, forced] of this.links) {
      const pa = this.provinces.get(a), pb = this.provinces.get(b);
      if (!pa || !pb) continue;
      if (pa._nb.has(b)) continue; // и так соседи по суше
      let gap = Infinity;
      for (const h of pa.hexes) for (const k of pb.hexes) gap = Math.min(gap, hexDistance(h.q, h.r, k.q, k.r) - 1);
      const open = forced ? true : gap <= this.ferryMax; // третий элемент связи — переправа открыта всегда (Скагеррак)
      this.ferries.push([a, b, gap, open]);
      if (open) { pa._nb.add(b); pb._nb.add(a); }
    }
    this._ferryGap = new Map(this.ferries.filter((f) => f[3]).map(([a, b, gap]) => [a < b ? a * 65536 + b : b * 65536 + a, gap]));
    this._parr = null; this._dist = null;
    for (const p of this.provinces.values()) {
      p.neighbors = [...p._nb];
      delete p._nb;
      let sx = 0, sy = 0;
      for (const h of p.hexes) {
        const c = hexToPixel(h.q, h.r, this.hexSize);
        sx += c.x; sy += c.y;
      }
      p.center = { x: sx / p.hexes.length, y: sy / p.hexes.length };
    }
  }

  // Объединить провинции в одну (для редактора карт). Свойства берутся у keepId.
  mergeProvinces(ids, keepId = ids[0]) {
    const set = new Set(ids);
    for (const h of this.hexes.values()) if (set.has(h.provinceId)) h.provinceId = keepId;
    this.rebuild();
  }

  // Ширина морской переправы между соседними провинциями (в клетках моря) или undefined, если это сухопутная граница.
  ferryGap(a, b) { return this._ferryGap.get(a < b ? a * 65536 + b : b * 65536 + a); }

  // Прибрежная провинция: рядом с её гексом есть море (клетка воды без провинции)
  isCoastal(id) {
    this._coast = this._coast || new Map();
    if (this._coast.has(id)) return this._coast.get(id);
    const p = this.provinces.get(id);
    let res = false;
    if (p) for (const h of p.hexes) { for (const n of this.hexNeighbors(h)) if (n.terrain === 'water' && n.provinceId == null) { res = true; break; } if (res) break; }
    this._coast.set(id, res);
    return res;
  }

  // Морской охват: какие провинции достижимы от прибрежной pid по воде не более чем range клеток моря.
  // Возвращает Map id → ширина (число клеток воды по кратчайшему маршруту); сухопутные соседи и обычные переправы не включаются.
  seaReach(pid, range) {
    this._sea = this._sea || new Map();
    const ck = pid + '|' + range;
    if (this._sea.has(ck)) return this._sea.get(ck);
    const p = this.provinces.get(pid);
    const out = new Map();
    if (!p || range < 1) { this._sea.set(ck, out); return out; }
    const hk = (h) => h.q + ',' + h.r;
    const depth = new Map();
    let frontier = [];
    for (const h of p.hexes) for (const n of this.hexNeighbors(h)) if (n.terrain === 'water' && n.provinceId == null && !depth.has(hk(n))) { depth.set(hk(n), 1); frontier.push(n); }
    for (let d = 1; frontier.length; d++) {
      for (const w of frontier) for (const m of this.hexNeighbors(w)) {
        if (m.provinceId != null && m.provinceId !== pid) { const prev = out.get(m.provinceId); if (prev === undefined || d < prev) out.set(m.provinceId, d); }
      }
      if (d >= range) break;
      const next = [];
      for (const w of frontier) for (const m of this.hexNeighbors(w)) if (m.terrain === 'water' && m.provinceId == null && !depth.has(hk(m))) { depth.set(hk(m), d + 1); next.push(m); }
      frontier = next;
    }
    this._sea.set(ck, out);
    return out;
  }

  // Поиск пути по графу провинций (Дейкстра).
  // goal: id провинции или функция (province) => boolean.
  // costFn(province, fromProvince) => стоимость входа или Infinity/null, если вход закрыт.
  // maxCost (необязательно) — дальше этой стоимости не ищем
  findPath(fromId, goal, costFn, maxCost = Infinity) {
    const isGoal = typeof goal === 'function' ? goal : (p) => p.id === goal;
    // провинции в массиве по id и переиспользуемые буферы: поиск вызывается тысячи раз в день
    let parr = this._parr;
    if (!parr) {
      let mx = 0;
      for (const id of this.provinces.keys()) if (id > mx) mx = id;
      parr = this._parr = new Array(mx + 1).fill(null);
      for (const [id, p] of this.provinces) parr[id] = p;
      this._dist = new Float64Array(mx + 1); this._seen = new Int32Array(mx + 1); this._prev = new Int32Array(mx + 1); this._stamp = 0;
    }
    const start = parr[fromId];
    if (!start) return null;
    if (isGoal(start)) return { path: [], cost: 0 };
    const dist = this._dist, seen = this._seen, prev = this._prev;
    const st = ++this._stamp;
    seen[fromId] = st; dist[fromId] = 0;
    const heap = new MinHeap();
    heap.push(0, fromId);
    while (heap.size) {
      const [d, id] = heap.pop();
      if (d > dist[id]) continue;
      if (d > maxCost) return null;
      const p = parr[id];
      if (id !== fromId && isGoal(p)) {
        const path = [];
        for (let c = id; c !== fromId; c = prev[c]) path.push(c);
        path.reverse();
        return { path, cost: d };
      }
      const nbs = p.neighbors;
      for (let i = 0; i < nbs.length; i++) {
        const nid = nbs[i];
        const c = costFn(parr[nid], p);
        if (c == null || c === Infinity || c !== c) continue;
        const nd = d + c;
        if (seen[nid] !== st || nd < dist[nid]) {
          seen[nid] = st; dist[nid] = nd; prev[nid] = id;
          heap.push(nd, nid);
        }
      }
    }
    return null;
  }

  toJSON() {
    return {
      hexSize: this.hexSize,
      links: this.links,
      cuts: this.cuts,
      ferryMax: isFinite(this.ferryMax) ? this.ferryMax : null,
      hexes: [...this.hexes.values()].map((h) => [h.q, h.r, h.terrain, h.provinceId]),
      provinces: [...this.provinces.values()].map((p) => ({ id: p.id, name: p.name, props: p.props })),
    };
  }

  static fromJSON(data) {
    const w = new World(data.hexSize);
    for (const [q, r, t, pid] of data.hexes) w.addHex(q, r, t, pid);
    for (const p of data.provinces) w.addProvince(p.id, p.name, p.props);
    w.links = data.links || [];
    w.cuts = data.cuts || [];
    w.ferryMax = data.ferryMax == null ? Infinity : data.ferryMax;
    w.rebuild();
    return w;
  }
}
