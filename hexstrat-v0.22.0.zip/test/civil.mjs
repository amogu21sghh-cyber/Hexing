// Быстрая проверка гражданской войны (те же тесты, что в конце sim.mjs): node test/civil.mjs
import assert from 'node:assert/strict';
import { createGame, stepDay, atWar, refreshStats } from '../game/state.js';
import { RULES } from '../game/data.js';
import { aiTick } from '../game/ai.js';
import { setIdeology, civilWarChance, byName } from '../game/events.js';
RULES.weather = false;
const ok = (name, f) => { f(); console.log('  ok ', name); };
const euro = (seed = 1) => { const g = createGame(seed, { scenario: 'europe1936' }); g.playerId = byName(g, 'Германия').id; return g; };
console.log('Гражданская война');
ok('гражданская война: вероятность по строю, стабильности и условиям', () => {
  RULES.civilWar = true;
  try {
    const g = euro(); const de = byName(g, 'Германия');
    refreshStats(g);
    de.stability = 50;
    const aut = civilWarChance(g, de, 'dem'), same = civilWarChance(g, de, de.ideo);
    assert.equal(same, 0);
    assert.ok(aut > 0.2 && aut <= 0.8, 'шанс ' + aut);
    de.stability = 90; const calm = civilWarChance(g, de, 'dem'); de.stability = 20; const shaky = civilWarChance(g, de, 'dem');
    assert.ok(calm < aut && shaky > aut, 'стабильность влияет');
    de.ideo = 'aut'; assert.ok(civilWarChance(g, de, 'fas') < civilWarChance(g, de, 'dem') + 1e-9);
    de.ideo = 'fas';
    const fr = byName(g, 'Франция'); g.historical = false; assert.ok(civilWarChance(g, fr, 'com') > 0);
    g.historical = true; assert.equal(civilWarChance(g, fr, 'com'), 0, 'в хронике у ИИ перевороты по сценарию');
    g.historical = false;
    de.overlord = fr.id; assert.equal(civilWarChance(g, de, 'dem'), 0, 'у вассала нет'); de.overlord = null;
    RULES.civilWar = false; assert.equal(civilWarChance(g, de, 'dem'), 0, 'правило выключено');
  } finally { RULES.civilWar = false; }
});
ok('гражданская война: раскол страны, мятежники воюют, столица остаётся', () => {
  RULES.civilWar = true;
  try {
    const g = euro(); const de = byName(g, 'Германия');
    refreshStats(g);
    const n0 = g.countries.length, prov0 = g.stats[de.id].provinces, cap = de.capital;
    g.rng = () => 0; // выпадает
    setIdeology(g, de, 'dem');
    assert.equal(g.countries.length, n0 + 1);
    const reb = g.countries[n0];
    assert.ok(reb.alive && reb.ideo === 'fas' && atWar(g, reb.id, de.id));
    refreshStats(g);
    assert.ok(g.stats[reb.id].provinces >= 3 && g.stats[reb.id].provinces < prov0 / 2);
    assert.equal(g.world.provinces.get(cap).props.owner, de.id, 'столица у правительства');
    assert.equal(g.world.provinces.get(reb.capital).props.owner, reb.id);
    assert.ok(de.civilDay === g.day && g.pending.some((p) => p.info && p.info.title === 'Гражданская война'));
    assert.equal(civilWarChance(g, de, 'com'), 0, 'повторно в течение года нельзя');
    g.rng = Math.random;
    for (let d = 0; d < 30; d++) stepDay(g, aiTick);
    assert.ok(g.countries.length >= n0 + 1);
    // не выпало
    const g2 = euro(); const de2 = byName(g2, 'Германия'); refreshStats(g2);
    g2.rng = () => 0.999; setIdeology(g2, de2, 'dem');
    assert.equal(g2.countries.length, n0);
  } finally { RULES.civilWar = false; }
});
