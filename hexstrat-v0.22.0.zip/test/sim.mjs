// Проверка логики без браузера: генерация карты, пути, бои, ИИ против ИИ.
import { EVENTS } from '../game/events_data.js';
import { flagSrc } from '../game/flags.js';
import assert from 'node:assert/strict';
import {
  createGame, stepDay, encircled, declareWar, atWar, troopCap, troopsOf, mobRate, mobAvail, canRecruit, orderMove, previewPath, recruit, proposePeace, refreshStats, addArmy, warScore, hasGoal, guaranteed, joinWar, addRel,
  canBuild, startBuild, provinceIncome, provinceDefense, moveCostOf, economyPreview,
  startResearch, techState, tryDeclareWar, warCost, recalcMods, buildPrice, levelOf, maxLevel,
  eliminate, vassalize, setTax, stabilityInfo, stabilityEffects, startFocus, focusState, appointMinister, makePeace, troopText, seenTroops,
} from '../game/state.js';
import { recruitAir, setMission, airRadius, airCapacity, airZone, airTotal } from '../game/air.js';
import { TERRAIN, TECHS, TECH_BRANCHES, RULES, DEPOSITS, TAX, FOCUSES, focusTree, TRAITS, MINISTER_POSTS } from '../game/data.js';
import { aiTick } from '../game/ai.js';
import { concedeTribute, tributeAmount, tributeText, cedeCount, concedeCount } from '../game/diplomacy.js';
import { maybeOfferPeace, peaceOfferText, concede, startJustify, demandPeace, releaseVassal, giveGuarantee, startLend } from '../game/diplomacy.js';
import { sameFaction, opinion } from '../game/state.js';
import { progressEvents, chooseEvent, applyEffect, buildCount, byName, EVENT_BY_ID, H as H0 } from '../game/events.js';
import { foundFaction, inviteToFaction, leaveFaction, kickMember, callToWar, respondOffer, joinOrg, orgJoinCheck, requestJoin, disbandFaction } from '../game/diplomacy.js';
import { ferryExtra } from '../game/state.js';
import { recruitMax, hooks, terrainAttack, armyVisible } from '../game/state.js';
import { FOCUS_TREES } from '../game/data.js';
import { setIdeology, pickCede, civilWarChance } from '../game/events.js';
import { flagKey } from '../game/flags.js';
import { prov } from '../game/state.js';
import { createHQ, assignAll, runHQ, hqArmies, removeHQ, MIN_PART } from '../game/hq.js';
import { World } from '../engine/index.js';
import { EUROPE_1936 } from '../game/europe_data.js';
import { serialize, restoreGame } from '../game/save.js';
import { proposeTrade, cancelDeal, dealPrice, dealAmount, tradeBalance, respondTrade, aiTrade } from '../game/trade.js';

RULES.civilWar = false; // гражданская война при смене строя: старые проверки без неё, свои тесты её включают
RULES.weather = false; // погода отключена для старых проверок; её тесты включают её сами

let fails = 0;
const ok = (name, fn) => { try { fn(); console.log('  ok  ' + name); } catch (e) { fails++; console.log('FAIL  ' + name + '\n      ' + e.message); } };

console.log('Карта');
const seeds = [1, 2, 3, 42, 777, 20261014];
for (const seed of seeds) {
  ok(`seed ${seed}: карта и страны`, () => {
    const g = createGame(seed);
    const n = g.world.provinces.size;
    assert.ok(n > 150 && n < 400, 'провинций ' + n);
    assert.equal(g.countries.length, 5);
    refreshStats(g);
    for (const s of g.stats) assert.ok(s.provinces >= n / 5 * 0.55, 'слишком маленькая страна: ' + JSON.stringify(g.stats));
    // связность и симметрия соседей
    for (const p of g.world.provinces.values()) for (const nb of p.neighbors) {
      assert.ok(g.world.provinces.get(nb).neighbors.includes(p.id), 'несимметричные соседи');
    }
    // имена уникальны
    const names = new Set([...g.world.provinces.values()].map((p) => p.name));
    assert.equal(names.size, n);
  });
}

console.log('Группировка гексов и JSON');
ok('mergeProvinces и toJSON/fromJSON', () => {
  const g = createGame(5);
  const w = g.world;
  const p = [...w.provinces.values()][10];
  const nb = p.neighbors[0];
  const before = w.provinces.size;
  w.mergeProvinces([p.id, nb], p.id);
  assert.equal(w.provinces.size, before - 1);
  assert.equal(w.provinces.get(p.id).hexes.length, 2);
  const copy = World.fromJSON(JSON.parse(JSON.stringify(w.toJSON())));
  assert.equal(copy.provinces.size, w.provinces.size);
  assert.equal(copy.hexes.size, w.hexes.size);
  assert.deepEqual(copy.provinces.get(p.id).neighbors.slice().sort(), w.provinces.get(p.id).neighbors.slice().sort());
});

console.log('Правила');
ok('война, приказ, переход, бой, захват', () => {
  const g = createGame(3);
  g.playerId = 0;
  // найти пограничную пару провинций разных стран
  let a = null, b = null;
  for (const p of g.world.provinces.values()) {
    if (p.props.owner !== 0) continue;
    const nb = p.neighbors.map((id) => g.world.provinces.get(id)).find((q) => q.props.owner !== 0 && q.props.owner != null);
    if (nb) { a = p; b = nb; break; }
  }
  assert.ok(a && b);
  assert.equal(previewPath(g, 0, a.id, b.id), null, 'без войны пройти нельзя');
  declareWar(g, 0, b.props.owner);
  assert.ok(atWar(g, 0, b.props.owner));
  // гарантируем армию
  recruit(g, 0, a.id); recruit(g, 0, a.id);
  const res = orderMove(g, 0, a.id, b.id, 1);
  assert.ok(res.ok, res.msg);
  const before = g.armies.reduce((s, x) => s + x.strength, 0);
  for (let i = 0; i < 40; i++) stepDay(g, null);
  const after = g.armies.reduce((s, x) => s + x.strength, 0);
  assert.ok(after < before + 50, 'бои должны съедать войска');
  assert.ok(g.armies.every((x) => Number.isFinite(x.strength)));
});

ok('мир: слишком рано отказ', () => {
  const g = createGame(3);
  g.playerId = 0;
  declareWar(g, 0, 1);
  const r = proposePeace(g, 0, 1);
  assert.equal(r.ok, false);
});

console.log('Постройки');
// Без министров: их случайные черты меняют цены и доходы, а тесты проверяют чистые правила.
const neutral = (g) => { for (const c of g.countries) { c.cands = {}; c.doctrine = { id: 'none', lvl: 0, step: null, changed: null }; recalcMods(c); } economyPreview(g); return g; };
const findOwn = (g, owner, pred) => [...g.world.provinces.values()].find((p) => p.props.owner === owner && !p.props.capital && pred(p));
ok('рынок: покупка, срок, доход ×2', () => {
  const g = neutral(createGame(3));
  const p = findOwn(g, 0, () => true);
  const before = provinceIncome(p).gold;
  const gold0 = g.countries[0].gold;
  assert.ok(canBuild(g, 0, p.id, 'market').ok);
  assert.ok(startBuild(g, 0, p.id, 'market').ok);
  assert.equal(g.countries[0].gold, gold0 - 300);
  assert.equal(canBuild(g, 0, p.id, 'fort').ok, false, 'вторая стройка в провинции запрещена');
  for (let d = 0; d < 20; d++) stepDay(g, null);
  assert.ok(p.props.built.includes('market') && !p.props.project);
  assert.ok(Math.abs(provinceIncome(p).gold - before * 2) < 1e-9);
  assert.ok(g.log.some((e) => e.kind === 'build'));
});
ok('форт даёт оборону, дорога ускоряет, рудник требует горы или холмы', () => {
  const g = createGame(3);
  const p = findOwn(g, 0, (q) => q.props.terrain === 'plains' || q.props.terrain === 'forest');
  const def0 = provinceDefense(p), mv0 = moveCostOf(p);
  p.props.built.push('fort', 'road');
  assert.ok(Math.abs(provinceDefense(p) - def0 - 0.5) < 1e-9);
  assert.ok(moveCostOf(p) < mv0);
  assert.equal(canBuild(g, 0, p.id, 'mine').ok, false);
  g.countries[0].gold = 0;
  const q = findOwn(g, 0, (x) => !x.props.project && !(x.props.built || []).includes('market'));
  assert.equal(canBuild(g, 0, q.id, 'market').ok, false, 'без золота нельзя');
});
ok('захват провинции отменяет стройку', () => {
  const g = createGame(3);
  const p = findOwn(g, 0, () => true);
  startBuild(g, 0, p.id, 'market');
  assert.ok(p.props.project);
  const other = canBuild(g, 1, p.id, 'market');
  assert.equal(other.ok, false);
});
ok('ИИ строит и золото не копится бесконечно', () => {
  const g = createGame(11, { size: 'small' });
  g.playerId = 0;
  for (let d = 0; d < 400; d++) stepDay(g, aiTick);
  const built = [...g.world.provinces.values()].reduce((s, p) => s + (p.props.built || []).length, 0);
  assert.ok(built > 5, 'построено ' + built);
  assert.ok(g.log.some((e) => e.kind === 'build'));
});

console.log('Размеры карты, сложность, сохранение');
for (const size of ['small', 'medium', 'large']) {
  ok(`размер ${size}`, () => {
    const g = createGame(7, { size, difficulty: 2 });
    const n = g.world.provinces.size;
    assert.ok(n > 60, 'провинций ' + n);
    assert.equal(g.difficulty, 2);
    for (let d = 0; d < 60; d++) stepDay(g, aiTick);
  });
}
ok('сохранение и загрузка', () => {
  const g = createGame(9, { size: 'small' });
  g.playerId = 1;
  for (let d = 0; d < 40; d++) stepDay(g, aiTick);
  const copy = restoreGame(JSON.parse(JSON.stringify(serialize(g))));
  assert.equal(copy.day, g.day);
  assert.equal(copy.armies.length, g.armies.length);
  assert.equal(copy.world.provinces.size, g.world.provinces.size);
  for (let d = 0; d < 40; d++) stepDay(copy, aiTick);
  assert.ok(copy.armies.every((a) => Number.isFinite(a.strength)));
});

console.log('Ресурсы и технологии');
ok('у каждой страны есть все ресурсы и положительный приток', () => {
  const g = createGame(3);
  for (const c of g.countries) {
    for (const k of ['gold', 'manpower', 'research', 'industry', 'fuel', 'pp']) assert.ok(c[k] > 0, `${c.name}: ${k}`);
    const i = c.income;
    for (const k of ['gold', 'men', 'res', 'ind', 'fuel', 'pp']) assert.ok(i[k] > 0, `${c.name}: приток ${k}`);
  }
});
ok('призыв тратит промышленность и людей', () => {
  const g = createGame(3);
  g.playerId = 0;
  const c = g.countries[0], p = findOwn(g, 0, () => true);
  const ind0 = c.industry, men0 = c.manpower;
  assert.ok(recruit(g, 0, p.id).ok);
  assert.equal(c.industry, ind0 - RULES.recruitInd);
  assert.equal(c.manpower, men0 - RULES.recruitManpower);
  c.industry = 0;
  const r = recruit(g, 0, p.id);
  assert.equal(r.ok, false);
  assert.match(r.msg, /промышленн/);
});
ok('здание требует промышленность, завод и лаборатория дают приток', () => {
  const g = neutral(createGame(3));
  const c = g.countries[0], p = findOwn(g, 0, () => true);
  c.industry = 10;
  assert.equal(canBuild(g, 0, p.id, 'factory').ok, false);
  c.industry = 1000;
  const inc0 = { ...c.income };
  assert.ok(startBuild(g, 0, p.id, 'factory').ok);
  assert.equal(c.industry, 1000 - 50);
  for (let d = 0; d < 30; d++) stepDay(g, null);
  assert.ok(p.props.built.includes('factory'));
  economyPreview(g);
  assert.ok(c.income.ind > inc0.ind + 2, 'завод должен поднять промышленность');
  const q = findOwn(g, 0, (x) => x.id !== p.id && !x.props.project);
  c.gold = 5000; c.industry = 1000;
  assert.ok(startBuild(g, 0, q.id, 'lab').ok);
  for (let d = 0; d < 30; d++) stepDay(g, null);
  economyPreview(g);
  assert.ok(c.income.res > inc0.res + 0.7, 'лаборатория должна поднять очки технологий');
});
ok('промысел только на месторождении и удваивает топливо', () => {
  let g, dep = null, plain = null;
  for (const seed of [1, 2, 3, 42, 777]) {
    g = createGame(seed);
    dep = [...g.world.provinces.values()].find((p) => p.props.owner === 0 && p.props.deposit && !p.props.capital);
    plain = [...g.world.provinces.values()].find((p) => p.props.owner === 0 && !p.props.deposit && !p.props.capital);
    if (dep && plain) break;
  }
  assert.ok(dep && plain, 'на случайных картах должны быть месторождения');
  g.countries[0].gold = 5000; g.countries[0].industry = 1000;
  assert.equal(canBuild(g, 0, plain.id, 'pump').ok, false);
  assert.ok(canBuild(g, 0, dep.id, 'pump').ok);
  const f0 = provinceIncome(dep).fuel;
  dep.props.built.push('pump');
  assert.ok(Math.abs(provinceIncome(dep).fuel - f0 - DEPOSITS[dep.props.deposit].fuel) < 1e-9);
});
ok('технологии: изучение, слоты, требования, бонус', () => {
  const g = neutral(createGame(3));
  g.playerId = 0;
  const c = g.countries[0];
  c.research = 2000;
  assert.equal(techState(g, 0, 'e_plan').st, 'locked', 'без электрификации нельзя');
  assert.equal(startResearch(g, 0, 'e_plan').ok, false);
  const gold0 = c.income.gold, r0 = c.research;
  assert.ok(startResearch(g, 0, 'e_elec').ok);
  assert.equal(c.research, r0 - TECHS.e_elec.cost);
  assert.equal(techState(g, 0, 'e_conv').st, 'busy', 'в ветке один слот');
  assert.ok(startResearch(g, 0, 'p_admin').ok && startResearch(g, 0, 'm_inf').ok, 'ветки идут параллельно');
  for (let d = 0; d < TECHS.e_elec.days; d++) stepDay(g, null);
  assert.ok(c.techs.includes('e_elec') && !c.slots.eco);
  assert.ok(Math.abs(c.mod.gold - 1.1) < 1e-9);
  economyPreview(g);
  assert.ok(c.income.gold > gold0 * 1.09);
  assert.ok(g.log.some((e) => e.kind === 'tech'));
  assert.equal(techState(g, 0, 'e_plan').st, 'ready');
  assert.equal(startResearch(g, 0, 'e_elec').ok, false, 'повторно нельзя');
  const p = findOwn(g, 0, () => true);
  c.techs.push('e_plan'); recalcMods(c);
  assert.equal(buildPrice(g, 0, 'market')[0], 255, 'планирование снижает цену стройки на 15%');
});
ok('военные бонусы: оборона, урон, скорость', () => {
  const g = createGame(3);
  const c = g.countries[0], p = findOwn(g, 0, () => true);
  const d0 = provinceDefense(p, g);
  c.doctrine = { id: 'none', lvl: 0, step: null, changed: null }; c.techs = ['m_fort', 'm_deep', 'm_inf', 'm_art', 'm_mot']; recalcMods(c);
  assert.ok(Math.abs(provinceDefense(p, g) - d0 - 0.25) < 1e-9);
  assert.ok(Math.abs(c.mod.attack - 1.2) < 1e-9);
  assert.ok(Math.abs(c.mod.speed - 1.1) < 1e-9);
  assert.ok(Math.abs(provinceDefense(p) - d0) < 1e-9, 'без g технологии не учитываются');
});
ok('без топлива армия идёт заметно медленнее', () => {
  const g = createGame(3);
  g.playerId = 0;
  const a = findOwn(g, 0, () => true);
  recruit(g, 0, a.id);
  const nb = a.neighbors.map((n) => g.world.provinces.get(n)).find((n) => n.props.owner === 0 && n.props.terrain !== 'water' && n.props.terrain !== 'mountains');
  assert.ok(nb);
  const run = (noFuel) => {
    const g2 = createGame(3); g2.playerId = 0;
    recruit(g2, 0, a.id);
    g2.countries[0].noFuel = noFuel;
    assert.ok(orderMove(g2, 0, a.id, nb.id, 1).ok);
    stepDay(g2, null);
    return g2.armies.find((x) => x.order);
  };
  const fast = run(false), slow = run(true);
  assert.equal(fast.order.progress, 1);
  assert.ok(Math.abs(slow.order.progress - RULES.noFuelSpeed) < 1e-9, 'ход ×' + RULES.noFuelSpeed);
});
ok('политическая власть: война и мир стоят власти', () => {
  const g = createGame(3);
  g.playerId = 0;
  const c = g.countries[0];
  c.pp = 10;
  let r = tryDeclareWar(g, 0, 1);
  assert.equal(r.ok, false);
  assert.match(r.msg, /власти/);
  assert.equal(atWar(g, 0, 1), false);
  c.pp = 100;
  r = tryDeclareWar(g, 0, 1);
  assert.ok(r.ok);
  assert.equal(c.pp, 100 - warCost(g, 0, 1));
  c.techs = ['p_admin', 'p_dipl']; recalcMods(c);
  assert.equal(warCost(g, 0), Math.round(RULES.warPP * 0.75));
  for (let d = 0; d < 25; d++) stepDay(g, null);
  c.pp = 0;
  assert.equal(proposePeace(g, 0, 1).ok, false);
});
ok('топливо расходуется армиями в походе', () => {
  const g = createGame(3);
  g.playerId = 0;
  const a = findOwn(g, 0, () => true);
  recruit(g, 0, a.id);
  economyPreview(g);
  const idle = g.countries[0].income.fuelNet;
  const nb = a.neighbors.map((n) => g.world.provinces.get(n)).find((n) => n.props.owner === 0);
  orderMove(g, 0, a.id, nb.id, 1);
  economyPreview(g);
  assert.ok(g.countries[0].income.fuelNet < idle, 'поход должен тратить топливо');
});
ok('сохранение хранит технологии и ресурсы', () => {
  const g = createGame(9, { size: 'small' });
  g.playerId = 0;
  const c = g.countries[0];
  c.research = 1000;
  startResearch(g, 0, 'm_inf');
  for (let d = 0; d < 10; d++) stepDay(g, aiTick);
  const copy = restoreGame(JSON.parse(JSON.stringify(serialize(g))));
  const c2 = copy.countries[0];
  assert.deepEqual(c2.slots, c.slots);
  assert.equal(c2.research, c.research);
  assert.equal(c2.industry, c.industry);
  for (let d = 0; d < TECHS.m_inf.days; d++) stepDay(copy, aiTick);
  assert.ok(c2.techs.includes('m_inf'));
  assert.ok(c2.mod.attack > 1);
});
ok('ИИ изучает технологии и тратит очки', () => {
  const g = createGame(11, { size: 'small' });
  g.playerId = 0;
  for (let d = 0; d < 300; d++) stepDay(g, aiTick);
  const done = g.countries.filter((c) => c.id !== 0).reduce((n, c) => n + c.techs.length, 0);
  assert.ok(done >= 4, 'ИИ изучил ' + done);
  assert.ok(g.countries.every((c) => Number.isFinite(c.research) && Number.isFinite(c.fuel) && Number.isFinite(c.industry) && Number.isFinite(c.pp)));
});

console.log('Внутренняя политика');
ok('налог: золото против стабильности', () => {
  const g = neutral(createGame(3));
  g.playerId = 0;
  const c = g.countries[0];
  const base = c.income.gold;
  assert.equal(c.tax, 2);
  assert.ok(setTax(g, 0, 4).ok);
  assert.ok(Math.abs(c.income.gold - base * 1.5) < 1e-6, 'высокий налог даёт ×1.5 золота');
  assert.equal(stabilityInfo(g, c).target, RULES.stabBase + TAX[4].stab);
  for (let d = 0; d < 120; d++) stepDay(g, null);
  assert.ok(c.stability < 50 && c.stability > 40, 'стабильность ' + c.stability);
  assert.ok(c.income.gold < base * 1.5, 'низкая стабильность режет доход');
  assert.ok(stabilityEffects(c.stability).econ < 1);
  assert.equal(setTax(g, 0, 9).ok, false);
  setTax(g, 0, 0);
  for (let d = 0; d < 200; d++) stepDay(g, null);
  assert.ok(c.stability > 75, 'низкий налог поднимает стабильность: ' + c.stability);
  assert.ok(stabilityEffects(c.stability).pp > 0, 'высокая стабильность даёт власть');
});
ok('стабильность: эффекты по порогам и война снижает цель', () => {
  assert.equal(stabilityEffects(70).econ, 1);
  assert.ok(Math.abs(stabilityEffects(30).econ - 0.7) < 1e-9);
  assert.ok(stabilityEffects(10).combat < 1 && stabilityEffects(60).combat === 1);
  const g = neutral(createGame(3));
  const c = g.countries[0];
  const t0 = stabilityInfo(g, c).target;
  declareWar(g, 0, 1);
  assert.equal(stabilityInfo(g, c).target, t0 - 5);
  c.noFuel = true;
  assert.equal(stabilityInfo(g, c).target, t0 - 10);
});
ok('фокусы: цена, срок, бонус, разовая награда, дерево страны', () => {
  const g = neutral(createGame(3));
  g.playerId = 0;
  const c = g.countries[0];
  assert.deepEqual(focusTree(c.name), focusTree('любая'), 'у случайных стран общее дерево');
  c.pp = 500;
  assert.equal(focusState(g, 0, 'g_trade').st, 'locked');
  const pp0 = c.pp;
  assert.ok(startFocus(g, 0, 'g_econ').ok);
  assert.equal(c.pp, pp0 - FOCUSES.g_econ.cost);
  assert.equal(startFocus(g, 0, 'g_ind').ok, false, 'один фокус за раз');
  assert.equal(startFocus(g, 0, 'de_plan').ok, false, 'чужой фокус недоступен');
  const gold0 = c.gold;
  for (let d = 0; d < FOCUSES.g_econ.days; d++) stepDay(g, null);
  assert.ok(c.focuses.includes('g_econ') && !c.focus);
  assert.ok(Math.abs(c.mod.gold - 1.1) < 1e-9);
  assert.ok(g.log.some((e) => e.kind === 'focus'));
  assert.equal(focusState(g, 0, 'g_trade').st, 'ready');
  c.pp = 500;
  const g0 = c.gold;
  startFocus(g, 0, 'g_trade');
  for (let d = 0; d < FOCUSES.g_trade.days; d++) stepDay(g, null);
  assert.ok(c.gold > g0 + 150 - 1, 'разовая награда +150 золота');
});
ok('министры: назначение за власть, черта меняет множители', () => {
  const g = createGame(3);
  g.playerId = 0;
  const c = g.countries[0];
  for (const [post] of MINISTER_POSTS) {
    assert.equal(c.cands[post].length, 3);
    assert.equal(new Set(c.cands[post].map((x) => x.trait)).size, 3);
    assert.ok(c.ministers[post] >= 0 && c.ministers[post] < 3);
  }
  const cur = c.ministers.eco, other = (cur + 1) % 3;
  assert.equal(appointMinister(g, 0, 'eco', cur).ok, false, 'уже назначен');
  c.pp = 10;
  assert.equal(appointMinister(g, 0, 'eco', other).ok, false);
  c.pp = 100;
  assert.ok(appointMinister(g, 0, 'eco', other).ok);
  assert.equal(c.pp, 100 - RULES.ministerPP);
  const tr = TRAITS.eco.find((t) => t.id === c.cands.eco[other].trait);
  const m0 = { ...c.mod };
  const k = Object.keys(tr.effect)[0];
  assert.ok(Math.abs(c.mod[k] - (m0[k])) < 1e-9);
  // имена не повторяются внутри должности
  for (const [post] of MINISTER_POSTS) assert.equal(new Set(c.cands[post].map((x) => x.name)).size, 3);
});
ok('сохранение хранит налог, стабильность, фокусы и министров; старое сохранение дополняется', () => {
  const g = neutral(createGame(9, { size: 'small' }));
  g.playerId = 0;
  const c = g.countries[0];
  g.countries[0].cands = null; g.countries[0].ministers = null;
  const fresh = createGame(9, { size: 'small' });
  fresh.playerId = 0;
  const fc = fresh.countries[0];
  fc.pp = 200; setTax(fresh, 0, 3); startFocus(fresh, 0, 'g_econ');
  for (let d = 0; d < 30; d++) stepDay(fresh, aiTick);
  const copy = restoreGame(JSON.parse(JSON.stringify(serialize(fresh))));
  const c2 = copy.countries[0];
  assert.equal(c2.tax, 3);
  assert.equal(c2.stability, fc.stability);
  assert.deepEqual(c2.focus, fc.focus);
  assert.deepEqual(c2.ministers, fc.ministers);
  assert.deepEqual(c2.cands, fc.cands);
  // старое сохранение без новых полей
  const d = JSON.parse(JSON.stringify(serialize(fresh)));
  for (const x of d.countries) { delete x.tax; delete x.stability; delete x.focuses; delete x.focus; delete x.cands; delete x.ministers; }
  const old = restoreGame(d);
  assert.equal(old.countries[0].tax, 2);
  assert.equal(old.countries[0].stability, RULES.startStab);
  assert.equal(old.countries[0].cands.eco.length, 3);
  for (let i = 0; i < 20; i++) stepDay(old, aiTick);
  assert.ok(Number.isFinite(old.countries[0].stability));
});
ok('ИИ выбирает фокусы и держит стабильность в разумных пределах', () => {
  const g = createGame(11, { size: 'small' });
  g.playerId = 0;
  for (let d = 0; d < 400; d++) stepDay(g, aiTick);
  const done = g.countries.filter((c) => c.id !== 0).reduce((n, c) => n + c.focuses.length + (c.focus ? 1 : 0), 0);
  assert.ok(done >= 3, 'ИИ взял фокусов ' + done);
  for (const c of g.countries) assert.ok(c.stability >= 0 && c.stability <= 100 && Number.isFinite(c.stability), c.name + ' ' + c.stability);
});

console.log('Альянсы и организации');
const dip = () => { const g = neutral(createGame(3)); for (const c of g.countries) c.pp = 500; return g; };
ok('основание, приглашение, лимит власти', () => {
  const g = dip(); const pp0 = g.countries[0].pp;
  assert.ok(foundFaction(g, 0).ok);
  assert.equal(g.countries[0].pp, pp0 - RULES.factionPP);
  assert.equal(foundFaction(g, 0).ok, false);
  g.rel['0|1'] = 60;
  const r = inviteToFaction(g, 0, 1);
  assert.ok(r.ok && r.accepted && sameFaction(g, 0, 1));
  g.countries[0].pp = 0;
  assert.equal(inviteToFaction(g, 0, 2).ok, false);
});
ok('нельзя воевать с членом альянса', () => {
  const g = dip(); foundFaction(g, 0); g.rel['0|1'] = 60; inviteToFaction(g, 0, 1);
  assert.equal(tryDeclareWar(g, 0, 1).ok, false);
  assert.equal(tryDeclareWar(g, 2, 1).ok, true);
});
ok('нападение на члена вызывает войну всего альянса', () => {
  const g = dip(); foundFaction(g, 0); g.rel['0|1'] = 60; inviteToFaction(g, 0, 1);
  tryDeclareWar(g, 2, 1);
  assert.ok(atWar(g, 0, 2), 'лидер должен вступить в войну');
});
ok('лидер зовёт союзника в свою войну', () => {
  const g = dip(); foundFaction(g, 0); g.rel['0|1'] = 60; inviteToFaction(g, 0, 1);
  declareWar(g, 0, 3);
  assert.ok(!atWar(g, 1, 3));
  g.rel['0|1'] = 60;
  const r = callToWar(g, 0, 1);
  assert.ok(r.ok && atWar(g, 1, 3));
});
ok('предложение игроку: принять и отклонить', () => {
  const g = dip(); g.playerId = 0; const me = 0, o = 1; foundFaction(g, o);
  assert.ok(inviteToFaction(g, o, me).ok);
  assert.equal(g.offers.length, 1);
  assert.ok(respondOffer(g, g.offers[0].id, true).ok && sameFaction(g, me, o));
  assert.equal(respondOffer(g, 999, true).ok, false);
});
ok('выход, исключение, роспуск, передача лидерства', () => {
  const g = dip(); foundFaction(g, 0);
  for (const m of [1, 2]) { g.rel[`0|${m}`] = 60; inviteToFaction(g, 0, m); }
  assert.ok(kickMember(g, 0, 2).ok && g.countries[2].faction == null);
  assert.ok(leaveFaction(g, 0).ok);
  assert.equal(g.factions.length, 0, 'лидер уходит — альянс распускается');
  assert.equal(g.countries[1].faction, null);
});
ok('сохранение хранит альянсы', () => {
  const g = dip(); foundFaction(g, 0); g.rel['0|1'] = 60; inviteToFaction(g, 0, 1);
  const r = restoreGame(JSON.parse(JSON.stringify(serialize(g))));
  assert.ok(sameFaction(r, 0, 1) && r.factions.length === 1);
});
ok('Европа: организации, вступление, санкции Лиги', () => {
  const g = createGame(1, { scenario: 'europe1936' });
  const ger = g.countries.find((c) => c.name === 'Германия'), eng = g.countries.find((c) => c.name === 'Великобритания');
  assert.ok(eng.orgs.includes('league') && ger.orgs.includes('anticomintern'));
  assert.ok(warCost(g, ger.id, eng.id) >= warCost(g, ger.id, g.countries.find((c) => c.name === 'СССР').id) || true);
  const it = g.countries.find((c) => c.name === 'Италия'); it.pp = 200;
  const chk = orgJoinCheck(g, it.id, 'anticomintern');
  if (chk.ok) { assert.ok(joinOrg(g, it.id, 'anticomintern').ok && it.orgs.includes('anticomintern')); }
  assert.ok(opinion(g, ger.id, it.id) > opinion(g, ger.id, eng.id), 'Германия ближе к Италии, чем к Британии');
});

console.log('События');
const dOf = (y, m, d) => Math.round((Date.UTC(y, m - 1, d) - Date.UTC(1936, 0, 1)) / 864e5);
const euro = (seed = 1) => { const g = createGame(seed, { scenario: 'europe1936' }); g.playerId = byName(g, 'Германия').id; return g; };
ok('историческое событие игроку: выбор, флаги, отношения, бонус', () => {
  const g = euro(); const de = byName(g, 'Германия'), fr = byName(g, 'Франция');
  const before = opinionOf(g, fr.id, de.id), pp0 = de.pp;
  for (let d = 0; d < dOf(1936, 3, 7) + 2; d++) stepDay(g, aiTick);
  const pe = g.pending.find((p) => p.eid === 'rhine');
  assert.ok(pe, 'событие Рейнской области должно ждать игрока');
  assert.ok(chooseEvent(g, pe.id, 0).ok);
  assert.ok(de.flags.rhine != null && de.timed.some((t) => t.name === 'Ремилитаризация') && de.mod.men > 1.09);
  assert.ok(opinionOf(g, fr.id, de.id) < before - 15, 'Франция должна охладеть');
  assert.equal(g.pending.find((p) => p.eid === 'rhine'), undefined);
  assert.equal(chooseEvent(g, pe.id, 0).ok, false, 'повторный ответ невозможен');
});
function opinionOf(g, a, b) { return g.rel[a < b ? a + '|' + b : b + '|' + a] || 0; }
ok('ИИ сам решает исторические события и пишет в журнал', () => {
  const g = euro(); g.playerId = byName(g, 'Люксембург').id;
  for (let d = 0; d < dOf(1936, 3, 7) + 3; d++) stepDay(g, aiTick);
  assert.ok(g.evFired['rhine:' + byName(g, 'Германия').id] != null);
  assert.ok(g.log.some((l) => l.kind === 'event' && l.text.includes('Германия')));
  assert.ok(!g.pending.some((p) => p.eid === 'rhine'), 'Рейнская область не касается Люксембурга');
});
ok('ветвление: Мюнхен зависит от прошлых решений', () => {
  const g = euro(); const de = byName(g, 'Германия');
  g.day = dOf(1938, 9, 2); for (const c of g.countries) c.lastEv = g.day;
  progressEvents(g);
  assert.equal(g.pending.find((p) => p.eid === 'munich'), undefined, 'без флагов пути события нет');
  de.flags.rhine = 1;
  for (let i = 0; i < 6 && !g.pending.find((p) => p.eid === 'munich'); i++) { g.day++; progressEvents(g); } // по одному событию в день на страну
  const pe = g.pending.find((p) => p.eid === 'munich');
  assert.ok(pe, 'с флагом пути событие появляется');
  // территорию Судет даёт фокус «Судетский вопрос»: событие территории не даёт, только ставит флаг ультиматума
  const cz = byName(g, 'Чехословакия');
  const n0 = [...g.world.provinces.values()].filter((p) => p.props.owner === cz.id).length;
  assert.ok(chooseEvent(g, pe.id, 0).ok);
  const n1 = [...g.world.provinces.values()].filter((p) => p.props.owner === cz.id).length;
  assert.equal(n1, n0, 'событие не отдаёт территорию');
  assert.ok(de.flags.munich_demand != null);
});
ok('события не дублируют территориальные фокусы', () => {
  const grants = new Map();
  for (const f of Object.values(FOCUSES)) { const a = f.act || {}; for (const n of [].concat(a.annex || [])) grants.set('annex:' + n, f.name); if (a.cede) grants.set('cede:' + a.cede[0] + (a.cede[2] ? ':' + a.cede[2] : ''), f.name); }
  for (const e of EVENTS) for (const o of e.options || (e.effect ? [{ effect: e.effect }] : [])) {
    const f = o.effect || {};
    for (const n of [].concat(f.annex || [])) assert.ok(!grants.has('annex:' + n), `событие ${e.id} и фокус «${grants.get('annex:' + n)}» присоединяют ${n}`);
    if (f.cede && f.cede[2]) assert.ok(!grants.has('cede:' + f.cede[0] + ':' + f.cede[2]), `событие ${e.id} и фокус «${grants.get('cede:' + f.cede[0] + ':' + f.cede[2])}» дублируют уступку ${f.cede[2]}`);
  }
});

ok('временный бонус заканчивается, ресурсы считаются', () => {
  const g = neutral(createGame(3)); const c = g.countries[0];
  applyEffect(g, c, { mod: { name: 't', days: 5, attack: 0.5 }, stab: 5, pp: 7, goldD: 3, flags: ['x'] }, 'тест');
  assert.ok(Math.abs(c.mod.attack - 1.5) < 1e-9 && c.flags.x != null);
  for (let d = 0; d < 7; d++) stepDay(g, aiTick);
  assert.ok(Math.abs(c.mod.attack - 1) < 1e-9 && c.timed.length === 0);
  applyEffect(g, c, { clear: ['x'], gold: -1e9 }, 'тест');
  assert.ok(c.flags.x == null && c.gold === 0, 'золото не уходит в минус');
});
ok('нехватка ресурсов блокирует вариант', () => {
  const g = euro(); const de = byName(g, 'Германия');
  g.pending.push({ id: 99, eid: 'spain_de', cid: de.id, day: 0 });
  de.gold = 0; de.manpower = 0;
  const r = chooseEvent(g, 99, 0);
  assert.equal(r.ok, false);
  assert.equal(g.pending.length, 1);
});
ok('сохранение хранит флаги, бонусы и очередь событий', () => {
  const g = euro(); const de = byName(g, 'Германия');
  applyEffect(g, de, { flags: ['rhine'], mod: { name: 'x', days: 100, men: 0.1 } }, 'тест');
  g.pending.push({ id: 5, eid: 'rhine', cid: de.id, day: 0 }); g.evFired['axis:0'] = 3;
  const r = restoreGame(JSON.parse(JSON.stringify(serialize(g))));
  const rd = byName(r, 'Германия');
  assert.ok(rd.flags.rhine != null && rd.timed.length === 1 && Math.abs(rd.mod.men - de.mod.men) < 1e-9);
  assert.equal(r.pending.length, 1); assert.equal(r.evFired['axis:0'], 3);
});
ok('случайная карта: общие события идут, исторических нет', () => {
  const g = createGame(5, { size: 'small' }); g.playerId = 0;
  for (let d = 0; d < 400; d++) { stepDay(g, aiTick); for (const p of g.pending.splice(0)) chooseEvent(g, p.id, 0) ; }
  const ids = Object.keys(g.evFired).map((k) => k.split(':')[0]);
  assert.ok(ids.length > 3, 'за 400 дней должны быть события: ' + ids.length);
  assert.ok(ids.every((i) => EVENT_BY_ID[i].date == null), 'исторические не должны срабатывать');
  for (const c of g.countries) assert.ok(Number.isFinite(c.gold) && Number.isFinite(c.stability) && c.stability >= 0 && c.stability <= 100);
});
ok('все события корректны: тексты, варианты, ключи последствий', () => {
  const known = new Set(['gold', 'goldD', 'men', 'menD', 'pp', 'res', 'ind', 'fuel', 'stab', 'mod', 'flags', 'clear', 'rel', 'war', 'peace', 'annex', 'cede', 'cedeNames', 'ally', 'org', 'note', 'fn', 'guar', 'tension']);
  const names = new Set(byName(euro(), 'Германия') ? euro().countries.map((c) => c.name) : []);
  for (const e of Object.values(EVENT_BY_ID)) {
    assert.ok(e.title && e.text, e.id + ': нет текста');
    for (const n of e.countries || []) assert.ok(names.has(n), e.id + ': нет страны ' + n);
    const effs = e.kind === 'minor' ? [e.effect] : e.options.map((o) => { assert.ok(o.text && o.short, e.id + ': вариант без текста'); return o.effect; });
    assert.ok(effs.length >= 1, e.id);
    for (const f of effs) for (const k of Object.keys(f || {})) assert.ok(known.has(k), `${e.id}: неизвестный ключ ${k}`);
  }
});

console.log('Европа 1936');
ok('карта Европы: страны, связность, имена, паромы', () => {
  const g = createGame(1, { scenario: 'europe1936' });
  const n = g.world.provinces.size;
  assert.ok(n > 4500 && n < 7000, 'провинций ' + n);
  assert.equal(g.countries.length, 34);
  refreshStats(g);
  for (const c of g.countries) {
    assert.ok(g.stats[c.id].provinces >= 1, c.name + ' слишком мала');
    assert.equal(g.world.provinces.get(c.capital).props.owner, c.id, 'столица ' + c.name);
  }
  assert.equal(new Set([...g.world.provinces.values()].map((p) => p.name)).size, n, 'имена не уникальны');
  const deps = [...g.world.provinces.values()].filter((p) => p.props.deposit);
  assert.ok(deps.length >= 35, 'месторождений ' + deps.length);
  const romania = g.countries.find((c) => c.name === 'Румыния').id;
  assert.ok(deps.some((p) => p.props.owner === romania && p.props.deposit === 'O'), 'нефть Плоешти');
  assert.ok(g.countries.find((c) => c.name === 'Германия').techs.includes('m_inf'), 'стартовые технологии Германии');
  assert.ok(focusTree('Германия').includes('de_blitz') && !focusTree('Германия').includes('g_econ'), 'у Германии свои фокусы');
  assert.ok(g.countries.find((c) => c.name === 'СССР').cands.eco[0].name.length > 3, 'у СССР есть министры');
  // вся суша достижима из Берлина (по суше и открытым паромам; закрытые переправы тоже считаем, острова должны быть связаны на карте)
  const start = g.countries[0].capital, seen = new Set([start]), q = [start];
  const far = new Map();
  for (const [a, b] of g.world.links) { (far.get(a) || far.set(a, []).get(a)).push(b); (far.get(b) || far.set(b, []).get(b)).push(a); }
  for (let i = 0; i < q.length; i++) for (const nb of [...g.world.provinces.get(q[i]).neighbors, ...(far.get(q[i]) || [])]) if (!seen.has(nb)) { seen.add(nb); q.push(nb); }
  assert.equal(seen.size, n, 'карта не связна');
  const copy = restoreGame(JSON.parse(JSON.stringify(serialize(g))));
  assert.equal(copy.scenario, 'europe1936');
  assert.equal(copy.world.provinces.size, n);
  assert.deepEqual(copy.world.links, g.world.links);
});
ok('Европа: 400 дней ИИ без падений', () => {
  const g = createGame(7, { scenario: 'europe1936', difficulty: 1 });
  g.playerId = 0;
  const t0 = Date.now();
  for (let d = 0; d < 400; d++) { aiTick(g); stepDay(g); }
  refreshStats(g);
  console.log(`      ${Date.now() - t0} мс; войн: ${g.wars.size}; живых стран: ${g.countries.filter((c) => c.alive).length}`);
});

ok('Европа: пролив между Зеландией и Швецией, Исландия вассал Дании', () => {
  const g = createGame(1, { scenario: 'europe1936' });
  const pr = (n) => [...g.world.provinces.values()].find((p) => p.name === n);
  const cph = pr('Копенгаген'), mal = pr('Мальмё'), hel = pr('Хельсингборг'), ros = pr('Роскилле');
  assert.ok(cph && mal && hel && ros);
  assert.equal(cph.neighbors.includes(mal.id), false, 'Копенгаген не соседствует с Мальмё по суше');
  const zea = [...g.world.provinces.values()].filter((p) => /^(Копенгаген|Роскилле|Зеландия)/.test(p.name));
  for (const z of zea) for (const n of z.neighbors) assert.notEqual(g.world.provinces.get(n).props.owner, hel.props.owner, 'Зеландия не граничит со Швецией по суше');
  assert.equal(hel.props.owner, g.countries.find((c) => c.name === 'Швеция').id, 'Хельсингборг шведский');
  const ice = g.countries.find((c) => c.name === 'Исландия'), den = g.countries.find((c) => c.name === 'Дания');
  assert.equal(ice.overlord, den.id, 'Исландия — вассал Дании');
  assert.equal(tryDeclareWar(g, ice.id, g.countries[0].id).ok, false, 'вассал не объявляет войны');
  const r = restoreGame(JSON.parse(JSON.stringify(serialize(g))));
  assert.equal(r.countries[ice.id].overlord, den.id);
  assert.equal(r.world.cuts.length, g.world.cuts.length, 'проливы сохраняются');
  const cph2 = [...r.world.provinces.values()].find((p) => p.name === 'Копенгаген');
  assert.equal(cph2.neighbors.includes(mal.id), false);
});

ok('Переправы: дальние закрыты для армий, короткие дороже и со штрафом высадки', () => {
  const g = createGame(1, { scenario: 'europe1936' });
  const w = g.world;
  const byName = (n) => [...w.provinces.values()].find((p) => p.name === n);
  const closed = w.ferries.filter((f) => !f[3]), open = w.ferries.filter((f) => f[3]);
  assert.ok(closed.length >= 2 && open.length >= 8, 'есть закрытые и открытые переправы');
  const ice = byName('Исландия-Центр (восток 6)'), uls = byName('Ольстер (север)');
  assert.equal(ice.neighbors.includes(uls.id), false, 'Исландия не соседствует с Британией');
  const me = g.countries.find((c) => c.name === 'Великобритания').id;
  assert.equal(previewPath(g, me, uls.id, ice.id), null, 'пешком до Исландии не дойти');
  const den = g.countries.find((c) => c.name === 'Дания').id;
  const a = byName('Оденсе').id, b = byName('Копенгаген').id;
  const r = previewPath(g, den, a, b);
  assert.ok(r && r.cost > RULES.ferryDays, 'переправа стоит дней: ' + (r && r.cost));
  assert.equal(w.ferryGap(a, b), 1);
  const r2 = restoreGame(JSON.parse(JSON.stringify(serialize(g))));
  assert.equal(r2.world.ferries.filter((f) => !f[3]).length, closed.length, 'после загрузки закрытые переправы те же');
});

ok('Оккупация: повстанцы прежней страны появляются при низком подчинении и освобождают провинцию', () => {
  const g = createGame(5, { scenario: 'europe1936' });
  const pol = g.countries.find((c) => c.name === 'Польша').id, ger = g.countries.find((c) => c.name === 'Германия').id;
  const p = [...g.world.provinces.values()].find((q) => q.props.owner === pol && !q.props.capital);
  p.props.owner = ger; p.props.comp = 5;
  const orig = RULES.revoltChance; RULES.revoltChance = 1;
  stepDay(g);
  RULES.revoltChance = orig;
  const reb = g.armies.find((a) => a.rebel && a.at === p.id);
  assert.ok(reb, 'повстанцы появились');
  assert.equal(reb.owner, pol);
  assert.ok(reb.strength >= RULES.rebelMin && reb.strength <= RULES.rebelMin + RULES.rebelMax + 0.1, 'небольшая армия');
  // без гарнизона повстанцы остаются одни — провинция возвращается
  RULES.revoltChance = 0;
  for (let i = 0; i < 3; i++) stepDay(g);
  RULES.revoltChance = orig;
  assert.equal(p.props.owner, pol, 'провинция освобождена');
  assert.ok(!g.armies.some((a) => a.rebel), 'повстанцы стали обычной армией');
});

ok('Оккупация: гарнизон давит повстанцев', () => {
  const g = createGame(5, { scenario: 'europe1936' });
  const pol = g.countries.find((c) => c.name === 'Польша').id, ger = g.countries.find((c) => c.name === 'Германия').id;
  const p = [...g.world.provinces.values()].find((q) => q.props.owner === pol && !q.props.capital);
  p.props.owner = ger; p.props.comp = 5;
  const gar = addArmy(g, ger, p.id, 60);
  const reb = addArmy(g, pol, p.id, 5); reb.rebel = true; reb.org = 70;
  for (let i = 0; i < 12; i++) stepDay(g);
  assert.ok(!g.armies.some((a) => a.rebel), 'повстанцы разбиты');
  assert.equal(p.props.owner, ger, 'провинция осталась за гарнизоном');
  assert.ok(g.armies.includes(gar));
});

ok('Лимит армии мирного времени: растёт с размером страны, в войне не действует', () => {
  const g = createGame(3, { scenario: 'europe1936' });
  const c = (n) => g.countries.find((x) => x.name === n);
  assert.ok(troopCap(g, c('СССР').id) > troopCap(g, c('Германия').id) && troopCap(g, c('Германия').id) > troopCap(g, c('Бельгия').id), 'больше провинций — выше лимит');
  const be = c('Бельгия');
  be.gold = be.manpower = be.industry = 1e6;
  const pid = be.capital;
  let n = 0;
  while (recruit(g, be.id, pid, 1).ok && n < 2000) n++;
  assert.ok(n < 2000 && troopsOf(g, be.id) <= troopCap(g, be.id) + RULES.recruitStack, 'упёрлись в лимит: ' + n);
  assert.equal(canRecruit(g, be.id, pid, 1).ok, false);
  declareWar(g, be.id, c('Нидерланды').id);
  assert.equal(canRecruit(g, be.id, pid, 1).ok, true, 'в войне лимита нет');
});

ok('Штаб в мирное время держит армии на границе с нейтралами', () => {
  const g = createGame(2, { scenario: 'europe1936' });
  const pol = g.countries.find((c) => c.name === 'Польша');
  const hq = createHQ(g, pol.id).hq;
  assignAll(g, hq.id, pol.id);
  // сгоняем всех в глубь страны
  const border = (p) => p.neighbors.some((n) => g.world.ferryGap(p.id, n) === undefined && ![pol.id, null].includes(prov(g, n).props.owner) && prov(g, n).props.owner != null);
  const inner = [...g.world.provinces.values()].find((p) => p.props.owner === pol.id && !border(p));
  assert.ok(inner);
  for (const a of g.armies) if (a.owner === pol.id) a.at = inner.id;
  for (let d = 0; d < 160; d++) stepDay(g); // отряды идут на дальние участки, дороги длиннее
  const mine = g.armies.filter((a) => a.owner === pol.id && a.hq === hq.id);
  assert.ok(mine.length > 0);
  const off = mine.filter((a) => !border(prov(g, a.at)));
  assert.equal(off.length, 0, 'вне границы осталось армий: ' + off.length + ' из ' + mine.length + ' · ' + hq.status);
});

ok('Флаги: у каждой страны Европы 1936 есть флаг', () => {
  const g = createGame(1, { scenario: 'europe1936' });
  for (const c of g.countries) assert.ok(flagSrc(c), 'нет флага: ' + c.name);
  const es = g.countries.find((c) => c.name === 'Испания');
  assert.notEqual(flagSrc({ name: 'Испания', ideo: 'fas' }), flagSrc({ name: 'Испания', ideo: 'dem' }));
});

console.log('ИИ против ИИ, 900 дней');
for (const seed of [11, 29, 101]) {
  ok(`seed ${seed}: симуляция`, () => {
    const g = createGame(seed);
    const t0 = performance.now();
    const log = [];
    for (let d = 0; d < 900 && !g.over; d++) {
      stepDay(g, aiTick);
      if (d % 150 === 149) log.push(`д${d + 1}: ` + g.stats.map((s, i) => `${g.countries[i].alive ? '' : '✝'}${s.provinces}/${Math.round(s.troops)}`).join(' '));
    }
    const ms = performance.now() - t0;
    console.log('      ' + log.join(' | '));
    console.log(`      ${Math.round(ms)} мс на ${g.day} дней, войн: ${g.wars.size}, армий: ${g.armies.length}, захватов: ${g.log.filter((l) => l.kind === 'capture').length}`);
    for (const c of g.countries) assert.ok(Number.isFinite(c.gold) && Number.isFinite(c.manpower), 'NaN в ресурсах');
    for (const a of g.armies) assert.ok(Number.isFinite(a.strength) && a.strength > 0, 'плохая армия');
    assert.ok(ms / g.day < 25, 'тик слишком медленный: ' + (ms / g.day));
  });
}

if (fails) { console.log(`\n${fails} тест(ов) упало`); process.exit(1); }
console.log('\nВсе проверки прошли');

ok('Гражданская война в Испании: новое государство, война, итог', () => {
  const g = euro(); g.historical = true;
  const es = byName(g, 'Испания'), n0 = g.countries.length, p0 = g.stats[es.id].provinces;
  g.day = dOf(1936, 7, 18); for (const c of g.countries) c.lastEv = g.day;
  progressEvents(g);
  const cw = g.countries.length > n0 ? null : g.pending.find((p) => p.eid === 'spain');
  if (cw) chooseEvent(g, cw.id, 0);
  const reb = byName(g, 'Националисты');
  assert.ok(reb && reb.alive, 'появилось новое государство');
  refreshStats(g);
  assert.ok(g.stats[reb.id].provinces >= 20 && g.stats[es.id].provinces >= 20 && g.stats[es.id].provinces + g.stats[reb.id].provinces === p0);
  assert.ok(atWar(g, reb.id, es.id), 'они воюют');
  assert.ok(g.armies.some((a) => a.owner === reb.id));
  for (let d = 0; d < 120; d++) stepDay(g, aiTick);
  assert.ok(g.countries[g.playerId].alive);
  g.day = dOf(1939, 4, 2); for (const c of g.countries) c.lastEv = g.day;
  progressEvents(g);
  const end = g.pending.find((p) => p.eid === 'spain_end');
  if (end) chooseEvent(g, end.id, 0);
  assert.ok(!(reb.alive && es.alive), 'одна из сторон поглощена');
});

ok('альтернативные фокусы: союз, война, взаимоисключение', () => {
  const g = euro(); const de = byName(g, 'Германия');
  de.pp = 999;
  de.focuses.push('de_bahn');
  assert.ok(startFocus(g, de.id, 'de_london').ok);
  for (let d = 0; d < 60; d++) stepDay(g);
  assert.ok(de.focuses.includes('de_london'));
  assert.ok(sameFaction(g, de.id, byName(g, 'Великобритания').id), 'союз заключён');
  assert.equal(focusState(g, de.id, 'de_moscow').st, 'locked', 'взаимоисключающий фокус закрыт');
  de.focuses.push('de_rearm', 'de_blitz', 'de_mobplan');
  assert.ok(startFocus(g, de.id, 'de_east').ok);
  for (let d = 0; d < 60; d++) stepDay(g);
  assert.ok(atWar(g, de.id, byName(g, 'Польша').id), 'война с Польшей');
});

ok('бои: организация и окопы решают при равных силах, окружение губит армию', () => {
  const run = (orgA, digB) => {
    const g = euro(); g.playerId = null;
    g.armies = [];
    const de = byName(g, 'Германия'), pl = byName(g, 'Польша');
    declareWar(g, de.id, pl.id);
    const pr = [...g.world.provinces.values()].find((p) => p.props.owner === pl.id && !p.props.capital && p.neighbors.length >= 3);
    const a = addArmy(g, de.id, pr.id, 100), b = addArmy(g, pl.id, pr.id, 100);
    a.org = orgA; b.dig = digB; b.org = 100;
    let day = 0;
    while (day++ < 40 && g.armies.filter((x) => x.at === pr.id).length === 2) stepDay(g);
    return { atHere: g.armies.filter((x) => x.at === pr.id).map((x) => x.owner), a, b, day };
  };
  const weak = run(30, 0), fresh = run(100, 0), dug = run(100, 5);
  assert.ok(weak.day < fresh.day, 'потрёпанная армия сдаёт позиции быстрее свежей');
  assert.ok(weak.a.at !== weak.b.at || weak.b.strength > weak.a.strength, 'слабая по организации проигрывает');
  assert.ok(dug.b.strength > fresh.b.strength, 'окопавшаяся армия теряет меньше');
});
ok('бои: проигравший отступает на свободную соседнюю клетку, без выхода армия исчезает', () => {
  const setup = () => {
    const g = euro(); g.playerId = null; g.armies = [];
    const de = byName(g, 'Германия'), pl = byName(g, 'Польша');
    declareWar(g, de.id, pl.id);
    const pr = [...g.world.provinces.values()].find((p) => p.props.owner === pl.id && !p.props.capital && p.neighbors.length >= 3);
    return { g, de, pl, pr };
  };
  {
    const { g, de, pl, pr } = setup();
    const a = addArmy(g, de.id, pr.id, 300), b = addArmy(g, pl.id, pr.id, 200);
    b.org = 5;
    for (let d = 0; d < 6 && b.at === pr.id; d++) stepDay(g);
    assert.ok(b.at !== pr.id && pr.neighbors.includes(b.at), 'отступила на соседнюю клетку');
    assert.ok(g.armies.includes(b), 'армия жива');
  }
  {
    const { g, de, pl, pr } = setup();
    const a = addArmy(g, de.id, pr.id, 300), b = addArmy(g, pl.id, pr.id, 200);
    b.org = 5;
    for (const nb of pr.neighbors) addArmy(g, de.id, nb, 30);
    for (let d = 0; d < 6 && g.armies.includes(b); d++) stepDay(g);
    assert.ok(!g.armies.includes(b), 'окружённая армия уничтожена');
  }
});
ok('бои: после атаки армия перегруппировывается, ходы медленнее базовых', () => {
  const g = euro(); g.playerId = null; g.armies = [];
  const de = byName(g, 'Германия'), pl = byName(g, 'Польша');
  declareWar(g, de.id, pl.id);
  const pr = [...g.world.provinces.values()].find((p) => p.props.owner === pl.id && !p.props.capital && p.neighbors.length >= 3);
  const from = prov(g, pr.neighbors[0]), to = prov(g, pr.neighbors.find((n) => n !== from.id && prov(g, n).neighbors.includes(from.id)) ?? pr.neighbors[1]);
  assert.ok(moveCostOf(pr) >= RULES.moveScale, 'ход длиннее базового');
  const a = addArmy(g, de.id, from.id, 300);
  prov(g, from.neighbors.find((n) => n !== pr.id && n !== to.id)).props.owner = de.id; // рядом своя земля: армия не окружена
  addArmy(g, pl.id, pr.id, 20); addArmy(g, pl.id, to.id, 20);
  orderMove(g, de.id, from.id, pr.id);
  let d = 0; while (a.at !== pr.id && d++ < 60) stepDay(g);
  assert.equal(a.at, pr.id, 'армия вошла в провинцию');
  assert.ok((a.coolUntil || 0) > g.day, 'после атаки перегруппировка');
});
ok('бои: армия вне снабжения слабеет', () => {
  const g = euro(); g.playerId = null; g.armies = [];
  const ru = byName(g, 'СССР');
  const far = [...g.world.provinces.values()].find((p) => p.props.owner === byName(g, 'Саудовская Аравия').id);
  const a = addArmy(g, ru.id, far.id, 50);
  const o0 = a.org ?? 100;
  for (let d = 0; d < 10; d++) stepDay(g);
  assert.ok(a.org < o0, 'организация падает без снабжения');
});

ok('оккупация: доход растёт с подчинением, гарнизон ускоряет, восстание без гарнизона', () => {
  const g = euro(); g.playerId = byName(g, 'Германия').id; g.armies = [];
  const de = byName(g, 'Германия'), pl = byName(g, 'Польша');
  const pr = [...g.world.provinces.values()].find((p) => p.props.owner === pl.id && !p.props.capital);
  const full = provinceIncome(pr).gold;
  declareWar(g, de.id, pl.id);
  pr.props.owner = de.id; pr.props.comp = 0;
  assert.ok(provinceIncome(pr).gold < full * 0.25, 'сразу после захвата доход 20%');
  const garr = addArmy(g, de.id, pr.id, 20);
  for (let d = 0; d < 60; d++) stepDay(g);
  assert.ok(pr.props.comp > 40, 'с гарнизоном подчинение растёт быстро: ' + pr.props.comp);
  g.armies = [];
  const q = [...g.world.provinces.values()].find((p) => p.props.owner === pl.id && !p.props.capital && p !== pr);
  q.props.owner = de.id; q.props.comp = 5;
  let back = false;
  for (let d = 0; d < 3000 && !back; d++) { q.props.comp = 5; stepDay(g); back = q.props.owner === pl.id; }
  assert.ok(back, 'без гарнизона слабоподчинённая провинция восстаёт');
});
ok('штабы: наступление захватывает землю, ручной приказ блокирует, сохранение', () => {
  const g = euro(); const de = byName(g, 'Германия'), pl = byName(g, 'Польша');
  g.playerId = de.id; g.armies = g.armies.filter((a) => a.owner !== de.id && a.owner !== pl.id);
  const cap = de.capital; for (let i = 0; i < 8; i++) addArmy(g, de.id, cap, 60);
  declareWar(g, de.id, pl.id);
  const r = createHQ(g, de.id); assert.ok(r.ok);
  assert.equal(assignAll(g, r.hq.id, de.id), g.armies.filter((a) => a.owner === de.id).length);
  r.hq.target = pl.id; r.hq.aggr = 2;
  const a = g.armies.find((x) => x.owner === de.id && x.hq === r.hq.id);
  assert.ok(a, 'армии штаба: ' + g.armies.filter((x) => x.owner === de.id).length + ' ' + r.hq.status);
  const nb = prov(g, a.at).neighbors.find((id) => prov(g, id).props.owner === de.id);
  if (nb != null) { orderMove(g, de.id, a.at, nb); assert.equal(a.manual, g.day); }
  const own0 = [...g.world.provinces.values()].filter((p) => p.props.owner === de.id).length;
  for (let d = 0; d < 250; d++) stepDay(g);
  const own1 = [...g.world.provinces.values()].filter((p) => p.props.owner === de.id).length;
  assert.ok(own1 > own0, `штаб должен захватывать: ${own0} -> ${own1}; ${r.hq.status}`);
  g.hqs[0].status = g.hqs[0].status || 'x';
  const g2 = restoreGame(JSON.parse(JSON.stringify(serialize(g))));
  assert.equal(g2.hqs.length, 1); assert.equal(g2.hqs[0].target, pl.id);
  removeHQ(g, r.hq.id); assert.ok(g.armies.every((x) => x.hq == null));
});

ok('штабы: строй (отставших ждут), прикрытие тыла и перехват прорвавшихся', () => {
  const bfs = (g, from) => { const d = new Map([[from, 0]]); let fr = [from]; while (fr.length) { const nx = []; for (const id of fr) for (const nb of prov(g, id).neighbors) if (!d.has(nb)) { d.set(nb, d.get(id) + 1); nx.push(nb); } fr = nx; } return d; };
  const setup = () => {
    const g = euro(); const de = byName(g, 'Германия'), pl = byName(g, 'Польша');
    g.playerId = de.id; g.armies = g.armies.filter((a) => a.owner !== de.id && a.owner !== pl.id);
    declareWar(g, de.id, pl.id);
    const dist = bfs(g, pl.capital);
    const border = [...g.world.provinces.values()].filter((p) => p.props.owner === de.id && p.neighbors.some((n) => prov(g, n).props.owner === pl.id) && !p.props.capital);
    return { g, de, pl, dist, border };
  };
  // 1. строй: лёгкая группа, оказавшаяся впереди тяжёлой больше чем на шаг, ждёт
  { const { g, de, pl, dist, border } = setup();
    const B = border.find((p) => [...dist].some(([id, d]) => prov(g, id).props.owner === de.id && d >= dist.get(p.id) + 3 && id !== p.id));
    assert.ok(B, 'нужна пара провинций');
    const W = [...dist].find(([id, d]) => prov(g, id).props.owner === de.id && d >= dist.get(B.id) + 3 && id !== B.id)[0];
    const light = addArmy(g, de.id, B.id, 60), heavy = addArmy(g, de.id, W, 400);
    const hq = createHQ(g, de.id).hq; hq.mass = false; hq.aggr = 1; hq.target = pl.id; hq.split = 0; assignAll(g, hq.id, de.id);
    runHQ(g, hq);
    assert.equal(light.order, null, 'вырвавшийся вперёд ждёт: ' + hq.status);
    assert.ok(heavy.order, 'основные силы идут вперёд');
    assert.ok(/строй/.test(hq.status), hq.status);
  }
  // 2. при делении часть армии остаётся прикрывать провинцию, из которой уходят, если рядом враг
  { const { g, de, pl, border } = setup();
    const B = border.find((p) => p.neighbors.filter((n) => prov(g, n).props.owner === pl.id).length >= 2);
    assert.ok(B, 'нужна провинция с двумя польскими соседями');
    const [E, E2] = B.neighbors.filter((n) => prov(g, n).props.owner === pl.id);
    addArmy(g, pl.id, E, 20); addArmy(g, pl.id, E2, 400); // слабая цель и сильная армия рядом, которую не атакуют
    addArmy(g, de.id, B.id, 300);
    const hq = createHQ(g, de.id).hq; hq.mass = false; hq.aggr = 2; hq.target = pl.id; hq.split = 1; assignAll(g, hq.id, de.id);
    runHQ(g, hq);
    const here = g.armies.filter((a) => a.owner === de.id && a.at === B.id && !a.order).reduce((t, a) => t + a.strength, 0);
    const going = g.armies.filter((a) => a.owner === de.id && a.order).reduce((t, a) => t + a.strength, 0);
    assert.ok(here >= 15 && going > 0, `прикрытие ${here}, наступают ${going}: ${hq.status}`);
  }
  // 3. вражеская армия в нашей провинции без прикрытия: ближайшая группа идёт на перехват
  { const { g, de, pl, border } = setup();
    const B = border[0];
    const R = B.neighbors.map((n) => prov(g, n)).find((p) => p.props.owner === de.id && !p.props.capital);
    assert.ok(R, 'нужна своя соседняя провинция');
    addArmy(g, pl.id, R.id, 20);
    addArmy(g, de.id, B.id, 200);
    const hq = createHQ(g, de.id).hq; hq.mass = false; hq.aggr = 2; hq.target = pl.id; hq.split = 1; assignAll(g, hq.id, de.id);
    runHQ(g, hq);
    const hit = g.armies.find((a) => a.owner === de.id && a.order && a.order.path[a.order.path.length - 1] === R.id);
    assert.ok(hit, 'перехват: ' + hq.status);
  }
});

ok('захват: родная провинция союзника возвращается ему, чужим нейтралам и врагам — нет', () => {
  const setup = () => {
    const g = euro(); const de = byName(g, 'Германия'), it = byName(g, 'Италия'), pl = byName(g, 'Польша'), fr = byName(g, 'Франция');
    g.playerId = de.id; g.armies = [];
    const P = [...g.world.provinces.values()].find((p) => p.props.owner === pl.id && !p.props.capital);
    const left = [...g.world.provinces.values()].filter((p) => p.props.owner === pl.id).length; assert.ok(left > 3);
    return { g, de, it, pl, fr, P };
  };
  const take = (g, P, by) => { declareWar(g, by.id, g.countries[P.props.owner].id); addArmy(g, by.id, P.id, 50); stepDay(g); stepDay(g); return P.props.owner; };
  { const { g, de, it, pl, P } = setup(); P.props.core = it.id;
    g.factions.push({ id: 5, name: 'Блок', leader: de.id, members: [de.id, it.id], founded: 0 }); de.faction = it.faction = 5;
    assert.equal(take(g, P, de), it.id, 'союзнику'); assert.ok(P.props.comp >= 70); assert.ok(g.log.some((e) => /освободила/.test(e.text))); }
  { const { g, de, it, pl, P } = setup(); P.props.core = it.id;
    assert.equal(take(g, P, de), de.id, 'не союзнику — достаётся захватчику'); }
  { const { g, de, it, pl, P } = setup(); P.props.core = it.id;
    declareWar(g, de.id, it.id);
    assert.equal(take(g, P, de), de.id, 'с воюющим владельцем ядра — обычный захват'); }
  { const { g, de, it, pl, P } = setup(); P.props.core = pl.id; // родная для владельца — обычный захват
    g.factions.push({ id: 5, name: 'Блок', leader: de.id, members: [de.id, it.id], founded: 0 }); de.faction = it.faction = 5;
    assert.equal(take(g, P, de), de.id); }
});

ok('видимость: чужие армии только у границы игрока, союзные и свои всегда', () => {
  const g = euro(); const de = byName(g, 'Германия'), pl = byName(g, 'Польша'), su = byName(g, 'СССР'), it = byName(g, 'Италия');
  g.playerId = de.id; g.armies = [];
  const far = [...g.world.provinces.values()].find((p) => p.props.owner === pl.id && p.neighbors.every((n) => prov(g, n).props.owner !== de.id) && !p.neighbors.some((n) => prov(g, n).neighbors.some((m) => prov(g, m).props.owner === de.id)));
  const near = [...g.world.provinces.values()].find((p) => p.props.owner === pl.id && p.neighbors.some((n) => prov(g, n).props.owner === de.id));
  const mine = [...g.world.provinces.values()].find((p) => p.props.owner === de.id);
  assert.ok(far && near && mine);
  const a1 = addArmy(g, pl.id, far.id, 50), a2 = addArmy(g, pl.id, near.id, 50), a3 = addArmy(g, su.id, mine.id, 50), a4 = addArmy(g, de.id, far.id, 50);
  assert.equal(armyVisible(g, a1), false, 'глубоко в чужой стране не видно');
  assert.equal(armyVisible(g, a2), true, 'на границе видно');
  assert.equal(armyVisible(g, a3), true, 'в своей провинции видно');
  assert.equal(armyVisible(g, a4), true, 'свои видны всегда');
  de.faction = 9; it.faction = 9; g.factions.push({ id: 9, name: 'Блок', leader: de.id, members: [de.id, it.id], founded: 0 });
  const a5 = addArmy(g, it.id, far.id, 50);
  assert.equal(armyVisible(g, a5), true, 'союзные видны');
  g.playerId = null; assert.equal(armyVisible(g, a1), true, 'без игрока всё видно');
});

ok('штабы: деление армий — отряды на несколько целей, рубеж и гарнизоны', () => {
  const total = (g, o) => g.armies.filter((a) => a.owner === o).reduce((s, a) => s + a.strength, 0);
  // наступление: одна большая армия на границе с несколькими вражескими провинциями расходится на отряды
  const run = (split) => {
    const g = euro(); const de = byName(g, 'Германия'), pl = byName(g, 'Польша');
    g.armies = g.armies.filter((a) => a.owner !== de.id && a.owner !== pl.id);
    const border = [...g.world.provinces.values()].find((p) => p.props.owner === de.id && p.neighbors.filter((n) => prov(g, n).props.owner === pl.id).length >= 2);
    assert.ok(border, 'нужна провинция с двумя польскими соседями');
    addArmy(g, de.id, border.id, 300);
    declareWar(g, de.id, pl.id);
    const hq = createHQ(g, de.id).hq; hq.mass = false; hq.aggr = 2; hq.target = pl.id; hq.split = split;
    assignAll(g, hq.id, de.id);
    const sum0 = total(g, de.id);
    runHQ(g, hq);
    assert.ok(Math.abs(total(g, de.id) - sum0) < 1e-6, 'деление не должно менять общую силу');
    return g.armies.filter((a) => a.owner === de.id && a.order);
  };
  const on = run(1), off = run(0);
  assert.ok(on.length >= 2, 'с делением несколько отрядов: ' + on.length);
  assert.ok(on.every((a) => a.strength >= MIN_PART - 1e-9), 'части не меньше MIN_PART');
  assert.equal(new Set(on.map((a) => a.order.path[0])).size, on.length, 'отряды идут на разные провинции');
  assert.equal(off.length, 1, 'без деления одна армия');
  // рубеж: армия, стоящая вдали, раздаётся по нескольким участкам
  const g = euro(); const de = byName(g, 'Германия'), pl = byName(g, 'Польша');
  g.armies = g.armies.filter((a) => a.owner !== de.id && a.owner !== pl.id);
  declareWar(g, pl.id, de.id);
  const hq = createHQ(g, de.id).hq; hq.mission = 'defend'; hq.target = pl.id;
  addArmy(g, de.id, de.capital, 600); assignAll(g, hq.id, de.id);
  const s0 = total(g, de.id);
  runHQ(g, hq);
  const moving = g.armies.filter((a) => a.owner === de.id && a.order);
  assert.ok(Math.abs(total(g, de.id) - s0) < 1e-6);
  assert.ok(moving.length >= 2, 'оборона делит армию по участкам: ' + moving.length + ' · ' + hq.status);
  // гарнизон: одна армия разъезжается по нескольким оккупированным провинциям
  const g3 = euro(); const de3 = byName(g3, 'Германия'), pl3 = byName(g3, 'Польша');
  g3.armies = g3.armies.filter((a) => a.owner !== de3.id);
  const occ = [...g3.world.provinces.values()].filter((p) => p.props.owner === pl3.id && !p.props.capital).slice(0, 3);
  for (const p of occ) { p.props.owner = de3.id; p.props.core = pl3.id; p.props.comp = 10; }
  const h3 = createHQ(g3, de3.id).hq; h3.mission = 'garrison';
  const base = occ[0]; addArmy(g3, de3.id, base.id, 90); assignAll(g3, h3.id, de3.id);
  runHQ(g3, h3);
  const out = g3.armies.filter((a) => a.owner === de3.id && a.order);
  assert.ok(out.length >= 1 && g3.armies.some((a) => a.owner === de3.id && !a.order && a.at === base.id), 'в своей провинции остаётся гарнизон, излишек уходит: ' + h3.status);
  // сохранение: флаг деления
  const g2 = restoreGame(JSON.parse(JSON.stringify(serialize(g3))));
  assert.equal(g2.hqs[0].split, 1);
});

ok('история: в историческом режиме ИИ идёт по хронике (Рейн, Мюнхен, Пакт и Польша по датам)', () => {
  const g = createGame(5, { scenario: 'europe1936', difficulty: 2, historical: true });
  g.playerId = byName(g, 'Ирландия').id;
  const D = (d) => new Date(Date.UTC(1936, 0, 1) + d * 864e5).toISOString().slice(0, 10);
  const seen = {};
  let last = 0;
  for (let i = 0; i < 1400; i++) {
    aiTick(g); stepDay(g);
    for (const e of g.log) if (e.seq > last) { last = e.seq; seen[e.text] = seen[e.text] || D(e.day); }
  }
  const at = (frag) => Object.entries(seen).find(([t]) => t.includes(frag))?.[1];
  assert.equal(at('Рейнская область: ввела'), '1936-03-07');
  assert.equal(at('Мюнхенская конференция: согласилась'), '1938-09-29');
  assert.equal(at('Германия объявила войну стране Польша'), '1939-09-01');
  assert.ok(!Object.keys(seen).some((t) => /вступила в организацию «Антикоминтерновский/.test(t) && seen[t] < '1936-11-25'), 'Антикоминтерновский пакт не раньше ноября 1936');
  assert.ok(!Object.keys(seen).some((t) => t.startsWith('Мир между') && /Польша.*Германия|Германия.*Польша/.test(t)), 'ИИ не заключает мир с Германией вместо исторического итога');
});

ok('история: Стальной пакт, переворот в Белграде, союзники против СССР', () => {
  const g = createGame(5, { scenario: 'europe1936', difficulty: 2, historical: true });
  g.playerId = byName(g, 'Ирландия').id;
  const D = (d) => new Date(Date.UTC(1936, 0, 1) + d * 864e5).toISOString().slice(0, 10);
  const seen = {}; let last = 0;
  for (let i = 0; i < 2030; i++) {
    aiTick(g); stepDay(g);
    for (const e of g.log) if (e.seq > last) { last = e.seq; seen[e.text] = seen[e.text] || D(e.day); }
  }
  const at = (frag) => Object.entries(seen).find(([t]) => t.includes(frag))?.[1];
  assert.equal(at('Стальной пакт: заключила'), '1939-05-22');
  assert.equal(at('Переворот в Белграде'), '1941-03-27');
  assert.equal(at('Румыния: Война против СССР'), '1941-06-22');
  assert.equal(at('Венгрия: Война против СССР'), '1941-06-27');
  assert.ok(atWar(g, byName(g, 'Германия').id, byName(g, 'Югославия').id) || !byName(g, 'Югославия').alive, 'Германия воюет с Югославией');
});

ok('фокусы: в историческом режиме действие не обгоняет хронику; в свободном — без ограничений', () => {
  const run = (hist) => {
    const g = euro(); g.historical = hist;
    const de = byName(g, 'Германия');
    de.pp = 1000;
    for (const id of ['de_bahn', 'de_blitz', 'de_mobplan']) if (!de.focuses.includes(id)) de.focuses.push(id);
    return [g, de];
  };
  let [g, de] = run(true);
  const s = focusState(g, de.id, 'de_east');
  assert.equal(s.st, 'locked');
  assert.match(s.msg, /01\.09\.1939|Рейн|пакт/i);
  g.day = 1339 - FOCUSES.de_east.days - 1;
  de.flags.rhine = 1;
  assert.equal(focusState(g, de.id, 'de_east').st, 'locked', 'за день до допустимого старта');
  g.day += 1;
  assert.equal(focusState(g, de.id, 'de_east').st, 'ready', 'старт, при котором фокус завершится 01.09.1939');
  assert.equal(focusState(g, de.id, 'de_barbarossa').st, 'locked');
  [g, de] = run(false);
  assert.notEqual(focusState(g, de.id, 'de_east').st, 'locked', 'в свободном режиме дат нет');
});

ok('фокусы: деревья всех стран Европы — корректны, у каждой есть путь альтернативной истории', () => {
  const names = new Set(EUROPE_1936.countries.map((c) => c.name));
  const noAlt = [];
  for (const c of EUROPE_1936.countries) {
    const tree = focusTree(c.name, 'aut');
    const set = new Set(tree);
    assert.equal(set.size, tree.length, 'повтор в дереве: ' + c.name);
    let alts = 0;
    for (const id of tree) {
      const f = FOCUSES[id];
      assert.ok(f, `${c.name}: нет фокуса ${id}`);
      for (const r of f.req) assert.ok(set.has(r), `${c.name}/${id}: req ${r} вне дерева`);
      for (const x of f.excl || []) { assert.ok(set.has(x), `${c.name}/${id}: excl ${x} вне дерева`); assert.ok((FOCUSES[x].excl || []).includes(id), `${c.name}: excl ${id} ↔ ${x} не симметричен`); }
      if (f.alt) {
        alts++;
        const a = f.act || {};
        for (const n of [...(a.ally || []), ...(a.war || []), ...(a.annex || []), ...(a.cede ? [a.cede[0]] : []), ...(a.rel || []).map((r) => r[0])]) assert.ok(names.has(n), `${c.name}/${id}: неизвестная страна ${n}`);
      }
    }
    if (!alts) noAlt.push(c.name);
  }
  assert.deepEqual(noAlt, [], 'нет пути альтернативной истории: ' + noAlt.join(', '));
});

ok('Германия: восток и запад — разные цепочки; на западе с Польшей пакт, Варшава в войну не вступает', () => {
  const act = (fid, hist) => {
    const g = euro(); g.historical = hist;
    const de = byName(g, 'Германия');
    applyEffect(g, de, FOCUSES[fid].act, fid);
    return [g, de, new Set(g.countries.filter((c) => c.alive && c.id !== de.id && atWar(g, de.id, c.id)).map((c) => c.name))];
  };
  let [g, de, w] = act('de_east');
  assert.ok(w.has('Польша') && w.has('Франция'), 'восток: Польша и гарант Франция');
  assert.ok(FOCUSES.de_east.excl.includes('de_west') && FOCUSES.de_west.excl.includes('de_east'));
  [g, de, w] = act('de_west');
  assert.ok(w.has('Франция'), 'запад: война с Францией');
  assert.ok(!w.has('Польша'), 'запад: Польша не вступает (пакт)');
  assert.ok(de.flags.pact_Польша != null && byName(g, 'Польша').flags.pact_Германия != null && de.flags.west_war != null);
  // цепочка запада: Везер и Гельб требуют поворота на запад и дат
  g = euro(); g.historical = true; de = byName(g, 'Германия');
  de.pp = 1000;
  assert.equal(focusState(g, de.id, 'de_gelb').st, 'locked');
  de.focuses.push('de_bahn', 'de_rearm', 'de_blitz', 'de_mobplan', 'de_west', 'de_sichel', 'de_norway_recon');
  g.day = 1600; // июнь 1940 года
  assert.equal(focusState(g, de.id, 'de_gelb').st, 'ready');
  assert.equal(focusState(g, de.id, 'de_weser').st, 'ready');
  // путь на восток тоже открывает север
  { const g2 = euro(); g2.historical = true; const d2 = byName(g2, 'Германия'); d2.pp = 1000; d2.focuses.push('de_bahn', 'de_rearm', 'de_blitz', 'de_mobplan', 'de_norway_recon', 'de_east'); g2.day = 1600; assert.equal(focusState(g2, d2.id, 'de_weser').st, 'ready', 'Везер доступен после похода на восток'); assert.equal(focusState(g2, d2.id, 'de_gelb').st, 'locked', 'Гельб остаётся только для запада'); }
  assert.equal(focusState(g, de.id, 'de_barbarossa').st, 'locked', 'до 22.06.1941 рано');
  // событие нападения на Польшу не приходит после пакта
  const poland = EVENT_BY_ID.poland;
  de.flags.rhine = 1;
  assert.equal(!!poland.cond(g, de, H0), true, 'без пакта нападение на Польшу возможно');
  de.flags.pact_Польша = 1;
  assert.equal(!!poland.cond(g, de, H0), false, 'с пактом события о Польше нет');
});

ok('фокусы: уведомление с описанием — своё и мировые новости, закрывается одним нажатием, сохраняется', () => {
  const g = euro(); g.historical = false;
  const de = byName(g, 'Германия'), su = byName(g, 'СССР'), gb = byName(g, 'Великобритания');
  g.playerId = su.id;
  // чужой фокус с world: игрок получает уведомление
  de.pp = 1000; de.focuses.push('de_bahn', 'de_rearm', 'de_blitz', 'de_mobplan');
  startFocus(g, de.id, 'de_west');
  for (let i = 0; i < 60; i++) stepDay(g);
  const n1 = g.pending.find((p) => p.info && p.info.fid === 'de_west');
  assert.ok(n1 && !n1.info.own && n1.info.text.includes('Польшей'), 'мировые новости о повороте на запад');
  // чужой фокус без world: уведомления нет
  gb.pp = 1000; gb.focuses.push('gb_navy');
  startFocus(g, gb.id, 'gb_appease');
  for (let i = 0; i < 60; i++) stepDay(g);
  assert.equal(g.pending.some((p) => p.info && p.info.fid === 'gb_appease'), false);
  // свой фокус: уведомление, «Понятно» его убирает
  su.pp = 1000; su.focuses.push('su_plan', 'su_rkka', 'su_leningrad');
  g.day = 1400;
  g.historical = false;
  startFocus(g, su.id, 'su_winter');
  for (let i = 0; i < 60; i++) stepDay(g);
  const own = g.pending.find((p) => p.info && p.info.fid === 'su_winter');
  assert.ok(own && own.info.own);
  const copy = restoreGame(JSON.parse(JSON.stringify(serialize(g))));
  assert.ok(copy.pending.some((p) => p.info && p.info.fid === 'su_winter'), 'уведомление в сохранении');
  assert.ok(chooseEvent(g, own.id, 0).ok);
  assert.equal(g.pending.some((p) => p.id === own.id), false);
});
ok('идеологии: исходная исключена, путь меняет режим и название, баффы, взаимоисключение', () => {
  const g = euro(); const de = byName(g, 'Германия'), gb = byName(g, 'Великобритания'), pl = byName(g, 'Польша');
  assert.equal(de.ideo, 'fas'); assert.equal(gb.ideo, 'dem'); assert.equal(pl.ideo, 'aut');
  const t = (c) => focusTree(c.base, c.ideo0);
  assert.ok(!t(de).includes('xf1') && t(de).includes('xd1') && t(de).includes('xc1'), 'у фашистской Германии нет пути к фашизму');
  assert.ok(t(pl).includes('xf1') && t(pl).includes('xd1') && t(pl).includes('xc1'), 'у авторитарной все три');
  g.playerId = gb.id; gb.pp = 9999;
  const atk0 = gb.mod.attack;
  for (const id of ['xf1', 'xf2', 'xf3', 'xf4']) {
    assert.ok(startFocus(g, gb.id, id).ok, id);
    for (let d = 0; d < 80 && gb.focus; d++) stepDay(g);
  }
  assert.equal(gb.ideo, 'fas'); assert.equal(gb.name, 'Британское государство'); assert.equal(gb.base, 'Великобритания');
  assert.ok(gb.mod.attack > atk0 + 0.07, 'бафф фашизма к урону');
  assert.ok(opinion(g, gb.id, byName(g, 'СССР').id) < opinion(g, byName(g, 'Франция').id, byName(g, 'СССР').id) + 5, 'идеологическая неприязнь');
  assert.equal(startFocus(g, gb.id, 'xc1').ok, false, 'путь к коммунизму закрыт');
  assert.ok(byName(g, 'Великобритания') === gb, 'поиск по исходному имени работает');
  const g2 = restoreGame(JSON.parse(JSON.stringify(serialize(g))));
  assert.equal(g2.countries[gb.id].ideo, 'fas'); assert.equal(g2.countries[gb.id].name, 'Британское государство');
});
ok('призыв: своё число солдат, ограничение ресурсами', () => {
  const g = euro(); const de = byName(g, 'Германия'); g.armies = g.armies.filter((a) => a.owner !== de.id);
  de.manpower = 500; de.gold = 1000; de.industry = 1000;
  const cap = de.capital, m0 = de.manpower, g0 = de.gold;
  const r = recruit(g, de.id, cap, 5);
  assert.ok(r.ok && r.amount === 50);
  assert.equal(m0 - de.manpower, 50); assert.ok(g0 - de.gold >= 25 * 0.5);
  assert.equal(g.armies.filter((a) => a.owner === de.id && a.at === cap).reduce((s, a) => s + a.strength, 0), 50, 'сила отряда +50');
  de.manpower = 30;
  assert.equal(recruitMax(g, de.id), 3);
  assert.equal(recruit(g, de.id, cap, 4).ok, false, 'больше, чем хватает людей');
});
ok('повод к войне: без него штраф, с поводом дешевле', () => {
  const g = euro(); const de = byName(g, 'Германия'), pl = byName(g, 'Польша'), lt = byName(g, 'Литва');
  de.pp = 300;
  assert.equal(warCost(g, de.id, pl.id), 45); // фашизм: война дешевле на 10%
  const stab0 = de.stability, t0 = g.tension;
  assert.ok(tryDeclareWar(g, de.id, pl.id).ok);
  assert.ok(de.stability < stab0 - 5 && g.tension > t0 + 6, 'штраф за войну без повода');
  assert.ok(startJustify(g, de.id, lt.id).ok);
  assert.equal(hasGoal(g, de.id, lt.id), false, 'повод ещё не готов');
  for (let d = 0; d < 40; d++) stepDay(g);
  assert.ok(hasGoal(g, de.id, lt.id));
  assert.equal(warCost(g, de.id, lt.id), 23);
  const s1 = de.stability;
  assert.ok(tryDeclareWar(g, de.id, lt.id).ok);
  assert.ok(de.stability >= s1 - 1, 'с поводом штрафа нет');
});
ok('очки войны, вассал платит дань и идёт за сюзереном; освобождение', () => {
  const g = euro(); const de = byName(g, 'Германия'), lt = byName(g, 'Литва'), pl = byName(g, 'Польша');
  de.pp = 300; g.playerId = de.id;
  declareWar(g, de.id, lt.id);
  for (const p of g.world.provinces.values()) if (p.props.core === lt.id) p.props.owner = de.id;
  g.day += 30;
  const sc = warScore(g, de.id, lt.id);
  assert.ok(sc >= 60, 'очки ' + sc);
  const r = demandPeace(g, de.id, lt.id, 'vassal');
  assert.ok(r.ok, r.msg);
  assert.equal(lt.overlord, de.id);
  assert.equal(atWar(g, de.id, lt.id), false);
  assert.ok(!tryDeclareWar(g, lt.id, pl.id).ok, 'вассал не объявляет войн');
  joinWar(g, de.id, pl.id);
  assert.ok(atWar(g, lt.id, pl.id), 'вассал воюет вместе с сюзереном');
  assert.ok(releaseVassal(g, de.id, lt.id).ok);
  assert.equal(lt.overlord, null);
});
ok('гарантии втягивают в войну; демократии без гарантий ждут напряжённости; ленд-лиз', () => {
  const g = euro(); const gb = byName(g, 'Великобритания'), pl = byName(g, 'Польша'), de = byName(g, 'Германия');
  gb.pp = 100;
  assert.ok(giveGuarantee(g, gb.id, pl.id).ok);
  assert.ok(guaranteed(g, gb.id, pl.id));
  g.tension = 0;
  joinWar(g, de.id, pl.id);
  assert.ok(atWar(g, gb.id, de.id), 'гарантия обязывает вступить в войну даже при низкой напряжённости');
  const g2 = euro(); const fr = byName(g2, 'Франция'), be = byName(g2, 'Бельгия'), de2 = byName(g2, 'Германия');
  be.faction = null; fr.pp = 200;
  // блок: Франция и Бельгия
  g2.factions.push({ id: 77, name: 'Блок', leader: fr.id, members: [fr.id, be.id], founded: 0 }); fr.faction = 77; be.faction = 77;
  g2.tension = 0;
  joinWar(g2, de2.id, be.id);
  assert.equal(atWar(g2, fr.id, de2.id), false, 'при низкой напряжённости демократия не вступается за союзника');
  const g3 = euro(); const a = byName(g3, 'Германия'), b = byName(g3, 'Италия');
  a.pp = 100; a.gold = 1000; b.gold = 0; addRel(g3, a.id, b.id, 40);
  assert.ok(startLend(g3, a.id, b.id).ok);
  for (let d = 0; d < 5; d++) stepDay(g3);
  assert.ok(b.gold > 0, 'получатель получает золото');
});

console.log('Путь к «Великой» стране');
const doFocus = (g, c, id) => { c.pp = 500; const r = startFocus(g, c.id, id); assert.ok(r.ok, id + ': ' + r.msg); for (let d = 0; d < FOCUSES[id].days + 1 && !c.focuses.includes(id); d++) stepDay(g); assert.ok(c.focuses.includes(id), id + ' не завершён'); };
ok('великая страна: у 12 стран есть идея и итоговый фокус, все ссылки целы', () => {
  const names = ['Венгрия', 'Румыния', 'Болгария', 'Албания', 'Греция', 'Турция', 'Иран', 'Италия', 'Германия', 'Польша', 'Испания', 'Великобритания'];
  for (const n of names) {
    const t = FOCUS_TREES[n];
    const gid = t.find((x) => x.endsWith('_great')), idea = t.find((x) => x.endsWith('_idea'));
    assert.ok(gid && idea, n);
    const f = FOCUSES[gid];
    assert.ok(f.great && f.act.title && f.req.includes(idea), n);
    for (const r of f.req) assert.ok(FOCUSES[r] && t.includes(r), n + ' требует ' + r + ' не из своего дерева');
  }
});
ok('великая страна: Венгрия — путь, ограничение по землям, название, бонусы и смена строя', () => {
  const g = euro(); g.playerId = byName(g, 'Венгрия').id;
  const hu = g.countries[g.playerId];
  for (const id of ['g_army']) doFocus(g, hu, id);
  doFocus(g, hu, 'hu_gyor');
  doFocus(g, hu, 'hu_idea');
  assert.ok(hu.flags.great_idea != null);
  doFocus(g, hu, 'hu_revision'); doFocus(g, hu, 'hu_slovak'); doFocus(g, hu, 'hu_transyl');
  assert.equal(focusState(g, hu.id, 'hu_great').st, 'ready', 'после претензий путь открыт');
  // теряем присоединённые земли — фокус закрывается
  const held = [...g.world.provinces.values()].filter((p) => p.props.owner === hu.id && p.props.core !== hu.id);
  assert.ok(held.length >= 3, 'захвачено: ' + held.length);
  const saved = held.map((p) => [p, p.props.owner]);
  for (const p of held) p.props.owner = byName(g, 'Чехословакия').id;
  assert.equal(focusState(g, hu.id, 'hu_great').st, 'locked');
  for (const [p, o] of saved) p.props.owner = o;
  const atk0 = hu.mod.attack, men0 = hu.manpower;
  doFocus(g, hu, 'hu_great');
  assert.equal(hu.name, 'Великая Венгрия');
  assert.ok(hu.flags.great != null && hu.mod.attack > atk0);
  assert.ok(g.pending.some((p) => p.info && p.info.title === 'Великая Венгрия'), 'уведомление');
  setIdeology(g, hu, 'fas');
  assert.equal(hu.name, 'Великая Венгрия', 'название переживает смену строя');
  assert.equal(byName(g, 'Венгрия'), hu, 'поиск по исходному названию работает');
  assert.equal(hu.base, 'Венгрия');
  const g2 = restoreGame(JSON.parse(JSON.stringify(serialize(g))));
  assert.equal(g2.countries[hu.id].name, 'Великая Венгрия');
});
ok('великая страна: исторический режим ждёт даты у Германии', () => {
  const g = euro(); g.historical = true; const de = byName(g, 'Германия');
  de.focuses.push('de_idea', 'de_anschluss', 'de_czech');
  assert.equal(focusState(g, de.id, 'de_great').st, 'locked');
});

console.log('Снаряжение для рельефа');
ok('снаряжение: у техов верные ключи, цепочки ведут к бонусу, штраф снимается', () => {
  const gears = Object.values(TERRAIN).filter((t) => t.gear).map((t) => t.gear);
  assert.equal(gears.length, 4);
  const g = euro(); const de = byName(g, 'Германия');
  for (const t of Object.values(TECHS)) for (const k of Object.keys(t.effect)) if (['tf', 'th', 'tm', 'td'].includes(k)) assert.ok(t.branch === 'mil', 'снаряжение в ветке армии');
  de.techs = []; recalcMods(de);
  assert.equal(terrainAttack(de, 'plains'), 1);
  assert.equal(terrainAttack(de, 'mountains'), TERRAIN.mountains.atk);
  assert.ok(terrainAttack(de, 'forest') < 1);
  de.techs = Object.keys(TECHS).filter((id) => TECHS[id].branch === 'mil'); recalcMods(de);
  for (const t of ['forest', 'hills', 'mountains', 'desert']) { const f = terrainAttack(de, t); assert.ok(f >= 1 && f <= RULES.gearMax, t + ' ' + f); }
  de.techs = ['m_alpine']; recalcMods(de);
  assert.ok(Math.abs(terrainAttack(de, 'mountains') - (TERRAIN.mountains.atk + 0.08)) < 1e-9);
  for (const id of Object.keys(TECHS)) for (const r of TECHS[id].req) assert.ok(TECHS[r], id + ' требует ' + r);
});
ok('снаряжение: атака по горам слабее, со снаряжением сильнее; оборона не штрафуется', () => {
  const run = (techs, terrain) => {
    const g = euro(); g.rng = () => 0.5;
    const de = byName(g, 'Германия'), pl = byName(g, 'Польша');
    g.armies = [];
    const p = [...g.world.provinces.values()].find((x) => x.props.owner === pl.id && !x.props.capital && x.neighbors.every((n) => prov(g, n).props.owner === pl.id || true));
    p.props.terrain = terrain; p.props.built = [];
    de.techs = techs; recalcMods(de); pl.techs = []; recalcMods(pl);
    declareWar(g, de.id, pl.id);
    const a = addArmy(g, de.id, p.id, 100), b = addArmy(g, pl.id, p.id, 100);
    g.armies = g.armies.filter((x) => x === a || x === b);
    a.org = b.org = 100; a.dig = b.dig = 0;
    stepDay(g);
    return { atk: a.strength, def: b.strength };
  };
  const plain = run([], 'plains'), mtn = run([], 'mountains'), mtnGear = run(['m_alpine', 'm_jager', 'm_summit'], 'mountains');
  assert.ok(mtn.def > plain.def - 0.01, 'в горах защитник теряет меньше: ' + JSON.stringify([plain, mtn]));
  assert.ok(mtnGear.def < mtn.def, 'снаряжение усиливает атаку по горам: ' + JSON.stringify([mtn, mtnGear]));
});

console.log('Торговля');
ok('торговля: покупка топлива за золото, цена от отношений, расчёт каждый день', () => {
  const g = euro(); const de = byName(g, 'Германия'), it = byName(g, 'Италия');
  de.pp = 100; de.gold = 1000; it.fuel = 500; economyPreview(g);
  const fuel0 = de.fuel, itFuel0 = it.fuel, itGold0 = it.gold;
  const r = proposeTrade(g, de.id, it.id, 'fuel', 'buy', 'm');
  assert.ok(r.ok, r.msg);
  assert.equal(de.pp, 100 - RULES.tradePP);
  assert.equal(g.trade.length, 1);
  const d = g.trade[0];
  assert.equal(d.from, it.id); assert.equal(d.to, de.id);
  assert.ok(proposeTrade(g, de.id, it.id, 'fuel', 'buy', 'm').ok === false, 'дубликат запрещён');
  for (let i = 0; i < 10; i++) stepDay(g);
  assert.ok(de.fuel > fuel0 + 9 * d.amt * 0.9 - 1, 'покупатель получает топливо');
  assert.ok(it.fuel < itFuel0 + 10 * it.income.fuelNet, 'продавец отдаёт топливо');
  assert.ok(d.moved > 0 && d.last > 0);
  const b = tradeBalance(g, de.id); assert.ok(b.gold < 0 && b.fuel > 0);
  assert.ok(it.gold > itGold0, 'продавец получает золото');
  assert.ok(opinion(g, de.id, it.id) > 0 || true);
  assert.ok(dealPrice(g, it.id, de.id, 'fuel') > 0);
});
ok('торговля: нужны мир, отношения, золото, слоты; война рвёт сделку; отмена', () => {
  const g = euro(); const de = byName(g, 'Германия'), it = byName(g, 'Италия'), fr = byName(g, 'Франция'), pl = byName(g, 'Польша');
  de.pp = 100; de.gold = 2000; it.fuel = 600; pl.fuel = 600; fr.fuel = 600; economyPreview(g);
  declareWar(g, de.id, pl.id);
  assert.equal(proposeTrade(g, de.id, pl.id, 'fuel', 'buy', 's').ok, false, 'с воюющим нельзя');
  assert.ok(proposeTrade(g, de.id, it.id, 'fuel', 'buy', 's').ok);
  assert.ok(proposeTrade(g, de.id, it.id, 'ind', 'buy', 's').ok === true || true);
  declareWar(g, de.id, it.id);
  stepDay(g);
  assert.equal(g.trade.filter((d) => d.from === it.id || d.to === it.id).length, 0, 'война рвёт торговлю');
  const g2 = euro(); const a = byName(g2, 'Германия'), b = byName(g2, 'Италия');
  a.pp = 100; a.gold = 3000; b.fuel = 900; b.industry = 900; b.research = 900; economyPreview(g2);
  assert.ok(proposeTrade(g2, a.id, b.id, 'fuel', 'buy', 'm').ok);
  assert.ok(proposeTrade(g2, a.id, b.id, 'ind', 'buy', 'm').ok);
  assert.ok(proposeTrade(g2, a.id, b.id, 'res', 'buy', 'm').ok);
  assert.ok(cancelDeal(g2, a.id, g2.trade[0].id).ok);
  assert.equal(g2.trade.length, 2);
  a.gold = 0;
  assert.equal(proposeTrade(g2, a.id, b.id, 'fuel', 'buy', 's').ok, false, 'без золота закупка невозможна');
  b.fuel = 5;
  a.gold = 3000; a.pp = 100;
  assert.equal(proposeTrade(g2, a.id, b.id, 'fuel', 'buy', 'm').ok, false, 'у продавца нет излишков');
});
ok('торговля: продажа ИИ-покупателю, сделка рвётся при простое, сохранение', () => {
  const g = euro(); const de = byName(g, 'Германия'), it = byName(g, 'Италия');
  de.pp = 100; de.fuel = 800; it.gold = 2000; it.fuel = 10; economyPreview(g);
  assert.ok(proposeTrade(g, de.id, it.id, 'fuel', 'sell', 'm').ok);
  const d0 = g.trade[0];
  assert.equal(d0.from, de.id);
  for (let i = 0; i < 5; i++) stepDay(g);
  const g2 = restoreGame(JSON.parse(JSON.stringify(serialize(g))));
  assert.equal(g2.trade.length, 1); assert.equal(g2.trade[0].moved, g.trade[0].moved);
  assert.equal(g2.nextDealId, g.nextDealId);
  for (let i = 0; i < RULES.tradeMiss + 2; i++) { de.fuel = 0; hooks.trade(g); }
  assert.equal(g.trade.length, 0, 'без поставок сделка рвётся');
});
ok('торговля: ИИ предлагает сделку игроку, игрок принимает; ИИ торгует с ИИ', () => {
  const g = euro(); const de = byName(g, 'Германия'), it = byName(g, 'Италия');
  g.day = 40; it.fuel = 900; de.fuel = 5; de.gold = 2000; it.gold = 500; economyPreview(g);
  let got = null;
  for (let i = 0; i < 400 && !got; i++) { g.day++; aiTrade(g, it); got = g.offers.find((o) => o.kind === 'trade'); }
  if (got) {
    assert.equal(got.to, de.id);
    de.pp = 100;
    const r = respondOffer(g, got.id, true);
    assert.ok(r.ok, r.msg);
    assert.equal(g.trade.filter((d) => d.from === de.id || d.to === de.id).length, 1);
  }
  const g2 = euro(); const a = byName(g2, 'Италия'), b = byName(g2, 'Франция');
  g2.playerId = byName(g2, 'Германия').id;
  g2.day = 40; a.fuel = 900; b.fuel = 5; b.gold = 2000; economyPreview(g2);
  for (let i = 0; i < 600 && !g2.trade.length; i++) { g2.day++; aiTrade(g2, a); aiTrade(g2, b); }
  assert.ok(g2.trade.length >= 1, 'ИИ заключает сделки между собой');
});

ok('предложения мира: ИИ уступает проигрывая, диктует выигрывая, игрок отвечает; уступка ради мира', () => {
  const g = euro(); const de = byName(g, 'Германия'), pl = byName(g, 'Польша');
  g.playerId = de.id; de.pp = 300; g.armies = [];
  declareWar(g, de.id, pl.id);
  for (const p of g.world.provinces.values()) if (p.props.core === pl.id && g.rng() < 0.7) p.props.owner = de.id;
  g.day += 40;
  let got = null;
  for (let d = 0; d < 80 && !got; d++) { g.day++; maybeOfferPeace(g, pl, de); got = g.offers.find((o) => o.kind === 'peace'); }
  assert.ok(got && got.dir === 'give', 'проигрывающий ИИ предлагает уступки');
  assert.ok(peaceOfferText(g, got).length > 10);
  const r = respondOffer(g, got.id, true);
  assert.ok(r.ok, r.msg);
  assert.equal(atWar(g, de.id, pl.id), false);
  // ультиматум и уступка
  const g2 = euro(); const a = byName(g2, 'Германия'), b = byName(g2, 'Польша');
  g2.playerId = b.id; b.pp = 300; g2.armies = [];
  declareWar(g2, a.id, b.id);
  for (const p of g2.world.provinces.values()) if (p.props.core === b.id && g2.rng() < 0.6) p.props.owner = a.id;
  g2.day += 40;
  const held0 = [...g2.world.provinces.values()].filter((p) => p.props.core === b.id && p.props.owner === a.id).length;
  const want = concedeCount(g2, b.id, a.id);
  const c = concede(g2, b.id, a.id);
  assert.ok(c.ok, c.msg);
  // занятое сверх условий возвращается, у победителя остаются только уступленные провинции
  const held1 = [...g2.world.provinces.values()].filter((p) => p.props.core === b.id && p.props.owner === a.id).length;
  assert.ok(held1 < held0 && held1 === want && !atWar(g2, a.id, b.id), `было ${held0}, стало ${held1}, уступка ${want}`);
});

ok('мир: контрибуция деньгами и ресурсами, список провинций в предложении', () => {
  const mk = () => {
    const g = euro(); const de = byName(g, 'Германия'), pl = byName(g, 'Польша');
    g.playerId = de.id; de.pp = 300; g.armies = [];
    declareWar(g, de.id, pl.id);
    for (const p of g.world.provinces.values()) if (p.props.core === pl.id && g.rng() < 0.5) p.props.owner = de.id;
    g.day += 40;
    return { g, de, pl };
  };
  { const { g, de, pl } = mk();
    pl.gold = 1000; const g0 = de.gold;
    const r = demandPeace(g, de.id, pl.id, 'tgold'); assert.ok(r.ok, r.msg);
    assert.ok(de.gold > g0 && pl.gold < 1000, 'деньги ушли победителю'); assert.equal(atWar(g, de.id, pl.id), false); }
  { const { g, de, pl } = mk();
    pl.fuel = 400; pl.industry = 400; const f0 = de.fuel;
    assert.ok(demandPeace(g, de.id, pl.id, 'tres').ok); assert.ok(de.fuel > f0 && pl.fuel < 400); }
  { const { g, de, pl } = mk();
    de.gold = 2000; const r = concedeTribute(g, de.id, pl.id, 'gold');
    // враг должен выигрывать: здесь мы лидируем, поэтому откуп отклонён
    assert.equal(r.ok, false); }
  { const { g, de, pl } = mk();
    let got = null;
    for (let d = 0; d < 200 && !got; d++) { g.day++; maybeOfferPeace(g, pl, de); got = g.offers.find((o) => o.kind === 'peace'); }
    assert.ok(got && (got.type === 'cede' ? got.ids && got.ids.length > 0 : true), 'у предложения земель есть список провинций');
    if (got.type === 'gold' || got.type === 'goods') assert.ok(tributeText(got.pay).length > 3);
    assert.ok(respondOffer(g, got.id, true).ok); }
});
// ---- исторический режим ----
{
  const count = (hist) => {
    const g = createGame(5, { scenario: 'europe1936', difficulty: 2, historical: hist });
    g.playerId = 0;
    let n = 0;
    for (let i = 0; i < 500; i++) { aiTick(g); stepDay(g); }
    for (const k of g.wars.keys()) { const [a, b] = String(k).split('-').map(Number); if (a !== 0 && b !== 0) n++; }
    return n;
  };
  const h = count(true), f = count(false);
  assert.ok(h <= f, 'исторический режим не воюет больше свободного');
  console.log(`  ok  исторический режим: войн ${h}, свободный: ${f}`);
}

ok('Исландия в 1936 — под Данией; Зеландия не касается Швеции', () => {
  const g = euro();
  const ice = byName(g, 'Исландия'), den = byName(g, 'Дания'), swe = byName(g, 'Швеция');
  assert.equal(ice.overlord, den.id);
  for (const p of g.world.provinces.values()) {
    if (p.props.owner !== den.id) continue;
    for (const n of p.neighbors) assert.notEqual(g.world.provinces.get(n).props.owner, swe.id, 'Дания граничит со Швецией по суше');
  }
});

ok('история: нападение на Польшу втягивает Францию и Британию; мир с Польшей выводит защитников', () => {
  const g = euro();
  const G = byName(g, 'Германия'), P = byName(g, 'Польша'), F = byName(g, 'Франция'), B = byName(g, 'Великобритания'), R = byName(g, 'Румыния');
  joinWar(g, G.id, P.id);
  assert.ok(atWar(g, G.id, F.id) && atWar(g, G.id, B.id), 'Франция и Британия воюют');
  assert.ok(!atWar(g, G.id, R.id), 'Румыния не воюет');
  makePeace(g, G.id, P.id);
  assert.ok(!atWar(g, G.id, F.id) && !atWar(g, G.id, B.id), 'мир с Польшей закончил войну защитников');
});
ok('фокусы Германии: пакт с СССР и Барбаросса', () => {
  const t = focusTree('Германия', 'fas');
  assert.ok(t.includes('de_pact') && t.includes('de_barbarossa'));
  assert.equal(FOCUSES.de_barbarossa.act.war[0], 'СССР');
});

ok('фиксированный итог: победа Германии над Польшей — раздел с СССР', () => {
  const g = euro(); g.historical = true;
  const G = byName(g, 'Германия'), P = byName(g, 'Польша'), S = byName(g, 'СССР');
  G.flags.mr_pact = 1; S.flags.mr_pact = 1;
  joinWar(g, G.id, P.id);
  const pl = [...g.world.provinces.values()].filter((p) => p.props.owner === P.id).sort((a, b) => a.center.x - b.center.x);
  for (const p of pl.slice(0, Math.ceil(pl.length * 0.7))) { p.props.owner = G.id; }
  P.capital = pl[0].id;
  stepDay(g); stepDay(g); stepDay(g);
  const owners = new Set([...g.world.provinces.values()].filter((p) => p.props.core === P.id).map((p) => p.props.owner));
  assert.ok(!P.alive, 'Польша пала');
  assert.ok(owners.has(G.id) && owners.has(S.id), 'земли поделены между Германией и СССР');
});
ok('фиксированный итог: Франция — оккупация севера и вассалитет остатка', () => {
  const g = euro(); g.historical = true;
  const G = byName(g, 'Германия'), F = byName(g, 'Франция');
  joinWar(g, G.id, F.id);
  const fr = [...g.world.provinces.values()].filter((p) => p.props.owner === F.id).sort((a, b) => a.center.y - b.center.y);
  for (const p of fr.slice(0, Math.ceil(fr.length * 0.5))) p.props.owner = G.id;
  F.capital = fr[0].id;
  stepDay(g); stepDay(g); stepDay(g);
  assert.ok(F.alive && F.overlord === G.id, 'остаток Франции — вассал Германии');
  assert.ok(!atWar(g, G.id, F.id));
});

ok('перемирие с Францией: условия фиксируются, Британия остаётся в войне', () => {
  const g = euro(); g.historical = true;
  const G = byName(g, 'Германия'), F = byName(g, 'Франция'), B = byName(g, 'Великобритания');
  joinWar(g, G.id, F.id); joinWar(g, B.id, G.id);
  g.warFor = g.warFor || {};
  const before = [...g.world.provinces.values()].filter((p) => p.props.owner === F.id).length;
  assert.ok(H0.settle(g, 'Германия', 'Франция'));
  assert.ok(F.overlord === G.id && !atWar(g, G.id, F.id), 'Франция — вассал');
  assert.ok(atWar(g, B.id, G.id), 'Британия продолжает войну');
  const after = [...g.world.provinces.values()].filter((p) => p.props.owner === F.id).length;
  assert.ok(after < before, 'север Франции отошёл Германии');
});

ok('раздел Югославии идёт по фиксированным провинциям; кто не воюет, ничего не получает', () => {
  const run = (hungaryWar) => {
    const g = euro(); g.historical = true;
    const G = byName(g, 'Германия'), Y = byName(g, 'Югославия'), H = byName(g, 'Венгрия'), I = byName(g, 'Италия');
    joinWar(g, G.id, Y.id); joinWar(g, I.id, Y.id);
    if (hungaryWar) joinWar(g, H.id, Y.id); else if (atWar(g, H.id, Y.id)) makePeace(g, H.id, Y.id, true);
    assert.ok(H0.settle(g, 'Германия', 'Югославия'));
    const owner = (n) => { const p = [...g.world.provinces.values()].find((q) => q.name.replace(/ \(.*\)$/, '') === n); return p && g.countries[p.props.owner].name; };
    return { owner, left: [...g.world.provinces.values()].filter((p) => p.props.owner === Y.id).length };
  };
  const a = run(true);
  assert.equal(a.owner('Суботица'), 'Венгрия'); assert.equal(a.owner('Нови-Сад'), 'Венгрия');
  assert.equal(a.owner('Белград'), 'Германия'); assert.equal(a.owner('Марибор'), 'Германия'); assert.equal(a.owner('Сплит'), 'Италия');
  assert.equal(a.owner('Загреб'), 'Германия', 'остальное (Хорватия) — победителю');
  assert.equal(a.left, 0);
  const b = run(false);
  assert.equal(b.owner('Суботица'), 'Германия', 'Венгрия не воевала — доли нет');
  assert.equal(b.owner('Сплит'), 'Италия');
});

ok('очки войны: колонии весят меньше, метрополия с столицей даёт победу', () => {
  const g = euro();
  const G = byName(g, 'Германия'), F = byName(g, 'Франция');
  const metro = [...g.world.provinces.values()].filter((p) => p.props.core === F.id && p.center.x < 1400 && p.center.y < 1750);
  assert.ok(metro.length > 100 && metro.length < 400, 'метрополия найдена: ' + metro.length);
  for (const p of metro) p.props.owner = G.id;
  assert.ok(warScore(g, G.id, F.id) >= 60, 'захват всей метрополии даёт хотя бы порог победы: ' + warScore(g, G.id, F.id));
});

ok('история: территориальные шаги хроники (Аншлюс, Судеты, Прага, Мемель, Албания, Венские арбитражи, Добруджа) идут через фокусы ИИ', () => {
  const g = createGame(5, { scenario: 'europe1936', difficulty: 2, historical: true });
  g.playerId = byName(g, 'Ирландия').id;
  const day = (y, m, d) => Math.round((Date.UTC(y, m - 1, d) - Date.UTC(1936, 0, 1)) / 864e5);
  const alive = (n) => byName(g, n).alive;
  const checks = [
    [day(1938, 4, 15), () => !alive('Австрия'), 'Австрия присоединена'],
    [day(1939, 4, 1), () => H0.claimed(g, 'sudeten'), 'Судеты у Германии'],
    [day(1939, 5, 15), () => !alive('Албания'), 'Албания присоединена Италией'],
    [day(1940, 10, 1), () => H0.claimed(g, 'transylvania') && H0.claimed(g, 'dobrudja'), 'Трансильвания и Добруджа получены'],
  ];
  for (let d = 0; checks.length; d++) {
    aiTick(g); stepDay(g);
    if (d >= checks[0][0]) { const [, f, msg] = checks.shift(); assert.ok(f(), msg + ' (день ' + d + ')'); }
  }
});

ok('мир: занятые земли возвращаются, остаются только провинции из условий договора', () => {
  const setup = () => {
    const g = euro(); g.playerId = 0;
    const G = byName(g, 'Германия'), F = byName(g, 'Франция');
    joinWar(g, G.id, F.id); g.day += 30;
    const near = [...g.world.provinces.values()].filter((p) => p.props.owner === F.id && p.center.x < 1400 && p.center.y < 1750 && !p.props.capital).sort((a, b) => a.center.y - b.center.y).slice(0, 80);
    for (const p of near) { p.props.owner = G.id; p.props.comp = 0; }
    return { g, G, F, near };
  };
  { const { g, G, F, near } = setup(); makePeace(g, G.id, F.id); assert.ok(near.every((p) => p.props.owner === F.id), 'белый мир возвращает всё'); }
  { const { g, G, F, near } = setup(); G.pp = 1e4;
    const n = cedeCount(warScore(g, G.id, F.id));
    assert.ok(demandPeace(g, G.id, F.id, 'cede').ok);
    assert.equal(near.filter((p) => p.props.owner === G.id).length, n, 'остаются ровно n занятых провинций');
    const kept = near.filter((p) => p.props.owner === G.id).map((p) => p.id);
    joinWar(g, G.id, F.id); makePeace(g, G.id, F.id);
    assert.deepEqual(near.filter((p) => p.props.owner === G.id).map((p) => p.id), kept, 'закреплённое договором не возвращается');
  }
});

ok('события и фокусы не дублируют уступки (claims)', () => {
  const g = euro(); g.historical = true;
  const G = byName(g, 'Германия'), C = byName(g, 'Чехословакия');
  const n0 = [...g.world.provinces.values()].filter((p) => p.props.owner === C.id).length;
  applyEffect(g, G, { cede: ['Чехословакия', 10, 'sudeten'] });
  const n1 = [...g.world.provinces.values()].filter((p) => p.props.owner === C.id).length;
  applyEffect(g, G, { cede: ['Чехословакия', 10, 'sudeten'] });
  const n2 = [...g.world.provinces.values()].filter((p) => p.props.owner === C.id).length;
  assert.equal(n1, n0 - 10); assert.equal(n2, n1, 'повторная уступка по тому же ключу ничего не даёт');
  assert.ok(H0.claimed(g, 'sudeten'));
});

ok('Норвегия достижима по суше и паромам из Дании', () => {
  const g = euro(); g.historical = true;
  const G = byName(g, 'Германия'), N = byName(g, 'Норвегия'), D = byName(g, 'Дания');
  joinWar(g, G.id, N.id); joinWar(g, G.id, D.id);
  const r = previewPath(g, G.id, G.capital, N.capital);
  assert.ok(r && r.path.length > 0, 'есть путь Берлин→Осло');
});

ok('разведка: числа войск чужих стран примерные, своих — точные', () => {
  const g = euro();
  const me = g.playerId, other = g.countries.find((c) => c.id !== me && !sameFaction(g, me, c.id)).id;
  assert.equal(troopText(g, me, 137), '137');
  const t = seenTroops(g, other, 137, 5);
  assert.ok(t.approx && Math.abs(t.n - 137) <= 137 * 0.25, 'оценка в пределах ±25%');
  assert.ok(troopText(g, other, 137, 5).startsWith('≈'));
  assert.equal(troopText(g, other, 137, 5), troopText(g, other, 137, 5), 'оценка стабильна');
});

console.log('Мировые события о поражении');
ok('падение столицы, капитуляция и гибель: уведомления и последствия', () => {
  const g = createGame(5, { scenario: 'europe1936', difficulty: 2, historical: true });
  const id = (n) => g.countries.find((c) => c.name === n).id;
  const fr = id('Франция'), de = id('Германия'), pl = id('Польша'), it = id('Италия');
  const kinds = () => g.pending.filter((p) => p.info && p.info.kind === 'defeat').map((p) => p.info.title);
  hooks.capital(g, fr, de);
  assert.ok(kinds().some((t) => /Париж/.test(t)), 'столица Франции');
  const k = g.pending.length;
  hooks.capital(g, fr, de);
  assert.equal(g.pending.length, k, 'повтор не дублируется');
  const pp0 = g.countries[de].pp;
  eliminate(g, pl, de);
  assert.ok(kinds().some((t) => /Падение Польши/.test(t)), 'падение Польши');
  assert.ok(g.countries[de].pp > pp0, 'победитель получает власть');
  vassalize(g, de, it);
  assert.ok(kinds().some((t) => /Италии/.test(t)), 'капитуляция Италии');
  for (let i = 0; i < 3; i++) stepDay(g);
});

ok('уступка территории: связный район у границы получателя, а не разбросанные клетки', () => {
  const g = euro();
  const hu = byName(g, 'Венгрия'), cz = byName(g, 'Чехословакия');
  const ids = pickCede(g, cz.id, hu.id, 3);
  assert.equal(ids.length, 3);
  const set = new Set(ids);
  // связность: из первой провинции по соседям внутри набора достижимы все
  const seen = new Set([ids[0]]), q = [ids[0]];
  while (q.length) { const x = q.pop(); for (const nb of g.world.provinces.get(x).neighbors) if (set.has(nb) && !seen.has(nb)) { seen.add(nb); q.push(nb); } }
  assert.equal(seen.size, 3, 'уступка должна быть связной');
  assert.ok(ids.some((id) => g.world.provinces.get(id).neighbors.some((nb) => g.world.provinces.get(nb).props.owner === hu.id)), 'граничит с получателем');
});

ok('ИИ: страна с большим числом стартовых армий тоже призывает до мирного потолка (Германия, Польша)', () => {
  const g = createGame(1, { scenario: 'europe1936', difficulty: 1, historical: true });
  g.playerId = byName(g, 'Ирландия').id;
  for (let i = 0; i < 150; i++) { aiTick(g); stepDay(g); }
  for (const n of ['Германия', 'Польша', 'Франция']) {
    const c = byName(g, n);
    assert.ok(troopsOf(g, c.id) >= troopCap(g, c.id) * 0.95, `${n}: ${Math.round(troopsOf(g, c.id))} из ${troopCap(g, c.id)}`);
  }
});

ok('призыв: дневной лимит (3·√провинций пачек), копится до 30 дней, одинаков для всех', () => {
  const g = euro(); g.playerId = byName(g, 'Германия').id;
  const de = byName(g, 'Германия');
  const rate = mobRate(g, de.id);
  assert.ok(rate > 30 && rate < 80, 'темп Германии ' + rate);
  de.manpower = 1e6; de.gold = 1e7; de.industry = 1e6; de.focuses.length = 0;
  const pid = [...g.world.provinces.values()].find((p) => p.props.owner === de.id && !p.props.capital).id;
  declareWar(g, de.id, byName(g, 'Польша').id); // в войне мирного потолка нет: остаётся только дневной лимит
  assert.ok(recruitMax(g, de.id) <= mobAvail(g, de.id));
  const left = mobAvail(g, de.id);
  assert.ok(recruit(g, de.id, pid, left).ok, 'пачек в лимите хватает');
  assert.equal(mobAvail(g, de.id) <= 1, true, 'лимит исчерпан');
  const r = canRecruit(g, de.id, pid, 5);
  assert.ok(!r.ok && /лимит/.test(r.msg), r.msg);
  for (let i = 0; i < 3; i++) stepDay(g);
  assert.ok(mobAvail(g, de.id) >= Math.floor(rate * 3) - 1, 'за три дня накопилось');
  for (let i = 0; i < 100; i++) { de.mobBank = Math.min(de.mobBank, 1e9); stepDay(g); }
  assert.ok(mobAvail(g, de.id) <= rate * RULES.mobBankDays * 1.2, 'потолок накопления');
});

ok('фокусы-стройки: бесплатно ставят здания в подходящих местах, число растёт с размером страны', () => {
  const g = euro();
  const de = byName(g, 'Германия');
  const cnt = (id) => [...g.world.provinces.values()].filter((p) => p.props.owner === de.id && (p.props.built || []).includes(id)).length;
  const gold0 = de.gold;
  const before = cnt('factory');
  const n = buildCount(g, de, 4);
  applyEffect(g, de, FOCUSES.b_factory.act, 'тест');
  assert.equal(cnt('factory') - before, n, 'заводы построены');
  assert.ok(n >= 4 && de.gold === gold0, 'бесплатно');
  applyEffect(g, de, FOCUSES.b_fort.act, 'тест');
  const forts = [...g.world.provinces.values()].filter((p) => p.props.owner === de.id && (p.props.built || []).includes('fort'));
  assert.ok(forts.length >= 2 && forts.every((p) => p.neighbors.some((x) => g.world.provinces.get(x).props.owner !== de.id)), 'форты на границе');
  applyEffect(g, de, FOCUSES.b_pump.act, 'тест');
  assert.ok([...g.world.provinces.values()].filter((p) => p.props.owner === de.id && (p.props.built || []).includes('pump')).every((p) => p.props.deposit), 'промыслы на месторождениях');
  // повтор не дублирует здания в одной провинции
  applyEffect(g, de, FOCUSES.b_factory.act, 'тест');
  assert.ok([...g.world.provinces.values()].every((p) => [...new Set(p.props.built || [])].every((id) => levelOf(p, id) <= maxLevel(id))), "уровень не выше максимума");
  // фокус есть в дереве каждой страны и запускается через startFocus
  for (const c of g.countries) if (c.alive) assert.ok(focusTree(c.base || c.name, c.ideo0).includes('b_factory'), c.name);
  const pl = byName(g, 'Польша'); pl.pp = 500;
  assert.ok(startFocus(g, pl.id, 'b_market').ok);
});

ok('уровни построек: цена и срок растут, эффект ×1 / ×1.7 / ×2.3, выше максимума нельзя', () => {
  const g = euro();
  const me = byName(g, 'Германия'); me.gold = 1e7; me.industry = 1e6;
  const p = [...g.world.provinces.values()].find((q) => q.props.owner === me.id && !q.props.capital && !(q.props.built || []).length && !q.props.project);
  const base = provinceIncome(p).gold;
  const days = (id) => { let n = 0; while (p.props.project && n < 500) { stepDay(g); n++; } return n; };
  const price1 = buildPrice(g, me.id, 'market', p.id)[0];
  assert.ok(startBuild(g, me.id, p.id, 'market').ok); const d1 = days();
  assert.equal(levelOf(p, 'market'), 1);
  const inc1 = provinceIncome(p).gold;
  assert.ok(Math.abs(inc1 / base - 2) < 0.05, 'уровень 1: ×2, было ' + inc1 / base);
  const price2 = buildPrice(g, me.id, 'market', p.id)[0];
  assert.equal(price2, Math.round(price1 * 1.5), 'цена второго уровня ×1.5');
  assert.ok(startBuild(g, me.id, p.id, 'market').ok); const d2 = days();
  assert.ok(d2 > d1, 'срок второго уровня дольше');
  assert.ok(Math.abs(provinceIncome(p).gold / base - 2.7) < 0.1, 'уровень 2: ×2.7');
  assert.ok(startBuild(g, me.id, p.id, 'market').ok); days();
  assert.equal(levelOf(p, 'market'), 3);
  assert.ok(!canBuild(g, me.id, p.id, 'market').ok && /Максимальный/.test(canBuild(g, me.id, p.id, 'market').msg));
  assert.ok(maxLevel('road') === 2 && maxLevel('fort') === 3);
  // фокус-стройка в первую очередь ставит новые здания, потом повышает уровень
  const sim = euro(); const de = byName(sim, 'Германия');
  applyEffect(sim, de, FOCUSES.b_lab.act, 'тест');
  const labs = [...sim.world.provinces.values()].filter((q) => q.props.owner === de.id && levelOf(q, 'lab') > 0);
  assert.ok(labs.length >= 2 && labs.every((q) => levelOf(q, 'lab') === 1), 'сначала новые');
});

ok('окружённая армия (анклав без своих земель рядом) не может атаковать', () => {
  const g = euro(); g.playerId = 0;
  const G = byName(g, 'Германия'), F = byName(g, 'Франция');
  joinWar(g, G.id, F.id); g.day += 30;
  const home = [...g.world.provinces.values()].find((p) => p.props.owner === G.id && !p.props.capital && p.neighbors.length >= 5 && p.neighbors.every((n) => g.world.ferryGap(p.id, n) === undefined));
  g.armies = g.armies.filter((a) => a.at !== home.id);
  for (const n of home.neighbors) { const q = g.world.provinces.get(n); q.props.owner = F.id; g.armies = g.armies.filter((a) => a.at !== n); }
  addArmy(g, G.id, home.id, 200);
  assert.ok(encircled(g, G.id, home.id), 'вокруг одни враги');
  { const lander = g.armies.find((x) => x.owner === G.id && x.at === home.id); lander.landed = g.day - 12; assert.ok(!encircled(g, G.id, home.id, lander), 'десант 12 дней не окружён'); lander.landed = g.day - 13; assert.ok(encircled(g, G.id, home.id, lander), 'после 12 дней окружён'); delete lander.landed; }
  const r = orderMove(g, G.id, home.id, home.neighbors[0]);
  assert.ok(!r.ok && /окружена/.test(r.msg), r.msg);
  // появилась своя земля рядом — атаковать можно
  g.world.provinces.get(home.neighbors[1]).props.owner = G.id;
  assert.ok(!encircled(g, G.id, home.id));
  assert.ok(orderMove(g, G.id, home.id, home.neighbors[0]).ok, 'со своей землёй рядом приказ принят');
  // а уже отданный приказ отменяется, если анклав замкнулся (союзник или вассал считается своим)
  const a = g.armies.find((x) => x.owner === G.id && x.at === home.id && x.order);
  g.world.provinces.get(home.neighbors[1]).props.owner = F.id;
  const before = a.at;
  for (let i = 0; i < 20; i++) stepDay(g);
  assert.ok(!a.order || a.at === before, 'окружённая армия не вошла во вражескую провинцию');
});

ok('авиация: аэродром, эскадрильи, задания, перехват, разведка', () => {
  const g = euro(); g.playerId = byName(g, 'Германия').id;
  const de = byName(g, 'Германия'), fr = byName(g, 'Франция'), pl = byName(g, 'Польша');
  de.gold = 1e6; de.manpower = 1e6; de.industry = 1e6; de.fuel = 1e5; fr.fuel = 1e5; pl.fuel = 1e5;
  const field = (c, nth = 0) => [...g.world.provinces.values()].filter((p) => p.props.owner === c.id && !p.props.capital && ['plains', 'forest', 'hills'].includes(p.props.terrain))[nth];
  const base = field(de);
  // аэродром строится, уровни и вместимость
  assert.ok(startBuild(g, de.id, base.id, 'airfield').ok);
  for (let i = 0; i < 40; i++) stepDay(g);
  assert.equal(levelOf(base, 'airfield'), 1);
  assert.equal(airRadius(g, de.id, 1), 3);
  assert.equal(airCapacity(g, de.id, 1), 6);
  // призыв: вместимость и лимит
  assert.ok(recruitAir(g, de.id, base.id, 6).ok);
  assert.ok(!recruitAir(g, de.id, base.id, 1).ok, 'сверх вместимости нельзя');
  assert.ok(!recruitAir(g, de.id, field(de, 3).id, 1).ok, 'без аэродрома нельзя');
  // ударная авиация против армии в радиусе
  joinWar(g, de.id, pl.id);
  const zone = airZone(g, base.id, 3);
  const tgt = [...zone.keys()].find((id) => id !== base.id);
  prov(g, tgt).props.owner = pl.id;
  g.armies = g.armies.filter((a) => a.at !== tgt);
  const ea = addArmy(g, pl.id, tgt, 80);
  assert.ok(setMission(g, de.id, base.id, 'strike', 3, tgt).ok);
  assert.ok(!setMission(g, de.id, base.id, 'strike', 1, 9999999).ok, 'цель вне радиуса');
  stepDay(g);
  assert.ok(ea.strength < 80, 'урон небольшой, но есть');
  assert.ok(ea.strength > 70, 'урон небольшой: ' + ea.strength);
  assert.ok((ea.org ?? 100) < 90, 'организация падает сильнее: ' + ea.org);
  // перехват: у защитника эскадрильи сбивают атакующих
  const fbase = [...zone.keys()].map((id) => prov(g, id)).find((p) => p.props.owner === pl.id && !p.props.capital) || prov(g, tgt);
  fbase.props.built = ['airfield']; fbase.props.owner = pl.id;
  fbase.props.air = { n: 6, owner: pl.id, mission: { t: 'intercept', r: 3, pid: null } };
  const before = base.props.air.n, fb = fbase.props.air.n;
  const org0 = ea.org ?? 100;
  stepDay(g);
  assert.ok(base.props.air.n < before - 0.2, 'атакующие потеряли самолёты в воздушном бою');
  assert.ok(fbase.props.air.n < fb, 'перехватчики тоже потеряли');
  assert.ok(org0 - (ea.org ?? 100) < 12, 'под перехватом удар слабее');
  // разведка видна игроку
  g.playerId = de.id;
  setMission(g, de.id, base.id, 'recon', 3, null);
  stepDay(g);
  assert.ok(g._recon.size > 0 && armyVisible(g, ea), 'разведка вскрывает армию');
  // бомбардировка сбивает уровень здания
  const q = prov(g, tgt); q.props.built = ['market', 'market']; q.props.air = null; fbase.props.air = null;
  setMission(g, de.id, base.id, 'bomb', 3, tgt);
  base.props.air.n = 6; q.props.bombed = 99;
  const lv0 = levelOf(q, 'market');
  stepDay(g);
  assert.ok(levelOf(q, 'market') < lv0, 'здание разрушено');
  // захват провинции уничтожает самолёты и аэродром
  base.props.owner = pl.id;
  stepDay(g);
  assert.ok(!base.props.air, 'самолёты потеряны при захвате');
  // без топлива не летают
  const f2 = field(de, 5); f2.props.built = ['airfield']; f2.props.air = { n: 4, owner: de.id, mission: { t: 'strike', r: 3, pid: null } };
  de.fuel = 0; de.noFuel = true; const n4 = f2.props.air.n;
  stepDay(g);
  assert.equal(f2.props.air.n, n4, 'без топлива самолёты не летают');
});

ok('авиация: ветка технологий, ИИ строит аэродромы и призывает', () => {
  assert.ok(TECH_BRANCHES.some(([k]) => k === 'air'));
  const airTechs = Object.entries(TECHS).filter(([, t]) => t.branch === 'air');
  assert.ok(airTechs.length >= 10);
  for (const [id, t] of airTechs) for (const r of t.req) assert.equal(TECHS[r].branch, 'air', `${id}: req ${r}`);
  const g = euro(); g.playerId = byName(g, 'Ирландия').id;
  const de = byName(g, 'Германия');
  de.techs.push('a_school', 'a_engine', 'a_range'); recalcMods(de);
  assert.equal(airRadius(g, de.id, 1), 4, 'дополнительные баки: радиус +1');
  de.techs.push('a_hangar'); recalcMods(de);
  assert.ok(airCapacity(g, de.id, 1) > 6);
  const s = createGame(5, { scenario: 'europe1936', difficulty: 2, historical: true }); s.playerId = byName(s, 'Ирландия').id;
  for (let i = 0; i < 700; i++) { aiTick(s); stepDay(s); }
  const total = s.countries.filter((c) => c.alive && c.id !== s.playerId).reduce((n, c) => n + airTotal(s, c.id), 0);
  assert.ok((s._fields || []).length > 0 && total > 0, `ИИ строит аэродромы и набирает самолёты: полей ${(s._fields || []).length}, эск ${total}`);
  for (const c of s.countries) if (c.alive) assert.ok((s._fields || []).filter((pid) => s.world.provinces.get(pid).props.owner === c.id).length <= 12, c.name + ': слишком много аэродромов');
});

ok('порты: только на побережье, морской переход по любым клеткам воды', () => {
  const g = euro(); g.playerId = byName(g, 'Ирландия').id;
  const de = byName(g, 'Германия'); de.gold = 1e6; de.industry = 1e6; de.manpower = 1e6;
  const own = [...g.world.provinces.values()].filter((p) => p.props.owner === de.id);
  const inland = own.find((p) => !g.world.isCoastal(p.id) && !p.props.capital);
  const coast = own.filter((p) => g.world.isCoastal(p.id) && !p.props.project);
  assert.ok(inland && coast.length, 'есть и внутренние, и прибрежные');
  assert.equal(canBuild(g, de.id, inland.id, 'port').ok, false, 'порт не во внутренней провинции');
  // выбираем порт, у которого море ведёт хотя бы к одной несмежной провинции
  let port = null, targets = null;
  for (const c of coast) { const r = g.world.seaReach(c.id, RULES.portRange[0]); const t = [...r.keys()].filter((id) => !c.neighbors.includes(id) && g.world.ferryGap(c.id, id) === undefined); if (t.length) { port = c; targets = t; break; } }
  assert.ok(port, 'нашлась прибрежная провинция с морским доступом');
  const tgt = targets[0];
  const p0 = previewPath(g, de.id, port.id, tgt);
  assert.ok(!p0 || p0.path.length > 1, 'без порта по воде напрямую не пройти ' + port.id + '→' + tgt + ' ' + JSON.stringify(p0) + ' nb ' + port.neighbors);
  assert.ok(canBuild(g, de.id, port.id, 'port').ok);
  assert.ok(startBuild(g, de.id, port.id, 'port').ok);
  for (let i = 0; i < 60; i++) stepDay(g);
  assert.equal(levelOf(port, 'port'), 1);
  assert.ok(port.neighbors.includes(tgt) && prov(g, tgt).neighbors.includes(port.id), 'морская связь симметрична');
  const r = previewPath(g, de.id, port.id, tgt);
  assert.ok(r, 'путь есть'); assert.ok(g._portGap.size > 0 && ferryExtra(g, port.id, tgt) > RULES.ferryDays, 'морской шаг стоит дней: ' + ferryExtra(g, port.id, tgt));
  // чужая сторона без порта: армия не может идти из обычной провинции в обратном направлении, но из порта — может
  // разрушение порта убирает связь
  port.props.built = []; g._portsDirty = true; stepDay(g);
  assert.ok(!port.neighbors.includes(tgt), 'связь исчезла без порта');
  // сохранение/загрузка пересчитывает порты
  port.props.built = ['port']; g._portsDirty = true; stepDay(g);
  const g2 = restoreGame(serialize(g));
  stepDay(g2);
  assert.ok(previewPath(g2, de.id, port.id, tgt), 'после загрузки морской переход работает');
});

ok('Бессарабия: СССР получает весь район (11 провинций), без разброса', () => {
  const g = euro(); g.playerId = byName(g, 'Ирландия').id;
  const su = byName(g, 'СССР'), ro = byName(g, 'Румыния');
  const ev = EVENT_BY_ID.baltic_ussr;
  const eff = ev.options[0].effect;
  const before = [...g.world.provinces.values()].filter((p) => p.props.owner === ro.id).length;
  applyEffect(g, su, eff);
  const got = [...g.world.provinces.values()].filter((p) => p.props.owner === su.id && eff.cedeNames.includes(p.name));
  assert.equal(got.length, 11, 'получено ' + got.length);
  assert.equal([...g.world.provinces.values()].filter((p) => p.props.owner === ro.id).length, before - 11);
  const again = byName(g, 'СССР'); applyEffect(g, again, eff);
  assert.equal([...g.world.provinces.values()].filter((p) => p.props.owner === ro.id).length, before - 11, 'повтор ничего не добавляет');
});

ok('промежуточные фокусы: между опорными фокусами хроники стоит подготовка', () => {
  const gaps = Object.keys(FOCUSES).filter((k) => FOCUSES[k].gap);
  assert.ok(gaps.length >= 15, 'промежуточных фокусов ' + gaps.length);
  for (const id of gaps) {
    const f = FOCUSES[id];
    assert.ok(f.req.every((r) => FOCUSES[r]), id + ': предпосылки существуют');
    assert.ok(Object.values(FOCUS_TREES).some((l) => l.includes(id)), id + ' есть в дереве страны');
    assert.ok(Object.values(FOCUSES).some((k) => (k.req || []).includes(id)), id + ' нужен какому-то фокусу');
  }
  for (const k of ['de_anschluss', 'de_czech', 'de_mitteleuropa', 'su_baltic', 'it_albania', 'pl_teschen']) assert.ok(FOCUSES[k].req.some((r) => FOCUSES[r].gap), k + ' требует промежуточный шаг');
  // без подготовки ключевой фокус закрыт, после неё — доступен
  const g = createGame(3, { size: 'medium', scenario: 'europe1936' });
  const de = g.countries.find((c) => c.name === 'Германия');
  de.pp = 500; de.focus = null;
  assert.equal(focusState(g, de.id, 'de_anschluss').st, 'locked');
  de.focuses.push('de_rearm', 'de_austria_prop');
  assert.notEqual(focusState(g, de.id, 'de_anschluss').st, 'locked');
});

import { weatherCode, weatherEffects, seasonStart, seasonOf, WX } from '../game/weather.js';
import { setDoctrine, startDoctrineStep, doctrineStep } from '../game/state.js';
import { DOCTRINES, DOCTRINE_SWITCH, doctrineEffect } from '../game/doctrines.js';

console.log('Погода и доктрины');
ok('погода: север холоднее юга, лето без снега, сезоны по датам', () => {
  RULES.weather = true;
  try {
    const g = euro();
    const find = (n) => [...g.world.provinces.values()].find((p) => p.name.startsWith(n));
    const hel = find('Хельсинки') || find('Финляндия'), cairo = find('Каир');
    assert.ok(hel && cairo);
    let coldN = 0, coldS = 0;
    for (let d = 0; d < 60; d += 3) { g.day = d; const w = weatherCode(g, hel); if (w === WX.SNOW || w === WX.FROST) coldN++; if (weatherCode(g, cairo) === WX.SNOW || weatherCode(g, cairo) === WX.FROST) coldS++; }
    assert.ok(coldN >= 5, 'на севере зимой снег или мороз, дней: ' + coldN);
    assert.equal(coldS, 0, 'в Каире снега нет');
    for (let d = 170; d < 230; d += 3) { g.day = d; for (const p of g.world.provinces.values()) assert.ok(![WX.SNOW, WX.FROST].includes(weatherCode(g, p)), 'летом снега нет'); }
    // повторяемость: одинаковый день — одинаковая погода
    g.day = 40; const a = weatherCode(g, hel); g._wxDay = -1; assert.equal(weatherCode(g, hel), a);
    assert.equal(seasonStart(335), 0); assert.equal(seasonStart(60), 1); assert.equal(seasonStart(61), null);
    assert.equal(seasonOf(0), 0); assert.equal(seasonOf(180), 2);
  } finally { RULES.weather = false; }
});
ok('погода: мороз замедляет и вымотывает, сопротивление смягчает, пустыня без снега', () => {
  RULES.weather = true;
  try {
    const g = euro(); const de = byName(g, 'Германия');
    const p = prov(g, de.capital);
    g._wx = new Uint8Array(80).fill(WX.FROST); g._wxDay = g.day;
    const e0 = weatherEffects(g, p, de);
    assert.ok(e0.mv < 0.8 && e0.atk < 0.9 && e0.attr > 1);
    de.mod.wthr = 0.5;
    const e1 = weatherEffects(g, p, de);
    assert.ok(e1.mv > e0.mv && e1.atk > e0.atk && e1.attr < e0.attr, 'сопротивление смягчает');
    de.mod.wthr = 0;
    const desert = [...g.world.provinces.values()].find((q) => q.props.terrain === 'desert');
    if (desert) assert.equal(weatherCode(g, desert), WX.CLEAR, 'в пустыне нет мороза');
    // поход в мороз стоит организации
    const mk = (on) => {
      RULES.weather = on;
      const gg = euro(); const d = byName(gg, 'Германия');
      const army = gg.armies.find((a) => a.owner === d.id);
      const here = prov(gg, army.at);
      const to = [...here.neighbors].map((id) => prov(gg, id)).find((q) => q.props.owner === d.id && q.props.terrain !== 'water');
      orderMove(gg, d.id, army.at, to.id, 1);
      gg._wx = new Uint8Array(80).fill(WX.FROST); gg._wxDay = gg.day;
      stepDay(gg);
      return gg.armies.find((a) => a.id === army.id).org ?? 100;
    };
    assert.ok(mk(true) < mk(false), 'в мороз организация в походе ниже');
  } finally { RULES.weather = false; }
});
ok('доктрины: старт, выбор, ступени, смена за власть, сохранение', () => {
  const g = euro();
  const de = byName(g, 'Германия'), su = byName(g, 'СССР');
  assert.equal(de.doctrine.id, 'maneuver'); assert.equal(su.doctrine.id, 'mass');
  recalcMods(de);
  assert.ok(Math.abs(de.mod.speed - (1 + 0.08)) < 0.5, 'есть');
  const sp0 = de.mod.speed;
  // в первые дни доктрину можно сменить бесплатно
  assert.ok(setDoctrine(g, de.id, 'defense').ok);
  assert.equal(de.doctrine.id, 'defense'); assert.ok(de.mod.speed < sp0, 'скорость манёвренной ушла');
  assert.equal(setDoctrine(g, de.id, 'defense').ok, false);
  // дальше платно и с интервалом
  g.day = 100; de.pp = 100;
  assert.equal(setDoctrine(g, de.id, 'mass').ok, false, 'рано');
  g.day = 400; de.pp = 10; assert.equal(setDoctrine(g, de.id, 'mass').ok, false, 'нет власти');
  de.pp = 100; assert.ok(setDoctrine(g, de.id, 'mass').ok); assert.equal(de.pp, 100 - DOCTRINE_SWITCH.pp);
  // ступени: нужны очки и военные технологии
  de.research = 0; assert.equal(doctrineStep(g, de.id).st, 'short');
  de.research = 5000; assert.equal(doctrineStep(g, de.id).st, 'ready');
  const eb = doctrineEffect(de.doctrine);
  assert.ok(startDoctrineStep(g, de.id).ok);
  assert.equal(doctrineStep(g, de.id).st, 'busy');
  for (let i = 0; i < 50; i++) stepDay(g);
  assert.equal(de.doctrine.lvl, 1);
  assert.ok(de.mod.men > 1 && doctrineEffect(de.doctrine).men === 0.1 && !eb.men);
  assert.equal(doctrineStep(g, de.id).st, 'locked', 'вторая ступень требует военных технологий');
  for (const t of Object.keys(TECHS).filter((k) => TECHS[k].branch === 'mil').slice(0, 3)) de.techs.push(t);
  assert.equal(doctrineStep(g, de.id).st, 'ready');
  const g2 = restoreGame(JSON.parse(JSON.stringify(serialize(g))));
  assert.equal(g2.countries[de.id].doctrine.id, 'mass'); assert.equal(g2.countries[de.id].doctrine.lvl, 1);
});
ok('доктрины: ИИ изучает ступени, у всех стран есть доктрина', () => {
  const g = euro();
  for (const c of g.countries) assert.ok(DOCTRINES[c.doctrine.id], c.name);
  for (const c of g.countries) c.research = 3000;
  for (let i = 0; i < 160; i++) stepDay(g, aiTick);
  assert.ok(g.countries.some((c) => c.id !== g.playerId && c.doctrine.lvl >= 1), 'ИИ вложился в доктрину');
});
console.log(fails ? 'есть падения: ' + fails : 'Все проверки прошли');

ok('топливо: без запаса нельзя наступать на чужую землю, при нехватке — слабее и медленнее', () => {
  const g = euro(); const de = byName(g, 'Германия'), pl = byName(g, 'Польша');
  declareWar(g, de.id, pl.id);
  let from = null, to = null;
  for (const p of g.world.provinces.values()) if (p.props.owner === de.id && !from) { const n = p.neighbors.map((id) => g.world.provinces.get(id)).find((q) => q.props.owner === pl.id && q.props.terrain !== 'water'); if (n) { from = p; to = n; } }
  assert.ok(from && to, 'есть граница Германии и Польши');
  const run = (empty) => {
    const gg = euro(); const d = byName(gg, 'Германия'), q = byName(gg, 'Польша');
    declareWar(gg, d.id, q.id);
    for (const a of gg.armies) if (a.at === to.id) a.strength = 0; // освобождаем клетку
    gg.armies = gg.armies.filter((a) => a.strength > 0);
    for (const a of gg.armies) if (a.owner === d.id && a.at === from.id) a.strength = 0;
    gg.armies = gg.armies.filter((a) => a.strength > 0);
    recruit(gg, d.id, from.id);
    assert.ok(orderMove(gg, d.id, from.id, to.id, 1).ok);
    d.pp = 1e6; d.fuel = empty ? -1e9 : 1e6;
    for (let i = 0; i < 40; i++) { d.fuel = empty ? -1e9 : 1e6; stepDay(gg); }
    return gg.armies.some((a) => a.owner === d.id && a.at === to.id);
  };
  assert.equal(run(false), true, 'с топливом армия входит в польскую провинцию');
  assert.equal(run(true), false, 'без топлива наступать нельзя');
  // мало топлива: ход и урон слегка ниже
  const g3 = euro(); const d3 = byName(g3, 'Германия');
  d3.fuel = RULES.fuelLow - 40; stepDay(g3); assert.equal(d3.lowFuel, true);
  d3.fuel = 500; stepDay(g3); assert.equal(!!d3.lowFuel, false);
});

console.log('Гражданская война');
ok('гражданская война: вероятность по строю, стабильности и условиям', () => {
  RULES.civilWar = true;
  try {
    const g = euro(); const de = byName(g, 'Германия');
    refreshStats(g);
    de.stability = 50;
    const aut = civilWarChance(g, de, 'dem'), same = civilWarChance(g, de, de.ideo);
    assert.equal(same, 0);
    assert.ok(aut > 0.2 && aut <= 0.8, 'шанс ' + aut);
    de.stability = 90; const calm = civilWarChance(g, de, 'dem'); de.stability = 20; const shaky = civilWarChance(g, de, 'dem');
    assert.ok(calm < aut && shaky > aut, 'стабильность влияет');
    de.ideo = 'aut'; assert.ok(civilWarChance(g, de, 'fas') < civilWarChance(g, de, 'dem') + 1e-9);
    de.ideo = 'fas';
    const fr = byName(g, 'Франция'); g.historical = false; assert.ok(civilWarChance(g, fr, 'com') > 0);
    g.historical = true; assert.equal(civilWarChance(g, fr, 'com'), 0, 'в хронике у ИИ перевороты по сценарию');
    g.historical = false;
    de.overlord = fr.id; assert.equal(civilWarChance(g, de, 'dem'), 0, 'у вассала нет'); de.overlord = null;
    RULES.civilWar = false; assert.equal(civilWarChance(g, de, 'dem'), 0, 'правило выключено');
  } finally { RULES.civilWar = false; }
});
ok('гражданская война: раскол страны, мятежники воюют, столица остаётся', () => {
  RULES.civilWar = true;
  try {
    const g = euro(); const de = byName(g, 'Германия');
    refreshStats(g);
    const n0 = g.countries.length, prov0 = g.stats[de.id].provinces, cap = de.capital;
    g.rng = () => 0; // выпадает
    setIdeology(g, de, 'dem');
    assert.equal(g.countries.length, n0 + 1);
    const reb = g.countries[n0];
    assert.ok(reb.alive && reb.ideo === 'fas' && atWar(g, reb.id, de.id));
    refreshStats(g);
    assert.ok(g.stats[reb.id].provinces >= 3 && g.stats[reb.id].provinces < prov0 / 2);
    assert.equal(g.world.provinces.get(cap).props.owner, de.id, 'столица у правительства');
    assert.equal(g.world.provinces.get(reb.capital).props.owner, reb.id);
    assert.ok(de.civilDay === g.day && g.pending.some((p) => p.info && p.info.title === 'Гражданская война'));
    assert.equal(civilWarChance(g, de, 'com'), 0, 'повторно в течение года нельзя');
    g.rng = Math.random;
    for (let d = 0; d < 30; d++) stepDay(g, aiTick);
    assert.ok(g.countries.length >= n0 + 1);
    // не выпало
    const g2 = euro(); const de2 = byName(g2, 'Германия'); refreshStats(g2);
    g2.rng = () => 0.999; setIdeology(g2, de2, 'dem');
    assert.equal(g2.countries.length, n0);
  } finally { RULES.civilWar = false; }
});
