// Сценарии «Европа 1939» и «Европа 1941»: node test/starts.mjs
import assert from 'node:assert/strict';
import { createGame, stepDay, atWar } from '../game/state.js';
import { aiTick } from '../game/ai.js';
import { serialize, restoreGame } from '../game/save.js';
import { scenarioOf, isEurope } from '../game/starts.js';

let fails = 0;
const ok = (name, fn) => { try { fn(); console.log('  ok  ' + name); } catch (e) { fails++; console.log('FAIL  ' + name + '\n      ' + e.message); } };
const by = (g, n) => g.countries.find((c) => c.name === n);
const dateOf = (g) => new Date(Date.UTC(1936, 0, 1) + g.day * 864e5).toISOString().slice(0, 10);
const owned = (g, core, owner) => [...g.world.provinces.values()].filter((p) => p.props.core === core.id && p.props.owner === owner.id).length;
const coreCount = (g, c) => [...g.world.provinces.values()].filter((p) => p.props.core === c.id).length;
const run = (g, days) => { for (let i = 0; i < days; i++) { aiTick(g); stepDay(g); } };

console.log('Выбор сценария');
ok('scenarioOf / isEurope', () => {
  assert.deepEqual(scenarioOf('europe1939'), { scenario: 'europe1936', start: '1939' });
  assert.deepEqual(scenarioOf('europe1941'), { scenario: 'europe1936', start: '1941' });
  assert.deepEqual(scenarioOf('europe1936'), { scenario: 'europe1936', start: null });
  assert.deepEqual(scenarioOf('random'), { scenario: 'random', start: null });
  assert.ok(isEurope('europe1936') && isEurope('europe1939') && isEurope('europe1941') && !isEurope('random'));
});

console.log('Европа 1939');
ok('дата, владельцы, войны: старт 01.09.1939, войны ещё нет', () => {
  const g = createGame(3, { scenario: 'europe1939', difficulty: 2, historical: true });
  assert.equal(g.scenario, 'europe1936'); assert.equal(g.start, '1939');
  assert.equal(dateOf(g), '1939-09-01');
  const de = by(g, 'Германия');
  assert.equal(owned(g, by(g, 'Австрия'), de), coreCount(g, by(g, 'Австрия')), 'Австрия у Германии');
  assert.ok(!by(g, 'Австрия').alive && !by(g, 'Чехословакия').alive);
  assert.ok(by(g, 'Польша').alive && by(g, 'Франция').alive && by(g, 'Великобритания').alive);
  assert.equal(g.wars.size, 0, 'до 01.09 войн нет');
  assert.ok(g.countries.length >= 34);
});
ok('Германия нападает на Польшу, Франция и Британия вступают', () => {
  const g = createGame(3, { scenario: 'europe1939', difficulty: 2, historical: true });
  g.playerId = by(g, 'Ирландия').id;
  run(g, 4);
  const de = by(g, 'Германия');
  assert.ok(atWar(g, de.id, by(g, 'Польша').id), 'война с Польшей');
  assert.ok(atWar(g, de.id, by(g, 'Франция').id) && atWar(g, de.id, by(g, 'Великобритания').id), 'гарантии сработали');
});

console.log('Европа 1941');
ok('дата, Франция, Норвегия, Британия', () => {
  const g = createGame(3, { scenario: 'europe1941', difficulty: 2, historical: true });
  assert.equal(dateOf(g), '1941-06-22');
  const de = by(g, 'Германия'), fr = by(g, 'Франция'), gb = by(g, 'Великобритания');
  assert.ok(!by(g, 'Норвегия').alive && !by(g, 'Польша').alive && !by(g, 'Югославия').alive && !by(g, 'Греция').alive);
  assert.equal(owned(g, gb, gb), coreCount(g, gb), 'Британия цела');
  assert.ok(fr.alive && g.world.provinces.get(fr.capital).props.owner === fr.id, 'столица Виши у Франции');
  const paris = [...g.world.provinces.values()].find((p) => p.name.startsWith('Париж'));
  assert.equal(paris.props.owner, de.id, 'Париж занят');
  assert.ok(fr.faction == null, 'Франция вышла из Антанты');
  assert.ok(atWar(g, de.id, gb.id) && !atWar(g, de.id, fr.id), 'Германия воюет с Британией, с Францией перемирие');
});
ok('22 июня: Германия, Италия, Румыния нападают на СССР', () => {
  const g = createGame(3, { scenario: 'europe1941', difficulty: 2, historical: true });
  g.playerId = by(g, 'Ирландия').id;
  run(g, 3);
  const ussr = by(g, 'СССР').id;
  for (const n of ['Германия', 'Италия', 'Румыния']) assert.ok(atWar(g, by(g, n).id, ussr), n + ' воюет с СССР');
});
ok('армии стоят только в провинциях своих владельцев (или союзников/врагов в бою)', () => {
  const g = createGame(3, { scenario: 'europe1941', difficulty: 2, historical: true });
  for (const a of g.armies) assert.ok(g.countries[a.owner].alive, 'армия мёртвой страны');
  const bad = g.armies.filter((a) => g.world.provinces.get(a.at).props.owner !== a.owner);
  assert.equal(bad.length, 0, 'армии вне своих земель: ' + bad.length);
});

console.log('Словакия и оккупация');
ok('Словакия — клиент Германии, Закарпатье у Венгрии, Острава (1939 и 1941)', () => {
  for (const sc of ['europe1939', 'europe1941']) {
    const g = createGame(3, { scenario: sc, difficulty: 2, historical: true });
    const sk = by(g, 'Словакия'), de = by(g, 'Германия'), hu = by(g, 'Венгрия');
    assert.ok(sk && sk.alive && sk.overlord === de.id, 'Словакия — вассал Германии');
    assert.ok(g.world.provinces.get(sk.capital).props.owner === sk.id);
    const at = (n) => [...g.world.provinces.values()].find((p) => p.name === n).props.owner;
    assert.equal(at('Ужгород'), hu.id, 'Закарпатье у Венгрии');
    assert.equal(at('Прага'), de.id, 'Прага у Германии');
    assert.equal(at('Острава'), sc === 'europe1939' ? by(g, 'Польша').id : de.id, 'Острава: у Польши до её падения, затем у Германии');
    const cz = [...g.world.provinces.values()].filter((p) => p.props.owner === de.id && p.props.core === by(g, 'Чехословакия').id);
    assert.ok(cz.length > 20 && cz.length < 32, 'у Германии только чешские земли: ' + cz.length);
  }
});
ok('штриховка оккупации: Австрия и Чехия — свои, Норвегия и Франция (1941) — заняты', () => {
  const g39 = createGame(3, { scenario: 'europe1939', historical: true });
  const occ = (g) => [...g.world.provinces.values()].filter((p) => p.props.owner !== p.props.core && (p.props.comp ?? 100) < 100);
  assert.equal(occ(g39).length, 0, 'в 1939 нет оккупированных провинций');
  const g41 = createGame(3, { scenario: 'europe1941', historical: true });
  const o = occ(g41), names = new Set(o.map((p) => g41.countries[p.props.core].name));
  assert.ok(names.has('Норвегия') && names.has('Франция') && names.has('Греция'));
  assert.ok(!names.has('Австрия') && !names.has('Чехословакия') && !names.has('Польша') && !names.has('Латвия'));
});

console.log('Общее');
ok('сохранение и загрузка стартовой игры', () => {
  for (const sc of ['europe1939', 'europe1941']) {
    const g = createGame(3, { scenario: sc, difficulty: 1, historical: true });
    g.playerId = by(g, 'Германия').id;
    run(g, 3);
    const g2 = restoreGame(JSON.parse(JSON.stringify(serialize(g))));
    assert.equal(g2.day, g.day); assert.equal(g2.countries.length, g.countries.length);
    run(g2, 2);
  }
});
ok('любая живая страна может быть игроком (30 дней без падения)', () => {
  const g = createGame(4, { scenario: 'europe1941', difficulty: 1, historical: true });
  const pl = by(g, 'СССР'); g.playerId = pl.id;
  run(g, 30);
  assert.ok(pl.alive);
});

if (fails) { console.log(`\n${fails} тест(ов) упало`); process.exit(1); }
console.log('\nсценарии: всё в порядке');
