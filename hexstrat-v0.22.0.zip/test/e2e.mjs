// Сквозная проверка в настоящем Chromium: node test/e2e.mjs (нужен playwright и dist/index.html).
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
const require = createRequire(process.env.PW_PATH || '/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM || '/opt/pw-browsers/chromium', args: ['--no-sandbox'] });
let fails = 0;
const ok = (c, m) => { console.log((c ? '  ok  ' : ' FAIL ') + m); if (!c) fails++; };
for (const [w, h] of [[740, 360], [360, 740]]) {
  const page = await (await browser.newContext({ viewport: { width: w, height: h }, hasTouch: true })).newPage();
  const errs = [];
  page.on('pageerror', (e) => errs.push(e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !m.text().includes('ERR_TUNNEL')) errs.push(m.text()); });
  await page.goto(pathToFileURL(resolve('dist/index.html')).href);
  await page.click('[data-act="newgame"]');
  await page.click('[data-act="begin"]');
  ok(await page.isVisible('#tools'), `${w}x${h}: игра началась`);
  for (const act of ['build', 'armies', 'tech', 'diplo']) {
    await page.click(`#tools [data-act="${act}"]`);
    ok(await page.isVisible('.panel'), `${w}x${h}: панель ${act}`);
    await page.click('.pback');
  }
  await page.click('#tools [data-act="tech"]');
  await page.click('.tnode.ready');
  await page.click('.tdetail .cost.rs');
  ok((await page.textContent('.tdetail')).includes('Изучается'), `${w}x${h}: технология пошла в изучение`);
  await page.click('[data-act="ttab"][data-arg="mil"]');
  ok((await page.textContent('.treewrap')).includes('Пехотные уставы'), `${w}x${h}: вкладка «Армия»`);
  await page.click('.pback');
  await page.click('#whoName');
  ok((await page.textContent('.plist')).includes('Стабильность'), `${w}x${h}: панель страны`);
  await page.click('[data-act="tax"][data-arg="3"]');
  ok((await page.textContent('.plist')).includes('Повышенный'), `${w}x${h}: налог меняется`);
  await page.click('[data-act="ctab"][data-arg="focus"]');
  await page.click('.tnode.ready');
  await page.click('.tdetail .cost.pp');
  ok((await page.textContent('.tdetail')).includes('Идёт: ещё'), `${w}x${h}: фокус начат`);
  await page.click('[data-act="ctab"][data-arg="min"]');
  ok((await page.textContent('.plist')).includes('Министр экономики'), `${w}x${h}: министры`);
  await page.click('.pback');
  await page.click('#tools [data-act="diplo"]');
  await page.click('[data-act="dtab"][data-arg="a"]');
  await page.click('[data-act="found"]');
  ok((await page.textContent('.panel')).includes('Основать альянс'), `${w}x${h}: вкладка альянса`);
  await page.click('[data-act="dtab"][data-arg="o"]');
  ok((await page.textContent('.panel')).includes('Лига Наций'), `${w}x${h}: организации`);
  await page.click('[data-act="dtab"][data-arg="c"]');
  await page.locator('[data-act="dipcard"]').nth(4).click(); // Италия: хорошие отношения с Германией
  await page.click('[data-act="tgood"][data-arg="ind"]');
  await page.click('[data-act="tsize"][data-arg="s"]');
  await page.click('[data-act="tradego"]');
  ok((await page.textContent('.panel')).includes('Расторгнуть'), `${w}x${h}: торговая сделка заключена`);
  await page.click('.pback');
  await page.click('#tools [data-act="diplo"]');
  await page.click('[data-act="dtab"][data-arg="t"]');
  ok((await page.textContent('.panel')).includes('сделок 1 из'), `${w}x${h}: сделка видна во вкладке договоров`);
  await page.click('[data-act="canceldeal"]');
  ok((await page.textContent('.panel')).includes('сделок 0 из'), `${w}x${h}: сделка расторгнута`);
  await page.click('.pback');
  ok(/\d/.test(await page.textContent('#ppv')) && /\d/.test(await page.textContent('#fuelv')), `${w}x${h}: ресурсы в шапке`);
  await page.click('[data-act="menu"]'); await page.click('.pback');
  for (let i = 0; i < 3; i++) await page.click('[data-act="faster"]');
  await page.waitForTimeout(2500);
  const day = await page.textContent('#dayno');
  ok(/\d+/.test(day) && !/ 0$/.test(day), `${w}x${h}: время идёт (${day})`);
  while (await page.isVisible('.evpanel')) { await page.click('.evopt:not([disabled])'); await page.waitForTimeout(100); }
  await page.click('#chatBtn'); ok(await page.isVisible('.panel'), `${w}x${h}: журнал`);
  await page.click('.pback');
  const box = (s) => page.evaluate((q) => { const r = document.querySelector(q).getBoundingClientRect(); return [r.left, r.right]; }, s);
  const [, chatR] = await box('#chatBtn'); const [zoomL] = await box('#zoomBtn');
  ok(zoomL >= chatR, `${w}x${h}: кнопки внизу не перекрываются`);
  ok(errs.length === 0, `${w}x${h}: без ошибок в консоли ${errs.join('|')}`);
}
// События: Европа 1936, играем за Германию, ждём Рейнскую область и отвечаем
for (const [w, h] of [[740, 360], [360, 740]]) {
  const page = await (await browser.newContext({ viewport: { width: w, height: h }, hasTouch: true })).newPage();
  const errs = [];
  page.on('pageerror', (e) => errs.push(e.message));
  await page.goto(pathToFileURL(resolve('dist/index.html')).href);
  await page.click('[data-act="newgame"]');
  await page.click('[data-act="scen"][data-arg="europe1936"]');
  await page.click('[data-act="begin"]');
  for (let i = 0; i < 5; i++) await page.click('[data-act="faster"]');
  await page.waitForSelector('.evpanel', { timeout: 90000 });
  // до марта 1936 могут прийти и случайные события: отвечаем на них и ждём Рейнскую область
  for (let i = 0; i < 6 && !(await page.textContent('.evpanel .evpaper h2')).includes('Рейнская'); i++) {
    await page.click('.evopt:not([disabled])');
    await page.waitForSelector('.evpanel', { timeout: 90000 });
  }
  ok((await page.textContent('.evpanel .evpaper h2')).includes('Рейнская'), `${w}x${h}: окно исторического события`);
  const optBox = await page.evaluate(() => [...document.querySelectorAll('.evopt')].map((b) => { const r = b.getBoundingClientRect(); return r.bottom <= innerHeight + 1 || b.closest('.plist').scrollHeight > b.closest('.plist').clientHeight; }));
  ok(optBox.length === 2 && optBox.every(Boolean), `${w}x${h}: варианты доступны (прокрутка при необходимости)`);
  await page.click('.evopt');
  await page.waitForTimeout(300);
  ok(!(await page.isVisible('.evpanel')), `${w}x${h}: окно закрылось после выбора`);
  ok(errs.length === 0, `${w}x${h}: без ошибок ${errs.join('|')}`);
}
// торговые предложения: круг с флагом, по нажатию — условия
for (const [w, h] of [[740, 360], [360, 740]]) {
  const page = await (await browser.newContext({ viewport: { width: w, height: h }, hasTouch: true })).newPage();
  const errs = [];
  page.on('pageerror', (e) => errs.push(e.message));
  await page.goto(pathToFileURL(resolve('dist/index.html')).href + '#to=1');
  await page.reload();
  await page.click('[data-act="newgame"]');
  await page.click('[data-act="begin"]');
  await page.waitForSelector('.ocirc', { timeout: 10000 });
  ok(await page.isVisible('.ocirc'), `${w}x${h}: круг торгового предложения на экране`);
  ok(await page.evaluate(() => { const r = document.querySelector('.ocirc').getBoundingClientRect(); return r.left >= 0 && r.right <= innerWidth && r.top >= 0 && r.bottom <= innerHeight; }), `${w}x${h}: круг внутри экрана`);
  await page.click('.ocirc');
  ok((await page.textContent('.evpanel .evpaper')).includes('Торговое предложение'), `${w}x${h}: окно с условиями`);
  await page.click('[data-act="tradeans"][data-arg$=":0"]');
  await page.waitForTimeout(300);
  ok(!(await page.isVisible('.ocirc')) && !(await page.isVisible('.evpanel')), `${w}x${h}: после ответа круг и окно исчезли`);
  ok(errs.length === 0, `${w}x${h}: без ошибок ${errs.join('|')}`);
}
await browser.close();
console.log(fails ? `Провалено: ${fails}` : 'Все проверки прошли');
process.exit(fails ? 1 : 0);
