// Проверка загрузчика модов: применение, конфликты, ошибки. Меняет данные игры, поэтому отдельным процессом.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { TECHS, FOCUSES, FOCUS_TREES, RULES } from '../game/data.js';
import { EVENTS } from '../game/events_data.js';
import { EVENT_BY_ID } from '../game/events.js';
import { ICONS } from '../game/icons.js';
import { validateMod, applyMods, modReport, activeMods, modsSignature } from '../game/mods.js';
import { createGame, stepDay, startResearch, techState, startFocus, focusState } from '../game/state.js';
import { plagueSummary, setQuarantine } from '../game/plague.js';
import { PLAGUE } from '../game/plague_core.js';
import { applyEffect } from '../game/events.js';
import { serialize, restoreGame } from '../game/save.js';

let n = 0;
const ok = (name, f) => { f(); n++; console.log('  ok ', name); };
const ex = JSON.parse(readFileSync('mods/example.hexmod.json', 'utf8'));
const clone = (o) => JSON.parse(JSON.stringify(o));

ok('пример проходит проверку без ошибок', () => { const v = validateMod(ex); assert.deepEqual(v.errors, []); });
ok('плохие моды отклоняются', () => {
  const bad = (f) => { const m = clone(ex); f(m); return validateMod(m).errors.length > 0; };
  assert.ok(bad((m) => { m.id = 'Плохой id'; }));
  assert.ok(bad((m) => { m.add.techs.x_kitchen.branch = 'nope'; }));
  assert.ok(bad((m) => { m.add.techs.x_kitchen.effect = { gold: 99 }; }));
  assert.ok(bad((m) => { m.add.techs.x_kitchen.effect = { hack: 1 }; }));
  assert.ok(bad((m) => { m.add.techs.e_elec = { branch: 'eco', tier: 1, name: 'a', desc: 'b', req: [], effect: {} }; }));
  assert.ok(bad((m) => { m.add.techs.x_kitchen2.req = ['нет_такой']; }));
  assert.ok(bad((m) => { m.add.events[0].options[0].effect = { fn: 'alert(1)' }; }));
  assert.ok(bad((m) => { m.add.events[0].p = 0.9; }));
  assert.ok(bad((m) => { m.add.icons = { x_i: 'http://evil/x.png' }; }));
  assert.ok(bad((m) => { m.patch.rules = { recruitGold: 'много' }; }));
  assert.ok(bad((m) => { m.patch.rules = { нет_правила: 1 }; }));
  assert.ok(bad((m) => { m.patch = { techs: { e_elec: { fn: 1 } } }; }));
  assert.ok(bad((m) => { m.api = 99; }));
  assert.ok(validateMod(JSON.parse('{"id":"zz","name":"a","patch":{"rules":{"__proto__":{"x":1}}}}')).errors.length > 0);
});
const goldBefore = RULES.recruitGold, techsBefore = Object.keys(TECHS).length, evBefore = EVENTS.length;
ok('применение: технологии, фокус, события, правило', () => {
  const rep = applyMods([{ mod: clone(ex), on: true }]);
  assert.equal(rep[0].status, 'on', JSON.stringify(rep[0].errors));
  assert.equal(Object.keys(TECHS).length, techsBefore + 2);
  assert.equal(TECHS.x_kitchen.cost, 180);
  assert.ok(FOCUSES.x_fair && FOCUS_TREES['*'].includes('x_fair'));
  assert.equal(EVENTS.length, evBefore + 2);
  assert.ok(EVENT_BY_ID.x_harvest_fest && EVENT_BY_ID.x_gift);
  assert.equal(RULES.recruitGold, 4); assert.notEqual(goldBefore, 4);
  assert.equal(modsSignature(), 'example_pack@1.0');
});
ok('конфликт: два мода с одним id технологии — второй отклонён, первый работает', () => {
  const t = (name) => ({ branch: 'eco', tier: 1, name, desc: 'д', req: [], effect: { gold: 0.1 } });
  const m1 = { id: 'm_one', name: 'Один', add: { techs: { zz_dup: t('Первая') } } };
  const m2 = { id: 'm_two', name: 'Два', add: { techs: { zz_dup: t('Дубль') } } };
  const rep = applyMods([{ mod: m1, on: true }, { mod: m2, on: true }]);
  assert.equal(rep[0].status, 'on'); assert.equal(rep[1].status, 'error');
  assert.equal(TECHS.zz_dup.name, 'Первая');
});
ok('игра с модом: ход, исследование новой технологии', () => {
  const g = createGame(5, { size: 'small', scenario: 'europe1936' });
  g.playerId = 0;
  const c = g.countries[0];
  c.research = 5000;
  const r = startResearch(g, 0, 'x_kitchen');
  assert.ok(r.ok, r.msg);
  for (let i = 0; i < 60; i++) stepDay(g);
  assert.ok(g.day >= 60);
});

const pw = JSON.parse(readFileSync('mods/plague_war.hexmod.json', 'utf8'));
ok('Плагуе Вар: проходит проверку; плохие настройки отклоняются', () => {
  assert.deepEqual(validateMod(pw).errors, []);
  const bad = (f) => { const m = clone(pw); f(m); return validateMod(m).errors.length > 0; };
  assert.ok(bad((m) => { m.systems.plague.growth = 'много'; }));
  assert.ok(bad((m) => { m.systems.plague.quarantine = [1]; }));
  assert.ok(bad((m) => { m.systems.plague.hack = 1; }));
  assert.ok(bad((m) => { m.add.focuses.pl_lab.icon = 'нет такой'; }));
  assert.ok(bad((m) => { m.add.events[0].when = { fn: 1 }; }));
  assert.ok(bad((m) => { m.add.focuses.pl_lab.act = { plague: { vaccine: 'x' } }; }));
});
ok('Плагуе Вар: фокусы у всех стран, эпидемия стартует и распространяется', () => {
  const rep = applyMods([{ mod: clone(pw), on: true }]);
  assert.equal(rep[0].status, 'on', JSON.stringify(rep[0].errors));
  assert.ok(PLAGUE.cfg);
  assert.ok(FOCUS_TREES['Германия'].includes('pl_lab') && FOCUS_TREES['*'].includes('pl_lab'));
  assert.ok(!FOCUSES.pl_lab.alt);
  assert.equal(FOCUSES.pl_lab.icon, 'pl_lab'); assert.ok(ICONS.pl_lab && ICONS.pl_warn && ICONS.pl_tab);
  const g = createGame(1, { scenario: 'europe1936' });
  g.playerId = 0;
  for (let i = 0; i < 200; i++) stepDay(g);
  const s = plagueSummary(g, 0);
  assert.ok(s.started && s.worldI > 0.5, 'worldI ' + s.worldI);
});
ok('Плагуе Вар: фокус вакцины, карантин, событие-условие, гибель мира', () => {
  const g = createGame(1, { scenario: 'europe1936' });
  g.playerId = 0;
  const c = g.countries[0];
  c.pp = 500;
  const r = startFocus(g, 0, 'pl_lab');
  assert.ok(r.ok, r.msg);
  for (let i = 0; i < 70; i++) stepDay(g);
  assert.ok(c.plague.v >= 15, 'вакцина ' + c.plague.v);
  assert.ok(setQuarantine(g, 0, 2).ok && c.plague.q === 2);
  applyEffect(g, c, { plague: { inf: 20 } }, 'тест');
  assert.ok(c.plague.i >= 20);
  // гибель: всё заражено
  for (const o of g.countries) { o.plague.i = 95; o.plague.v = 0; o.plague.q = 0; }
  PLAGUE.cfg.collapseDays = 5;
  for (let i = 0; i < 12 && !g.over; i++) stepDay(g);
  assert.ok(g.over && g.over.plague && g.over.won === false);
});
ok('Плагуе Вар: новостные окна доходят до игрока, старая игра получает эпидемию', () => {
  PLAGUE.cfg.collapseDays = 200;
  const g = createGame(1, { scenario: 'europe1936' });
  g.playerId = 0;
  for (let i = 0; i < 70; i++) stepDay(g);
  assert.ok(g.pending.some((p) => p.info && p.info.kind === 'plague' && p.info.title === 'Неизвестная болезнь'), 'окно новостей об эпидемии не показано');
  assert.ok(g.log.some((e) => e.text.includes('Неизвестная болезнь') && e.involves.includes(0)));
  const d = serialize(g); d.plague = null;
  const old = restoreGame(d);
  assert.ok(old.plague && old.plague.started === false);
});
ok('Плагуе Вар: без мода эпидемии нет', () => {
  applyMods([]);
  assert.equal(PLAGUE.cfg, null);
  const g = createGame(2, { scenario: 'europe1936' });
  for (let i = 0; i < 40; i++) stepDay(g);
  assert.equal(g.plague, null);
});
console.log(`mods: ${n} проверок пройдено`);
