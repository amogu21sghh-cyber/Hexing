// Генерация карты: шум высот -> суша/море -> ландшафт -> провинции -> страны.
import { World, MinHeap, offsetToAxial, hexDistance } from '../engine/index.js';
import { TERRAIN, COUNTRY_DEFS, MAP } from './data.js';
import { mulberry32 } from './rng.js';
import { provinceName } from './names.js';

const smooth = (t) => t * t * (3 - 2 * t);

function makeNoise(rng, gx, gy) {
  const g = [];
  for (let i = 0; i < gx * gy; i++) g.push(rng());
  return (x, y) => {
    const fx = x * (gx - 1), fy = y * (gy - 1);
    const x0 = Math.floor(fx), y0 = Math.floor(fy);
    const x1 = Math.min(x0 + 1, gx - 1), y1 = Math.min(y0 + 1, gy - 1);
    const tx = smooth(fx - x0), ty = smooth(fy - y0);
    const a = g[y0 * gx + x0], b = g[y0 * gx + x1], c = g[y1 * gx + x0], d = g[y1 * gx + x1];
    return (a + (b - a) * tx) + ((c + (d - c) * tx) - (a + (b - a) * tx)) * ty;
  };
}

const percentile = (arr, p) => {
  const s = [...arr].sort((a, b) => a - b);
  return s[Math.max(0, Math.min(s.length - 1, Math.floor(s.length * p)))];
};

export function generateMap(seed, opts = {}) {
  for (let attempt = 0; attempt < 40; attempt++) {
    const res = tryGenerate(seed + attempt * 1013, opts);
    if (res) return res;
  }
  throw new Error('Не удалось сгенерировать карту');
}

function tryGenerate(seed, opts) {
  const rng = mulberry32(seed);
  const { cols, rows, hexSize, waterShare } = { ...MAP, ...opts };
  const world = new World(hexSize);
  const n1 = makeNoise(rng, 5, 4), n2 = makeNoise(rng, 11, 9), moist = makeNoise(rng, 7, 6);

  const cells = [];
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const { q, r } = offsetToAxial(col, row);
      const u = col / (cols - 1), v = row / (rows - 1);
      const dx = (u - 0.5) * 2, dy = (v - 0.5) * 2;
      const falloff = Math.min(1, dx * dx * 0.8 + dy * dy * 0.9);
      const h = 0.62 * n1(u, v) + 0.38 * n2(u, v) - 0.4 * falloff * falloff;
      cells.push({ q, r, h, m: moist(u, v), land: false, terrain: 'water' });
    }
  }
  const t = percentile(cells.map((c) => c.h), waterShare);
  for (const c of cells) c.land = c.h > t;

  // оставляем только самый большой материк
  const byKey = new Map(cells.map((c) => [c.q + ',' + c.r, c]));
  const DIR = [[0, 1], [-1, 1], [-1, 0], [0, -1], [1, -1], [1, 0]];
  const seen = new Set();
  let best = [];
  for (const c of cells) {
    if (!c.land || seen.has(c)) continue;
    const comp = [c];
    seen.add(c);
    for (let i = 0; i < comp.length; i++) {
      for (const [dq, dr] of DIR) {
        const n = byKey.get((comp[i].q + dq) + ',' + (comp[i].r + dr));
        if (n && n.land && !seen.has(n)) { seen.add(n); comp.push(n); }
      }
    }
    if (comp.length > best.length) best = comp;
  }
  const landSet = new Set(best);
  for (const c of cells) c.land = landSet.has(c);
  const land = cells.filter((c) => c.land);
  if (land.length < cols * rows * 0.3) return null;

  const hs = land.map((c) => c.h);
  const mountT = percentile(hs, 0.93), hillT = percentile(hs, 0.78);
  const low = land.filter((c) => c.h < hillT);
  const forestT = percentile(low.map((c) => c.m), 0.7);
  for (const c of land) {
    c.terrain = c.h >= mountT ? 'mountains' : c.h >= hillT ? 'hills' : c.m >= forestT ? 'forest' : 'plains';
  }

  // гексы и провинции (1 гекс = 1 провинция)
  const used = new Set();
  let id = 1;
  for (const c of cells) {
    if (!c.land) { world.addHex(c.q, c.r, 'water', null); continue; }
    const pid = id++;
    world.addHex(c.q, c.r, c.terrain, pid);
    const T = TERRAIN[c.terrain];
    const pop = Math.round(T.pop[0] + rng() * (T.pop[1] - T.pop[0]));
    const wealth = Math.round(T.wealth * (0.8 + rng() * 0.4) * 100) / 100;
    world.addProvince(pid, provinceName(rng, c.terrain, used), { terrain: c.terrain, pop, wealth, owner: null, capital: false, built: [], project: null });
  }
  world.rebuild();

  // столицы: дальние друг от друга точки суши
  const provs = [...world.provinces.values()].filter((p) => p.props.terrain === 'plains' || p.props.terrain === 'forest');
  const cell = (p) => p.hexes[0];
  const seeds = [provs[Math.floor(rng() * provs.length)]];
  while (seeds.length < COUNTRY_DEFS.length) {
    let bestP = null, bestD = -1;
    for (let i = 0; i < 80; i++) {
      const p = provs[Math.floor(rng() * provs.length)];
      const d = Math.min(...seeds.map((s) => hexDistance(cell(p).q, cell(p).r, cell(s).q, cell(s).r)));
      if (d > bestD) { bestD = d; bestP = p; }
    }
    seeds.push(bestP);
  }

  // рост территорий: Дейкстра от столиц, горы и леса тормозят рост
  const owner = new Map();
  const heap = new MinHeap();
  seeds.forEach((p, i) => heap.push(0, [p.id, i]));
  while (heap.size) {
    const [d, [pid, ci]] = heap.pop();
    if (owner.has(pid)) continue;
    owner.set(pid, ci);
    const p = world.provinces.get(pid);
    for (const nid of p.neighbors) {
      if (owner.has(nid)) continue;
      const np = world.provinces.get(nid);
      heap.push(d + TERRAIN[np.props.terrain].move * (0.75 + rng() * 0.5), [nid, ci]);
    }
  }
  const counts = COUNTRY_DEFS.map(() => 0);
  for (const ci of owner.values()) counts[ci]++;
  const minShare = world.provinces.size / COUNTRY_DEFS.length * 0.55;
  if (owner.size !== world.provinces.size || Math.min(...counts) < minShare) return null;

  for (const [pid, ci] of owner) world.provinces.get(pid).props.owner = ci;
  // месторождения: у каждой провинции небольшой шанс, горы и холмы богаче углём
  const drng = mulberry32(seed * 31 + 7);
  for (const p of world.provinces.values()) {
    const hill = p.props.terrain === 'hills' || p.props.terrain === 'mountains';
    if (drng() < (hill ? 0.1 : 0.05)) p.props.deposit = drng() < (hill ? 0.15 : 0.35) ? (drng() < 0.2 ? 'O' : 'o') : 'c';
  }
  const countries = COUNTRY_DEFS.map((def, i) => {
    const cap = seeds[i];
    cap.props.capital = true;
    cap.props.pop = Math.round(cap.props.pop * 1.5);
    cap.props.wealth = Math.round((cap.props.wealth + 1.5) * 100) / 100;
    return { id: i, name: def.name, color: def.color, capital: cap.id, alive: true };
  });
  return { world, countries, seed };
}
