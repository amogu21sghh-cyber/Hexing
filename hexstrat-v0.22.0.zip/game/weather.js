// Погода: времена года и климат по широте. Всё считается из номера дня и положения провинции (без случайных чисел
// симуляции), поэтому партия остаётся детерминированной, а сохранения не хранят погоду.
//   Север холоднее юга; зимой снег и мороз, весной и осенью распутица, летом редкие дожди, на юге жара.
//   Влияние: скорость армий, атака на чужой земле, потеря организации в походе. Сопротивление погоде — мод wthr.
import { RULES } from './data.js';

export const WX = { CLEAR: 0, RAIN: 1, MUD: 2, SNOW: 3, FROST: 4, HEAT: 5 };
// mv — множитель скорости, atk — множитель атаки армий на чужой земле, attr — потеря организации в день в походе
export const WX_INFO = [
  { id: 'clear', name: 'Ясно', mv: 1, atk: 1, attr: 0 },
  { id: 'rain', name: 'Дождь', mv: 0.92, atk: 0.96, attr: 0 },
  { id: 'mud', name: 'Распутица', mv: 0.6, atk: 0.85, attr: 0.6 },
  { id: 'snow', name: 'Снег', mv: 0.78, atk: 0.9, attr: 0.8 },
  { id: 'frost', name: 'Сильный мороз', mv: 0.7, atk: 0.85, attr: 2 },
  { id: 'heat', name: 'Жара', mv: 0.88, atk: 0.92, attr: 1.2 },
];
export const SEASONS = ['Зима', 'Весна', 'Лето', 'Осень'];
const ZX = 10, ZY = 8;

const hash = (a, b, c) => {
  let h = Math.imul(a + 374761393, 668265263) ^ Math.imul(b + 1274126177, 2246822519) ^ Math.imul(c + 3266489917, 3266489917);
  h = Math.imul(h ^ (h >>> 15), 2246822519); h = Math.imul(h ^ (h >>> 13), 3266489917);
  return (h ^ (h >>> 16)) >>> 0;
};

const dateOf = (day) => new Date(Date.UTC(RULES.start[0], RULES.start[1], RULES.start[2] + day));
export function seasonOf(day) { const m = dateOf(day).getUTCMonth(); return m === 11 || m < 2 ? 0 : m < 5 ? 1 : m < 8 ? 2 : 3; }
// первый день сезона (1 декабря, 1 марта, 1 июня, 1 сентября)
export function seasonStart(day) { const d = dateOf(day); return d.getUTCDate() === 1 && [11, 2, 5, 8].includes(d.getUTCMonth()) ? seasonOf(day) : null; }

// Зоны погоды: сетка ZX×ZY по границам мира; широта — нормированная координата y (0 — север)
function zones(g) {
  if (g._wxZ) return g._wxZ;
  let x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
  for (const p of g.world.provinces.values()) { const c = p.center; if (c.x < x0) x0 = c.x; if (c.x > x1) x1 = c.x; if (c.y < y0) y0 = c.y; if (c.y > y1) y1 = c.y; }
  const wx = Math.max(1, x1 - x0), wy = Math.max(1, y1 - y0);
  let max = 0;
  for (const id of g.world.provinces.keys()) if (id > max) max = id;
  const zone = new Int16Array(max + 1), lat = new Float32Array(max + 1);
  for (const p of g.world.provinces.values()) {
    const nx = (p.center.x - x0) / wx, ny = (p.center.y - y0) / wy;
    zone[p.id] = Math.min(ZX - 1, Math.floor(nx * ZX)) * ZY + Math.min(ZY - 1, Math.floor(ny * ZY));
    lat[p.id] = ny;
  }
  // широта зоны — по середине ячейки сетки
  g._wxZ = { zone, lat };
  return g._wxZ;
}

function compute(g, day) {
  const doy = (Date.UTC(dateOf(day).getUTCFullYear(), dateOf(day).getUTCMonth(), dateOf(day).getUTCDate()) - Date.UTC(dateOf(day).getUTCFullYear(), 0, 1)) / 864e5;
  const cold = Math.cos(2 * Math.PI * (doy - 20) / 365);
  const block = Math.floor(day / 3);
  const out = new Uint8Array(ZX * ZY);
  for (let zx = 0; zx < ZX; zx++) for (let zy = 0; zy < ZY; zy++) {
    const z = zx * ZY + zy, lat = (zy + 0.5) / ZY;
    const F = 0.75 * cold + 0.9 * (0.45 - lat);
    const roll = hash(z, block, 7) % 100;
    let w = WX.CLEAR;
    if (F > 0.95) w = roll < 70 ? WX.FROST : roll < 90 ? WX.SNOW : WX.CLEAR;
    else if (F > 0.5) w = roll < 45 ? WX.SNOW : WX.CLEAR;
    else if (F > 0 && lat < 0.7) w = roll < 50 ? WX.MUD : WX.CLEAR;
    else if (F < -1.0) w = roll < 50 ? WX.HEAT : WX.CLEAR;
    else if (F < 0) w = roll < 18 && lat < 0.75 ? WX.RAIN : WX.CLEAR;
    out[z] = w;
  }
  return out;
}

// Погода по зонам на текущий день (кэш на день)
export function weatherDay(g) {
  if (g._wxDay !== g.day || !g._wx) {
    g._wx = compute(g, g.day); g._wxDay = g.day;
    let s = '';
    for (let i = 0; i < g._wx.length; i++) s += g._wx[i];
    g._wxSig = s;
  }
  return g._wx;
}

// Код погоды в провинции; пустыня не знает снега, мороза и распутицы
export function weatherCode(g, p) {
  if (!RULES.weather || !p) return WX.CLEAR;
  const wx = weatherDay(g), Z = zones(g);
  let w = wx[Z.zone[p.id]] || 0;
  if (p.props.terrain === 'desert' && (w === WX.SNOW || w === WX.FROST || w === WX.MUD)) w = WX.CLEAR;
  return w;
}

const soften = (v, res) => 1 - (1 - v) * (1 - res);
// Множители погоды для армий страны c в провинции p: { w, mv, atk, attr }
export function weatherEffects(g, p, c) {
  const w = weatherCode(g, p);
  if (w === WX.CLEAR) return { w, mv: 1, atk: 1, attr: 0 };
  const i = WX_INFO[w], res = Math.max(0, Math.min(0.8, (c && c.mod && c.mod.wthr) || 0));
  return { w, mv: soften(i.mv, res), atk: soften(i.atk, res), attr: i.attr * (1 - res) };
}

export const weatherText = (w) => {
  const i = WX_INFO[w];
  if (!i || w === WX.CLEAR) return '';
  const pc = (v) => Math.round((1 - v) * 100);
  return `скорость −${pc(i.mv)}%, атака на чужой земле −${pc(i.atk)}%${i.attr ? ', организация в походе падает' : ''}`;
};
