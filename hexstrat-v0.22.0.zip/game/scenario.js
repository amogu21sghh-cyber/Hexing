// Сценарий «Европа 1936»: карта собрана из game/europe_data.js (создаётся tools/europe36.mjs).
import { World, offsetToAxial } from '../engine/index.js';
import { TERRAIN, RULES } from './data.js';
import { EUROPE_1936 } from './europe_data.js';
import { mulberry32 } from './rng.js';

const TERRAIN_BY_CODE = { p: 'plains', f: 'forest', h: 'hills', m: 'mountains', d: 'desert' };

// Правки карты поверх game/europe_data.js: северный мыс Сардинии («Сассари (север)») затоплен,
// чтобы между Корсикой и Сардинией был виден пролив Бонифачо; переправа переведена на «Сассари (восток)».
const SINK = new Set([4033]);
const RELINK = { 4033: 4100 };

export function buildEurope1936(seed) {
  const D = EUROPE_1936;
  const rng = mulberry32(seed);
  const world = new World(D.hexSize);
  const idAt = new Map(); // "col,row" -> id провинции
  let id = 1;
  for (let row = 0; row < D.rows; row++) {
    const line = D.cells[row];
    for (let col = 0; col < D.cols; col++) {
      const { q, r } = offsetToAxial(col, row);
      const s = line.slice(col * 3, col * 3 + 3);
      if (s[0] === '.') { world.addHex(q, r, 'water', null); continue; }
      if (SINK.has(id - 1)) { id++; world.addHex(q, r, 'water', null); continue; } // пролив: клетка уходит под воду, номера остальных провинций не сдвигаются
      const owner = s.charCodeAt(0) - 48, terrain = TERRAIN_BY_CODE[s[1]], w = +s[2];
      const T = TERRAIN[terrain];
      const pid = id++;
      idAt.set(col + ',' + row, pid);
      world.addHex(q, r, terrain, pid);
      const pop = Math.round((T.pop[0] + rng() * (T.pop[1] - T.pop[0])) * (1 + 0.45 * w));
      const wealth = Math.round(T.wealth * (0.8 + rng() * 0.4) * (1 + 0.35 * w) * 100) / 100;
      world.addProvince(pid, D.names[pid - 1], { terrain, pop, wealth, owner, capital: false, built: [], project: null });
    }
  }
  for (const [i, t] of D.deposits || []) world.provinces.get(i + 1).props.deposit = t;
  world.links = D.links.map(([a, b, f]) => { a = RELINK[a] ?? a; b = RELINK[b] ?? b; return f ? [a + 1, b + 1, 1] : [a + 1, b + 1]; });
  world.ferryMax = RULES.ferryMax;
  world.cuts = (D.cuts || []).map(([a, b]) => [a + 1, b + 1]);
  world.rebuild();
  const countries = D.countries.map((c, i) => {
    const cap = world.provinces.get(idAt.get(c.capital[0] + ',' + c.capital[1]));
    cap.props.capital = true;
    cap.props.pop = Math.round(cap.props.pop * 1.5);
    cap.props.wealth = Math.round((cap.props.wealth + 1.5) * 100) / 100;
    return { id: i, name: c.name, color: c.color, capital: cap.id, alive: true, power: c.power };
  });
  return { world, countries, seed };
}
