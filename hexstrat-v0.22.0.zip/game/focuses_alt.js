// Деревья фокусов для малых и средних стран «Европа 1936»: несколько своих фокусов и пути альтернативной истории
// (союзы, ревизия границ, нейтралитет). Модуль без импортов: data.js подмешивает его в FOCUSES и FOCUS_TREES.
//   rg(ключ, название, описание, цена, дни, req, эффект)               — обычный фокус
//   al(ключ, название, страны, эффект, req, excl)                      — союз с названными странами (отношения +25)
//   cl(ключ, название, страна, n, эффект, req, excl)                   — требование n провинций у страны (отношения −25)
//   cu(ключ, название, описание, эффект, действие, req, excl)          — свой путь
const F = (name, desc, cost, days, req, effect, instant, extra) => ({ name, desc, cost, days, req, effect, instant: instant || null, ...(extra || {}) });
const PCT = { gold: 'золото', ind: 'промышленность', men: 'прирост людей', res: 'очки технологий', fuel: 'топливо', loot: 'добыча', speed: 'скорость' };
const bonus = (e) => Object.entries(e).map(([k, v]) => {
  if (k === 'stab') return `стабильность ${v > 0 ? '+' : '−'}${Math.abs(v)}`;
  if (k === 'defense') return `оборона +${v}`;
  if (k === 'attack') return `урон +${Math.round(v * 100)}%`;
  if (k === 'pp') return `власть +${v} в день`;
  return `${PCT[k] || k} ${v > 0 ? '+' : '−'}${Math.abs(Math.round(v * 100))}%`;
}).join(', ');

export const ALT_FOCUSES = {};
export const ALT_TREES = {};
const BASE = ['g_econ', 'g_army', 'g_border', 'g_cons', 'g_trade'];

function country(name, p, list) {
  const ids = [];
  const id = (k) => `${p}_${k}`;
  const add = (k, f) => { ALT_FOCUSES[id(k)] = f; ids.push(id(k)); };
  const px = (a) => (a || []).map((x) => (x.startsWith('g_') || x.startsWith(p + '_') ? x : id(x)));
  const rg = (k, n, d, cost, days, req, eff) => add(k, F(n, d, cost, days, px(req), eff));
  const cu = (k, n, d, eff, act, req, excl) => add(k, F(n, `${d}${bonus(eff) ? '. ' + bonus(eff).replace(/^./, (c) => c.toUpperCase()) : ''}`, 45, 50, px(req), eff, null, { alt: true, act, excl: px(excl) }));
  const al = (k, n, who, eff, req, excl) => cu(k, n, `Союз: ${who.join(', ')}`, eff, { ally: who, rel: who.map((w) => [w, 25]) }, req, excl);
  const cl = (k, n, who, cnt, eff, req, excl, key) => cu(k, n, `Получает ${cnt} пров.: ${who}`, eff, { cede: key ? [who, cnt, key] : [who, cnt], rel: [[who, -25]] }, req, excl);
  list({ rg, al, cl, cu });
  ALT_TREES[name] = [...BASE, ...ids];
}

country('Австрия', 'au', ({ rg, al, cl, cu }) => {
  rg('alps', 'Укрепление Альп', 'Оборона провинций +0.12', 45, 55, [], { defense: 0.12 });
  al('rome', 'Римский блок', ['Италия', 'Венгрия'], { stab: 3 }, ['g_cons'], ['german', 'danube']);
  al('german', 'Союз с Германией', ['Германия'], { gold: 0.06 }, ['g_cons'], ['rome', 'danube']);
  al('danube', 'Дунайская конфедерация', ['Чехословакия', 'Венгрия', 'Югославия'], { stab: 3, gold: 0.04 }, ['g_cons'], ['german', 'rome']);
});
country('Чехословакия', 'cz', ({ rg, al, cl, cu }) => {
  rg('skoda', 'Заводы Шкода', 'Промышленность +15%, золото +5%', 40, 50, [], { ind: 0.15, gold: 0.05 });
  rg('wall', 'Чехословацкий вал', 'Оборона провинций +0.2', 55, 65, ['g_border'], { defense: 0.2 });
  al('west', 'Союз с Францией', ['Франция'], { stab: 3 }, ['g_cons'], []);
  al('east', 'Договор с СССР', ['СССР'], { ind: 0.05 }, ['g_cons'], []);
  al('smalla', 'Малая Антанта', ['Румыния', 'Югославия'], { defense: 0.05 }, ['g_cons'], []);
  cl('teschen', 'Тешинский вопрос', 'Польша', 2, { attack: 0.04 }, ['skoda'], [], 'teschen_cz');
});
country('Венгрия', 'hu', ({ rg, al, cl, cu }) => {
  rg('agr', 'Аграрная модернизация', 'Золото +10%, прирост людей +5%', 35, 45, [], { gold: 0.1, men: 0.05 });
  rg('gyor', 'Программа Дьёра', 'Урон армий +7%', 45, 55, ['g_army'], { attack: 0.07 });
  cl('slovak', 'Ревизия Трианона: юг Словакии', 'Чехословакия', 3, { pp: 0.1 }, ['gyor'], [], 'vienna1');
  cl('transyl', 'Трансильвания', 'Румыния', 3, { attack: 0.03 }, ['gyor'], [], 'transylvania');
  cl('banat', 'Воеводина', 'Югославия', 2, { loot: 0.1 }, ['gyor'], []);
  al('axis', 'Союз с Германией', ['Германия'], { attack: 0.04 }, ['g_cons'], ['rome']);
  al('rome', 'Римский блок', ['Италия', 'Австрия'], { stab: 3 }, ['g_cons'], ['axis']);
});
country('Югославия', 'yu', ({ rg, al, cl, cu }) => {
  rg('army', 'Реорганизация армии', 'Урон +6%, оборона +0.05', 45, 55, ['g_army'], { attack: 0.06, defense: 0.05 });
  rg('unity', 'Югославское единство', 'Стабильность +6', 40, 50, [], { stab: 6 });
  al('west', 'Союз с Францией', ['Франция', 'Чехословакия'], { stab: 3 }, ['unity'], ['axis']);
  al('axis', 'Союз с Осью', ['Германия', 'Италия'], { attack: 0.04 }, ['unity'], ['west']);
  al('balkan', 'Балканский союз', ['Греция', 'Румыния', 'Турция'], { defense: 0.05 }, ['unity'], []);
  cl('albania', 'Албанский вопрос', 'Албания', 2, { loot: 0.1 }, ['army'], []);
});
country('Греция', 'gr', ({ rg, al, cl, cu }) => {
  rg('line', 'Линия Метаксаса', 'Оборона провинций +0.15', 50, 60, ['g_border'], { defense: 0.15 });
  rg('fleet', 'Торговый флот', 'Золото +10%', 35, 45, [], { gold: 0.1 });
  al('west', 'Союз с Британией', ['Великобритания'], { gold: 0.05 }, ['g_cons'], ['italy']);
  al('italy', 'Договор с Италией', ['Италия'], { stab: 2 }, ['g_cons'], ['west']);
  al('balkan', 'Балканский пакт', ['Турция', 'Югославия', 'Румыния'], { defense: 0.05 }, ['g_cons'], []);
  cl('epirus', 'Северный Эпир', 'Албания', 2, { attack: 0.03 }, ['line'], []);
});
country('Болгария', 'bg', ({ rg, al, cl, cu }) => {
  rg('army', 'Перевооружение армии', 'Урон +6%', 45, 55, ['g_army'], { attack: 0.06 });
  rg('coop', 'Аграрная кооперация', 'Золото +8%, прирост людей +5%', 35, 45, [], { gold: 0.08, men: 0.05 });
  cl('dobrudja', 'Южная Добруджа', 'Румыния', 1, { pp: 0.1 }, ['army'], [], 'dobrudja');
  cl('aegean', 'Выход к Эгейскому морю', 'Греция', 2, { loot: 0.15 }, ['army'], []);
  cl('macedonia', 'Македонский вопрос', 'Югославия', 2, { attack: 0.03 }, ['army'], []);
  al('germany', 'Союз с Германией', ['Германия'], { attack: 0.04 }, ['g_cons'], ['russia']);
  al('russia', 'Договор с СССР', ['СССР'], { ind: 0.06 }, ['g_cons'], ['germany']);
});
country('Бельгия', 'be', ({ rg, al, cl, cu }) => {
  rg('forts', 'Бельгийские форты', 'Оборона провинций +0.15', 50, 60, ['g_border'], { defense: 0.15 });
  rg('congo', 'Конго', 'Золото +10%', 35, 45, [], { gold: 0.1 });
  cu('neutral', 'Возврат к нейтралитету', 'Политика независимости 1936 года', { stab: 3 }, { rel: [['Германия', 20], ['Франция', -10]], pp: 15 }, ['g_cons'], ['west']);
  al('west', 'Союз с Францией и Британией', ['Франция', 'Великобритания'], { defense: 0.05 }, ['g_cons'], ['neutral']);
  al('benelux', 'Бенилюкс', ['Нидерланды', 'Люксембург'], { gold: 0.05 }, ['g_cons'], []);
});
country('Нидерланды', 'nl', ({ rg, al, cl, cu }) => {
  rg('water', 'Голландская водная линия', 'Оборона провинций +0.15', 50, 60, ['g_border'], { defense: 0.15 });
  rg('indies', 'Колониальная торговля', 'Золото +12%', 35, 45, [], { gold: 0.12 });
  cu('neutral', 'Нейтралитет', 'Страна остаётся в стороне от европейских споров', { stab: 3 }, { rel: [['Германия', 20]], pp: 15 }, ['g_cons'], ['west']);
  al('west', 'Союз с Британией и Францией', ['Великобритания', 'Франция'], { defense: 0.05 }, ['g_cons'], ['neutral']);
  al('benelux', 'Бенилюкс', ['Бельгия', 'Люксембург'], { gold: 0.05 }, ['g_cons'], []);
});
country('Люксембург', 'lu', ({ rg, al, cl, cu }) => {
  rg('steel', 'Сталелитейная промышленность', 'Промышленность +12%', 35, 45, [], { ind: 0.12 });
  al('france', 'Союз с Францией и Бельгией', ['Франция', 'Бельгия'], { defense: 0.05 }, ['g_cons'], ['germany']);
  al('germany', 'Договор с Германией', ['Германия'], { gold: 0.06 }, ['g_cons'], ['france']);
});
country('Швеция', 'se', ({ rg, al, cl, cu }) => {
  rg('steel', 'Шведская сталь', 'Промышленность +12%, золото +5%', 40, 50, [], { ind: 0.12, gold: 0.05 });
  rg('def', 'Оборонная программа', 'Оборона +0.1, урон +4%', 45, 55, ['g_army'], { defense: 0.1, attack: 0.04 });
  al('finland', 'Помощь Финляндии', ['Финляндия'], { stab: 2 }, ['g_cons'], []);
  al('nordic', 'Скандинавская оборона', ['Норвегия', 'Дания'], { defense: 0.05 }, ['g_cons'], []);
  al('axis', 'Сделка с Германией', ['Германия'], { ind: 0.05 }, ['g_cons'], ['west']);
  al('west', 'Ориентация на Запад', ['Великобритания'], { gold: 0.05 }, ['g_cons'], ['axis']);
});
country('Норвегия', 'no', ({ rg, al, cl, cu }) => {
  rg('fleet', 'Торговый флот', 'Золото +12%', 35, 45, [], { gold: 0.12 });
  rg('north', 'Оборона Севера', 'Оборона провинций +0.1', 40, 50, ['g_border'], { defense: 0.1 });
  al('nordic', 'Скандинавский союз', ['Швеция', 'Дания', 'Финляндия'], { stab: 3 }, ['g_cons'], []);
  al('west', 'Союз с Британией', ['Великобритания'], { defense: 0.05 }, ['g_cons'], ['germany']);
  al('germany', 'Договор с Германией', ['Германия'], { ind: 0.05 }, ['g_cons'], ['west']);
});
country('Дания', 'dk', ({ rg, al, cl, cu }) => {
  rg('bacon', 'Экспорт бекона', 'Золото +12%', 35, 45, [], { gold: 0.12 });
  cu('pact', 'Пакт о ненападении с Германией', 'Копенгаген договаривается с Берлином', { stab: 3 }, { rel: [['Германия', 30]], pp: 10 }, ['g_cons'], ['west']);
  al('nordic', 'Скандинавский союз', ['Швеция', 'Норвегия'], { defense: 0.05 }, ['g_cons'], []);
  al('west', 'Союз с Британией', ['Великобритания'], { gold: 0.05 }, ['g_cons'], ['pact']);
});
country('Исландия', 'is', ({ rg, al, cl, cu }) => {
  rg('fish', 'Рыбный промысел', 'Золото +15%', 35, 45, [], { gold: 0.15 });
  cu('indep', 'Независимость', 'Разрыв унии с Данией', { stab: 3 }, { rel: [['Дания', -15]], fn: (g, c) => { c.overlord = null; } }, ['g_cons'], []);
  al('west', 'Защита Британии', ['Великобритания'], { defense: 0.05 }, ['g_cons'], []);
});
for (const [name, p, pair, finn] of [['Эстония', 'ee', ['Латвия', 'Литва'], true], ['Латвия', 'lv', ['Эстония', 'Литва'], false], ['Литва', 'lt', ['Эстония', 'Латвия'], false]]) {
  country(name, p, ({ rg, al, cl, cu }) => {
    rg('coast', 'Оборона границ', 'Оборона провинций +0.1', 40, 50, ['g_border'], { defense: 0.1 });
    al('baltic', 'Балтийский союз', pair, { defense: 0.05 }, ['g_cons'], []);
    if (finn) al('finland', 'Союз с Финляндией', ['Финляндия'], { stab: 2 }, ['g_cons'], []);
    else al('poland', 'Союз с Польшей', ['Польша'], { defense: 0.04 }, ['g_cons'], ['germany']);
    al('germany', 'Договор с Германией', ['Германия'], { gold: 0.05 }, ['g_cons'], p !== 'ee' ? ['poland'] : []);
    al('ussr', 'Договор с СССР', ['СССР'], { ind: 0.05 }, ['g_cons'], []);
    if (p === 'lt') cl('vilnius', 'Виленский вопрос', 'Польша', 2, { pp: 0.1 }, ['coast'], []);
  });
}
country('Португалия', 'pt', ({ rg, al, cl, cu }) => {
  rg('estado', 'Новое государство', 'Стабильность +5, золото +5%', 40, 50, [], { stab: 5, gold: 0.05 });
  rg('empire', 'Колониальная империя', 'Золото +12%', 40, 50, [], { gold: 0.12 });
  al('oldest', 'Старейший союз', ['Великобритания'], { defense: 0.05 }, ['estado'], ['iberia']);
  al('iberia', 'Иберийский пакт', ['Испания'], { stab: 3 }, ['estado'], ['oldest']);
});
country('Ирландия', 'ie', ({ rg, al, cl, cu }) => {
  rg('dev', 'Экономическая самостоятельность', 'Золото +10%, стабильность +3', 35, 45, [], { gold: 0.1, stab: 3 });
  cl('north', 'Единая Ирландия', 'Великобритания', 1, { stab: 2 }, ['dev'], ['dominion']);
  al('dominion', 'Союз с Британией', ['Великобритания'], { defense: 0.05 }, ['g_cons'], ['north']);
  cu('neutral', 'Нейтралитет', 'Страна остаётся в стороне от войны', { stab: 4 }, { rel: [['Германия', 10]], pp: 20 }, ['g_cons'], []);
});
country('Швейцария', 'ch', ({ rg, al, cl, cu }) => {
  rg('redoubt', 'Национальный редут', 'Оборона провинций +0.25', 60, 70, ['g_border'], { defense: 0.25 });
  rg('bank', 'Банковская тайна', 'Золото +15%', 40, 50, [], { gold: 0.15 });
  cu('neutral', 'Вооружённый нейтралитет', 'Мобилизация без союзов', { defense: 0.05 }, { pp: 25, rel: [['Германия', 5], ['Франция', 5]] }, ['redoubt'], ['west']);
  al('west', 'Союз с Францией', ['Франция'], { stab: 2 }, ['g_cons'], ['neutral']);
});
country('Албания', 'al', ({ rg, al, cl, cu }) => {
  rg('zog', 'Королевская гвардия', 'Стабильность +5', 35, 45, [], { stab: 5 });
  rg('oil', 'Нефть Девол', 'Топливо +30%, золото +5%', 40, 50, [], { fuel: 0.3, gold: 0.05 });
  al('italy', 'Союз с Италией', ['Италия'], { gold: 0.08 }, ['zog'], ['balkan']);
  al('balkan', 'Балканский союз', ['Югославия', 'Греция'], { defense: 0.05 }, ['zog'], ['italy']);
  cl('kosovo', 'Косово', 'Югославия', 2, { loot: 0.1 }, ['oil'], []);
});
country('Египет', 'eg', ({ rg, al, cl, cu }) => {
  rg('cotton', 'Хлопковая экономика', 'Золото +12%', 35, 45, [], { gold: 0.12 });
  rg('army', 'Реформа армии 1936', 'Урон +5%, оборона +0.06', 45, 55, ['g_army'], { attack: 0.05, defense: 0.06 });
  al('brit', 'Англо-египетский договор', ['Великобритания'], { defense: 0.05 }, ['g_cons'], ['indep']);
  cu('indep', 'Полная независимость', 'Выход из-под британской опеки', { stab: 4 }, { rel: [['Великобритания', -30]], pp: 20 }, ['g_cons'], ['brit']);
  al('arab', 'Арабский союз', ['Ирак', 'Саудовская Аравия'], { stab: 2 }, ['g_cons'], []);
});
country('Ирак', 'iq', ({ rg, al, cl, cu }) => {
  rg('oil', 'Нефть Киркука', 'Топливо +40%, золото +5%', 40, 50, [], { fuel: 0.4, gold: 0.05 });
  rg('army', 'Реформа армии', 'Урон +5%', 40, 50, ['g_army'], { attack: 0.05 });
  al('brit', 'Союз с Британией', ['Великобритания'], { defense: 0.05 }, ['g_cons'], []);
  al('arab', 'Арабский союз', ['Египет', 'Саудовская Аравия'], { stab: 2 }, ['g_cons'], []);
  al('saadabad', 'Саадабадский пакт', ['Турция', 'Иран'], { stab: 2 }, ['g_cons'], []);
});
country('Иран', 'ir', ({ rg, al, cl, cu }) => {
  rg('rail', 'Трансиранская железная дорога', 'Золото +10%, скорость +5%', 40, 50, [], { gold: 0.1, speed: 0.05 });
  rg('oil', 'Нефть Персии', 'Топливо +35%, золото +5%', 40, 50, [], { fuel: 0.35, gold: 0.05 });
  al('germany', 'Сближение с Германией', ['Германия'], { ind: 0.05 }, ['g_cons'], ['brit', 'ussr']);
  al('brit', 'Союз с Британией', ['Великобритания'], { gold: 0.05 }, ['g_cons'], ['germany', 'ussr']);
  al('ussr', 'Договор с СССР', ['СССР'], { ind: 0.05 }, ['g_cons'], ['germany', 'brit']);
  al('saadabad', 'Саадабадский пакт', ['Турция', 'Ирак'], { stab: 2 }, ['g_cons'], []);
});
country('Саудовская Аравия', 'sa', ({ rg, al, cl, cu }) => {
  rg('oil', 'Нефтяная концессия', 'Топливо +30%, золото +10%', 40, 50, [], { fuel: 0.3, gold: 0.1 });
  rg('militia', 'Племенные ополчения', 'Прирост людей +10%', 35, 45, [], { men: 0.1 });
  al('brit', 'Союз с Британией', ['Великобритания'], { gold: 0.05 }, ['g_cons'], []);
  al('arab', 'Арабский союз', ['Египет', 'Ирак'], { stab: 2 }, ['g_cons'], []);
});

// Дополнительные пути для стран, у которых уже есть свои деревья
export const ALT_ADD = {};
function extend(name, p, list) {
  country(name, p, list);
  const own = ALT_TREES[name].filter((x) => !BASE.includes(x));
  delete ALT_TREES[name];
  ALT_ADD[name] = own;
}
extend('Турция', 'tr', ({ al, cl }) => {
  al('balkan', 'Балканская Антанта', ['Греция', 'Румыния', 'Югославия'], { defense: 0.05 }, ['tr_atat'], []);
  al('west', 'Союз с Британией и Францией', ['Великобритания', 'Франция'], { gold: 0.06 }, ['tr_atat'], ['axis']);
  al('axis', 'Договор с Германией', ['Германия'], { ind: 0.05 }, ['tr_atat'], ['west']);
  al('saadabad', 'Саадабадский пакт', ['Иран', 'Ирак'], { stab: 2 }, ['tr_atat'], []);
  cl('thrace', 'Западная Фракия', 'Греция', 2, { attack: 0.03 }, ['tr_army'], []);
});
extend('Румыния', 'ro', ({ al, cl }) => {
  al('west', 'Гарантии Запада', ['Франция', 'Великобритания'], { defense: 0.05 }, ['ro_king'], ['axis']);
  al('axis', 'Союз с Германией', ['Германия'], { fuel: 0.1 }, ['ro_king'], ['west']);
  al('poland', 'Союз с Польшей', ['Польша'], { defense: 0.05 }, ['ro_king'], []);
  al('smalla', 'Малая Антанта', ['Чехословакия', 'Югославия'], { stab: 2 }, ['ro_king'], []);
  cl('bessarabia', 'Бессарабский вопрос', 'СССР', 2, { attack: 0.03 }, ['ro_army'], []);
});

// ---------- пути к «Великой» стране ----------
// Для ряда стран: идея нации (общий фокус), требования земель у соседей и завершающий фокус «Великая X».
// Завершающий фокус даёт постоянные бонусы, разовую награду, новое название страны и доступен, только если страна удерживает
// не менее GREAT_MIN присоединённых провинций (не родных по ядру). В историческом режиме у Германии и Италии есть дата.
const GREAT_MIN = 3;
const heldForeign = (g, c) => { let n = 0; for (const p of g.world.provinces.values()) if (p.props.owner === c.id && p.props.core !== c.id) n++; return n; };
const greatNeed = { need: (g, c) => heldForeign(g, c) >= GREAT_MIN, needText: `Нужно удерживать не менее ${GREAT_MIN} присоединённых провинций` };

function greatPath(name, p, cfg) {
  const id = (k) => `${p}_${k}`;
  const px = (a) => (a || []).map((x) => (x.startsWith('g_') || x.startsWith(p + '_') || /^[a-z]{2}_/.test(x) ? x : id(x)));
  const ids = [];
  const add = (k, f) => { ALT_FOCUSES[id(k)] = f; ids.push(id(k)); };
  add('idea', F(cfg.idea, `${cfg.ideaDesc}. ${bonus({ stab: 2, pp: 0.2 }).replace(/^./, (c) => c.toUpperCase())}`, 45, 50, px(cfg.ideaReq), { stab: 2, pp: 0.2 }, null, { alt: true, act: { flags: ['great_idea'] }, excl: [] }));
  for (const [k, n, who, cnt, eff] of cfg.claims || []) {
    add(k, F(n, `Получает ${cnt} пров.: ${who}. ${bonus(eff).replace(/^./, (c) => c.toUpperCase())}`, 45, 50, [id('idea')], eff, null, { alt: true, act: { cede: [who, cnt], rel: [[who, -25]] }, excl: [] }));
  }
  const eff = cfg.effect || { stab: 3, pp: 0.3, attack: 0.05, men: 0.1 };
  const desc = `Страна становится «${cfg.title}». ${bonus(eff).replace(/^./, (c) => c.toUpperCase())}, сразу +20 власти и +50 людей. ${greatNeed.needText}`;
  const news = { title: cfg.title, text: cfg.news || `${name} объявляет о создании «${cfg.title}»: многолетняя политика расширения доведена до конца. Соседи с тревогой следят за новым центром силы.`, world: true };
  add('great', F(cfg.cap, desc, 80, 70, px([id('idea'), ...(cfg.capReq || [])]), eff, { pp: 20, men: 50 },
    { alt: true, great: true, act: { title: cfg.title, flags: ['great'], tension: 5 }, excl: [], news, ...greatNeed, ...(cfg.from ? { from: cfg.from } : {}) }));
  if (ALT_TREES[name]) ALT_TREES[name].push(...ids);
  else (ALT_ADD[name] = ALT_ADD[name] || []).push(...ids);
}

greatPath('Венгрия', 'hu', { idea: 'Земли Святого Иштвана', ideaDesc: 'Ревизия Трианона становится целью государства', ideaReq: ['gyor'],
  capReq: ['slovak', 'transyl'], cap: 'Великая Венгрия', title: 'Великая Венгрия' });
greatPath('Румыния', 'ro', { idea: 'Идея Великой Румынии', ideaDesc: 'Объединение всех румын в одном государстве', ideaReq: ['ro_king'],
  claims: [['bukovina', 'Северная Буковина', 'СССР', 1, { pp: 0.1 }]], capReq: ['ro_bessarabia', 'bukovina'], cap: 'Великая Румыния', title: 'Великая Румыния' });
greatPath('Болгария', 'bg', { idea: 'Сан-Стефанская Болгария', ideaDesc: 'Границы 1878 года как национальная цель', ideaReq: ['army'],
  capReq: ['macedonia', 'aegean'], cap: 'Великая Болгария', title: 'Великая Болгария' });
greatPath('Албания', 'al', { idea: 'Албанская идея', ideaDesc: 'Объединение албанских земель', ideaReq: ['zog'],
  claims: [['chameria', 'Чамерия', 'Греция', 2, { attack: 0.03 }]], capReq: ['kosovo', 'chameria'], cap: 'Великая Албания', title: 'Великая Албания' });
greatPath('Греция', 'gr', { idea: 'Мегали идея', ideaDesc: 'Греческий мир по обе стороны Эгейского моря', ideaReq: ['line'],
  claims: [['smyrna', 'Смирна и Малая Азия', 'Турция', 3, { loot: 0.1 }]], capReq: ['epirus', 'smyrna'], cap: 'Великая Греция', title: 'Великая Греция' });
greatPath('Турция', 'tr', { idea: 'Турецкий мир', ideaDesc: 'Новая роль Турции в регионе', ideaReq: ['tr_atat'],
  claims: [['mosul', 'Мосульский вилайет', 'Ирак', 2, { fuel: 0.1 }]], capReq: ['thrace', 'mosul'], cap: 'Великая Турция', title: 'Великая Турция' });
greatPath('Иран', 'ir', { idea: 'Идея Великого Ирана', ideaDesc: 'Наследие Персидской державы', ideaReq: ['rail'],
  claims: [['iraq', 'Земли Двуречья', 'Ирак', 3, { fuel: 0.1 }]], capReq: ['iraq'], cap: 'Великий Иран', title: 'Великий Иран' });
greatPath('Италия', 'it', { idea: 'Наше море', ideaDesc: 'Mare Nostrum: Средиземное море — итальянское', ideaReq: ['it_empire'],
  claims: [['nice', 'Ницца, Савойя и Корсика', 'Франция', 3, { loot: 0.1 }]], capReq: ['it_albania', 'nice'], cap: 'Великая Италия', title: 'Великая Италия', from: [1940, 6, 10] });
greatPath('Германия', 'de', { idea: 'Идея Великой Германии', ideaDesc: 'Объединение немцев в одном государстве', ideaReq: ['de_rearm'],
  capReq: ['de_anschluss', 'de_czech'], cap: 'Великая Германия', title: 'Великая Германия', from: [1939, 3, 15] });
greatPath('Польша', 'pl', { idea: 'Идея Междуморья', ideaDesc: 'Польша как центр между Балтикой и Чёрным морем', ideaReq: ['pl_cop'],
  claims: [['lit', 'Литовская уния', 'Литва', 3, { men: 0.05 }]], capReq: ['pl_inter', 'lit'], cap: 'Великая Польша', title: 'Великая Польша' });
greatPath('Испания', 'es', { idea: 'Идеи Испанидад', ideaDesc: 'Единый испанский мир', ideaReq: ['es_unity'],
  capReq: ['es_iberia'], cap: 'Великая Испания', title: 'Великая Испания' });
greatPath('Великобритания', 'gb', { idea: 'Имперская федерация', ideaDesc: 'Метрополия и доминионы как единое целое', ideaReq: ['gb_pref'],
  capReq: ['gb_empire'], cap: 'Великая Британия', title: 'Великая Британия', effect: { stab: 3, pp: 0.3, gold: 0.1, men: 0.1 } });
