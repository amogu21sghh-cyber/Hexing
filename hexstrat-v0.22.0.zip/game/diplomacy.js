// Альянсы и организации: операции игрока и ИИ. Основа (отношения, фракции, оборона) лежит в state.js.
import { RULES, ORGS } from './data.js';
import {
  atWar, opinion, addRel, factionOf, factionMates, sameFaction, removeFromFaction, joinWar, emit, recalcMods, economyPreview,
  warScore, vassalize, makePeace, justifying, hasGoal, guaranteed, addGuarantee, vassalLink, refreshStats, warAge,
} from './state.js';
import { cedeProvinces, pickCede } from './events.js';
import { respondTrade } from './trade.js';

const fail = (msg) => ({ ok: false, msg });
const name = (g, id) => g.countries[id].name;

function addMember(g, f, id) {
  const c = g.countries[id];
  c.faction = f.id;
  f.members.push(id);
  addRel(g, id, f.leader, 5);
  emit(g, `${c.name} вступила в ${f.name}`, [id, f.leader], 'alliance');
}

const warsWithMembers = (g, id, f) => f.members.some((m) => atWar(g, id, m));

export function foundFaction(g, owner) {
  const c = g.countries[owner];
  if (c.faction != null) return fail('Вы уже состоите в альянсе');
  if (c.pp < RULES.factionPP) return fail(`Не хватает политической власти: нужно ${RULES.factionPP}`);
  c.pp -= RULES.factionPP;
  const f = { id: g.nextFactionId++, name: `Блок «${c.name}»`, leader: owner, members: [owner], founded: g.day };
  g.factions.push(f);
  c.faction = f.id;
  emit(g, `${c.name} основала ${f.name}`, [owner], 'alliance');
  return { ok: true };
}

export function disbandFaction(g, owner) {
  const f = factionOf(g, g.countries[owner]);
  if (!f || f.leader !== owner) return fail('Только лидер может распустить альянс');
  for (const m of f.members) g.countries[m].faction = null;
  g.factions = g.factions.filter((x) => x !== f);
  emit(g, `${name(g, owner)} распустила ${f.name}`, [...f.members], 'alliance');
  return { ok: true };
}

export function leaveFaction(g, owner) {
  const f = factionOf(g, g.countries[owner]);
  if (!f) return fail('Вы не в альянсе');
  if (f.leader === owner) return disbandFaction(g, owner);
  addRel(g, owner, f.leader, -15);
  emit(g, `${name(g, owner)} вышла из ${f.name}`, [owner, f.leader], 'alliance');
  removeFromFaction(g, owner);
  return { ok: true };
}

export function kickMember(g, owner, target) {
  const f = factionOf(g, g.countries[owner]);
  if (!f || f.leader !== owner) return fail('Только лидер может исключать');
  if (!f.members.includes(target) || target === owner) return fail('Не член альянса');
  addRel(g, target, owner, -30);
  emit(g, `${name(g, target)} исключена из ${f.name}`, [target, owner], 'alliance');
  removeFromFaction(g, target);
  return { ok: true };
}

// Согласие ИИ на вступление: отношение к лидеру плюс интерес воюющей страны.
export function joinScore(g, target, f) {
  return opinion(g, target, f.leader) + (g.wars.size && [...g.wars.keys()].some((k) => k.split('|').map(Number).includes(target)) ? 10 : 0);
}

export function canJoinFaction(g, target, f) {
  const c = g.countries[target];
  if (!c.alive) return fail('Страны больше нет');
  if (c.faction != null) return fail('Уже состоит в альянсе');
  if (warsWithMembers(g, target, f)) return fail('Воюет с членом альянса');
  if (f.members.length >= 8) return fail('В альянсе уже 8 стран');
  return { ok: true };
}

const hasOffer = (g, kind, from, to) => g.offers.some((o) => o.kind === kind && o.from === from && o.to === to);
function pushOffer(g, o) {
  g.offers.push({ id: g.nextOfferId++, day: g.day, ...o });
}

// Лидер приглашает страну: игрок получает предложение, ИИ отвечает сразу.
export function inviteToFaction(g, owner, target) {
  const c = g.countries[owner], f = factionOf(g, c);
  if (!f || f.leader !== owner) return fail('Приглашать может только лидер');
  const can = canJoinFaction(g, target, f);
  if (!can.ok) return can;
  if (c.pp < RULES.invitePP) return fail(`Не хватает политической власти: нужно ${RULES.invitePP}`);
  if (target === g.playerId) {
    if (hasOffer(g, 'invite', owner, target)) return fail('Приглашение уже отправлено');
    c.pp -= RULES.invitePP;
    pushOffer(g, { kind: 'invite', from: owner, to: target, factionId: f.id });
    emit(g, `${c.name} приглашает вас в ${f.name}`, [target, owner], 'offer');
    return { ok: true, msg: 'Приглашение отправлено' };
  }
  c.pp -= RULES.invitePP;
  if (joinScore(g, target, f) >= RULES.inviteMin) {
    addMember(g, f, target);
    return { ok: true, accepted: true, msg: `${name(g, target)} вступила в альянс` };
  }
  addRel(g, target, owner, -3);
  return { ok: true, accepted: false, msg: `${name(g, target)} отклонила приглашение` };
}

// Страна просит принять её в альянс: лидер-игрок получает предложение, лидер-ИИ отвечает сразу.
export function requestJoin(g, owner, factionId) {
  const f = g.factions.find((x) => x.id === factionId);
  if (!f) return fail('Нет такого альянса');
  const can = canJoinFaction(g, owner, f);
  if (!can.ok) return can;
  if (f.leader === g.playerId) {
    if (hasOffer(g, 'join', owner, f.leader)) return fail('Просьба уже отправлена');
    pushOffer(g, { kind: 'join', from: owner, to: f.leader, factionId: f.id });
    emit(g, `${name(g, owner)} просит принять её в ${f.name}`, [f.leader, owner], 'offer');
    return { ok: true, msg: 'Просьба отправлена' };
  }
  if (opinion(g, f.leader, owner) >= RULES.inviteMin) {
    addMember(g, f, owner);
    return { ok: true, accepted: true, msg: `${f.name} принял вас` };
  }
  addRel(g, owner, f.leader, -2);
  return { ok: true, accepted: false, msg: `${name(g, f.leader)} отклонила просьбу` };
}

// Враги лидера, в войну с которыми можно позвать члена.
export function callableEnemies(g, owner, target) {
  const out = [];
  for (let e = 0; e < g.countries.length; e++) {
    if (e === owner || e === target || !g.countries[e].alive) continue;
    if (atWar(g, owner, e) && !atWar(g, target, e) && !sameFaction(g, target, e)) out.push(e);
  }
  return out;
}

// Лидер зовёт члена альянса в свои войны.
export function callToWar(g, owner, target) {
  const c = g.countries[owner], f = factionOf(g, c);
  if (!f || f.leader !== owner) return fail('Звать может только лидер');
  if (!f.members.includes(target) || target === owner) return fail('Не член альянса');
  const enemies = callableEnemies(g, owner, target);
  if (!enemies.length) return fail('Нет войн, в которые можно позвать');
  if (c.pp < RULES.callPP) return fail(`Не хватает политической власти: нужно ${RULES.callPP}`);
  if (target === g.playerId) {
    if (hasOffer(g, 'call', owner, target)) return fail('Призыв уже отправлен');
    c.pp -= RULES.callPP;
    pushOffer(g, { kind: 'call', from: owner, to: target });
    emit(g, `${c.name} призывает вас в войну`, [target, owner], 'offer');
    return { ok: true, msg: 'Призыв отправлен' };
  }
  c.pp -= RULES.callPP;
  if (opinion(g, target, owner) >= 10) {
    for (const e of enemies) joinWar(g, target, e);
    return { ok: true, accepted: true, msg: `${name(g, target)} вступает в войну` };
  }
  addRel(g, target, owner, -5);
  return { ok: true, accepted: false, msg: `${name(g, target)} отказалась воевать` };
}

// Ответ игрока на предложение.
export function respondOffer(g, id, accept) {
  const i = g.offers.findIndex((o) => o.id === id && o.to === g.playerId);
  if (i < 0) return fail('Предложение устарело');
  const o = g.offers[i];
  g.offers.splice(i, 1);
  const me = g.playerId;
  if (o.kind === 'invite' || o.kind === 'join') {
    const f = g.factions.find((x) => x.id === o.factionId);
    const joiner = o.kind === 'invite' ? me : o.from;
    if (!accept) { addRel(g, me, o.from, -3); return { ok: true, msg: 'Отклонено' }; }
    if (!f) return fail('Альянса больше нет');
    const can = canJoinFaction(g, joiner, f);
    if (!can.ok) return can;
    addMember(g, f, joiner);
    return { ok: true, msg: o.kind === 'invite' ? `Вы вступили в ${f.name}` : `${name(g, joiner)} принята в альянс` };
  }
  if (o.kind === 'call') {
    if (!accept) { addRel(g, me, o.from, -10); return { ok: true, msg: 'Вы отказались воевать' }; }
    let n = 0;
    for (const e of callableEnemies(g, o.from, me)) if (joinWar(g, me, e)) n++;
    return n ? { ok: true, msg: 'Вы вступили в войну союзника' } : fail('Войны уже закончились');
  }
  if (o.kind === 'peace') return respondPeace(g, o, accept);
  if (o.kind === 'trade') return respondTrade(g, o, accept);
  return fail('Неизвестное предложение');
}

// ---------- организации ----------
export const orgMembers = (g, oid) => g.countries.filter((c) => c.alive && c.orgs.includes(oid));

export function orgJoinCheck(g, owner, oid) {
  const o = ORGS[oid], c = g.countries[owner];
  if (c.orgs.includes(oid)) return fail('Вы уже состоите');
  if (o.closed && !o.members.includes(c.base || c.name)) return fail('Только для стран региона');
  if (o.ideo && !o.ideo.includes(c.ideo)) return fail('Не подходит по строю');
  const members = orgMembers(g, oid);
  if (!members.length) return fail('В организации никого нет');
  if (members.some((m) => atWar(g, owner, m.id))) return fail('Воюете с членом организации');
  const avg = members.reduce((t, m) => t + opinion(g, owner, m.id), 0) / members.length;
  if (avg < o.minOpinion) return fail(`Плохие отношения с членами: нужно от ${o.minOpinion}, сейчас ${Math.round(avg)}`);
  if (c.pp < RULES.orgPP) return fail(`Не хватает политической власти: нужно ${RULES.orgPP}`);
  return { ok: true };
}

export function joinOrg(g, owner, oid) {
  const can = orgJoinCheck(g, owner, oid);
  if (!can.ok) return can;
  const c = g.countries[owner];
  c.pp -= RULES.orgPP;
  c.orgs.push(oid);
  recalcMods(c);
  economyPreview(g);
  emit(g, `${c.name} вступила в организацию «${ORGS[oid].name}»`, [owner], 'alliance');
  return { ok: true };
}

export function leaveOrg(g, owner, oid) {
  const c = g.countries[owner];
  if (!c.orgs.includes(oid)) return fail('Вы не состоите');
  c.orgs = c.orgs.filter((x) => x !== oid);
  recalcMods(c);
  economyPreview(g);
  emit(g, `${c.name} вышла из организации «${ORGS[oid].name}»`, [owner], 'alliance');
  return { ok: true };
}

// ---------- повод к войне, гарантии, ленд-лиз, условия мира ----------
export function startJustify(g, owner, target) {
  const c = g.countries[owner], t = g.countries[target];
  if (!t.alive || owner === target) return fail('Нельзя');
  if (c.overlord != null) return fail('Вассал не ведёт своей политики');
  if (atWar(g, owner, target)) return fail('Война уже идёт');
  if (sameFaction(g, owner, target) || vassalLink(g, owner, target)) return fail('Это союзник или вассал');
  if (hasGoal(g, owner, target)) return fail('Повод уже есть');
  if (justifying(g, owner, target)) return fail('Повод уже обосновывается');
  if ((g.justify || []).some((j) => j.a === owner && g.day < j.end)) return fail('Вы уже обосновываете другую войну');
  if (c.pp < RULES.justifyPP) return fail(`Не хватает политической власти: нужно ${RULES.justifyPP}`);
  c.pp -= RULES.justifyPP;
  const days = Math.round(RULES.justifyDays + g.tension * 0.2);
  g.justify.push({ a: owner, b: target, start: g.day, end: g.day + days });
  g.tension = Math.min(100, g.tension + 3);
  emit(g, `${c.name} обосновывает претензии к ${t.name}`, [owner, target], 'war');
  return { ok: true, msg: `Повод будет готов через ${days} дн.` };
}

export function justifyDays(g) { return Math.round(RULES.justifyDays + g.tension * 0.2); }

export function giveGuarantee(g, by, of) {
  const c = g.countries[by], t = g.countries[of];
  if (!t.alive || by === of) return fail('Нельзя');
  if (c.overlord != null) return fail('Вассал не даёт гарантий');
  if (guaranteed(g, by, of)) return fail('Гарантия уже дана');
  if (atWar(g, by, of)) return fail('Вы воюете');
  if (c.pp < RULES.guarPP) return fail(`Не хватает политической власти: нужно ${RULES.guarPP}`);
  if (opinion(g, of, by) < -20) return fail(`${t.name} не принимает гарантий`);
  c.pp -= RULES.guarPP;
  addGuarantee(g, by, of);
  return { ok: true, msg: `Вы гарантируете независимость: ${t.name}` };
}

export function revokeGuarantee(g, by, of) {
  const n = g.guar.length;
  g.guar = g.guar.filter((x) => !(x.by === by && x.of === of));
  if (g.guar.length === n) return fail('Гарантии нет');
  addRel(g, of, by, -15);
  emit(g, `${g.countries[by].name} отозвала гарантии стране ${g.countries[of].name}`, [by, of], 'alliance');
  return { ok: true };
}

export const lendOf = (g, from, to) => (g.lend || []).find((l) => l.from === from && l.to === to) || null;

export function startLend(g, from, to) {
  const c = g.countries[from], t = g.countries[to];
  if (!t.alive || from === to) return fail('Нельзя');
  if (lendOf(g, from, to)) return fail('Ленд-лиз уже идёт');
  if (atWar(g, from, to)) return fail('Вы воюете');
  const near = sameFaction(g, from, to) || vassalLink(g, from, to) || guaranteed(g, from, to) || guaranteed(g, to, from) || opinion(g, to, from) >= 30;
  if (!near) return fail('Нужны союз, гарантии или хорошие отношения');
  if ((g.lend || []).filter((l) => l.from === from).length >= 3) return fail('Не больше трёх получателей');
  if (c.pp < RULES.lendPP) return fail(`Не хватает политической власти: нужно ${RULES.lendPP}`);
  c.pp -= RULES.lendPP;
  g.lend.push({ from, to, day: g.day, until: g.day + RULES.lendDays });
  addRel(g, to, from, 15);
  emit(g, `${c.name} поставляет помощь стране ${t.name}`, [from, to], 'alliance');
  return { ok: true, msg: `Ленд-лиз: ${RULES.lendDays} дн.` };
}

export function stopLend(g, from, to) {
  const n = g.lend.length;
  g.lend = g.lend.filter((l) => !(l.from === from && l.to === to));
  return n === g.lend.length ? fail('Нет поставок') : { ok: true };
}

export function releaseVassal(g, owner, id) {
  const v = g.countries[id];
  if (!v.alive || v.overlord !== owner) return fail('Это не ваш вассал');
  v.overlord = null;
  addRel(g, id, owner, 15);
  emit(g, `${g.countries[owner].name} отпустила ${v.name}`, [owner, id], 'peace');
  return { ok: true };
}

// Мирная конференция: победитель тратит очки войны на условия. cede — земли, vassal — вассал.
export const PEACE_TERMS = { tgold: { min: 25, label: 'Контрибуция деньгами' }, tres: { min: 25, label: 'Контрибуция ресурсами' }, cede: { min: 40, label: 'Забрать земли' }, vassal: { min: 60, label: 'Сделать вассалом' } };
const KIND_OF = { tgold: 'gold', tres: 'goods' };

// Контрибуция: деньги или ресурсы (топливо и промышленность). Доля запасов плательщика растёт с очками войны.
export function tributeAmount(g, payer, score, kind) {
  const c = g.countries[payer];
  const pct = Math.max(0.15, Math.min(0.6, score / 200));
  if (kind === 'gold') return { gold: Math.min(Math.floor(c.gold), Math.max(80, Math.round(c.gold * pct))) };
  return { fuel: Math.round(c.fuel * pct), industry: Math.round(c.industry * pct) };
}
export function tributeText(pay) {
  const t = [];
  if (pay.gold) t.push(`${Math.round(pay.gold)} золота`);
  if (pay.fuel) t.push(`${Math.round(pay.fuel)} топлива`);
  if (pay.industry) t.push(`${Math.round(pay.industry)} промышленности`);
  return t.join(' и ') || 'ничего';
}
export function payTribute(g, payer, receiver, pay) {
  const p = g.countries[payer], r = g.countries[receiver];
  for (const k of ['gold', 'fuel', 'industry']) {
    const amt = Math.min(p[k], pay[k] || 0);
    if (amt > 0) { p[k] -= amt; r[k] += amt; }
  }
}
export const canPay = (g, payer, pay) => ['gold', 'fuel', 'industry'].every((k) => !pay[k] || g.countries[payer][k] >= pay[k] * 0.999);

// Проигравший сам платит откупом и просит мира: враг согласен всегда
export function concedeTribute(g, from, to, kind) {
  const sT = warScore(g, to, from);
  if (!atWar(g, from, to)) return fail('Вы не воюете');
  if (sT < PEACE_TERMS.tgold.min) return fail('Враг не требует контрибуции: попробуйте белый мир');
  const pay = tributeAmount(g, from, sT, kind);
  payTribute(g, from, to, pay);
  makePeace(g, from, to);
  return { ok: true, msg: `Мир: вы заплатили ${tributeText(pay)}` };
}
export const cedeCount = (score) => Math.max(2, Math.min(12, Math.floor(score / 6)));

export function demandPeace(g, from, to, kind) {
  const t = PEACE_TERMS[kind];
  if (!t || !atWar(g, from, to)) return fail('Вы не воюете');
  const c = g.countries[from], enemy = g.countries[to];
  if (warAge(g, from, to) < 20) return fail('Война только началась');
  if (enemy.overlord != null && kind === 'vassal') return fail('Страна уже вассал');
  if (c.overlord != null) return fail('Вассал не диктует условий');
  const score = warScore(g, from, to);
  if (score < t.min) return fail(`Мало очков войны: ${score} из ${t.min}`);
  const cost = RULES.peacePP * 2;
  if (c.pp < cost) return fail(`Не хватает политической власти: нужно ${cost}`);
  c.pp -= cost;
  applyTerms(g, from, to, kind, score);
  return { ok: true, msg: kind === 'vassal' ? `${enemy.name} стала вашим вассалом` : KIND_OF[kind] ? `Мир: ${enemy.name} выплатила контрибуцию` : 'Мир на ваших условиях' };
}

function applyTerms(g, winner, loser, kind, score, n) {
  if (kind === 'vassal') { vassalize(g, winner, loser); return; }
  if (KIND_OF[kind]) payTribute(g, loser, winner, tributeAmount(g, loser, score, KIND_OF[kind]));
  if (kind === 'cede') cedeProvinces(g, loser, winner, n != null ? n : cedeCount(score));
  makePeace(g, winner, loser);
}

// Мир между ИИ: сильнейший по очкам войны диктует условия
// Пары, чьи войны в историческом режиме ИИ не прекращает сам: их заканчивают события и фиксированные итоги (SETTLE)
const HIST_NO_PEACE = [['Германия', 'Польша'], ['Германия', 'Франция'], ['Германия', 'Великобритания'], ['Германия', 'СССР'], ['Испания', 'Националисты'], ['Италия', 'Великобритания'], ['Италия', 'Франция'], ['Италия', 'Греция'], ['Германия', 'Дания'], ['Германия', 'Норвегия'], ['Германия', 'Нидерланды'], ['Германия', 'Бельгия'], ['Германия', 'Люксембург'], ['Германия', 'Югославия'], ['Германия', 'Греция'], ['Германия', 'Чехословакия']];
function histLocked(g, a, b) {
  if (!g.historical || g.scenario !== 'europe1936') return false;
  const x = g.countries[a].base || g.countries[a].name, y = g.countries[b].base || g.countries[b].name;
  return HIST_NO_PEACE.some(([p, q]) => (p === x && q === y) || (p === y && q === x));
}

export function aiPeace(g, a, b) {
  if (histLocked(g, a, b)) return;
  const sa = warScore(g, a, b), sb = warScore(g, b, a);
  const w = sa >= sb ? a : b, l = w === a ? b : a, s = Math.max(sa, sb);
  const wc = g.countries[w], lc = g.countries[l];
  // в историческом режиме ИИ не подчиняет великие державы (power ≥ 0.8)
  const spare = g.historical && (lc.power ?? 1) >= 0.8;
  if (spare) { makePeace(g, a, b); return; }
  if (s >= PEACE_TERMS.vassal.min && wc.overlord == null && lc.overlord == null && g.rng() < 0.6) { vassalize(g, w, l); return; }
  if (s >= PEACE_TERMS.cede.min && g.rng() < 0.7) { applyTerms(g, w, l, 'cede', s); return; }
  if (s >= PEACE_TERMS.tgold.min && g.rng() < 0.6) { applyTerms(g, w, l, g.rng() < 0.5 ? 'tgold' : 'tres', s); return; }
  makePeace(g, a, b);
}

// ---------- окно переговоров и предложения мира ----------
// Проигравший сам уступает землю и просит мира: враг согласен всегда
export function concede(g, from, to) {
  const sT = warScore(g, to, from);
  if (!atWar(g, from, to)) return fail('Вы не воюете');
  if (sT < PEACE_TERMS.cede.min) return fail('Враг не требует земель: попробуйте белый мир');
  const n = Math.max(1, Math.floor(cedeCount(sT) / 2));
  cedeProvinces(g, from, to, n);
  makePeace(g, from, to);
  return { ok: true, msg: `Мир: вы уступили ${n} провинций` };
}

export const concedeCount = (g, from, to) => Math.max(1, Math.floor(cedeCount(warScore(g, to, from)) / 2));

export function peaceOfferText(g, o) {
  const n = g.countries[o.from].name;
  if (o.type === 'gold' || o.type === 'goods') {
    return o.dir === 'give' ? `${n} просит мира и готова выплатить контрибуцию: ${tributeText(o.pay)}.` : `${n} предлагает мир на условиях: вы выплачиваете контрибуцию (${tributeText(o.pay)}).`;
  }
  if (o.dir === 'give') {
    if (o.type === 'white') return `${n} предлагает белый мир: захваченные земли возвращаются прежним владельцам.`;
    if (o.type === 'cede') return `${n} просит мира и готова уступить вам ${o.n} провинц.`;
    return `${n} просит мира и готова стать вашим вассалом.`;
  }
  if (o.type === 'cede') return `${n} предлагает мир на условиях: вы уступаете ${o.n} провинц.`;
  return `${n} требует капитуляции: ваша страна станет её вассалом.`;
}

export const peaceOffers = (g) => (g.offers || []).filter((o) => o.kind === 'peace' && o.to === g.playerId);

// ИИ предлагает игроку мир или ультиматум: проигрывающая сторона уступает, выигрывающая диктует
export function maybeOfferPeace(g, c, p) {
  const key = `${c.id}|${p.id}`;
  if (!g.peaceCd) Object.defineProperty(g, 'peaceCd', { value: {}, enumerable: false, writable: true });
  if (c.overlord != null || warAge(g, c.id, p.id) < 30) return;
  if (g.peaceCd[key] != null && g.day - g.peaceCd[key] < 40) return;
  if (g.offers.some((o) => o.kind === 'peace' && o.from === c.id && o.to === p.id)) return;
  if (g.rng() > 0.1) return;
  const sT = warScore(g, p.id, c.id), sM = warScore(g, c.id, p.id);
  let o = null;
  const tr = () => (g.rng() < 0.5 ? 'gold' : 'goods');
  if (sT >= 70 && p.overlord == null) o = { dir: 'give', type: 'vassal' };
  else if (sT >= PEACE_TERMS.cede.min) o = g.rng() < 0.3 ? { dir: 'give', type: tr() } : { dir: 'give', type: 'cede', n: Math.max(1, Math.floor(cedeCount(sT) / 2)) };
  else if (sM >= 80 && p.overlord == null) o = { dir: 'take', type: 'vassal' };
  else if (sM >= PEACE_TERMS.cede.min) o = g.rng() < 0.3 ? { dir: 'take', type: tr() } : { dir: 'take', type: 'cede', n: cedeCount(sM) };
  else if (sT >= PEACE_TERMS.tgold.min) o = { dir: 'give', type: tr() };
  else if (sM >= PEACE_TERMS.tgold.min) o = { dir: 'take', type: tr() };
  else if (warAge(g, c.id, p.id) > 150) o = { dir: 'give', type: 'white' };
  if (!o) return;
  // условия фиксируются при отправке: игрок видит, какие именно провинции или сколько ресурсов
  if (o.type === 'cede') o.ids = o.dir === 'give' ? pickCede(g, c.id, p.id, o.n) : pickCede(g, p.id, c.id, o.n);
  if (o.type === 'gold' || o.type === 'goods') o.pay = o.dir === 'give' ? tributeAmount(g, c.id, sT, o.type) : tributeAmount(g, p.id, sM, o.type);
  g.peaceCd[key] = g.day;
  g.offers.push({ id: g.nextOfferId++, day: g.day, kind: 'peace', from: c.id, to: p.id, seen: false, ...o });
  emit(g, peaceOfferText(g, { ...o, from: c.id }), [p.id, c.id], 'offer');
}

function respondPeace(g, o, accept) {
  const me = g.playerId, ai = o.from;
  if (!accept) return { ok: true, msg: 'Предложение отклонено' };
  if (!atWar(g, me, ai)) return fail('Война уже закончилась');
  if (o.type === 'gold' || o.type === 'goods') {
    const payer = o.dir === 'give' ? ai : me, rec = o.dir === 'give' ? me : ai;
    if (payer === me && !canPay(g, me, o.pay)) return fail(`Не хватает средств: нужно ${tributeText(o.pay)}`);
    payTribute(g, payer, rec, o.pay);
    makePeace(g, me, ai);
    return { ok: true, msg: payer === me ? `Мир: вы выплатили ${tributeText(o.pay)}` : `Мир: получено ${tributeText(o.pay)}` };
  }
  if (o.dir === 'give') {
    if (o.type === 'vassal') { vassalize(g, me, ai); return { ok: true, msg: `${name(g, ai)} стала вашим вассалом` }; }
    if (o.type === 'cede') cedeProvinces(g, ai, me, o.n, o.ids);
  } else if (o.type === 'vassal') { vassalize(g, ai, me); return { ok: true, msg: 'Вы стали вассалом' }; }
  else cedeProvinces(g, me, ai, o.n, o.ids);
  makePeace(g, me, ai);
  return { ok: true, msg: 'Мир заключён' };
}
