// Интерфейс по образцу: кнопки-квадраты слева сверху, панель ресурсов по центру, страна и «Меню» справа,
// лента событий внизу слева, дата и время внизу справа, панели по центру (строительство, армии, дипломатия, журнал).
import { VERSION } from './version.js';
import { isEurope } from './starts.js';
import { TERRAIN, RULES, SIZES, SCENARIOS, DIFFICULTY, COUNTRY_DEFS, BUILDINGS, BUILD_TABS, DEPOSITS, TECHS, TECH_BRANCHES, TAX, FOCUSES, focusTree, IDEOS, MINISTER_POSTS, TRAITS, ORGS } from './data.js';
import { armyVisible, terrainAttack, atWar, prov, idleArmiesAt, canRecruit, recruitMax, mobAvail, mobRate, inAnyWar, troopsOf, troopCap, canBuild, levelOf, maxLevel, warAge, provinceDefense, provinceIncome, moveCostOf, hasB, buildPrice, recruitGold, techState, warCost, stabilityInfo, stabilityEffects, focusState, ministerTrait, opinion, factionOf, sameFaction, warScore, vassalLink, vassalsOf, hasGoal, justifying, guaranteed, troopText, knowsTroops } from './state.js';
import { weatherCode, weatherEffects, WX_INFO, SEASONS, seasonOf, weatherText } from './weather.js';
import { DOCTRINES, DOCTRINE_IDS, DOCTRINE_STEP, DOCTRINE_SWITCH, doctrineEffect } from './doctrines.js';
import { doctrineStep } from './state.js';
import { ICONS } from './icons.js';
import { PRIVACY_URL, PRIVACY_TEXT } from './legal.js';
import { airRadius, airCapacity, airPackCost, AIR_MISSIONS, AIR_HINT, airPacks } from './air.js';
import { flagSrc } from './flags.js';
import { EVENT_BY_ID, describeEffect, canAfford, lookOf, pickCede, civilWarChance } from './events.js';
import { audioCfg } from './audio.js';
import { HQ_MISSIONS, HQ_AGGR, HQ_RETREAT, HQ_SPLIT, HQ_MAX, hqById, hqArmies, hqStrength } from './hq.js';
import { TRADE_GOODS, TRADE_SIZES, LEVEL_COST } from './data.js';
import { dealsOf, dealBetween, dealAmount, dealPrice, canTrade, dealCost, tradeBalance, tradeOfferText } from './trade.js';
import { storedMods, modReport } from './mods.js';
import { BUNDLED_MODS } from './bundled_mods.js';
import { plagueSummary } from './plague.js';
import { PLAGUE } from './plague_core.js';
import { orgMembers, orgJoinCheck, callableEnemies, PEACE_TERMS, cedeCount, justifyDays, lendOf, concedeCount, peaceOfferText, tributeAmount, tributeText } from './diplomacy.js';

const $ = (id) => document.getElementById(id);
const fmt = (n) => Math.round(n).toLocaleString('ru-RU');
const signed = (n) => (n >= 0 ? '+' : '−') + Math.abs(n).toFixed(1);
const flag = (c) => { const src = flagSrc(c); return src ? `<img class="flg" src="${src}" alt="">` : dot(c.color); };
const dot = (color) => `<i class="dot" style="background:${color}"></i>`;

const svg = (body) => `<svg viewBox="0 0 24 24" aria-hidden="true">${body}</svg>`;
export const ICON = {
  coin: svg('<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6.6" fill="none" stroke="#000" stroke-opacity=".4" stroke-width="1.6"/>'),
  people: svg('<circle cx="8" cy="7.5" r="3.2"/><path d="M2 20v-2.5A4.5 4.5 0 0 1 6.5 13h3a4.5 4.5 0 0 1 4.5 4.5V20z"/><circle cx="17" cy="8.5" r="2.7"/><path d="M15.2 13.2A4.2 4.2 0 0 1 22 16.5V20h-6v-2.6a6 6 0 0 0-.8-4.2z"/>'),
  flag: svg('<path d="M5 3h2v18H5z"/><path d="M8 4h12l-3.2 4.5L20 13H8z"/>'),
  sword: svg('<path d="M19.5 3 21 4.5 9.5 16 8 14.5z"/><path d="M6.2 12.8l5 5-1.6 1.6-5-5z"/><path d="M4.6 17.6l1.8 1.8-2.8 2.8-1.8-1.8z"/>'),
  hammer: svg('<path d="M13.6 2.8l7.6 7.6-3.1 3.1-7.6-7.6z"/><path d="M9.6 10.6 3.3 16.9a1.7 1.7 0 0 0 2.4 2.4l6.3-6.3z"/>'),
  army: svg('<path d="M12 3.5 21 13h-5l-4-4.4L8 13H3z"/><path d="M12 11.5 21 21h-5l-4-4.4L8 21H3z"/>'),
  layers: svg('<path d="M12 3 2.5 8.5 12 14l9.5-5.5z"/><path d="M2.5 12.5 12 18l9.5-5.5M2.5 16 12 21.5 21.5 16" fill="none" stroke="currentColor" stroke-width="2"/>'),
  flask: svg('<path d="M9 2h6v2h-1v5.2l5.6 9.1A2 2 0 0 1 17.9 21H6.1a2 2 0 0 1-1.7-2.7L10 9.2V4H9z"/>'),
  gear: svg('<path fill-rule="evenodd" d="M10.3 2h3.4l.5 2.6 1.6.7 2.2-1.5 2.4 2.4-1.5 2.2.7 1.6 2.4.5v3.4l-2.4.5-.7 1.6 1.5 2.2-2.4 2.4-2.2-1.5-1.6.7-.5 2.4h-3.4l-.5-2.4-1.6-.7-2.2 1.5-2.4-2.4 1.5-2.2-.7-1.6L2 13.7v-3.4l2.6-.5.7-1.6-1.5-2.2 2.4-2.4 2.2 1.5 1.6-.7zM12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7z"/>'),
  drop: svg('<path d="M12 2.5c3.4 4.4 6 7.7 6 11a6 6 0 0 1-12 0c0-3.3 2.6-6.6 6-11z"/>'),
  star: svg('<path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.5l1.2-6.5L2.5 9.4l6.6-.9z"/>'),
  shield: svg('<path d="M12 2.5 20 5.5v6c0 5-3.4 8.6-8 10-4.6-1.4-8-5-8-10v-6z"/>'),
  chat: svg('<path d="M3 4h18v13H10l-5 4v-4H3z"/>'),
  zoom: svg('<circle cx="10" cy="10" r="6.2" fill="none" stroke="currentColor" stroke-width="2.4"/><path d="M14.6 14.6 21 21" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>'),
  play: svg('<path d="M7 4v16l13-8z"/>'),
  pause: svg('<path d="M6 4h4v16H6zM14 4h4v16h-4z"/>'),
};

// Нарисованные иконки (game/icons.js) заменяют простые векторные; остальные остаются запасными.
// Картинки лежат в коде как data-URI. Вставлять их в HTML каждый раз тяжело (сотни КБ на перерисовку),
// поэтому один раз превращаем в blob-ссылки: HTML становится маленьким, а браузер кэширует расшифрованное.
const urlCache = new Map();
function iu(k) {
  const d = ICONS[k];
  if (!d || typeof URL === 'undefined' || !URL.createObjectURL || !d.startsWith('data:')) return d;
  let u = urlCache.get(k);
  if (u) return u;
  try {
    const m = /^data:([^;]+);base64,(.*)$/.exec(d);
    const bin = atob(m[2]), arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    u = URL.createObjectURL(new Blob([arr], { type: m[1] }));
  } catch (_) { u = d; }
  urlCache.set(k, u);
  return u;
}
const pic = (k, cls = 'pi') => `<img class="${cls}" src="${iu(k)}" alt="" draggable="false">`;
Object.assign(ICON, {
  coin: pic('r_gold'), people: pic('r_men'), flag: pic('r_prov'), sword: pic('r_troops'), flask: pic('r_res'), gear: pic('r_ind'),
  drop: pic('r_fuel'), star: pic('r_pp'), shield: pic('r_stab'), defense: pic('r_def'), war: pic('r_war'),
  hammer: pic('u_build'), army: pic('u_armies'), tech: pic('u_tech'), diplo: pic('u_diplo'), layers: pic('u_layers'),
  chat: pic('u_journal'), zoom: pic('u_search'), play: pic('u_play'), pause: pic('u_pause'), fast: pic('u_fast'), slow: pic('u_slow'),
});
const pico = (k) => (ICONS[k] ? pic(k, 'pi') : '');
const bico = (k) => (ICONS[k] ? pic(k, 'pi bi') : '');

// Не заменяем DOM, пока палец на кнопке: иначе нажатие теряется, когда тик перерисовывает панель.
const SCROLLERS = '.plist,.treewrap,.dbody,.card,.sheetpanel,.evopts,.tdetail';
function setHtml(el, html) {
  el._pending = null;
  if (el._html === html) return;
  if (el._down) { el._pending = html; return; }
  el._html = html;
  // прокрутка сохраняется, пока открыта та же вкладка: выбор пункта не должен бросать наверх
  const sig = () => [...el.querySelectorAll('[aria-selected="true"]')].map((b) => b.textContent).join('|') + '#' + el.querySelectorAll(SCROLLERS).length;
  const before = [el, ...el.querySelectorAll(SCROLLERS)].map((n) => [n.scrollTop, n.scrollLeft]);
  const sigBefore = sig();
  el.innerHTML = html;
  if (sig() === sigBefore) [el, ...el.querySelectorAll(SCROLLERS)].forEach((n, i) => { if (before[i]) { n.scrollTop = before[i][0]; n.scrollLeft = before[i][1]; } });
}

export function initUI() {
  for (const id of ['drawerBody', 'orderbar', 'screen', 'modal']) {
    const el = $(id);
    el.addEventListener('pointerdown', () => { el._down = true; });
    const up = () => {
      if (!el._down) return;
      el._down = false;
      setTimeout(() => {
        if (el._pending != null) { const h = el._pending; el._pending = null; setHtml(el, h); }
      }, 0);
    };
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
  }
  const tools = [['build', 'hammer', 'Строительство', ''], ['armies', 'army', 'Армии', ''], ['tech', 'tech', 'Технологии', ''], ['diplo', 'diplo', 'Дипломатия', ''], ['layers', 'layers', 'Режим карты', 'layersBtn']];
  $('tools').innerHTML = tools.map(([act, ic, label, id]) => `<button type="button" class="tool" ${id ? `id="${id}"` : ''} data-act="${act}" aria-label="${label}" title="${label}">${ICON[ic]}</button>`).join('')
    + (PLAGUE.cfg ? `<button type="button" class="tool plgtool" id="toolPlg" data-act="plague" aria-label="Эпидемия" title="Эпидемия" hidden>${ICONS.pl_tab ? pic('pl_tab', 'pi') : ICON.shield}</button>` : '');
  $('bar').innerHTML = `<div class="brow res"><div class="r gold" id="rGold">${ICON.coin}<b id="gold">—</b><small id="goldNet"></small></div>`
    + `<div class="r men" id="rMen">${ICON.people}<b id="men">—</b><small id="menNet"></small></div>`
    + `<div class="r rs" id="rRs">${ICON.flask}<b id="rsv">—</b><small id="rsNet"></small></div>`
    + `<div class="r ind" id="rInd">${ICON.gear}<b id="indv">—</b><small id="indNet"></small></div>`
    + `<div class="r fuel" id="rFuel">${ICON.drop}<b id="fuelv">—</b><small id="fuelNet"></small></div>`
    + `<div class="r pp" id="rPP">${ICON.star}<b id="ppv">—</b><small id="ppNet"></small></div></div>`
    + `<div class="brow"><div class="r" title="Провинции">${ICON.flag}<b id="provs">—</b></div>`
    + `<div class="r" title="Войска">${ICON.sword}<b id="troops">—</b></div><div class="r stab" id="rStab">${ICON.shield}<b id="stabv">—</b></div><div class="r war" id="warline"></div><button type="button" class="r plg" id="plg" data-act="plague" hidden></button></div>`;
  $('chatBtn').innerHTML = ICON.chat;
  { const sl = document.querySelector('[data-act="slower"]'), fa = document.querySelector('[data-act="faster"]'); if (sl) sl.innerHTML = ICON.slow; if (fa) fa.innerHTML = ICON.fast; }
  $('zoomBtn').innerHTML = ICON.zoom;
}

// Строка в ленте событий внизу слева.
export function toast(text, mine = false) {
  const box = $('feed');
  const el = document.createElement('div');
  el.className = mine ? 'fl me' : 'fl';
  el.textContent = text;
  box.appendChild(el);
  while (box.children.length > 4) box.removeChild(box.firstChild);
  setTimeout(() => el.remove(), 8200);
}

export function renderAll(ui, clock) {
  const inGame = ui.screen === 'game';
  $('hud').hidden = !inGame;
  $('bl').hidden = !inGame;
  $('br').hidden = !inGame;
  $('stage').classList.toggle('aiming', !!(inGame && ui.aiming));
  if (inGame) renderHud(ui, clock);
  else $('plabel').hidden = true;
  renderOffers(ui, inGame);
  renderDrawer(ui);
  renderOrderBar(ui);
  renderScreen(ui);
  renderModal(ui, clock);
}

// Торговые предложения ИИ: круги с флагом заявителя на экране, по нажатию открываются условия
function renderOffers(ui, inGame) {
  const el = $('offers'), g = ui.game;
  const list = inGame && g ? (g.offers || []).filter((o) => o.kind === 'trade' && o.to === g.playerId) : [];
  el.hidden = !list.length;
  if (!list.length) { setHtml(el, ''); return; }
  setHtml(el, list.map((o) => {
    const from = g.countries[o.from], src = flagSrc(from);
    return `<button type="button" class="ocirc" data-act="tradeoffer" data-arg="${o.id}" aria-label="Торговое предложение: ${from.name}" title="${from.name}: ${TRADE_GOODS[o.deal.good].name.toLowerCase()}">${src ? `<img src="${src}" alt="" draggable="false">` : `<i style="background:${from.color}"></i>`}<b class="obadge" aria-hidden="true">⇄</b></button>`;
  }).join(''));
}

function tradeOfferPanel(ui, clock) {
  const g = ui.game, o = (g.offers || []).find((x) => x.id === ui.tradeOfferId && x.kind === 'trade');
  if (!o) return panel(title('Торговое предложение'), '<div class="empty">Предложение больше не действует.</div>');
  const from = g.countries[o.from], d = o.deal, G = TRADE_GOODS[d.good], me = g.playerId;
  const sells = d.from === o.from, cost = d.amt * d.price;
  const can = canTrade(g, d.from, d.to);
  const rows = [
    `Товар: ${G.name.toLowerCase()}`,
    `${sells ? 'Вы покупаете' : 'Вы продаёте'}: ${r1t(d.amt)} в день по ${d.price} зол.`,
    `Золото: ${sells ? '−' : '+'}${r1t(cost)} в день`,
    `Срок: ${RULES.tradeDays} дн.`,
    `Отношение ${from.name}: ${opinion(g, me, from.id) > 0 ? "+" : ""}${Math.round(opinion(g, me, from.id))}`,
  ];
  const paper = `<div class="evpaper news"><div class="evhead"><span>Торговое предложение</span><small>${clock ? clock.formatDate(o.day) : ''}</small></div><h2>${flag(from)} ${from.name}</h2><p class="evtext">${tradeOfferText(g, o)}</p><div class="evlist"><b>Условия:</b><ul>${rows.map((r) => `<li>${r}</li>`).join('')}</ul></div>${can.ok ? '' : `<div class="evlist"><span class="bad">${can.msg || 'Сделка сейчас невозможна'}</span></div>`}</div>`;
  const opts = `<button type="button" class="evopt" data-act="tradeans" data-arg="${o.id}:1"><b>Принять</b></button><button type="button" class="evopt" data-act="tradeans" data-arg="${o.id}:0"><b>Отклонить</b></button>`;
  return `<div class="panel evpanel" role="dialog"><div class="plist">${paper}<div class="evopts">${opts}</div></div></div>`;
}

// ---------- верх и низ ----------
function renderHud(ui, clock) {
  const g = ui.game, me = g.playerId;
  const c = g.countries[me], st = g.stats[me];
  $('gold').textContent = fmt(c.gold);
  $('men').textContent = fmt(c.manpower);
  const inc = c.income;
  $('rsv').textContent = fmt(c.research);
  $('indv').textContent = fmt(c.industry);
  $('fuelv').textContent = fmt(c.fuel);
  $('ppv').textContent = fmt(c.pp);
  const net = (id, v) => { const el = $(id); el.textContent = `(${signed(v)})`; el.classList.toggle('neg', v < -0.05); };
  net('goldNet', inc.net); net('menNet', inc.men); net('rsNet', inc.res); net('indNet', inc.ind); net('fuelNet', inc.fuelNet); net('ppNet', inc.pp);
  $('rGold').title = `Золото ${signed(inc.net)} в день`;
  $('rMen').title = `Люди ${signed(inc.men)} в день`;
  $('rRs').title = `Очки технологий ${signed(inc.res)} в день`;
  $('rInd').title = `Промышленность ${signed(inc.ind)} в день`;
  $('rFuel').title = c.noFuel ? 'Топливо кончилось: армии бьют слабее и ходят медленнее' : `Топливо ${signed(inc.fuelNet)} в день`;
  $('rPP').title = `Политическая власть ${signed(inc.pp)} в день`;
  $('rFuel').classList.toggle('low', !!c.noFuel || !!c.lowFuel || (inc.fuelNet < 0 && c.fuel < -inc.fuelNet * 20));
  $('provs').textContent = String(st.provinces);
  $('troops').textContent = fmt(st.troops);
  const foes = g.countries.filter((o) => o.alive && atWar(g, me, o.id)).map((o) => o.name);
  const war = $('warline');
  war.textContent = foes.length ? 'Война: ' + foes.join(', ') : 'Мир';
  war.className = foes.length ? 'r war on' : 'r war';
  const ps = plagueSummary(g, me), pe = $('plg');
  if (pe) {
    pe.hidden = !(ps && ps.started);
    const tp = $('toolPlg'); if (tp) tp.hidden = !(ps && ps.started);
    if (ps && ps.started) {
      const tx = ps.ended ? 'Болезнь побеждена' : ps.warn ? `Мир гибнет: ${ps.doomLeft} дн.` : `Болезнь ${Math.round(ps.worldI)}% · вакцина ${Math.round(ps.effV)}%`;
      setHtml(pe, (ICONS.pl_warn ? pico('pl_warn') : '') + `<span>${tx}</span>`);
      pe.className = 'r plg' + (ps.ended ? ' ok' : ps.warn ? ' bad' : ps.worldI > 25 ? ' warn' : '');
      pe.title = `Заражено в мире: ${ps.worldI.toFixed(1)}%. В вашей стране: ${ps.own.toFixed(1)}%. Защита: ${Math.round(ps.prot * 100)}%`;
    }
  }
  const sv = Math.round(c.stability);
  $('stabv').textContent = sv + '%';
  $('rStab').title = `Стабильность ${sv}%, цель ${Math.round(stabilityInfo(g, c).target)}%`;
  $('rStab').className = 'r stab' + (sv < 30 ? ' bad' : sv < 50 ? ' warn' : '');
  setHtml($('whoName'), `${flag(c)}<span class="nmt">${c.name}</span><span class="chev">▾</span>`);
  $('date').textContent = clock.formatDate();
  $('dayno').textContent = 'День ' + clock.dayIndex + (RULES.weather ? ' · ' + SEASONS[seasonOf(clock.dayIndex)] : '');
  setHtml($('pips'), [1, 2, 3, 4, 5].map((i) => `<i class="${i <= clock.speed ? 'on' : ''}"></i>`).join(''));
  setHtml($('playBtn'), clock.paused ? ICON.play : ICON.pause);
  const lb = $('layersBtn');
  if (lb) lb.setAttribute('aria-pressed', String(ui.mode !== 'political'));

  const pl = $('plabel');
  const p = ui.selected != null ? prov(g, ui.selected) : null;
  const show = !!p && (!ui.drawerOpen || ui.aiming) && !g.over;
  pl.hidden = !show;
  if (show) {
    const o = p.props.owner != null ? g.countries[p.props.owner] : null;
    setHtml(pl, `${o ? flag(o) : ''}<span>${p.name}${o ? ' · ' + o.name : ''}</span>`);
  }
}

// ---------- панель провинции ----------
function armyGroups(g, pid) {
  const m = new Map();
  for (const a of g.armies) if (a.at === pid && armyVisible(g, a)) m.set(a.owner, (m.get(a.owner) || 0) + a.strength);
  return [...m].map(([owner, total]) => ({ owner, total })).sort((a, b) => b.total - a.total);
}

function chips(ui) {
  return `<div class="chips" role="group" aria-label="Доля войск">${[0.25, 0.5, 1]
    .map((f) => `<button type="button" data-act="frac" data-arg="${f}" aria-pressed="${ui.fraction === f}">${f * 100}%</button>`)
    .join('')}</div>`;
}

function provinceHtml(ui) {
  const g = ui.game, me = g.playerId;
  const p = prov(g, ui.selected);
  const T = TERRAIN[p.props.terrain];
  const owner = p.props.owner != null ? g.countries[p.props.owner] : null;
  const groups = armyGroups(g, p.id);
  const troops = groups.length ? groups.map((x) => `<span>${flag(g.countries[x.owner])} ${troopText(g, x.owner, x.total, p.id)}</span>`).join('') : '0';
  const tags = [...new Set(p.props.built || [])].map((id) => `<span>${bico('b_' + id)}${BUILDINGS[id].name}${maxLevel(id) > 1 ? ' ' + ROMAN[levelOf(p, id)] : ''}</span>`);
  if (p.props.deposit) tags.unshift(`<span class="dep">${bico('dp_' + p.props.deposit)}${DEPOSITS[p.props.deposit].name}</span>`);
  if (p.props.project) tags.push(`<span class="wip">${BUILDINGS[p.props.project.id].name}: ещё ${p.props.project.left} дн.</span>`);
  let actions = '';
  if (p.props.owner === me) {
    const can = canRecruit(g, me, p.id);
    const idleN = idleArmiesAt(g, me, p.id).reduce((s, a) => s + a.strength, 0);
    const moving = g.armies.some((a) => a.owner === me && a.at === p.id && a.order);
    if (idleN > 0) actions += '<button type="button" class="btn primary" data-act="aim">Двигаться</button>';
    const mx = recruitMax(g, me), stk = RULES.recruitStack;
    const want = ui.recruitN === 'max' ? Math.max(1, mx) : Math.max(1, Math.round((ui.recruitN || stk) / stk));
    const n = Math.min(want, Math.max(1, mx));
    const can2 = canRecruit(g, me, p.id, n);
    const opts = [[10, '10'], [25, '25'], [50, '50'], [100, '100'], ['max', 'Макс']].map(([v, l]) => `<button type="button" data-act="rn" data-arg="${v}" aria-pressed="${String(ui.recruitN || 10) === String(v)}">${l}</button>`).join('');
    if (!inAnyWar(g, me)) actions += `<p class="note">Армия ${fmt(troopsOf(g, me))} / ${fmt(troopCap(g, me))} — лимит мирного времени (растёт с числом провинций, в войне не действует)</p>`;
    actions += `<p class="note">Призыв: доступно ${fmt(mobAvail(g, me))} пачек (+${fmt(Math.round(mobRate(g, me)))} в день, копится до ${RULES.mobBankDays} дней)</p>`;
    actions += `<div class="seg recseg" role="group" aria-label="Сколько призвать">${opts}</div>`;
    actions += `<button type="button" class="btn" data-act="recruit" ${can2.ok ? '' : 'disabled'}>Призвать +${n * stk}<small>${can2.ok ? `${n * RULES.recruitManpower} люд. · ${fmt(recruitGold(g, me) * n)} зол. · ${n * RULES.recruitInd} пром.` : can2.msg}</small></button>`;
    if (levelOf(p, 'airfield')) actions += airPanel(g, me, p, ui);
    actions += '<button type="button" class="btn" data-act="build">Строить</button>';
    if (moving) actions += '<button type="button" class="btn" data-act="stop">Остановить походы</button>';
  } else if (owner) {
    const war = atWar(g, me, owner.id);
    const s = g.stats[owner.id];
    actions += `<p class="note">${owner.name}: ${s.provinces} пров. · ${troopText(g, owner.id, s.troops)} войск<br>${war ? `Война · ${warAge(g, me, owner.id)} дн.` : 'Мир'}</p>`;
    actions += `<button type="button" class="btn primary" data-act="dipcard" data-arg="${owner.id}">Дипломатия</button>`;
    actions += war
      ? `<button type="button" class="btn" data-act="peace" data-arg="${owner.id}">Предложить мир</button>`
      : `<button type="button" class="btn danger" data-act="war" data-arg="${owner.id}"><span class="bll">${bico('r_war')}${ui.confirmWar === owner.id ? 'Подтвердить войну' : 'Объявить войну'}</span><small>${warCost(g, me, owner.id)} власти</small></button>`;
  }
  if (p.props.owner !== me && T.passable && T.atk) {
    const f = terrainAttack(g.countries[me], p.props.terrain);
    actions += `<p class="note">Атака сюда: ×${f.toFixed(2)} (${T.name.toLowerCase()})${f < 1 ? ' — штраф снимают технологии снаряжения' : f > 1 ? ' — снаряжение даёт бонус' : ''}</p>`;
  }
  const subOwner = owner ? `${flag(owner)}<span>${owner.name}</span>` : '<span>Ничья земля</span>';
  return `<h2>${p.name}</h2><div class="sub">${subOwner}<span>· ${bico('t_' + p.props.terrain)}${T.name}${p.props.capital ? ' · столица' : ''}</span></div>
    <dl class="facts"><div><dt>Население</dt><dd>${p.props.pop} тыс.</dd></div><div><dt>Доход</dt><dd>${provinceIncome(p).gold.toFixed(1)}</dd></div><div><dt>Войска</dt><dd>${troops}</dd></div><div><dt>Оборона</dt><dd>×${provinceDefense(p, g).toFixed(2)}</dd></div></dl>
    ${tags.length ? `<div class="tags">${tags.join('')}</div>` : ''}${wxLine(g, p)}<div class="actions">${actions}</div>`;
}

function wxLine(g, p) {
  if (!RULES.weather || !p || p.props.terrain === 'water') return '';
  const w = weatherCode(g, p);
  if (!w) return `<p class="note wx">Погода: ясно</p>`;
  const e = weatherEffects(g, p, g.countries[g.playerId]);
  const pc = (v) => Math.round((1 - v) * 100);
  return `<p class="note wx wx${w}"><b>${WX_INFO[w].name}</b>: ваши армии — скорость −${pc(e.mv)}%, атака на чужой земле −${pc(e.atk)}%${e.attr ? ', организация в походе −' + e.attr.toFixed(1) + '/день' : ''}</p>`;
}

function renderDrawer(ui) {
  const g = ui.game, d = $('drawer');
  const show = ui.screen === 'game' && ui.selected != null && !ui.aiming && !g.over && !!prov(g, ui.selected);
  d.hidden = !show;
  if (!show) return;
  d.classList.toggle('collapsed', !ui.drawerOpen);
  setHtml($('drawerBody'), provinceHtml(ui));
  $('tabChev').textContent = ui.drawerOpen ? '›' : '‹';
  const o = prov(g, ui.selected).props.owner;
  setHtml($('tabDot'), o != null ? flag(g.countries[o]) : '');
  $('drawerTab').setAttribute('aria-expanded', String(ui.drawerOpen));
}

// ---------- плашка приказа ----------
function whyBlocked(ui, t) {
  const g = ui.game;
  if (!TERRAIN[t.props.terrain].passable) return { text: 'Море: туда не пройти.' };
  const o = t.props.owner;
  if (o != null && o !== g.playerId && !atWar(g, g.playerId, o)) return { text: `Нужна война с ${g.countries[o].name}.`, warWith: o };
  return { text: 'Пути нет: мешают чужие границы.' };
}

function orderHtml(ui) {
  const g = ui.game, me = g.playerId;
  const p = prov(g, ui.selected);
  const idleN = idleArmiesAt(g, me, p.id).reduce((s, a) => s + a.strength, 0);
  let text, extra = '';
  if (ui.target == null) {
    text = `<b>${p.name}</b> · ${Math.ceil(idleN)} войск. Коснитесь цели на карте.`;
  } else {
    const t = prov(g, ui.target);
    const o = t.props.owner != null ? g.countries[t.props.owner] : null;
    const label = `${o ? flag(o) + ' ' : ''}${t.name}`;
    if (ui.preview) {
      text = `<b>${label}</b> · путь около ${ui.preview.cost} дн. Коснитесь цели ещё раз, чтобы подтвердить.`;
    } else {
      const why = whyBlocked(ui, t);
      text = `<b>${label}</b> · ${why.text}`;
      if (why.warWith != null) extra = `<button type="button" class="btn danger" data-act="war" data-arg="${why.warWith}">${ui.confirmWar === why.warWith ? 'Подтвердить войну' : 'Объявить войну'}</button>`;
    }
  }
  return `<p class="obtext">${text}</p><div class="obrow">${chips(ui)}<span class="grow"></span>${extra}${ui.preview ? '<button type="button" class="btn primary" data-act="go">Идти</button>' : ''}<button type="button" class="btn" data-act="cancel">Отмена</button></div>`;
}

function renderOrderBar(ui) {
  const g = ui.game, el = $('orderbar');
  const show = ui.screen === 'game' && ui.aiming && ui.selected != null && !g.over;
  el.hidden = !show;
  if (show) setHtml(el, orderHtml(ui));
}

// ---------- главное меню и новая игра ----------
function emblem() {
  const R = 19, dist = R * Math.sqrt(3) + 2;
  const colors = ['#ebe07a', ...COUNTRY_DEFS.map((c) => c.color), '#2a4a5c'];
  const centers = [[0, 0]];
  for (let k = 0; k < 6; k++) centers.push([Math.cos(k * Math.PI / 3) * dist, Math.sin(k * Math.PI / 3) * dist]);
  const poly = (cx, cy) => [0, 1, 2, 3, 4, 5].map((i) => {
    const a = (60 * i + 30) * Math.PI / 180;
    return `${(cx + R * Math.cos(a)).toFixed(1)},${(cy + R * Math.sin(a)).toFixed(1)}`;
  }).join(' ');
  const hexes = centers.map(([x, y], i) => `<polygon points="${poly(60 + x, 52 + y)}" fill="${colors[i]}" stroke="#0a0a0a" stroke-width="2" stroke-linejoin="round"/>`).join('');
  return `<svg class="emblem" viewBox="0 0 120 104" aria-hidden="true">${hexes}</svg>`;
}

function modBadge() {
  const on = modReport.filter((m) => m.status === 'on').length;
  return on ? `<small>включено: ${on}</small>` : '';
}

const PAUSE_GLYPH = {
  save: svg('<path d="M5 3h11l3 3v15H5z"/><path d="M8 3v6h7V3M8 21v-7h8v7" fill="none" stroke="#000" stroke-opacity=".5" stroke-width="1.5"/>'),
  snd: svg('<path d="M3 9h4l5-4v14l-5-4H3z"/><path d="M15 8.5a5 5 0 0 1 0 7M17.5 6a8.5 8.5 0 0 1 0 12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>'),
  mus: svg('<path d="M9 4v11.2A3 3 0 1 0 11 18V8h7V4z"/>'),
  fx: svg('<path d="M13 2 4.5 13H11l-1 9 8.5-11.5H12z"/>'),
  full: svg('<path d="M3 3h7v2.4H5.4V10H3zM14 3h7v7h-2.4V5.4H14zM3 14h2.4v4.6H10V21H3zM18.6 14H21v7h-7v-2.4h4.6z"/>'),
  help: svg('<circle cx="12" cy="12" r="10"/><path d="M9.2 9.3a2.9 2.9 0 1 1 4.4 2.5c-.9.6-1.6 1.1-1.6 2.3" fill="none" stroke="#000" stroke-opacity=".6" stroke-width="2"/><circle cx="12" cy="17.4" r="1.3" fill="#000" fill-opacity=".6"/>'),
  tomain: svg('<path d="M12 3 2.5 11.5H5V21h5v-6h4v6h5v-9.5h2.5z"/>'),
};

// Каждый раздел получает свой цвет и шапку со значком и сводкой, чтобы панели не сливались в одинаковые прямоугольники.
const HEAD = {
  build: ['u_build', 'Строительство'], tech: ['u_tech', 'Технологии'], country: ['r_prov', 'Страна'], armies: ['u_armies', 'Армии'],
  diplo: ['u_diplo', 'Дипломатия'], journal: ['u_journal', 'Журнал'], plague: ['pl_tab', 'Эпидемия'],
};
function headSub(ui, kind) {
  const g = ui.game; if (!g || !g.countries) return '';
  const c = g.countries[g.playerId];
  if (kind === 'tech') return `изучено ${c.techs.length} из ${Object.keys(TECHS).length}`;
  if (kind === 'country') return c.name;
  if (kind === 'armies') { const m = g.armies.filter((a) => a.owner === g.playerId); return `${fmt(m.reduce((s, a) => s + a.strength, 0))} войск · отрядов ${m.length}`; }
  if (kind === 'diplo') return `напряжённость мира ${Math.round(g.tension || 0)}%`;
  if (kind === 'journal') return `записей: ${g.log.length}`;
  if (kind === 'plague') { const s = plagueSummary(g, g.playerId); return s && s.started ? `мир: ${s.worldI.toFixed(0)}% заражено` : 'всё спокойно'; }
  if (kind === 'build') return c.name;
  return '';
}
function decoratePanel(html, ui, kind) {
  if (html.startsWith('<div class="panel treepanel" role="dialog">')) return `<div class="panel treepanel k-${kind}" role="dialog">` + html.slice('<div class="panel treepanel" role="dialog">'.length);
  const open = '<div class="panel" role="dialog">';
  if (!html.startsWith(open)) return html;
  const h = HEAD[kind];
  const head = h && ICONS[h[0]] ? `<div class="phead">${pic(h[0], 'pi ph')}<div><b>${h[1]}</b><small>${headSub(ui, kind)}</small></div></div>` : '';
  const rest = head && (kind === 'journal' || kind === 'plague') ? html.slice(open.length).replace(/<div class="ptitle">[^<]*<\/div>/, '') : html.slice(open.length);
  return `<div class="panel k-${kind}" role="dialog">${head}` + rest;
}

function modsBody(ui) {
  const list = storedMods();
  const rep = new Map(modReport.map((r) => [r.id, r]));
  const esc = (t) => String(t == null ? '' : t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const rows = list.map(({ mod, on }, i) => {
    const r = rep.get(mod.id);
    const st = !r ? 'новый' : r.status === 'error' ? 'ошибка' : r.status === 'on' ? 'работает' : 'выключен';
    const chg = !r || r.on !== on ? ' · изменится после перезапуска' : '';
    const errs = r && r.errors.length ? `<ul class="merr">${r.errors.slice(0, 5).map((e) => `<li>${esc(e)}</li>`).join('')}${r.errors.length > 5 ? `<li>…ещё ${r.errors.length - 5}</li>` : ''}</ul>` : '';
    const wrn = r && r.warnings.length ? `<ul class="mwarn">${r.warnings.slice(0, 3).map((e) => `<li>${esc(e)}</li>`).join('')}</ul>` : '';
    return `<div class="modrow ${r ? r.status : ''}"><div class="mh"><b>${esc(mod.name)}</b><span>${esc(mod.version || '')}${mod.author ? ' · ' + esc(mod.author) : ''}</span><em>${st}${chg}</em></div>${mod.desc ? `<p>${esc(mod.desc)}</p>` : ''}${errs}${wrn}
      <div class="mb"><button type="button" class="mrow" data-act="modon" data-arg="${esc(mod.id)}">${on ? 'Выключить' : 'Включить'}</button><button type="button" class="mrow" data-act="modup" data-arg="${esc(mod.id)}" ${i === 0 ? 'disabled' : ''}>Выше</button><button type="button" class="mrow" data-act="moddown" data-arg="${esc(mod.id)}" ${i === list.length - 1 ? 'disabled' : ''}>Ниже</button><button type="button" class="mrow" data-act="moddel" data-arg="${esc(mod.id)}">Удалить</button></div></div>`;
  }).join('');
  const msg = ui.modMsg ? `<div class="modmsg">${esc(ui.modMsg).replace(/\n/g, '<br>')}</div>` : '';
  const apply = ui.modsDirty ? `<button type="button" class="mrow primary" data-act="modapply"><b>Применить и перезапустить</b></button>` : '';
  const have = new Set(list.map((x) => x.mod.id));
  const avail = BUNDLED_MODS.filter((m) => !have.has(m.id)).map((m) => `<div class="modrow"><div class="mh"><b>${esc(m.name)}</b><span>${esc(m.version || '')}${m.author ? ' · ' + esc(m.author) : ''}</span><em>встроен</em></div><p>${esc(m.desc)}</p><div class="mb"><button type="button" class="mrow primary" data-act="modbuiltin" data-arg="${esc(m.id)}">Установить</button></div></div>`).join('');
  const builtin = avail ? `<h3 class="mh3">Встроенные моды</h3>${avail}` : '';
  return `${msg}${list.length ? rows : '<div class="empty" style="padding:10px 12px">Модов пока нет. Установите встроенный или загрузите файл .json — формат описан в MODDING.md.</div>'}${builtin}
    <div class="mlist"><button type="button" class="mrow" data-act="modfile">Загрузить файл мода…</button>${apply}</div>`;
}

function mainHtml(ui) {
  const cont = ui.saveInfo ? `<button type="button" class="mbtn primary" data-act="continue"><b>Продолжить</b><small>${ui.saveInfo}</small></button>` : '';
  return `<div class="hero"><div class="brand">${emblem()}<h1>Гексархия</h1><p class="tag">Гранд-стратегия на шестиугольной карте</p><p class="ver">версия ${VERSION}</p></div>
    <div class="side"><div class="mbtns">${cont}<button type="button" class="mbtn ${cont ? '' : 'primary'}" data-act="newgame"><b>Новая игра</b></button><button type="button" class="mbtn" data-act="help"><b>Как играть</b></button><button type="button" class="mbtn" data-act="mods"><b>Моды</b>${modBadge()}</button></div>
    <p class="legal">Продолжая пользование приложением, вы соглашаетесь с нашей ${PRIVACY_URL ? `<a href="${PRIVACY_URL}" target="_blank" rel="noopener">политикой конфиденциальности</a>` : '<button type="button" class="lnk" data-act="privacy">политикой конфиденциальности</button>'}.</p>
    <p class="ver">Версия ${VERSION}</p></div></div>`;
}

function seg(items, act, current) {
  return `<div class="seg">${items.map(([val, label]) => `<button type="button" data-act="${act}" data-arg="${val}" aria-pressed="${String(val) === String(current)}">${label}</button>`).join('')}</div>`;
}

function setupHtml(ui) {
  const g = ui.game, st = ui.setup;
  const cards = g.countries.filter((c) => c.alive).map((c) => {
    const s = g.stats[c.id];
    return `<button type="button" class="cty" data-act="pick" data-arg="${c.id}" aria-pressed="${st.country === c.id}">${flag(c)}<b>${c.name}</b><span>${s.provinces} пров.</span><span>${fmt(s.troops)} войск</span></button>`;
  }).join('');
  const sizes = seg(Object.entries(SIZES).map(([k, v]) => [k, v.label]), 'size', st.size);
  const diffs = seg(DIFFICULTY.map((d, i) => [i, d.label]), 'diff', st.difficulty);
  return `<div class="sheetpanel" id="setupPanel">
    <div class="sh"><button type="button" class="x" data-act="back" aria-label="Назад">‹</button><h2>Новая игра</h2></div>
    <h3>Сценарий</h3>${seg(SCENARIOS, 'scen', st.scenario)}
    <h3>Страна</h3><div class="countries${g.countries.length > 8 ? ' many' : ''}">${cards}</div>
    ${st.scenario === 'random' ? `<h3>Карта</h3>${sizes}
    <div class="mapline"><button type="button" class="btn" data-act="reroll">Другая карта</button><span>${g.world.provinces.size} провинций · № ${g.seed % 10000}</span></div>` : `<p class="note" style="margin-top:10px">${g.world.provinces.size} провинций. Границы упрощены: одна провинция — около 100 км. Через проливы ходят переправы.</p>`}
    ${isEurope(st.scenario) ? `<h3>Ход истории</h3>${seg([[1, 'Исторический'], [0, 'Свободный']], 'hist', st.historical ? 1 : 0)}<p class="note" style="margin-top:8px">${st.historical ? 'ИИ не начинает войн сам: Европа идёт по хронике событий, и все цепочки доживают до конца. Войны начинаете вы или события.' : 'ИИ воюет по своему усмотрению, хроника событий может сломаться.'}</p>` : ''}
    <h3>Сложность</h3>${diffs}<p class="note" style="margin-top:8px">${DIFFICULTY[st.difficulty].hint}</p>
    <div class="foot"><button type="button" class="btn fill" data-act="begin">Начать за страну «${g.countries[st.country].name}»</button></div></div>`;
}

function renderScreen(ui) {
  const el = $('screen');
  if (ui.screen === 'main') {
    el.hidden = false;
    el.className = 'screen main';
    setHtml(el, mainHtml(ui));
  } else if (ui.screen === 'setup') {
    el.hidden = false;
    el.className = 'screen setup';
    const old = $('setupPanel');
    const top = old ? old.scrollTop : 0;
    setHtml(el, setupHtml(ui));
    const now = $('setupPanel');
    if (now && top) now.scrollTop = top;
  } else {
    el.hidden = true;
  }
}

// ---------- панели по центру ----------
const panel = (head, body, back = 'Назад', act = 'closemodal') =>
  `<div class="panel" role="dialog">${head}<div class="plist">${body}</div><button type="button" class="pback" data-act="${act}">${back}</button></div>`;
const title = (t) => `<div class="ptitle">${t}</div>`;
const sub = (t) => `<div class="empty" style="padding:8px 12px;font-size:13px">${t}</div>`;

const ROMAN = ['', 'I', 'II', 'III'];
const priceHtml = (g, me, id, pid) => { const [gold, ind] = buildPrice(g, me, id, pid); return `${fmt(gold)} ${ICON.coin} ${fmt(ind)} ${ICON.gear}`; };

// Меню аэродрома: призыв эскадрилий, задание, радиус, цель
function airPanel(g, me, p, ui) {
  const lv = levelOf(p, 'airfield'), R = airRadius(g, me, lv), cap = airCapacity(g, me, lv);
  const air = p.props.air, n = airPacks(p), m = air && air.mission;
  const cost = airPackCost(g, me);
  let h = `<h3>Авиация · аэродром ${ROMAN[lv]}</h3>`;
  h += `<p class="note">Эскадрильи: ${fmt(Math.round(n * 10) / 10)} из ${cap} · радиус заданий до ${R} пров.<br>Эскадрилья: ${cost.gold} зол., ${cost.men} люд., ${cost.ind} пром. · топливо ${RULES.airFuel} в день при задании</p>`;
  h += `<div class="seg recseg" role="group" aria-label="Призвать эскадрильи">${[1, 3, 6].map((k) => `<button type="button" data-act="airrec" data-arg="${k}">+${k}</button>`).join('')}</div>`;
  h += `<div class="seg recseg" role="group" aria-label="Задание">${AIR_MISSIONS.map(([k, l]) => `<button type="button" data-act="airmis" data-arg="${k}" aria-pressed="${!!m && m.t === k}">${bico('ac_' + k)}${l}</button>`).join('')}<button type="button" data-act="airmis" data-arg="none" aria-pressed="${!m}">Нет</button></div>`;
  if (m) {
    h += `<p class="note">${AIR_HINT[m.t]}</p>`;
    h += `<div class="seg recseg" role="group" aria-label="Радиус">${Array.from({ length: R }, (_, i) => i + 1).map((k) => `<button type="button" data-act="airrad" data-arg="${k}" aria-pressed="${m.r === k}">${k}</button>`).join('')}</div>`;
    if (m.t !== 'intercept') {
      const tg = m.pid != null ? prov(g, m.pid).name : null;
      h += `<button type="button" class="btn" data-act="airaim">${ui.airAim != null ? 'Выберите клетку на карте…' : tg ? 'Цель: ' + tg + ' · сменить' : 'Цель: вся зона · выбрать клетку'}</button>`;
      if (tg) h += '<button type="button" class="btn" data-act="airzone">Вся зона</button>';
    }
  }
  return h;
}

function buildBody(ui) {
  const g = ui.game, me = g.playerId;
  const p = ui.selected != null ? prov(g, ui.selected) : null;
  if (!p || p.props.owner !== me) return `<div class="empty">Выберите свою провинцию на карте, затем откройте строительство.</div>`;
  const items = Object.entries(BUILDINGS).filter(([, b]) => b.tab === ui.buildTab).map(([id, b]) => {
    const can = canBuild(g, me, p.id, id);
    const building = p.props.project && p.props.project.id === id;
    let right;
    const lv = levelOf(p, id), mx = maxLevel(id);
    if (lv >= mx) right = `<span class="st">${mx > 1 ? 'Макс. уровень ' + ROMAN[lv] : 'Построено'}</span>`;
    else if (building) right = `<span class="st">Строится: ещё ${p.props.project.left} дн.</span>`;
    else if (can.ok) right = `<span class="days">${Math.round(b.days * LEVEL_COST[Math.min(lv, LEVEL_COST.length - 1)])} дн.</span><button type="button" class="cost" data-act="construct" data-arg="${id}">${lv ? 'Улучшить · ' : ''}${priceHtml(g, me, id, p.id)}</button>`;
    else if (can.msg.startsWith('Не хватает')) right = `<span class="days">${Math.round(b.days * LEVEL_COST[Math.min(lv, LEVEL_COST.length - 1)])} дн.</span><button type="button" class="cost short" disabled>${lv ? 'Улучшить · ' : ''}${priceHtml(g, me, id, p.id)}</button>`;
    else right = `<span class="st bad">${can.msg}</span>`;
    return `<div class="item ${can.ok || building || lv ? '' : 'dim'}"><div class="it">${bico('b_' + id)}${b.name}${mx > 1 ? ` <small class="tier">${lv}/${mx}</small>` : ''}</div><div class="id">${b.desc}</div><div class="ic">${right}</div></div>`;
  }).join('');
  return sub(`${p.name} · казна ${fmt(g.countries[me].gold)} · промышленность ${fmt(g.countries[me].industry)}`) + (items || '<div class="empty">Здесь пока ничего нет.</div>');
}

function armiesBody(ui) {
  const g = ui.game, me = g.playerId;
  const mine = g.armies.filter((a) => a.owner === me).sort((a, b) => b.strength - a.strength);
  if (!mine.length) return '<div class="empty">У вас пока нет войск. Призовите их в своей провинции.</div>';
  const total = mine.reduce((s, a) => s + a.strength, 0);
  const rows = mine.map((a) => {
    const here = prov(g, a.at);
    let line;
    if (a.fighting) line = 'В бою';
    else if (a.order) {
      let d = -a.order.progress;
      for (const id of a.order.path) d += moveCostOf(prov(g, id));
      line = `→ ${prov(g, a.order.path[a.order.path.length - 1]).name}, ещё около ${Math.max(1, Math.round(d))} дн.`;
    } else line = 'Стоит на месте';
    if ((a.coolUntil || 0) > g.day) line += ` · перегруппировка ${a.coolUntil - g.day} дн.`;
    if (a.hq != null && hqById(g, a.hq)) line = `[${hqById(g, a.hq).name}] ` + line;
    const org = Math.round(Math.max(0, a.org == null ? 100 : a.org));
    line += `${a.dig >= 1 && !a.order ? ` · окопы ${Math.floor(a.dig)}` : ''}`;
    const st = a.fighting ? 'fight' : a.order ? 'move' : 'idle';
    return `<button type="button" class="row army ${st}" data-act="goto" data-arg="${a.at}"><div class="nm2">${flag(g.countries[me])}<span>${here.name}</span></div><div class="sm">${line}</div><div class="orgbar" title="Организация ${org}%"><i style="width:${org}%"></i></div><div class="rt">${Math.ceil(a.strength)}</div></button>`;
  }).join('');
  return sub(`Всего ${fmt(total)} войск, отрядов: ${mine.length}`) + rows;
}

function hqBody(ui) {
  const g = ui.game, me = g.playerId;
  const list = (g.hqs || []).filter((h) => h.owner === me);
  const free = g.armies.filter((a) => a.owner === me && a.hq == null).length;
  let sel = hqById(g, ui.hqSel);
  if (!sel || sel.owner !== me) sel = list[0] || null;
  ui.hqSel = sel ? sel.id : null;
  const chips = list.map((h) => `<button type="button" class="btn" data-act="hqsel" data-arg="${h.id}" aria-pressed="${sel && sel.id === h.id}">${h.name}<small>${hqArmies(g, h.id).length} арм.</small></button>`).join('');
  let out = sub(`Штаб сам двигает армии по тактике. Свободных армий: ${free}`) + `<div class="row multi"><div class="sm">${chips || 'Штабов пока нет'}</div><div class="rt">${list.length < HQ_MAX ? '<button type="button" class="btn" data-act="hqnew">Создать штаб</button>' : ''}</div></div>`;
  if (!sel) return out + '<div class="empty">Создайте штаб, назначьте ему армии и выберите тактику.</div>';
  const foes = g.countries.filter((c) => c.alive && c.id !== me && atWar(g, me, c.id));
  const tg = seg([['', 'Любой враг'], ...foes.map((c) => [c.id, c.name])], 'hqt', sel.target == null ? '' : sel.target);
  const desc = { attack: 'Собирает силы, бьёт в слабое место и идёт к столице врага.', defend: 'Держит рубеж, распределяет армии по угрозе, контратакует ослабленных.', garrison: 'Расставляет армии по оккупированным землям для подчинения.' }[sel.mission];
  out += `<h3>${sel.name}</h3><div class="item"><div class="it">Статус</div><div class="id">${sel.status || '—'} · армий ${hqArmies(g, sel.id).length}, сила ${fmt(Math.ceil(hqStrength(g, sel.id)))}</div></div>`;
  out += `<h3>Тактика</h3>${seg(HQ_MISSIONS.map(([k, l]) => [k, l]), 'hqm', sel.mission)}<p class="note">${desc}</p>`;
  if (sel.mission !== 'garrison') out += `<h3>Цель</h3>${tg}`;
  if (sel.mission !== 'garrison') out += `<h3>Риск</h3>${seg(HQ_AGGR.map(([k, l]) => [k, l]), 'hqa', sel.aggr)}`;
  out += `<h3>Отступление</h3>${seg(HQ_RETREAT.map(([k, l]) => [k, l]), 'hqr', sel.retreat)}`;
  if (sel.mission === 'attack') out += `<h3>Сосредоточение</h3>${seg([[1, 'Собирать кулак'], [0, 'Сразу в бой']], 'hqmass', sel.mass ? 1 : 0)}`;
  out += `<h3>Деление</h3>${seg(HQ_SPLIT.map(([k, l]) => [k, l]), 'hqsplit', sel.split === 0 ? 0 : 1)}<p class="note">Штаб отделяет от армии части: отряды на пустые и слабо занятые провинции, нужную силу на участок рубежа, гарнизоны на оккупированные земли.</p>`;
  out += `<h3>Армии</h3><div class="row multi"><div class="rt"><button type="button" class="btn" data-act="hqaddall">Все свободные<small>${free}</small></button><button type="button" class="btn" data-act="hqaddsel">Из выбранной провинции</button><button type="button" class="btn" data-act="hqclear">Освободить</button><button type="button" class="btn danger" data-act="hqdel">Удалить штаб</button></div></div>`;
  return out;
}

const pp = (n) => `${n} ${ICON.star}`;
const opTxt = (v) => `${v > 0 ? '+' : ''}${Math.round(v)}`;
const opCls = (v) => (v >= 20 ? 'good' : v <= -20 ? 'bad' : '');

function tensionLine(g) {
  const t = Math.round(g.tension || 0);
  return `<div class="item"><div class="it">Мировая напряжённость: ${t}%</div><div class="id">Демократии вступаются за союзников при ${RULES.demDefense}% и выше, сами нападают при ${RULES.demWar}%. Война без повода стоит стабильности и поднимает напряжённость.</div></div>`;
}

function diploCountries(ui) {
  const g = ui.game, me = g.playerId, mf = factionOf(g, g.countries[me]), mc = g.countries[me];
  const rows = g.countries.filter((c) => c.id !== me).map((c) => {
    const s = g.stats[c.id];
    const war = atWar(g, me, c.id);
    const f = factionOf(g, c);
    const mate = sameFaction(g, me, c.id);
    const link = vassalLink(g, me, c.id);
    const rel = !c.alive ? 'Пала' : war ? `Война · ${warAge(g, me, c.id)} дн.` : link ? (c.overlord === me ? 'Ваш вассал' : 'Ваш сюзерен') : mate ? 'Союзник' : c.overlord != null ? `Вассал: ${g.countries[c.overlord].name}` : 'Мир';
    let btn = '';
    if (c.alive) {
      if (war) {
        const sc = warScore(g, me, c.id);
        btn = `<button type="button" class="btn" data-act="openpeace" data-arg="${c.id}">Мирные переговоры<small>очки войны ${sc}</small></button>`;
      } else if (!mate && !link && mc.overlord == null) {
        const goal = hasGoal(g, me, c.id), jf = justifying(g, me, c.id);
        if (!goal && !jf) btn += `<button type="button" class="btn" data-act="justify" data-arg="${c.id}">Обосновать войну<small>${pp(RULES.justifyPP)} · ${justifyDays(g)} дн.</small></button>`;
        if (jf) btn += `<span class="st">Повод через ${jf.end - g.day} дн.</span>`;
        btn += `<button type="button" class="btn danger" data-act="war" data-arg="${c.id}"><span class="bll">${bico('r_war')}${ui.confirmWar === c.id ? 'Подтвердить' : 'Объявить войну'}</span><small>${warCost(g, me, c.id)} власти${goal ? ' · есть повод' : ' · без повода'}</small></button>`;
      }
      if (!war) btn += `<button type="button" class="btn" data-act="dipcard" data-arg="${c.id}">Торговля и договоры</button>`;
      if (mf && mf.leader === me && !f && !war && !link) btn += `<button type="button" class="btn" data-act="invite" data-arg="${c.id}"><span class="bll">${bico('a_invite')}В альянс</span><small>${pp(RULES.invitePP)}</small></button>`;
      if (!mf && f && !war) btn += `<button type="button" class="btn" data-act="joinreq" data-arg="${f.id}">Вступить в ${f.name}</button>`;
    }
    const op = c.alive ? opinion(g, me, c.id) : 0;
    const sc2 = c.alive && war ? ` · очки войны ${warScore(g, me, c.id)}` : '';
    return `<div class="row ${c.alive ? '' : 'dead'} ${btn ? 'multi' : ''}"><div class="nm2">${flag(c)}<span>${c.name}</span></div><div class="sm">${c.alive ? `${s.provinces} пров. · ${troopText(g, c.id, s.troops)} войск · <span class="${opCls(op)}">отн. ${opTxt(op)}</span>${f ? ` · ${f.name}` : ''} · ${(IDEOS[c.ideo] || IDEOS.aut).name} · ` : ''}${rel}${sc2}</div><div class="rt">${btn}</div></div>`;
  }).join('');
  return tensionLine(g) + rows;
}

function diploTreaties(ui) {
  const g = ui.game, me = g.playerId, mc = g.countries[me];
  let h = tensionLine(g);
  const mine = (g.guar || []).filter((x) => x.by === me), got = (g.guar || []).filter((x) => x.of === me);
  const vs = vassalsOf(g, me);
  if (mc.overlord != null) h += sub(`Вы вассал страны ${g.countries[mc.overlord].name}: четверть золота уходит сюзерену, войн самим не объявить`);
  if (vs.length) h += sub('Ваши вассалы') + vs.map((v) => `<div class="row"><div class="nm2">${flag(v)}<span>${v.name}</span></div><div class="sm">Платит ${Math.round(RULES.tribute * 100)}% золота и воюет вместе с вами</div><div class="rt"><button type="button" class="btn" data-act="release" data-arg="${v.id}">Отпустить</button></div></div>`).join('');
  if (got.length) h += sub('Вам гарантируют: ' + got.map((x) => g.countries[x.by].name).join(', '));
  h += tradeBlock(ui);
  h += sub('Гарантии и поставки' + (mine.length ? ` · вы гарантируете: ${mine.length}` : ''));
  h += g.countries.filter((c) => c.id !== me && c.alive).map((c) => {
    const gu = guaranteed(g, me, c.id), ld = lendOf(g, me, c.id), inL = lendOf(g, c.id, me);
    const state = [gu ? 'гарантия дана' : '', ld ? `ленд-лиз ещё ${ld.until - g.day} дн.` : '', inL ? `поставляет вам` : ''].filter(Boolean).join(' · ') || 'нет договоров';
    const b1 = gu ? `<button type="button" class="btn" data-act="unguar" data-arg="${c.id}">Отозвать гарантию</button>` : `<button type="button" class="btn" data-act="guar" data-arg="${c.id}">Гарантировать<small>${pp(RULES.guarPP)}</small></button>`;
    const b2 = ld ? `<button type="button" class="btn" data-act="unlend" data-arg="${c.id}">Прекратить помощь</button>` : `<button type="button" class="btn" data-act="lend" data-arg="${c.id}">Ленд-лиз<small>${pp(RULES.lendPP)}</small></button>`;
    return `<div class="row multi"><div class="nm2">${flag(c)}<span>${c.name}</span></div><div class="sm">${state}</div><div class="rt">${mc.overlord == null ? b1 + b2 : ''}</div></div>`;
  }).join('');
  return h;
}

function diploAlliance(ui) {
  const g = ui.game, me = g.playerId, c = g.countries[me], f = factionOf(g, c);
  let h = '';
  const offers = g.offers.filter((o) => o.to === me && o.kind !== 'trade');
  if (offers.length) {
    h += sub('Предложения') + offers.map((o) => {
      const from = g.countries[o.from].name;
      const txt = o.kind === 'peace' ? peaceOfferText(g, o) : o.kind === 'invite' ? `${from} приглашает вас в альянс` : o.kind === 'join' ? `${from} просит принять её в ваш альянс` : `${from} призывает вас в свою войну`;
      return `<div class="row"><div class="nm2"><span>${txt}</span></div><div class="rt"><button type="button" class="btn" data-act="offer" data-arg="${o.id}:1">Принять</button><button type="button" class="btn" data-act="offer" data-arg="${o.id}:0">Отклонить</button></div></div>`;
    }).join('');
  }
  if (!f) {
    h += sub('Вы не состоите в альянсе');
    h += `<div class="row"><div class="nm2"><span>Основать альянс</span></div><div class="sm">Нападение на члена вызывает войну всего альянса; лидер зовёт союзников в свои войны.</div><div class="rt"><button type="button" class="btn" data-act="found"><span class="bll">${bico('a_found')}Основать</span><small>${pp(RULES.factionPP)}</small></button></div></div>`;
    for (const o of g.factions) h += `<div class="row"><div class="nm2">${flag(g.countries[o.leader])}<span>${o.name}</span></div><div class="sm">Членов: ${o.members.length} · лидер ${g.countries[o.leader].name}</div><div class="rt"><button type="button" class="btn" data-act="joinreq" data-arg="${o.id}">Просить приёма</button></div></div>`;
    return h;
  }
  const lead = f.leader === me;
  h += sub(`${f.name}${lead ? ' · вы лидер' : ''}`);
  h += f.members.map((m) => {
    const mc = g.countries[m];
    let btns = '';
    if (lead && m !== me) {
      if (callableEnemies(g, me, m).length) btns += `<button type="button" class="btn" data-act="callwar" data-arg="${m}"><span class="bll">${bico('a_call')}В войну</span><small>${pp(RULES.callPP)}</small></button>`;
      btns += `<button type="button" class="btn" data-act="kick" data-arg="${m}">Исключить</button>`;
    }
    return `<div class="row"><div class="nm2">${flag(mc)}<span>${mc.name}${m === f.leader ? ' ★' : ''}</span></div><div class="sm">${g.stats[m].provinces} пров. · ${troopText(g, m, g.stats[m].troops)} войск</div><div class="rt">${btns}</div></div>`;
  }).join('');
  h += `<div class="row"><div class="rt"><button type="button" class="btn danger" data-act="leavef"><span class="bll">${bico('a_leave')}${lead ? 'Распустить альянс' : 'Выйти из альянса'}</span></button></div></div>`;
  return h;
}

function diploOrgs(ui) {
  const g = ui.game, me = g.playerId, c = g.countries[me];
  return Object.entries(ORGS).filter(([id]) => orgMembers(g, id).length || c.orgs.includes(id)).map(([id, o]) => {
    const mem = orgMembers(g, id);
    const inn = c.orgs.includes(id);
    let btn;
    if (inn) btn = `<button type="button" class="btn" data-act="orgleave" data-arg="${id}">Выйти</button>`;
    else { const ck = orgJoinCheck(g, me, id); btn = ck.ok ? `<button type="button" class="btn" data-act="org" data-arg="${id}">Вступить<small>${pp(RULES.orgPP)}</small></button>` : `<span class="st bad" style="display:block;margin-top:4px">${ck.msg}</span>`; }
    return `<div class="item"><div class="it">${bico('o_' + id)}${o.name}${inn ? ' ✓' : ''}</div><div class="id">${o.desc}<br>Члены: ${mem.map((m) => m.name).join(', ') || '—'}${btn.startsWith('<span') ? btn : ''}</div><div class="ic">${btn.startsWith('<span') ? '' : btn}</div></div>`;
  }).join('') || sub('Организаций нет');
}

function diploBody(ui) {
  const tab = ui.diploTab || 'c';
  const tabs = `<div class="ptabs" role="tablist">${[['c', 'Страны'], ['a', 'Альянс'], ['t', 'Договоры'], ['o', 'Организации']].map(([k, l]) => `<button type="button" role="tab" data-act="dtab" data-arg="${k}" aria-selected="${tab === k}">${l}</button>`).join('')}</div>`;
  return { tabs, body: tab === 'a' ? diploAlliance(ui) : tab === 'o' ? diploOrgs(ui) : tab === 't' ? diploTreaties(ui) : diploCountries(ui) };
}


// ---------- торговля ----------
const r1t = (x) => (Math.round(x * 10) / 10).toString();
function dealRow(g, me, d) {
  const G = TRADE_GOODS[d.good], buying = d.to === me, other = g.countries[buying ? d.from : d.to];
  const gold = d.amt * d.price;
  const state = d.miss ? `<span class="st bad">перебой ${d.miss} дн.</span>` : '';
  return `<div class="row multi"><div class="nm2">${flag(other)}<span>${buying ? 'Покупаете' : 'Продаёте'}: ${G.name.toLowerCase()}</span></div>
    <div class="sm">${other.name} · ${r1t(d.amt)}/день по ${d.price} · ${buying ? '−' : '+'}${r1t(gold)} зол./день · ещё ${Math.max(0, d.until - g.day)} дн. ${state}</div>
    <div class="rt"><button type="button" class="btn" data-act="canceldeal" data-arg="${d.id}">Расторгнуть</button></div></div>`;
}

function tradeBlock(ui) {
  const g = ui.game, me = g.playerId;
  let h = sub('Торговля · сделок ' + dealsOf(g, me).length + ' из ' + RULES.tradeSlots);
  for (const o of g.offers.filter((x) => x.to === me && x.kind === 'trade')) {
    h += `<div class="row"><div class="nm2"><span>${tradeOfferText(g, o)}</span></div><div class="rt"><button type="button" class="btn" data-act="offer" data-arg="${o.id}:1">Принять</button><button type="button" class="btn" data-act="offer" data-arg="${o.id}:0">Отклонить</button></div></div>`;
  }
  const deals = dealsOf(g, me);
  if (!deals.length) h += `<p class="note" style="padding:0 12px">Сделок нет. Откройте страну во вкладке «Страны» и заключите торговлю: излишки топлива, промышленности и очков технологий можно продавать за золото, а нехватку докупать.</p>`;
  else {
    const b = tradeBalance(g, me);
    h += deals.map((d) => dealRow(g, me, d)).join('');
    h += `<p class="note" style="padding:0 12px">В день: золото ${signed(b.gold)}${['fuel', 'ind', 'res'].filter((k) => Math.abs(b[k]) > 0.05).map((k) => ` · ${TRADE_GOODS[k].name.toLowerCase()} ${signed(b[k])}`).join('')}</p>`;
  }
  return h;
}

// Блок торговли в карточке страны: выбор товара, направления и размера, потом «Заключить».
function dipTradeBlock(ui, c) {
  const g = ui.game, me = g.playerId, mc = g.countries[me];
  const good = ui.tgood || 'fuel', dir = ui.tdir || 'buy', size = ui.tsize || 'm';
  const G = TRADE_GOODS[good];
  const seller = dir === 'buy' ? c.id : me, buyer = dir === 'buy' ? me : c.id;
  const amt = dealAmount(g, seller, good, size), price = dealPrice(g, seller, buyer, good);
  const can = canTrade(g, me, c.id);
  const seg = (act, cur, items) => `<div class="seg" role="group" style="padding:4px 12px">${items.map(([k, l]) => `<button type="button" data-act="${act}" data-arg="${k}" aria-pressed="${cur === k}">${l}</button>`).join('')}</div>`;
  let h = sub('Торговля');
  const mine = dealBetween(g, me, c.id);
  h += mine.map((d) => dealRow(g, me, d)).join('');
  if (!can.ok) return h + `<p class="note" style="padding:0 12px">${can.msg}</p>`;
  h += seg('tgood', good, Object.entries(TRADE_GOODS).map(([k, v]) => [k, v.short]));
  h += seg('tdir', dir, [['buy', 'Купить у них'], ['sell', 'Продать им']]);
  h += seg('tsize', size, TRADE_SIZES.map(([k, l]) => [k, l]));
  const stock = Math.round(mc[G.key]);
  h += `<p class="note" style="padding:0 12px">${dir === 'buy' ? 'Вы получаете' : 'Вы отдаёте'} ${r1t(amt)} ${G.name.toLowerCase()} в день, ${dir === 'buy' ? 'платите' : 'получаете'} ${r1t(amt * price)} золота в день (${price} за единицу, срок ${RULES.tradeDays} дн.). На вашем складе: ${stock}.</p>`;
  h += `<div class="row"><div class="rt"><button type="button" class="btn" data-act="tradego" data-arg="${c.id}">Заключить<small>${pp(RULES.tradePP)}</small></button></div></div>`;
  return h;
}

// ---------- карточка страны: вся дипломатия с одной страной в одном окне ----------
function dipCardPanel(ui) {
  const g = ui.game, me = g.playerId, mc = g.countries[me], c = g.countries[ui.dipId];
  if (!c || !c.alive || c.id === me) return panel(title('Дипломатия'), sub('Страны больше нет'));
  const s = g.stats[c.id];
  const war = atWar(g, me, c.id), mate = sameFaction(g, me, c.id), link = vassalLink(g, me, c.id);
  const f = factionOf(g, c), mf = factionOf(g, mc);
  const op = opinion(g, me, c.id);
  const status = war ? `Война · ${warAge(g, me, c.id)} дн.` : link ? (c.overlord === me ? 'Ваш вассал' : 'Ваш сюзерен') : mate ? 'Союзник по альянсу' : c.overlord != null ? `Вассал страны ${g.countries[c.overlord].name}` : 'Мир';
  const gaveG = guaranteed(g, me, c.id), gotG = guaranteed(g, c.id, me);
  const theirG = (g.guar || []).filter((x) => x.by === c.id && x.of !== me).map((x) => g.countries[x.of].name);
  const ld = lendOf(g, me, c.id), inL = lendOf(g, c.id, me);
  const vs = vassalsOf(g, c.id).map((v) => v.name);
  const guardians = (g.guar || []).filter((x) => x.of === c.id && x.by !== me).map((x) => g.countries[x.by].name);
  const orgs = c.orgs.map((id) => `${ORGS[id].name}${mc.orgs.includes(id) ? ' ✓' : ''}`);
  const treaty = [gaveG ? 'вы гарантируете их независимость' : '', gotG ? 'они гарантируют вашу' : '', ld ? `ваш ленд-лиз ещё ${ld.until - g.day} дн.` : '', inL ? 'они поставляют вам помощь' : ''].filter(Boolean).join('; ') || 'нет';
  const idn = IDEOS[c.ideo] || IDEOS.aut;
  const facts = `<div class="blk"><dl class="facts plain">
    <div><dt>Строй</dt><dd>${idn.name}</dd></div><div><dt>Отношение</dt><dd class="${opCls(op)}">${opTxt(op)}</dd></div>
    <div><dt>Провинции</dt><dd>${s.provinces}</dd></div><div><dt>Войска</dt><dd>${troopText(g, c.id, s.troops)}</dd></div>
    <div><dt>Статус</dt><dd>${status}</dd></div><div><dt>Стабильность</dt><dd>${knowsTroops(g, c.id) ? Math.round(c.stability) : '—'}</dd></div></dl></div>`;
  const info = `<div class="blk"><p class="note">Альянс: ${f ? `${f.name} (лидер ${g.countries[f.leader].name}, стран: ${f.members.length})` : 'нет'}<br>
    Организации: ${orgs.join(', ') || 'нет'}<br>Договоры: ${treaty}${theirG.length ? `<br>Гарантирует: ${theirG.join(', ')}` : ''}${guardians.length ? `<br>Им гарантируют: ${guardians.join(', ')}` : ''}${vs.length ? `<br>Вассалы: ${vs.join(', ')}` : ''}</p></div>`;
  const row = (name, desc, btn) => `<div class="row multi"><div class="nm2"><span>${name}</span></div><div class="sm">${desc}</div><div class="rt">${btn}</div></div>`;
  const B = (act, label, small, cls = '', dis = false) => `<button type="button" class="btn ${cls}" data-act="${act}" data-arg="${c.id}" ${dis ? 'disabled' : ''}>${label}${small ? `<small>${small}</small>` : ''}</button>`;
  const vassalMe = mc.overlord != null;
  let h = sub(`${flag(c)} <b>${c.name}</b>`) + facts + info;
  h += sub('Война и мир');
  if (war) {
    h += row('Мирные переговоры', `Очки войны: вы ${warScore(g, me, c.id)}, они ${warScore(g, c.id, me)}`, B('openpeace', 'Начать переговоры', ''));
  } else if (mate || link) {
    h += row('Война', mate ? 'Нельзя воевать с союзником: сначала выйдите из альянса' : 'Нельзя воевать с вассалом или сюзереном', '');
  } else if (vassalMe) {
    h += row('Война', 'Вассал не ведёт своей политики', '');
  } else {
    const goal = hasGoal(g, me, c.id), jf = justifying(g, me, c.id);
    h += row('Обосновать войну', goal ? 'Повод уже есть: война будет дешевле' : jf ? `Повод через ${jf.end - g.day} дн.` : `Даёт повод: война вдвое дешевле. ${justifyDays(g)} дн.`, goal || jf ? '' : B('justify', 'Обосновать', pp(RULES.justifyPP)));
    h += row('Объявить войну', `${warCost(g, me, c.id)} власти${goal ? ' · есть повод' : ' · без повода: потеря стабильности'}`, B('war', ui.confirmWar === c.id ? 'Подтвердить' : 'Объявить войну', '', 'danger'));
  }
  h += sub('Союз и договоры');
  if (mate) h += row('Альянс', `Вы оба в ${f.name}`, mf && mf.leader === me ? B('kick', 'Исключить', '') : '');
  else if (!war && !link) {
    if (mf && mf.leader === me && !f) h += row('Пригласить в альянс', `${mf.name}`, B('invite', 'Пригласить', pp(RULES.invitePP)));
    else if (!mf && f) h += row('Вступить в альянс', `${f.name}`, B('joinreq', 'Попроситься', ''));
    else if (!mf && !f) h += row('Основать альянс', 'Создайте свой альянс, потом пригласите страну', `<button type="button" class="btn" data-act="found">Основать</button>`);
    else h += row('Альянс', mf ? 'Приглашать может только лидер альянса; страна уже в другом блоке' : 'Они уже в блоке', '');
  }
  if (!vassalMe) {
    h += row('Гарантии независимости', gaveG ? 'Вы гарантируете их границы' : 'Нападение на них вызовет вашу войну', gaveG ? B('unguar', 'Отозвать', '') : B('guar', 'Гарантировать', pp(RULES.guarPP), '', war));
    h += row('Ленд-лиз', ld ? `Поставки идут ещё ${ld.until - g.day} дн.` : 'Поставки золота и снаряжения за счёт вашей казны', ld ? B('unlend', 'Прекратить', '') : B('lend', 'Помогать', pp(RULES.lendPP), '', war));
  }
  if (!war) h += dipTradeBlock(ui, c);
  if (c.overlord === me) h += row('Вассал', 'Платит четверть золота и воюет с вами', B('release', 'Отпустить', ''));
  const joinable = Object.keys(ORGS).filter((id) => c.orgs.includes(id) && !mc.orgs.includes(id));
  if (joinable.length) {
    h += sub('Организации');
    h += joinable.map((id) => { const ck = orgJoinCheck(g, me, id); return row(ORGS[id].name, ck.ok ? ORGS[id].desc : ck.msg, ck.ok ? `<button type="button" class="btn" data-act="org" data-arg="${id}">Вступить<small>${pp(RULES.orgPP)}</small></button>` : ''); }).join('');
  }
  return panel(title(`Дипломатия · ${c.name}`), h);
}

// ---------- деревья технологий и фокусов ----------
const TREE = { W: 132, H: 82, GX: 40, GY: 14, PAD: 14 };
const EFF_ICON = { tf: 't_forest', th: 't_hills', tm: 't_mountains', td: 't_desert', org: 'r_stab', orgLoss: 'r_stab', dig: 'r_def', supply: 'u_armies', comp: 'r_prov', gold: 'r_gold', ind: 'r_ind', res: 'r_res', fuel: 'r_fuel', men: 'r_men', pp: 'r_pp', attack: 'r_troops', defense: 'r_def', stab: 'r_stab', speed: 'u_armies', build: 'u_build', war: 'u_diplo', upkeep: 'r_gold', recruit: 'r_men', loot: 'r_prov', fuelUse: 'r_fuel' };
// Образ по названию технологии или фокуса: первое совпадение выигрывает, иначе значок по эффекту
const MOTIFS = [
  [/лётн|летн/, 'g_fighter'],
  [/реактивные двигател|двигател/, 'g_engine'], [/радар|радиолок/, 'g_radar'], [/радио|связь/, 'g_radio'], [/ядерн/, 'g_atom'],
  [/ракет|реактивн/, 'g_rocket'], [/криптограф/, 'g_decree'], [/разведыв|тайная|полици/, 'g_police'],
  [/лаборатор|институт|научн|исследован|образован|хими|нефтехим|школ/, 'g_lab'],
  [/баки|дальняя авиац/, 'g_fueltank'], [/ангар/, 'g_hangar'], [/десант|парашют/, 'g_parachute'],
  [/бомбардир|штурмовик|пикирующ/, 'g_bomber'], [/истребит|авиац|воздух|единое командование/, 'g_fighter'],
  [/противотанк/, 'g_atgun'], [/артиллер|гаубиц|орудий/, 'g_artillery'], [/танк|моториз|манёвренн|маневренн|блицкриг|бронет|кавалер/, 'g_tank'],
  [/окоп|эшелониров|глубокая оборона|мобильная оборона/, 'g_trench'], [/пулем/, 'g_mg'],
  [/фортифик|укрепл|линия|форт|вал\b|пояс|оборон/, 'g_bunker'], [/инженер|мост/, 'g_bridge'],
  [/тыл|снабж|автотранспорт|автоцистерн|колонн|вьючн|логист/, 'g_truck'],
  [/электрифик/, 'g_pylon'], [/железнодорож|дорожн|автобан|магистрал/, 'g_train'], [/нефт|топлив|бензин|синтет/, 'g_barrel'],
  [/банк|капитал|финанс|золот|преференц/, 'g_gold'], [/торгов|порт|флот|судов/, 'g_ship'],
  [/аграр|зерн|колхоз|коллективиз|земельн|рыб|бекон|осушен/, 'g_grain'], [/рудник|добыч|шахт/, 'b_mine'], [/лесн/, 'b_lumber'],
  [/конвейер|массов|промышлен|завод|индустр|пятилет|экономическ|стал|производств/, 'g_factory'],
  [/пропаганд|пресс/, 'g_propaganda'], [/закон|правов|юстиц/, 'g_law'], [/администр|оккупац|гражданск|централиз|управлен/, 'g_decree'],
  [/союз|договор|пакт|дипломат|гарант|антант|конфедерац|влияние|блок|безопасн|сердечное|бенилюкс|унив/, 'g_deal'],
  [/единств|консолидац|национал|народн|согласие|нейтралитет/, 'g_vote'], [/корол|импер|диктатур|монарх|государств/, 'g_crown'],
  [/пехот|устав|учебн|лагер|призыв|воинск|мобилизац|армия|армии|армию|стрелк|егер|лыж|альпин|горн|камуфляж|маскиров|элитн|подготовк|городки/, 'g_infantry'],
  [/поход|вторжен|барбаросса|гельб|везер|зимняя война|война/, 'g_tank'],
  [/железн/, 'g_train'], [/проливам|море|эгейск/, 'g_ship'], [/арсенал|милитариз|ремилитар|ркка|войска|ополчен|экипировк|форма|штабн|родов войск|оперативн|глубокой операции|реорганизац/, 'g_infantry'],
  [/экономик|рынок|плановая|стаханов|четырёхлет|четырехлет|автаркия|программа|перевооружение/, 'g_factory'],
  [/революц|рабочее|республик|парламент|реформ/, 'g_vote'], [/сделка|умиротворение|жёсткий курс|сближение|ориентация|защита британии|помощь/, 'g_deal'],
];
const motif = (name) => { const t = String(name || '').toLowerCase(); for (const [re, k] of MOTIFS) if (re.test(t) && ICONS[k]) return pic(k); return null; };
const effIcon = (eff) => { for (const k of Object.keys(eff || {})) if (EFF_ICON[k] && ICONS[EFF_ICON[k]]) return pic(EFF_ICON[k]); return pic('r_prov'); };

// Раскладка: столбец = глубина по требованиям, строка = рядом с родителями, без наложений
function layoutTree(ids, reqOf) {
  const depth = {};
  const dep = (id) => (depth[id] != null ? depth[id] : (depth[id] = Math.max(-1, ...reqOf(id).filter((r) => ids.includes(r)).map(dep)) + 1));
  ids.forEach(dep);
  const cols = [];
  ids.forEach((id) => { (cols[depth[id]] = cols[depth[id]] || []).push(id); });
  const row = {};
  for (const col of cols) {
    const used = new Set();
    col.sort((x, y) => {
      const mean = (id) => { const ps = reqOf(id).filter((r) => row[r] != null); return ps.length ? ps.reduce((t, r) => t + row[r], 0) / ps.length : 1e9; };
      return mean(x) - mean(y);
    });
    for (const id of col) {
      const ps = reqOf(id).filter((r) => row[r] != null);
      let want = ps.length ? Math.round(ps.reduce((t, r) => t + row[r], 0) / ps.length) : 0;
      for (let d = 0; d < 60; d++) {
        const cand = [want + d, want - d].filter((v) => v >= 0 && !used.has(v));
        if (cand.length) { want = cand[0]; break; }
      }
      used.add(want); row[id] = want;
    }
  }
  return { depth, row, cols: cols.length, rows: Math.max(0, ...Object.values(row)) + 1 };
}

// nodes: [{id, name, desc, req, st, left, days, costHtml, costOk, icon, tier}]; sel — выбранный; act — действие выбора узла
function treeHtml(nodes, sel, act) {
  const ids = nodes.map((n) => n.id), byId = Object.fromEntries(nodes.map((n) => [n.id, n]));
  const L = layoutTree(ids, (id) => byId[id].req);
  const { W, H, GX, GY, PAD } = TREE;
  const pos = (id) => ({ x: PAD + L.depth[id] * (W + GX), y: PAD + L.row[id] * (H + GY) });
  const width = PAD * 2 + L.cols * W + (L.cols - 1) * GX, height = PAD * 2 + L.rows * H + (L.rows - 1) * GY;
  let lines = '';
  for (const n of nodes) for (const r of n.req) {
    if (!byId[r]) continue;
    const a = pos(r), b = pos(n.id), x1 = a.x + W, y1 = a.y + H / 2, x2 = b.x, y2 = b.y + H / 2, mx = (x1 + x2) / 2;
    const cls = byId[r].st === 'known' ? (n.st === 'known' ? 'on' : 'open') : 'off';
    lines += `<path class="tl ${cls}" d="M${x1} ${y1}C${mx} ${y1} ${mx} ${y2} ${x2} ${y2}"/>`;
  }
  const cards = nodes.map((n) => {
    const { x, y } = pos(n.id);
    const prog = n.st === 'active' && n.days ? `<i class="tp" style="width:${Math.round((1 - n.left / n.days) * 100)}%"></i>` : '';
    const bottom = n.st === 'known' ? '<span class="tk">Изучено</span>' : n.st === 'active' ? `<span class="ta">${n.left} дн.</span>` : n.costHtml;
    return `<button type="button" class="tnode ${n.st} ${n.alt ? 'alt' : ''} ${n.id === sel ? 'sel' : ''}" data-act="${act}" data-arg="${n.id}" style="left:${x}px;top:${y}px;width:${W}px;height:${H}px"><span class="ti">${n.icon}</span><span class="tn">${n.name}</span><span class="tc ${n.costOk === false ? 'short' : ''}">${bottom}</span>${prog}</button>`;
  }).join('');
  return `<div class="treewrap"><div class="tree" style="width:${width}px;height:${height}px"><svg class="tlines" width="${width}" height="${height}" aria-hidden="true">${lines}</svg>${cards}</div></div>`;
}

function treePanel(tabs, summary, tree, detail) {
  return `<div class="panel treepanel" role="dialog">${tabs}<div class="tsum">${summary}</div>${tree}<div class="tdetail">${detail}</div><button type="button" class="pback" data-act="closemodal">Назад</button></div>`;
}

function pickSel(nodes, want) {
  if (want && nodes.some((n) => n.id === want)) return want;
  return (nodes.find((n) => n.st === 'ready') || nodes.find((n) => n.st === 'active') || nodes[0] || {}).id;
}

function techPanel(ui, tabs) {
  const g = ui.game, me = g.playerId, c = g.countries[me];
  const busy = Object.values(c.slots).filter(Boolean).length;
  const nodes = Object.entries(TECHS).filter(([, t]) => t.branch === ui.techTab).sort((a, b) => a[1].tier - b[1].tier).map(([id, t]) => {
    const s = techState(g, me, id);
    return { id, name: t.name, desc: t.desc, req: t.req, st: s.st === 'busy' || s.st === 'short' ? 'ready' + (s.st === 'short' ? ' lack' : '') : s.st, raw: s, left: s.left, days: t.days, tier: t.tier, icon: motif(t.name) || effIcon(t.effect),
      costHtml: `<span>${fmt(t.cost)}</span>${ICON.flask}`, costOk: c.research >= t.cost };
  });
  const sel = ui.techSel = pickSel(nodes, ui.techSel);
  const n = nodes.find((x) => x.id === sel), t = n && TECHS[n.id];
  let detail = '<div class="empty">Нет технологий.</div>';
  if (n) {
    const s = n.raw;
    let act;
    if (s.st === 'known') act = '<span class="st">Изучено</span>';
    else if (s.st === 'active') act = `<span class="st">Изучается: ещё ${s.left} дн.</span>`;
    else if (s.st === 'ready') act = `<button type="button" class="cost rs" data-act="research" data-arg="${n.id}">${fmt(t.cost)} ${ICON.flask}<small>${t.days} дн.</small></button>`;
    else if (s.st === 'short') act = `<button type="button" class="cost short" disabled>${fmt(t.cost)} ${ICON.flask}<small>${t.days} дн.</small></button><span class="st bad">${s.msg}</span>`;
    else act = `<span class="st bad">${s.msg}</span>`;
    detail = `<div class="dt"><b>${t.name}</b><small class="tier">${['I', 'II', 'III', 'IV', 'V', 'VI'][t.tier - 1]}</small><div class="dd">${t.desc}</div></div><div class="da">${act}</div>`;
  }
  const summary = `Очки технологий ${fmt(c.research)} (${signed(c.income.res)} в день) · в работе ${busy} из ${TECH_BRANCHES.length}`;
  return treePanel(tabs, summary, treeHtml(nodes, sel, 'tnode'), detail);
}

function focusPanel(ui, tabs) {
  const g = ui.game, me = g.playerId, c = g.countries[me];
  const nodes = focusTree(c.base || c.name, c.ideo0).map((id) => {
    const f = FOCUSES[id], s = focusState(g, me, id);
    return { id, name: f.name, desc: f.desc, req: f.req, st: s.st === 'busy' || s.st === 'short' ? 'ready' + (s.st === 'short' ? ' lack' : '') : s.st, raw: s, left: s.left, days: f.days, alt: f.alt, icon: (f.icon && ICONS[f.icon] ? pic(f.icon) : null) || motif(f.name) || (f.alt ? pic(f.act.war ? 'r_war' : f.act.annex || f.act.cede ? 'r_prov' : f.act.ally ? 'u_diplo' : 'r_stab') : effIcon({ ...f.effect, ...(f.instant || {}) })),
      costHtml: `<span>${f.cost}</span>${ICON.star}`, costOk: c.pp >= f.cost };
  });
  const sel = ui.focusSel = pickSel(nodes, ui.focusSel);
  const n = nodes.find((x) => x.id === sel), f = n && FOCUSES[n.id];
  let detail = '<div class="empty">Нет фокусов.</div>';
  if (n) {
    const s = n.raw;
    let act;
    if (s.st === 'known') act = '<span class="st">Завершён</span>';
    else if (s.st === 'active') act = `<span class="st">Идёт: ещё ${s.left} дн.</span>`;
    else if (s.st === 'ready') act = `<button type="button" class="cost pp" data-act="focus" data-arg="${n.id}">${f.cost} ${ICON.star}<small>${f.days} дн.</small></button>`;
    else if (s.st === 'short') act = `<button type="button" class="cost short" disabled>${f.cost} ${ICON.star}<small>${f.days} дн.</small></button><span class="st bad">${s.msg}</span>`;
    else act = `<span class="st bad">${s.msg}</span>`;
    const excl = (f.excl || []).map((x) => `«${FOCUSES[x].name}»`).join(', ');
    detail = `<div class="dt"><b>${f.name}</b>${f.alt ? '<small class="tier alt">Альтернативная история</small>' : ''}${f.ideo ? `<small class="tier alt">${f.regime ? 'Смена режима: ' : 'Путь: '}${IDEOS[f.ideo].name}</small>` : ''}${f.regime ? `<div class="dd">${IDEOS[f.ideo].desc}${s.st !== 'known' ? ` <span class="civ">Риск гражданской войны: ${Math.round(civilWarChance(g, c, f.ideo) * 100)}%.</span>` : ''}</div>` : ''}<div class="dd">${f.desc}${excl ? `<br>Исключает: ${excl}` : ''}</div></div><div class="da">${act}</div>`;
  }
  const now = c.focus ? `идёт «${FOCUSES[c.focus.id].name}»` : 'не выбран';
  return treePanel(tabs, `Власть ${fmt(c.pp)} (${signed(c.income.pp)} в день) · фокус ${now}`, treeHtml(nodes, sel, 'fnode'), detail);
}

const stabLine = (v) => (v >= 0 ? '+' : '−') + Math.abs(Math.round(v * 10) / 10);

function countryOverview(ui) {
  const g = ui.game, me = g.playerId, c = g.countries[me], st = g.stats[me];
  const s = c.stability, info = stabilityInfo(g, c), eff = stabilityEffects(s);
  const tone = s < 30 ? 'bad' : s < 50 ? 'warn' : '';
  const lines = info.lines.map(([l, v]) => `<div class="ln"><span>${l}</span><b class="${v < 0 ? 'neg' : 'pos'}">${stabLine(v)}</b></div>`).join('');
  const stab = `<div class="blk"><div class="stabrow"><span>Стабильность</span><b class="${tone}">${Math.round(s)}%</b><small>цель ${Math.round(info.target)}%</small></div>
    <div class="meter ${tone}"><i style="width:${s}%"></i><u style="left:${info.target}%"></u></div>
    <p class="note">Доход ×${eff.econ.toFixed(2)} · урон армий ×${eff.combat.toFixed(2)} · власть ${eff.pp ? stabLine(eff.pp) + ' в день' : 'без изменений'}</p>${lines}</div>`;
  const tax = `<div class="blk"><div class="stabrow"><span>Налог</span><b>${TAX[c.tax].name}</b></div>
    <div class="taxseg" role="group" aria-label="Налог">${TAX.map((t, i) => `<button type="button" data-act="tax" data-arg="${i}" aria-pressed="${c.tax === i}">${bico('tax' + i)}${t.name}</button>`).join('')}</div>
    <p class="note">Золото ×${TAX[c.tax].gold.toFixed(2)} · цель стабильности ${stabLine(TAX[c.tax].stab)}. Высокий налог даёт золото, но стабильность падает, а вместе с ней доход, приток людей и сила армий.</p></div>`;
  const id = IDEOS[c.ideo] || IDEOS.aut;
  const ideo = `<div class="blk"><div class="stabrow"><span>Строй</span><b>${pico('id_' + c.ideo)}${id.name}</b><small>${c.name}</small></div><p class="note">${id.desc}</p></div>`;
  const doneF = c.focuses.length, totalF = focusTree(c.base || c.name, c.ideo0).length;
  const facts = `<div class="blk"><dl class="facts plain"><div><dt>Провинции</dt><dd>${st.provinces}</dd></div><div><dt>Войска</dt><dd>${troopText(g, c.id, st.troops)}</dd></div>
    <div><dt>Технологии</dt><dd>${c.techs.length} из ${Object.keys(TECHS).length}</dd></div><div><dt>Фокусы</dt><dd>${doneF} из ${totalF}</dd></div>
    <div><dt>Золото в день</dt><dd>${signed(c.income.net)}</dd></div><div><dt>Торговля в день</dt><dd>${signed(tradeBalance(g, c.id).gold)}</dd></div><div><dt>Власть в день</dt><dd>${signed(c.income.pp)}</dd></div></dl></div>`;
  return ideo + stab + tax + facts;
}


function plagueBody(ui) {
  const g = ui.game, s = plagueSummary(g, g.playerId), cfg = PLAGUE.cfg;
  if (!s) return '<div class="empty">Эпидемии нет.</div>';
  if (!s.started) return `<div class="blk"><p class="note">Всё спокойно. Но врачи говорят о странных случаях на юге.</p></div>`;
  const bar = (v, cls) => `<div class="pbar"><i class="${cls}" style="width:${Math.max(0, Math.min(100, v))}%"></i></div>`;
  const status = s.ended ? '<p class="note ok">Болезнь побеждена. Игра идёт дальше обычным порядком.</p>'
    : s.warn ? `<p class="note bad">Пандемия вышла из-под контроля: если средняя заражённость не опустится ниже ${s.collapseAt}%, через ${s.doomLeft} дн. проиграют все.</p>`
    : `<p class="note">Если средняя заражённость мира удержится выше ${s.collapseAt}% в течение ${cfg.collapseDays} дней, проиграют все. Победа над болезнью: меньше ${cfg.winBelow}% в среднем по миру.</p>`;
  const rows = [['Заражённость мира', s.worldI, 'bad'], ['Ваша страна', s.own, 'bad'], ['Ваша вакцина', s.ownV, 'ok'], ['Вакцина с учётом помощи других стран', s.effV, 'ok']]
    .map(([l, v, cls]) => `<div class="stabrow"><span>${l}</span><b>${v.toFixed(1)}%</b></div>${bar(v, cls)}`).join('');
  const q = ['Без карантина', 'Мягкий карантин', 'Строгий карантин'];
  const qb = [0, 1, 2].map((k) => `<button type="button" class="btn ${s.q === k ? 'on' : ''}" data-act="quar" data-arg="${k}">${q[k]}${k ? ` · золото −${Math.round(cfg.quarantineGold[k] * 100)}%` : ''}</button>`).join('');
  return `<div class="blk">${rows}<div class="stabrow"><span>Защита страны</span><b>${Math.round(s.prot * 100)}%</b></div></div>${status}
    <div class="blk"><div class="stabrow"><span>Карантин</span><b>${q[s.q]}</b></div><div class="qbtns">${qb}</div>
    <p class="note">Карантин режет заражение на ${Math.round(cfg.quarantine[1] * 100)}% и ${Math.round(cfg.quarantine[2] * 100)}%, но бьёт по экономике. Вакцину создают фокусы вкладки «Фокусы»; союзники и мирные страны делятся частью успеха.</p></div>`;
}

function doctrineBody(ui) {
  const g = ui.game, c = g.countries[g.playerId], d = c.doctrine;
  const me = c.doctrine;
  const first = d.changed == null && g.day < 30;
  const res = Math.round(Math.min(0.8, c.mod.wthr || 0) * 100);
  const head = `<div class="blk"><div class="stabrow"><span>Доктрина</span><b>${DOCTRINES[d.id].name}</b><small>ступень ${d.lvl} из 3</small></div>
    <p class="note">${DOCTRINES[d.id].short}. Сопротивление погоде: ${res}%. Очки технологий: ${Math.floor(c.research)}.</p></div>`;
  const cards = [...DOCTRINE_IDS].sort((a, b) => (b === d.id) - (a === d.id)).map((id) => {
    const D = DOCTRINES[id], cur = d.id === id;
    const base = Object.entries(D.base).map(([k, v]) => `${MOD_LABEL[k] || k} ${v > 0 ? '+' : ''}${Math.round(v * 100)}%`).join(', ');
    let steps = '';
    if (cur) {
      const st = doctrineStep(g, g.playerId);
      steps = D.steps.map((s, i) => {
        const done = i < d.lvl, busy = d.step && i === d.lvl;
        let tail;
        if (done) tail = '<em class="ok">изучено</em>';
        else if (busy) tail = `<em>идёт, ещё ${d.step.left} дн.</em>`;
        else if (i === d.lvl && st.st === 'ready') tail = `<button type="button" class="btn" data-act="docstep">Изучить · ${st.cost} оч. · ${st.days} дн.</button>`;
        else if (i === d.lvl) tail = `<em>${st.msg || ''}</em>`;
        else tail = '<em>позже</em>';
        return `<div class="dstep ${done ? 'done' : ''}"><div><b>${s.name}</b><small>${s.desc}</small></div>${tail}</div>`;
      }).join('');
    }
    const btn = cur ? '<span class="dcur">выбрана</span>' : `<button type="button" class="btn" data-act="docpick" data-arg="${id}">Выбрать · ${first ? 'бесплатно' : DOCTRINE_SWITCH.pp + ' власти'}</button>`;
    return `<div class="dcard ${cur ? 'cur' : ''}"><div class="dh"><b>${D.name}</b>${btn}</div><p>${D.short}</p><small>База: ${base}</small>${steps}</div>`;
  }).join('');
  return head + cards + `<p class="note">Смена доктрины после начала игры стоит ${DOCTRINE_SWITCH.pp} власти, сбрасывает ступени и возможна раз в ${DOCTRINE_SWITCH.gap} дней. Ступени открываются по числу изученных военных технологий.</p>`;
}
const MOD_LABEL = { recruit: 'призыв', upkeep: 'содержание', speed: 'скорость', defense: 'оборона', dig: 'окопы', attack: 'урон' };

function ministersBody(ui) {
  const g = ui.game, me = g.playerId, c = g.countries[me];
  if (!c.cands) return '<div class="empty">Министров нет.</div>';
  const parts = MINISTER_POSTS.map(([post, label]) => {
    const rows = c.cands[post].map((cand, i) => {
      const tr = TRAITS[post].find((t) => t.id === cand.trait);
      const cur = c.ministers[post] === i;
      const right = cur ? '<span class="st">Назначен</span>'
        : `<button type="button" class="cost ${c.pp >= RULES.ministerPP ? 'pp' : 'short'}" data-act="minister" data-arg="${post}:${i}" ${c.pp >= RULES.ministerPP ? '' : 'disabled'}>${RULES.ministerPP} ${ICON.star}</button>`;
      return `<div class="item tech ${cur ? 'known' : ''}"><div class="it">${cand.name}<small class="tier">${tr.name}</small></div><div class="id">${tr.desc}</div><div class="ic">${right}</div></div>`;
    }).join('');
    return `<div class="posthead">${bico('m_' + post)}${label}</div>${rows}`;
  }).join('');
  return sub(`Власть ${fmt(c.pp)} · смена министра ${RULES.ministerPP}`) + parts;
}

function journalBody(ui, clock) {
  const g = ui.game, me = g.playerId;
  if (!g.log.length) return '<div class="empty">Пока ничего не произошло.</div>';
  const KL = { war: 'Война', alliance: 'Союз', peace: 'Мир', event: 'Событие', offer: 'Предложение', capture: 'Захват', fall: 'Падение', build: 'Стройка', tech: 'Наука', focus: 'Фокус', info: 'Новость' };
  return [...g.log].reverse().map((e) => `<div class="ev k-${e.kind || 'info'} ${e.involves.includes(me) ? 'me' : ''}"><div class="eh"><i class="kd">${KL[e.kind] || KL.info}</i><small>${clock.formatDate(e.day)}</small></div>${e.text}</div>`).join('');
}

const HELP = `<ul class="help">
  <li><b>Топливо.</b> Расходуется армиями в походе и в бою, меньше — на стоящих войсках. Когда запас ниже 60, армии идут и бьют чуть хуже. Когда топливо закончилось: армии вдвое с лишним медленнее, урон ×0.55, организация восстанавливается вдвое медленнее, стабильность падает, авиация стоит на земле, а наступать на чужую землю и атаковать врага нельзя — только обороняться и отходить. Топливо дают нефть и уголь, промыслы, торговля, синтетическое топливо.</li>
  <li><b>Погода.</b> Времена года и климат: север холоднее юга. Зимой снег и мороз, весной и осенью распутица, на юге летом жара. Погода замедляет армии, снижает их атаку на чужой земле и в походе отнимает организацию; на карте провинции окрашены по погоде, в панели провинции указаны точные числа. Сопротивление погоде дают зимнее обмундирование, дорожные технологии и оборонная доктрина.</li>
  <li><b>Доктрины.</b> Окно страны → «Доктрина»: один из четырёх стилей войны (массы, манёвр, оборона, огонь). У каждого три ступени за очки технологий; ступени открываются по числу изученных военных технологий. Первый выбор в начале партии бесплатный, смена позже стоит власти.</li>
  <li><b>Карта.</b> Тяните пальцем, щипком меняйте масштаб. Коснитесь провинции: справа выедет панель с её данными, язычок на краю прячет её.</li>
  <li><b>Кнопки слева сверху.</b> Молоток: строительство в выбранной провинции. Шевроны: список ваших армий. Двое людей: дипломатия, война и мир. Слои: страны или рельеф. Лупа справа внизу: вся карта или прежний вид.</li>
  <li><b>Бой.</b> Проигравшая армия отступает на свободную соседнюю клетку (лучше всего на свою землю). Если отступать некуда, армия уничтожается. После атаки (входа в провинцию с врагом) армия перегруппировывается 5 дней и не может атаковать снова. Ходы армий медленнее: равнина занимает больше двух дней.</li>
  <li><b>Мир и контрибуция.</b> Условия мира можно закрыть не только землёй: победитель вправе потребовать деньги или ресурсы (от 25 очков войны), проигравший может откупиться. В предложении мира поимённо перечислены провинции (на карте они подсвечены) или указана сумма выплаты.</li>
  <li><b>Призыв.</b> В своей провинции выберите сколько призвать (10, 25, 50, 100 или максимум): стоимость пересчитается, солдаты добавятся к стоящему отряду.</li>
  <li><b>Звук.</b> Музыка и эффекты создаются прямо в браузере. Громкость и выключатель в «Меню». В войне музыка темнеет и ускоряется, в бою звучат барабаны. На телефонах звук включается после первого касания экрана.</li>
  <li><b>Дипломатия со страной.</b> Дважды щёлкните (или дважды коснитесь) по чужой провинции либо нажмите «Дипломатия» в её панели: откроется карточка страны с отношениями, статусом, альянсом, гарантиями, ленд-лизом, организациями, войной и миром.</li>
  <li><b>Разведка.</b> Точные числа войск видны только у вас, союзников по альянсу и вассалов. У остальных, в том числе у врагов, показана примерная оценка со знаком ≈ (ошибка до 20%, обновляется раз в 20 дней).</li>
  <li><b>Правая кнопка мыши.</b> Выберите провинцию со своими армиями и щёлкните правой кнопкой по любой другой: армии пойдут туда сразу, как в HoI4.</li>
  <li><b>Идеологии.</b> У каждой страны есть строй: фашизм, демократия, коммунизм или авторитаризм, и каждый даёт свои бонусы. В дереве фокусов открыты пути к другим строям (исходный исключён, у авторитарных стран доступны все три). Пути взаимоисключающие, а завершающий фокус меняет режим и название страны. Разные строи относятся друг к другу хуже.</li>
  <li><b>Штабы.</b> Окно «Армии», вкладка «Штабы»: создайте штаб, назначьте армии и выберите тактику — наступление (сбор кулака, удар в слабое место, натиск к столице), оборона рубежа или гарнизон оккупированных земель. Задайте цель, риск и порог отступления. Ваш ручной приказ отключает штаб для этой армии на 6 дней.</li>
  <li><b>Штабы в мирное время.</b> Пока страна ни с кем не воюет, армии штаба сами выстраиваются на сухопутной границе с нейтральными странами (не своими и не союзными), пропорционально её длине. С началом войны штаб переходит к своей задаче.</li>
  <li><b>Уровни построек.</b> Большинство зданий можно улучшать: до 3 уровней (дороги и промыслы до 2). Эффект суммарно ×1, ×1,7, ×2,3 от базового, цена и срок следующего уровня ×1,5 и ×2. Фокусы-стройки сначала ставят новые здания, потом поднимают уровень.</li>
  <li><b>Порты.</b> Порт строится только на побережье. Армия в порту (своём или союзном) может плыть к любому берегу в радиусе по морю: 6 / 10 / 16 клеток воды для уровней I–III. Переход занимает дни на погрузку и на каждую клетку моря, высадка действует как десант (окружение не мешает 12 дней). Достижимые побережья подсвечены пунктиром, когда выбран порт.</li>
  <li><b>Авиация.</b> Постройте аэродром (уровни 1–3: вместимость 6 / 12 / 20 эскадрилий, радиус 3 / 4 / 6 провинций) и призовите эскадрильи (дневной лимит призыва общий с армией). Задания: <i>наземный удар</i> (небольшой урон, главное — организация армий), <i>разрушение зданий</i> (накапливает разрушение и сбивает уровень), <i>разведка</i> (видно армии и их точная численность), <i>перехват</i> (прикрывает зону: вражеские эскадрильи в ней вступают в воздушный бой, обе стороны теряют самолёты). Цель — вся зона или выбранная клетка. Самолёты тратят топливо; захват провинции уничтожает аэродром и самолёты. Технологии: ветка «Авиация».</li>
  <li><b>Темп призыва.</b> Призывать можно не больше 3·√(провинций) пачек в день (пачка — 10 войск); неиспользованное копится до 30 дней. Лимит одинаков для игрока и ИИ, поэтому мобилизацию надо готовить заранее.</li>
  <li><b>Лимит армии.</b> В мирное время армию нельзя раздувать выше потолка: 200 + 120·√(провинций). Чем больше страна, тем он выше. В войне призыв не ограничен.</li>
  <li><b>Размер страны.</b> У стран крупнее 250 провинций каждая провинция сверх порога приносит всё меньше (административные издержки): гигантская территория не равна гигантской экономике. Стартовая армия тоже ограничена.</li>
  <li><b>Оккупация.</b> Захваченная чужая земля даёт сначала лишь 20% дохода и дорастает до 100%: быстрее, если на ней стоит ваша армия-гарнизон. Без гарнизона растёт сопротивление (оно давит на стабильность), а при низком подчинении вспыхивает восстание: на провинции появляется небольшая армия повстанцев прежней страны. Если гарнизон их не разобьёт, провинция освобождается. При мире все занятые земли возвращаются прежнему владельцу, остаются только провинции, названные в условиях договора. На карте оккупированная земля сохраняет цвет прежней страны и штрихуется цветом захватчика, пока подчинение не дойдёт до 100%.</li>
  <li><b>Повод к войне и напряжённость.</b> «Обосновать войну» занимает около 20 дней и стоит власти, зато потом объявление вдвое дешевле. Нападение без повода снижает стабильность и сильно поднимает мировую напряжённость. Демократии вступаются за союзников при напряжённости от 15%, сами нападают от 45%.</li>
  <li><b>Мир и вассалы.</b> Захватив достаточную долю земель врага (очки войны), вы можете потребовать провинции (от 40 очков) или сделать страну вассалом (от 60). Вассал платит четверть золота, воюет вместе с вами и не может объявлять войны сам.</li>
  <li><b>Гарантии и ленд-лиз.</b> Вкладка «Договоры»: гарантия независимости обязывает вступить в войну, если на страну нападут; ленд-лиз 150 дней отдаёт союзнику долю вашего золота.</li>
  <li><b>Бои.</b> Исход решает не только число. У армии есть организация (полоска под числом): в бою она падает, и армия с нулевой организацией отступает, а если отступать некуда — её громят. Слабая организация снижает урон. Армия на месте окапывается (до +30% к обороне), движение сбрасывает окопы. Вне своих земель дальше двух провинций армия теряет снабжение: урон ниже, организация падает. Окружайте врага и бейте уставшие армии.</li>
  <li><b>Войска.</b> Числа на карте показывают силу армий. В своей провинции можно призвать солдат за людей и золото. Чтобы двинуть армию, нажмите «Двигаться», коснитесь цели и подтвердите приказ.</li>
  <li><b>Ресурсы.</b> Золото платит за здания и содержание войск. Люди нужны для призыва. Промышленность идёт на здания и снаряжение новых отрядов, завод даёт её больше. Топливо жгут армии в походе и в бою, при его нехватке они бьют слабее и ходят медленнее. Больше всего его на нефтяных и угольных месторождениях, промысел удваивает добычу. Очки технологий платят за изучение. Политическая власть нужна, чтобы объявить войну или попросить мира.</li>
  <li><b>Страна.</b> Нажмите на название своей страны вверху справа. Там налог, стабильность, национальные фокусы и министры. Высокий налог даёт золото, но снижает стабильность, а при низкой стабильности падают доход, приток людей и сила армий. Фокус даёт постоянный бонус и стоит власти. Министров можно менять за власть.</li>
  <li><b>Дипломатия.</b> Кнопка с людьми: страны и их отношения к вам, альянс и организации. Альянс (власть) защищает членов: нападение на одного вызывает войну всех. Лидер зовёт союзников в свои войны, на союзных землях армии проходят свободно. Организации дают бонусы, вступить можно при хороших отношениях с членами.</li>\n  <li><b>События.</b> Время от времени приходят события: важные открывают окно с выбором, мелкие просто попадают в журнал. Исторические зависят от даты и ваших прошлых решений, случайные от состояния страны: налога, стабильности, войны, технологий и министров. Пока окно открыто, время стоит.</li>\n  <li><b>Технологии.</b> Кнопка с колбой: три ветки, экономика, политика и армия. В каждой можно вести одно исследование. Очки платятся сразу, изучение занимает несколько дней, а бонусы действуют на всю страну. Лаборатории ускоряют приток очков.</li>
  <li><b>Строительство.</b> Здания покупаются за золото и промышленность и строятся несколько дней: рынок, рудник и лесопилка дают золото, завод промышленность, лаборатория очки технологий, казармы людей, форт укрепляет оборону, дорога ускоряет походы.</li>
  <li><b>Война.</b> Чужие земли закрыты, пока не объявлена война. Захватывайте провинции и столицы, страна без провинций выбывает. Мир можно предложить после 20 дней войны.</li>
  <li><b>Время.</b> Справа внизу: пауза, медленнее и быстрее. Пока открыта любая панель, время стоит.</li>
</ul>`;

function modalHtml(ui, clock, kind) {
  const g = ui.game;
  if (kind === 'build') {
    const tabs = `<div class="ptabs" role="tablist">${BUILD_TABS.map(([k, l]) => `<button type="button" role="tab" data-act="btab" data-arg="${k}" aria-selected="${ui.buildTab === k}">${l}</button>`).join('')}</div>`;
    return panel(tabs, buildBody(ui));
  }
  if (kind === 'tech') {
    const tabs = `<div class="ptabs" role="tablist">${TECH_BRANCHES.map(([k, l]) => `<button type="button" role="tab" data-act="ttab" data-arg="${k}" aria-selected="${ui.techTab === k}">${bico(ICONS['br_' + k] ? 'br_' + k : 'r_res')}${l}</button>`).join('')}</div>`;
    return techPanel(ui, tabs);
  }
  if (kind === 'country') {
    const tabs = `<div class="ptabs" role="tablist">${[['own', 'Страна'], ['focus', 'Фокусы'], ['doc', 'Доктрина'], ['min', 'Министры']].map(([k, l]) => `<button type="button" role="tab" data-act="ctab" data-arg="${k}" aria-selected="${ui.countryTab === k}">${l}</button>`).join('')}</div>`;
    if (ui.countryTab === 'focus') return focusPanel(ui, tabs);
    return panel(tabs, ui.countryTab === 'min' ? ministersBody(ui) : ui.countryTab === 'doc' ? doctrineBody(ui) : countryOverview(ui));
  }
  if (kind === 'event') return eventPanel(ui, clock);
  if (kind === 'dipcard') return dipCardPanel(ui);
  if (kind === 'peace') return peacePanel(ui);
  if (kind === 'peaceoffer') return peaceOfferPanel(ui, clock);
  if (kind === 'tradeoffer') return tradeOfferPanel(ui, clock);
  if (kind === 'armies') {
    const t = ui.armyTab || 'l';
    const tabs = `<div class="ptabs" role="tablist">${[['l', 'Армии'], ['h', 'Штабы']].map(([k, l]) => `<button type="button" role="tab" data-act="atab" data-arg="${k}" aria-selected="${t === k}">${l}</button>`).join('')}</div>`;
    return panel(tabs, t === 'h' ? hqBody(ui) : armiesBody(ui));
  }
  if (kind === 'diplo') { const d = diploBody(ui); return panel(d.tabs, d.body); }
  if (kind === 'journal') return panel(title('Журнал'), journalBody(ui, clock));
  if (kind === 'plague') return panel(title('Эпидемия'), plagueBody(ui));
  if (kind === 'help') return panel(title('Как играть'), HELP);
  if (kind === 'privacy') return panel(title('Конфиденциальность'), PRIVACY_TEXT);
  if (kind === 'mods') return panel(title('Моды'), modsBody(ui));
  if (kind === 'pause') {
    const au = audioCfg(), pc = (v) => (v > 0 ? Math.round(v * 100) + '%' : 'выкл');
    const rows = [['save', 'Сохранить игру'], ['snd', `Звук: ${au.on ? 'вкл' : 'выкл'}`], ['mus', `Музыка: ${pc(au.music)}`], ['fx', `Эффекты: ${pc(au.sfx)}`], ['full', 'Во весь экран / обратно'], ['help', 'Как играть'], ['tomain', 'В главное меню']]
      .map(([a, l]) => { const [h, s] = l.split(': '); return `<button type="button" class="mtile t-${a}" data-act="${a}"><span class="mg">${PAUSE_GLYPH[a] || ''}</span><b>${h}</b>${s ? `<small>${s}</small>` : ''}</button>`; }).join('');
    return panel(title('Меню'), `<div class="mgrid">${rows}</div>`, 'Продолжить');
  }
  const won = g.over && g.over.won;
  const w = g.over && g.over.winner != null ? g.countries[g.over.winner] : null;
  const text = g.over && g.over.plague ? 'Пандемия победила: болезнь не удалось ни остановить, ни удержать. Проиграли все страны.' : won ? 'Все соперники повержены.' : w ? `${w.name} подчинила весь континент.` : 'Ваша страна пала.';
  return `<div class="card"><h1 class="${won ? 'win' : 'lose'}">${won ? 'Победа' : 'Поражение'}</h1><p class="note">${text} Прошло ${g.day} дн.</p>
    <div class="mbtns"><button type="button" class="mbtn primary" data-act="newgame"><b>Новая игра</b></button><button type="button" class="mbtn" data-act="tomain"><b>В главное меню</b></button></div></div>`;
}

const EV_FALLBACK = { ev_war: 'r_war', ev_border: 'b_fort', ev_diplo: 'u_diplo', ev_politics: 'm_for', ev_crowd: 'a_call', ev_farm: 't_plains', ev_lab: 'r_res', ev_medic: 'b_lab', ev_army: 'r_troops', ev_factory: 'b_factory', ev_refugees: 'r_def', ev_oil: 'b_pump', ev_money: 'tax2' };
const EV_HEAD = { news: 'Мировые новости', letter: 'Личное письмо', report: 'Донесение', telegram: 'Телеграмма' };
// ---------- мирные переговоры ----------
function scoreBar(me, my, them, enemy) {
  return `<div class="pscore"><div class="pside"><b>${me.name}</b><div class="pbar"><i style="width:${my}%;background:${me.color}"></i></div><span>${my}</span></div><div class="pside"><b>${enemy.name}</b><div class="pbar"><i style="width:${them}%;background:${enemy.color}"></i></div><span>${them}</span></div></div>`;
}

function peacePanel(ui) {
  const g = ui.game, me = g.playerId, mc = g.countries[me], e = g.countries[ui.peaceWith];
  if (!e || !e.alive || !atWar(g, me, e.id)) return panel(title('Мирные переговоры'), '<div class="empty">Война уже окончена.</div>', 'Назад', 'diplo');
  const sM = warScore(g, me, e.id), sT = warScore(g, e.id, me);
  const term = ui.peaceTerm || 'white';
  const vas = mc.overlord == null;
  const cn = cedeCount(sM), names = pickCede(g, e.id, me, cn).map((id) => g.world.provinces.get(id).name);
  const can = (k) => vas && sM >= PEACE_TERMS[k].min && !(k === 'vassal' && e.overlord != null);
  const row = (k, ttl, desc, ok, why, cost) => `<button type="button" class="pterm ${term === k ? 'sel' : ''}" data-act="pterm" data-arg="${k}" ${ok ? '' : 'disabled'}><b>${ttl}</b><small>${ok ? desc : why}</small>${cost ? `<span class="pc">${cost}</span>` : ''}</button>`;
  const rows = row('white', 'Белый мир', 'Границы остаются как есть. Согласие врага зависит от хода войны.', true, '', pp(RULES.peacePP))
    + row('cede', `Потребовать ${cn} провинц.`, names.length ? `${names.slice(0, 8).join(', ')}${names.length > 8 ? '…' : ''}` : 'Нет подходящих провинций', can('cede') && names.length > 0, `Нужно ${PEACE_TERMS.cede.min} очков войны`, pp(RULES.peacePP * 2))
    + row('vassal', `Сделать вассалом`, `${e.name} платит четверть золота и воюет за вас.`, can('vassal'), e.overlord != null ? 'Страна уже вассал' : `Нужно ${PEACE_TERMS.vassal.min} очков войны`, pp(RULES.peacePP * 2))
    + row('tgold', 'Контрибуция деньгами', `${e.name} выплатит ${tributeText(tributeAmount(g, e.id, sM, 'gold'))}`, vas && sM >= PEACE_TERMS.tgold.min, `Нужно ${PEACE_TERMS.tgold.min} очков войны`, pp(RULES.peacePP * 2))
    + row('tres', 'Контрибуция ресурсами', `${e.name} выплатит ${tributeText(tributeAmount(g, e.id, sM, 'goods'))}`, vas && sM >= PEACE_TERMS.tgold.min, `Нужно ${PEACE_TERMS.tgold.min} очков войны`, pp(RULES.peacePP * 2))
    + (sT >= PEACE_TERMS.tgold.min ? row('givegold', 'Откупиться деньгами', `Вы заплатите ${tributeText(tributeAmount(g, me, sT, 'gold'))}. Враг согласен всегда.`, true, '', '') + row('giveres', 'Откупиться ресурсами', `Вы заплатите ${tributeText(tributeAmount(g, me, sT, 'goods'))}. Враг согласен всегда.`, true, '', '') : '')
    + (sT >= PEACE_TERMS.cede.min ? row('give', `Уступить ${concedeCount(g, me, e.id)} провинц.`, 'Враг побеждает: можно купить мир землёй, он согласен всегда.', true, '', '') : '');
  const allies = g.countries.filter((c) => c.alive && c.id !== e.id && c.id !== me && atWar(g, me, c.id) && (c.faction != null && c.faction === e.faction || c.overlord === e.id || e.overlord === c.id));
  const note = allies.length ? `<div class="item"><div class="id">Союзники врага продолжат войну с вами: ${allies.map((a) => a.name).join(', ')}.</div></div>` : '';
  const go = `<button type="button" class="btn fill pgo" data-act="pgo">Предложить условия</button>`;
  const body = `<div class="item"><div class="it">Очки войны</div>${scoreBar(mc, sM, sT, e)}</div>${rows}${note}${go}`;
  return panel(title(`Мир с ${e.name}`), body, 'Назад', 'diplo');
}

// Какие именно провинции участвуют в предложении (подсвечиваются и на карте)
function offerDetail(g, o) {
  if (o.type !== 'cede') return '';
  const ids = o.ids && o.ids.length ? o.ids : o.dir === 'give' ? pickCede(g, o.from, g.playerId, o.n) : pickCede(g, g.playerId, o.from, o.n);
  if (!ids.length) return '<div class="evlist"><b>Подходящих провинций нет</b></div>';
  const rows = ids.map((id) => { const q = prov(g, id); return `<li>${q.name} <small>${q.props.deposit ? DEPOSITS[q.props.deposit].name + ' · ' : ''}доход ${provinceIncome(q).gold.toFixed(1)}</small></li>`; }).join('');
  return `<div class="evlist"><b>${o.dir === 'give' ? 'Вы получите' : 'Вы отдадите'} (${ids.length}):</b><ul>${rows}</ul></div>`;
}

function peaceOfferPanel(ui, clock) {
  const g = ui.game, o = (g.offers || []).find((x) => x.id === ui.offerId);
  if (!o) return panel(title('Предложение'), '<div class="empty">Предложение больше не действует.</div>');
  const from = g.countries[o.from];
  const date = clock ? clock.formatDate(g.day) : '';
  const ult = o.dir === 'take';
  const paper = `<div class="evpaper letter"><div class="evhead"><span>${ult ? 'Ультиматум' : 'Дипломатическая нота'}</span><small>${date}</small></div><h2>${ult ? 'Условия мира' : 'Предложение мира'}</h2><div class="evpic emblem">${pico('u_diplo')}</div><p class="evtext">${peaceOfferText(g, o)}</p>${offerDetail(g, o)}</div>`;
  const opts = `<button type="button" class="evopt" data-act="peaceans" data-arg="${o.id}:1"><b>Принять</b></button><button type="button" class="evopt" data-act="peaceans" data-arg="${o.id}:0"><b>Отклонить</b><small>война продолжится</small></button>${o.dir === 'give' ? `<button type="button" class="evopt" data-act="peaceans" data-arg="${o.id}:2"><b>Требовать большего</b><small>открыть переговоры с ${from.name}</small></button>` : ''}`;
  return `<div class="panel evpanel" role="dialog"><div class="plist">${paper}<div class="evopts">${opts}</div></div></div>`;
}

function noticePanel(ui, clock, pe) {
  const g = ui.game, c = g.countries[pe.cid], inf = pe.info, f = FOCUSES[inf.fid] || {};
  const dft = inf.kind === 'defeat' || inf.kind === 'plague';
  const [, pic] = dft ? [0, inf.pic || 'ev_war'] : lookOf({ kind: 'minor', effect: f.act || {} });
  const art = inf.kind === 'plague' ? `<div class="evpic emblem pl">${pico(ICONS[pic] ? pic : 'r_stab')}</div>` : ICONS[pic] ? `<div class="evpic photo"><img src="${iu(pic)}" alt="" draggable="false"></div>` : `<div class="evpic emblem">${pico(EV_FALLBACK[pic])}</div>`;
  const lines = dft ? (inf.lines || []) : f.act ? describeEffect(f.act, c) : [];
  const who = inf.kind === 'plague' ? 'Эпидемия' : dft ? 'Последствия' : inf.own ? 'Ваш фокус завершён' : `${c.name}: завершён фокус`;
  const more = g.pending.length > 1 ? `<div class="evmore">Ещё уведомлений: ${g.pending.length - 1}</div>` : '';
  const paper = `<div class="evpaper news"><div class="evhead"><span>${inf.own || dft ? 'Мировые новости' : 'Мировые новости: ' + c.name}</span><small>${clock ? clock.formatDate(pe.day) : ''}</small></div><h2>${inf.title}</h2>${art}<p class="evtext">${inf.text}</p>${lines.length ? `<div class="evlist"><b>${who}:</b><ul>${lines.map((l) => `<li>${l}</li>`).join('')}</ul></div>` : ''}</div>`;
  return `<div class="panel evpanel" role="dialog"><div class="plist">${paper}<div class="evopts"><button type="button" class="evopt" data-act="evchoose" data-arg="${pe.id}:0"><b>Понятно</b></button></div>${more}</div></div>`;
}

function eventPanel(ui, clock) {
  const g = ui.game, pe = g.pending[0];
  if (!pe) return panel(title('Событие'), '<div class="empty">Нет событий.</div>');
  if (pe.info) return noticePanel(ui, clock, pe);
  const e = EVENT_BY_ID[pe.eid], c = g.countries[pe.cid];
  const opts = (e.options || []).map((o, i) => {
    if (o.show && !o.show(g, c)) return '';
    const lines = describeEffect(o.effect, c);
    const ok = canAfford(c, o.effect) && (!o.req || o.req(g, c));
    const note = ok ? '' : `<span class="bad">${o.req && !o.req(g, c) ? (o.reqText || 'Условия не выполнены') : 'Не хватает ресурсов'}</span>`;
    return `<button type="button" class="evopt" data-act="evchoose" data-arg="${pe.id}:${i}" ${ok ? '' : 'disabled'}><b>${o.text}</b>${lines.length ? `<small>${lines.join(' · ')}</small>` : ''}${note}</button>`;
  }).join('');
  const more = g.pending.length > 1 ? `<div class="evmore">Ещё событий: ${g.pending.length - 1}</div>` : '';
  const [style, pic] = lookOf(e);
  const art = ICONS[pic] ? `<div class="evpic photo"><img src="${iu(pic)}" alt="" draggable="false"></div>` : `<div class="evpic emblem">${pico(EV_FALLBACK[pic])}</div>`;
  const date = clock ? clock.formatDate(pe.day) : '';
  const paper = `<div class="evpaper ${style}"><div class="evhead"><span>${EV_HEAD[style]}</span><small>${date}</small></div><h2>${e.title}</h2>${art}<p class="evtext">${e.text}</p></div>`;
  return `<div class="panel evpanel" role="dialog"><div class="plist">${paper}<div class="evopts">${opts}</div>${more}</div></div>`;
}

function renderModal(ui, clock) {
  const el = $('modal');
  const kind = ui.modal || (ui.screen === 'game' && ui.game.over ? 'end' : null);
  el.hidden = !kind;
  if (kind) {
    const tw = el.querySelector('.treewrap');
    if (tw) ui._ts = { l: tw.scrollLeft, t: tw.scrollTop };
    setHtml(el, decoratePanel(modalHtml(ui, clock, kind), ui, kind));
    const nw = el.querySelector('.treewrap');
    if (nw && ui._ts) { nw.scrollLeft = ui._ts.l; nw.scrollTop = ui._ts.t; }
  }
}

