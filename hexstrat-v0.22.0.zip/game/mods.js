// Моды HexaCore RM: наборы данных в JSON (без кода). Формат описан в MODDING.md.
// Мод проверяется (validateMod) и накладывается на данные игры один раз при запуске (applyMods);
// после смены списка модов страница перезагружается, поэтому исходные данные восстанавливать не нужно.
import { TECHS, TECH_BRANCHES, FOCUSES, FOCUS_TREES, BUILDINGS, RULES } from './data.js';
import { EVENTS } from './events_data.js';
import { rebuildEvents } from './events.js';
import { ICONS } from './icons.js';
import { PLAGUE, PLAGUE_DEFAULTS, WHEN_KEYS } from './plague_core.js';
import { initPlague } from './plague.js'; // подключает ход эпидемии (hooks.plague)
void initPlague;

const KEY = 'hexarchy.mods.v1';
export const MOD_API = 1;
const MAX_BYTES = 3 * 1024 * 1024;
const ID_RE = /^[a-z0-9_]{2,40}$/;
const BAD = new Set(['__proto__', 'constructor', 'prototype']);
// ключи множителей (как MOD_BASE в state.js) и разовых наград
const MOD_KEYS = ['gold', 'men', 'res', 'ind', 'fuel', 'pp', 'attack', 'defense', 'speed', 'recruit', 'upkeep', 'build', 'war', 'loot', 'fuelUse', 'stab', 'wthr', 'ctl'];
const INSTANT_KEYS = ['gold', 'men', 'ind', 'fuel', 'res', 'pp'];
// последствия событий: только данные, без fn
const EFFECT_NUM = ['gold', 'goldD', 'men', 'menD', 'pp', 'res', 'ind', 'fuel', 'stab', 'tension'];
const EFFECT_STR_LIST = ['flags', 'clear', 'war', 'peace', 'guar'];

const isObj = (v) => v && typeof v === 'object' && !Array.isArray(v);
const isNum = (v) => typeof v === 'number' && Number.isFinite(v);
const isStr = (v, max = 400) => typeof v === 'string' && v.length > 0 && v.length <= max;

function safeKeys(o, where, err) {
  for (const k of Object.keys(o)) if (BAD.has(k)) { err(`${where}: недопустимое имя «${k}»`); return false; }
  return true;
}

function checkMods(m, where, err, keys = MOD_KEYS) {
  if (!isObj(m)) { err(`${where}: нужен объект`); return false; }
  let ok = safeKeys(m, where, err);
  for (const [k, v] of Object.entries(m)) {
    if (!keys.includes(k)) { err(`${where}: неизвестный параметр «${k}»`); ok = false; } else if (!isNum(v) || Math.abs(v) > 10) { err(`${where}.${k}: число от −10 до 10`); ok = false; }
  }
  return ok;
}

function checkEffect(e, where, err) {
  if (!isObj(e)) { err(`${where}: нужен объект`); return false; }
  let ok = safeKeys(e, where, err);
  for (const [k, v] of Object.entries(e)) {
    if (EFFECT_NUM.includes(k)) { if (!isNum(v) || Math.abs(v) > 5000) { err(`${where}.${k}: число`); ok = false; } }
    else if (EFFECT_STR_LIST.includes(k)) { if (!Array.isArray(v) || v.length > 12 || !v.every((x) => isStr(x, 60))) { err(`${where}.${k}: список строк`); ok = false; } }
    else if (k === 'mod') {
      if (!isObj(v) || !(v.days == null || (isNum(v.days) && v.days > 0 && v.days <= 3650))) { err(`${where}.mod: объект, days от 1 до 3650`); ok = false; }
      else { const { name, days, ...rest } = v; if (name != null && !isStr(name, 60)) { err(`${where}.mod.name: строка`); ok = false; } if (!checkMods(rest, `${where}.mod`, err)) ok = false; }
    } else if (k === 'rel') {
      if (!Array.isArray(v) || v.length > 12 || !v.every((x) => Array.isArray(x) && isStr(x[0], 60) && isNum(x[1]) && Math.abs(x[1]) <= 100)) { err(`${where}.rel: список пар [страна, число]`); ok = false; }
    } else if (k === 'plague') {
      if (!isObj(v) || !Object.entries(v).every(([kk, vv]) => ['inf', 'vaccine'].includes(kk) && isNum(vv) && Math.abs(vv) <= 100)) { err(`${where}.plague: объект с числами inf и vaccine (от −100 до 100)`); ok = false; }
    } else if (k === 'note') { if (!isStr(v, 200)) { err(`${where}.note: строка`); ok = false; } }
    else { err(`${where}: «${k}» в модах не поддерживается`); ok = false; }
  }
  return ok;
}

function dataUri(s) { return typeof s === 'string' && /^data:image\/(png|webp|jpeg);base64,[A-Za-z0-9+/=]+$/.test(s) && s.length <= 300000; }

// Проверка структуры; ничего не меняет. Возвращает { ok, errors, warnings }.
export function validateMod(mod, taken = {}) {
  const errors = [], warnings = [];
  const err = (m) => errors.push(m), warn = (m) => warnings.push(m);
  if (!isObj(mod)) return { ok: false, errors: ['Файл должен содержать объект JSON'], warnings };
  if (!isStr(mod.id, 40) || !ID_RE.test(mod.id)) err('id: латинские буквы, цифры и «_», 2–40 знаков');
  if (!isStr(mod.name, 60)) err('name: название мода (строка до 60 знаков)');
  if (mod.version != null && !isStr(mod.version, 20)) err('version: строка');
  if (mod.api != null && mod.api !== MOD_API) err(`api: игра поддерживает формат ${MOD_API}, а в моде ${mod.api}`);
  for (const k of Object.keys(mod)) if (!['id', 'name', 'version', 'author', 'desc', 'api', 'add', 'patch', 'remove', 'systems'].includes(k)) warn(`лишнее поле «${k}» игнорируется`);
  if (errors.length) return { ok: false, errors, warnings };
  const add = mod.add || {}, patch = mod.patch || {}, remove = mod.remove || {};
  if (!isObj(add) || !isObj(patch) || !isObj(remove)) return { ok: false, errors: ['add, patch, remove: объекты'], warnings };

  // id, которые есть или появятся (для проверки ссылок)
  const techIds = new Set([...Object.keys(TECHS), ...Object.keys(add.techs || {})]);
  const focusIds = new Set([...Object.keys(FOCUSES), ...Object.keys(add.focuses || {})]);
  const takenT = taken.techs || new Set(), takenF = taken.focuses || new Set(), takenE = taken.events || new Set();
  // own — id, которые уже внесла прежняя версия этого же мода (при повторной загрузке)
  const own = taken.own || { techs: new Set(), focuses: new Set(), events: new Set() };
  for (const t of remove.techs || []) techIds.delete(t);
  for (const f of remove.focuses || []) focusIds.delete(f);

  // --- add.techs
  if (add.techs != null) {
    if (!isObj(add.techs)) err('add.techs: объект {id: технология}'); else {
      for (const [id, t] of Object.entries(add.techs)) {
        const w = `techs.${id}`;
        if (!ID_RE.test(id)) { err(`${w}: недопустимый id`); continue; }
        if ((TECHS[id] && !own.techs.has(id)) || takenT.has(id)) { err(`${w}: такой id уже занят (другим модом или игрой)`); continue; }
        if (!isObj(t)) { err(`${w}: нужен объект`); continue; }
        if (!TECH_BRANCHES.some(([k]) => k === t.branch)) err(`${w}.branch: одна из ${TECH_BRANCHES.map(([k]) => k).join(', ')}`);
        if (!Number.isInteger(t.tier) || t.tier < 1 || t.tier > 6) err(`${w}.tier: целое от 1 до 6`);
        if (!isStr(t.name, 60)) err(`${w}.name: строка`);
        if (!isStr(t.desc, 200)) err(`${w}.desc: строка`);
        if (t.req != null && (!Array.isArray(t.req) || !t.req.every((r) => techIds.has(r)))) err(`${w}.req: список id существующих технологий`);
        checkMods(t.effect, `${w}.effect`, err);
        if (t.cost != null && !(isNum(t.cost) && t.cost > 0 && t.cost <= 1e5)) err(`${w}.cost: положительное число`);
        if (t.days != null && !(isNum(t.days) && t.days > 0 && t.days <= 3650)) err(`${w}.days: от 1 до 3650`);
      }
    }
  }
  // --- add.focuses
  if (add.focuses != null) {
    if (!isObj(add.focuses)) err('add.focuses: объект {id: фокус}'); else {
      for (const [id, f] of Object.entries(add.focuses)) {
        const w = `focuses.${id}`;
        if (!ID_RE.test(id)) { err(`${w}: недопустимый id`); continue; }
        if ((FOCUSES[id] && !own.focuses.has(id)) || takenF.has(id)) { err(`${w}: такой id уже занят`); continue; }
        if (!isObj(f)) { err(`${w}: нужен объект`); continue; }
        if (!isStr(f.name, 60)) err(`${w}.name: строка`);
        if (!isStr(f.desc, 200)) err(`${w}.desc: строка`);
        if (!(isNum(f.cost) && f.cost >= 0 && f.cost <= 1000)) err(`${w}.cost: власть, число 0–1000`);
        if (!(isNum(f.days) && f.days > 0 && f.days <= 3650)) err(`${w}.days: от 1 до 3650`);
        if (f.req != null && (!Array.isArray(f.req) || !f.req.every((r) => focusIds.has(r)))) err(`${w}.req: список id существующих фокусов`);
        checkMods(f.effect || {}, `${w}.effect`, err);
        if (f.instant != null) { if (!isObj(f.instant) || !Object.entries(f.instant).every(([k, v]) => INSTANT_KEYS.includes(k) && isNum(v) && Math.abs(v) <= 5000)) err(`${w}.instant: разовая награда, ключи ${INSTANT_KEYS.join(', ')}, числа до 5000`); }
        if (f.act != null) checkEffect(f.act, `${w}.act`, err);
        if (f.icon != null && !(typeof f.icon === 'string' && ID_RE.test(f.icon) && (ICONS[f.icon] || (add.icons && add.icons[f.icon])))) err(`${w}.icon: имя иконки из add.icons или из игры`);
      }
    }
  }
  // --- add.focusTrees
  if (add.focusTrees != null) {
    if (!isObj(add.focusTrees)) err('add.focusTrees: объект {страна или "*": [id фокусов]}'); else {
      for (const [k, list] of Object.entries(add.focusTrees)) {
        if (k !== '@all' && !FOCUS_TREES[k]) { warn(`focusTrees.${k}: у такой страны нет дерева фокусов, пропущено`); continue; }
        if (!Array.isArray(list) || !list.every((id) => focusIds.has(id))) err(`focusTrees.${k}: список id существующих фокусов`);
      }
    }
  }
  // --- add.events
  if (add.events != null) {
    if (!Array.isArray(add.events)) err('add.events: список событий'); else {
      const seen = new Set();
      add.events.forEach((e, i) => {
        const w = `events[${i}]`;
        if (!isObj(e)) { err(`${w}: нужен объект`); return; }
        if (!isStr(e.id, 40) || !ID_RE.test(e.id)) { err(`${w}.id: латиница, цифры, «_»`); return; }
        if (seen.has(e.id) || takenE.has(e.id) || EVENTS.some((x) => x.id === e.id && !own.events.has(e.id))) { err(`${w}: id «${e.id}» уже занят`); return; }
        seen.add(e.id);
        if (!isStr(e.title, 80)) err(`${w}.title: строка`);
        if (!isStr(e.text, 600)) err(`${w}.text: строка`);
        const hist = e.date != null;
        if (hist) {
          if (!Array.isArray(e.date) || e.date.length !== 3 || !e.date.every(Number.isInteger) || e.date[0] < 1900 || e.date[0] > 2100) err(`${w}.date: [год, месяц, день]`);
          if (!Array.isArray(e.countries) || !e.countries.length || !e.countries.every((c) => isStr(c, 60))) err(`${w}.countries: названия стран`);
          if (e.window != null && !(Number.isInteger(e.window) && e.window > 0 && e.window <= 3650)) err(`${w}.window: дни`);
        } else if (!(isNum(e.p) && e.p > 0 && e.p <= 0.05)) err(`${w}: нужна либо date+countries, либо шанс p в день (0–0.05)`);
        if (e.scenario != null && !isStr(e.scenario, 40)) err(`${w}.scenario: строка`);
        if (e.kind === 'minor') checkEffect(e.effect, `${w}.effect`, err);
        else if (e.kind != null) err(`${w}.kind: только «minor» или не указывать`);
        else if (!Array.isArray(e.options) || e.options.length < 1 || e.options.length > 4) err(`${w}.options: от 1 до 4 вариантов`);
        else e.options.forEach((o, j) => {
          if (!isObj(o) || !isStr(o.text, 160)) { err(`${w}.options[${j}].text: строка`); return; }
          if (o.short != null && !isStr(o.short, 160)) err(`${w}.options[${j}].short: строка`);
          if (o.ai != null && !(isNum(o.ai) && o.ai >= 0 && o.ai <= 100)) err(`${w}.options[${j}].ai: число 0–100`);
          checkEffect(o.effect || {}, `${w}.options[${j}].effect`, err);
        });
        if (e.when != null) {
          if (!isObj(e.when) || !Object.entries(e.when).every(([kk, vv]) => WHEN_KEYS.includes(kk) && isNum(vv))) err(`${w}.when: условия ${WHEN_KEYS.join(', ')} (числа)`);
        }
        for (const k of Object.keys(e)) if (!['id', 'title', 'text', 'date', 'countries', 'window', 'p', 'scenario', 'kind', 'effect', 'options', 'look', 'when'].includes(k)) warn(`${w}: поле «${k}» игнорируется`);
      });
    }
  }
  // --- add.icons
  if (add.icons != null) {
    if (!isObj(add.icons)) err('add.icons: объект {имя: data-URI}'); else {
      for (const [k, v] of Object.entries(add.icons)) {
        if (!ID_RE.test(k)) err(`icons.${k}: недопустимое имя`);
        else if (!dataUri(v)) err(`icons.${k}: нужна картинка data:image/png|webp|jpeg;base64,… до 300 КБ`);
        else if (ICONS[k] && !taken.icons?.has(k)) warn(`icons.${k}: заменяет существующую иконку`);
      }
    }
  }
  // --- systems
  if (mod.systems != null) {
    if (!isObj(mod.systems)) err('systems: объект'); else {
      for (const k of Object.keys(mod.systems)) if (k !== 'plague') warn(`systems.${k}: неизвестная система, игнорируется`);
      const pl = mod.systems.plague;
      if (pl != null) {
        if (!isObj(pl)) err('systems.plague: объект'); else {
          for (const [k, v] of Object.entries(pl)) {
            const d = PLAGUE_DEFAULTS[k];
            if (BAD.has(k) || d === undefined) { err(`systems.plague.${k}: нет такой настройки`); continue; }
            if (typeof d === 'number') { if (!isNum(v) || Math.abs(v) > 100000) err(`systems.plague.${k}: число`); }
            else if (typeof d === 'string') { if (!isStr(v, 40)) err(`systems.plague.${k}: строка`); }
            else if (Array.isArray(d)) { if (!Array.isArray(v) || v.length !== d.length || !v.every(isNum)) err(`systems.plague.${k}: список из ${d.length} чисел`); }
            else if (isObj(d)) { if (!isObj(v) || !Object.entries(v).every(([kk, vv]) => kk in d && isNum(vv))) err(`systems.plague.${k}: объект с числами (${Object.keys(d).join(', ')})`); }
          }
        }
      }
    }
  }
  // --- patch
  if (patch.rules != null) {
    if (!isObj(patch.rules)) err('patch.rules: объект'); else {
      for (const [k, v] of Object.entries(patch.rules)) {
        const cur = RULES[k];
        if (cur === undefined || BAD.has(k)) err(`rules.${k}: такого правила нет`);
        else if (typeof cur === 'number' ? !isNum(v) : Array.isArray(cur) ? !(Array.isArray(v) && v.length === cur.length && v.every((x, i) => typeof x === typeof cur[i] && (typeof x !== 'number' || isNum(x)))) : true) err(`rules.${k}: значение должно быть того же вида, что и сейчас (число или список той же длины)`);
      }
    }
  }
  for (const [grp, src] of [['techs', TECHS], ['focuses', FOCUSES], ['buildings', BUILDINGS]]) {
    const pt = patch[grp];
    if (pt == null) continue;
    if (!isObj(pt)) { err(`patch.${grp}: объект`); continue; }
    for (const [id, f] of Object.entries(pt)) {
      const w = `patch.${grp}.${id}`;
      if (BAD.has(id) || !(src[id] || (grp === 'techs' ? add.techs : grp === 'focuses' ? add.focuses : null)?.[id])) { err(`${w}: такого элемента нет`); continue; }
      if (!isObj(f) || safeKeys(f, w, err) === false) { err(`${w}: нужен объект`); continue; }
      for (const [k, v] of Object.entries(f)) {
        if (k === 'effect') checkMods(v, `${w}.effect`, err, grp === 'buildings' ? ['goldMul', 'goldAdd', 'menAdd', 'defAdd', 'moveMul', 'indAdd', 'resAdd', 'fuelMul'] : MOD_KEYS);
        else if (['name', 'desc'].includes(k)) { if (!isStr(v, 200)) err(`${w}.${k}: строка`); }
        else if (['cost', 'days', 'ind', 'max'].includes(k)) { if (!(isNum(v) && v >= 0 && v <= 1e5)) err(`${w}.${k}: число`); }
        else if (k === 'req' && grp !== 'buildings') { if (!Array.isArray(v) || !v.every((r) => (grp === 'techs' ? techIds : focusIds).has(r))) err(`${w}.req: список существующих id`); }
        else err(`${w}: поле «${k}» менять нельзя`);
      }
    }
  }
  // --- remove
  for (const [grp, src, extra] of [['techs', TECHS, add.techs], ['focuses', FOCUSES, add.focuses]]) {
    const rm = remove[grp];
    if (rm == null) continue;
    if (!Array.isArray(rm) || !rm.every((id) => isStr(id, 60) && !BAD.has(id))) { err(`remove.${grp}: список id`); continue; }
    for (const id of rm) if (!src[id] && !extra?.[id]) warn(`remove.${grp}: «${id}» не найден`);
  }
  if (remove.events != null && (!Array.isArray(remove.events) || !remove.events.every((id) => isStr(id, 60)))) err('remove.events: список id');
  return { ok: errors.length === 0, errors, warnings };
}

// Накладывает мод на данные игры. Мод уже проверен.
export function applyMod(mod, ctx) {
  const add = mod.add || {}, patch = mod.patch || {}, remove = mod.remove || {};
  const tCost = [180, 320, 580, 900, 1300, 1800], tDays = [30, 40, 55, 75, 95, 120];
  // сначала удаление: потом то, что добавляет мод, не затрагивается
  for (const id of remove.techs || []) {
    delete TECHS[id];
    for (const t of Object.values(TECHS)) if (t.req) t.req = t.req.filter((r) => r !== id);
  }
  for (const id of remove.focuses || []) {
    delete FOCUSES[id];
    for (const list of Object.values(FOCUS_TREES)) { const i = list.indexOf(id); if (i >= 0) list.splice(i, 1); }
    for (const f of Object.values(FOCUSES)) { if (f.req) f.req = f.req.filter((r) => r !== id); if (f.excl) f.excl = f.excl.filter((r) => r !== id); }
  }
  if (remove.events && remove.events.length) { const rm = new Set(remove.events); for (let i = EVENTS.length - 1; i >= 0; i--) if (rm.has(EVENTS[i].id)) EVENTS.splice(i, 1); }
  for (const [id, t] of Object.entries(add.techs || {})) {
    TECHS[id] = { branch: t.branch, tier: t.tier, name: t.name, desc: t.desc, req: [...(t.req || [])], effect: { ...t.effect }, cost: t.cost ?? tCost[t.tier - 1], days: t.days ?? tDays[t.tier - 1], mod: mod.id };
    ctx.techs.add(id);
  }
  for (const [id, f] of Object.entries(add.focuses || {})) {
    FOCUSES[id] = { name: f.name, desc: f.desc, cost: f.cost, days: f.days, req: [...(f.req || [])], effect: { ...(f.effect || {}) }, instant: f.instant ? { ...f.instant } : null, icon: f.icon || null, mod: mod.id };
    if (f.act) { FOCUSES[id].act = JSON.parse(JSON.stringify(f.act)); if (Object.keys(f.act).some((k) => k !== 'plague')) { FOCUSES[id].alt = true; FOCUSES[id].excl = []; } }
    ctx.focuses.add(id);
  }
  for (const [k, list] of Object.entries(add.focusTrees || {})) {
    for (const key of k === '@all' ? Object.keys(FOCUS_TREES) : FOCUS_TREES[k] ? [k] : []) for (const id of list) if (!FOCUS_TREES[key].includes(id)) FOCUS_TREES[key].push(id);
  }
  if (mod.systems && mod.systems.plague) PLAGUE.cfg = { ...PLAGUE_DEFAULTS, ...JSON.parse(JSON.stringify(mod.systems.plague)), eff: { ...PLAGUE_DEFAULTS.eff, ...((mod.systems.plague.eff) || {}) } };
  for (const e of add.events || []) { EVENTS.push({ ...JSON.parse(JSON.stringify(e)), mod: mod.id }); ctx.events.add(e.id); }
  for (const [k, v] of Object.entries(add.icons || {})) { ICONS[k] = v; ctx.icons.add(k); }
  for (const [k, v] of Object.entries(patch.rules || {})) RULES[k] = Array.isArray(v) ? [...v] : v;
  for (const [grp, src] of [['techs', TECHS], ['focuses', FOCUSES], ['buildings', BUILDINGS]]) {
    for (const [id, f] of Object.entries(patch[grp] || {})) {
      if (!src[id]) continue;
      for (const [k, v] of Object.entries(f)) src[id][k] = k === 'effect' ? { ...src[id].effect, ...v } : Array.isArray(v) ? [...v] : v;
    }
  }
}

// ---------- хранилище и активный набор ----------
let stored = [];         // [{ mod, on }]
export const activeMods = []; // [{ id, name, version }]
export const modReport = [];  // [{ id, name, status: 'on'|'off'|'error', errors, warnings }]

function readStore() {
  try { const raw = localStorage.getItem(KEY); const a = raw ? JSON.parse(raw) : []; return Array.isArray(a) ? a.filter((x) => x && isObj(x.mod) && x.mod.id) : []; } catch (_) { return []; }
}
function writeStore() {
  try { localStorage.setItem(KEY, JSON.stringify(stored)); return true; } catch (_) { return false; }
}

// Применяет включённые моды по порядку. Вызывается один раз до создания партии.
export function applyMods(list = readStore()) {
  stored = list;
  const ctx = { techs: new Set(), focuses: new Set(), events: new Set(), icons: new Set() };
  activeMods.length = 0; modReport.length = 0;
  PLAGUE.cfg = null;
  for (const { mod, on } of list) {
    const rep = { id: mod.id, name: mod.name || mod.id, version: mod.version || '', on: !!on, status: on ? 'on' : 'off', errors: [], warnings: [] };
    if (on) {
      const v = validateMod(mod, ctx);
      rep.errors = v.errors; rep.warnings = v.warnings;
      if (!v.ok) rep.status = 'error';
      else {
        try { applyMod(mod, ctx); activeMods.push({ id: mod.id, name: mod.name, version: mod.version || '' }); } catch (e) { rep.status = 'error'; rep.errors.push('Ошибка при применении: ' + e.message); }
      }
    }
    modReport.push(rep);
  }
  if (activeMods.length) rebuildEvents();
  return modReport;
}

export const storedMods = () => stored.map((s) => ({ ...s }));
export const modsSignature = () => activeMods.map((m) => `${m.id}@${m.version}`).join(',');

// Разбор загруженного текста. Возвращает { ok, msg } и при успехе сохраняет мод (выключенным не добавляет — сразу включён).
export function importMod(text) {
  if (typeof text !== 'string' || text.length > MAX_BYTES) return { ok: false, msg: 'Файл пустой или больше 3 МБ' };
  let mod;
  try { mod = JSON.parse(text); } catch (e) { return { ok: false, msg: 'Это не JSON: ' + e.message }; }
  // проверка в чистом контексте: сравниваем с данными игры, а не с другими модами
  const prev = isObj(mod) ? stored.find((x) => x.mod.id === mod.id) : null, pa = (prev && prev.mod.add) || {};
  const own = { techs: new Set(Object.keys(pa.techs || {})), focuses: new Set(Object.keys(pa.focuses || {})), events: new Set((pa.events || []).map((e) => e && e.id)) };
  const v = validateMod(mod, { techs: new Set(), focuses: new Set(), events: new Set(), icons: new Set(), own });
  if (!v.ok) {
    return { ok: false, msg: v.errors.slice(0, 6).join('\n') + (v.errors.length > 6 ? `\n…ещё ${v.errors.length - 6}` : '') };
  }
  const i = stored.findIndex((s) => s.mod.id === mod.id);
  if (i >= 0) stored[i] = { mod, on: true }; else stored.push({ mod, on: true });
  if (!writeStore()) return { ok: false, msg: 'Не удалось сохранить: хранилище браузера заполнено или недоступно' };
  return { ok: true, msg: `Мод «${mod.name}» добавлен${v.warnings.length ? '. Замечания: ' + v.warnings.join('; ') : ''}`, id: mod.id };
}
export function setModOn(id, on) { const s = stored.find((x) => x.mod.id === id); if (s) { s.on = !!on; writeStore(); } }
export function moveMod(id, dir) { const i = stored.findIndex((x) => x.mod.id === id), j = i + dir; if (i < 0 || j < 0 || j >= stored.length) return; [stored[i], stored[j]] = [stored[j], stored[i]]; writeStore(); }
export function removeMod(id) { const i = stored.findIndex((x) => x.mod.id === id); if (i >= 0) { stored.splice(i, 1); writeStore(); } }
