// Флаги стран: ключ — название страны. У Испании флаг зависит от режима (республика / националисты).
import { FLAG_DATA as BASE_FLAGS } from './flags_data.js';

// Страны, возникающие только в сценариях 1939 и 1941 (Словакия): флаг нарисован здесь
const SK_SVG = "<svg xmlns='http://www.w3.org/2000/svg' width='64' height='40'><rect width='64' height='14' fill='#fff'/><rect y='13' width='64' height='14' fill='#0b4ea2'/><rect y='26' width='64' height='14' fill='#ee1c25'/><path d='M13 7h16v14c0 7-8 10-8 10s-8-3-8-10z' fill='#ee1c25' stroke='#fff' stroke-width='1.2'/><path d='M21 11v15M17 15h8M18 19.5h6' stroke='#fff' stroke-width='2'/></svg>";
const FLAG_DATA = { ...BASE_FLAGS, 'Словакия': 'data:image/svg+xml,' + encodeURIComponent(SK_SVG) };

export function flagKey(c) {
  if (!c) return null;
  if (c.name === 'Испания' && c.ideo === 'fas') return 'Испания_нац';
  return FLAG_DATA[c.name] ? c.name : c.base && FLAG_DATA[c.base] ? c.base : null;
}
export function flagSrc(c) { const k = flagKey(c); return k ? FLAG_DATA[k] : null; }

const imgs = new Map();
export function flagImg(c) {
  const k = flagKey(c);
  if (!k || typeof Image === 'undefined') return null;
  let im = imgs.get(k);
  if (!im) { im = new Image(); im.src = FLAG_DATA[k]; imgs.set(k, im);
    im.onload = () => window.dispatchEvent(new Event('resize')); }
  return im.complete && im.naturalWidth ? im : null;
}

// Флаг на canvas; пока картинка не готова (или флага нет) — цвет страны.
export function drawFlag(ctx, c, x, y, w, h) {
  const im = flagImg(c);
  if (im) ctx.drawImage(im, x, y, w, h);
  else { ctx.fillStyle = c.color; ctx.fillRect(x, y, w, h); }
  ctx.strokeStyle = 'rgba(0,0,0,0.85)'; ctx.lineWidth = 1; ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
}
