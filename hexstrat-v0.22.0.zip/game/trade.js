// Торговля: сделки «товар за золото» между странами. Продавец каждый день отдаёт amt единиц товара,
// покупатель платит amt × price золота. Война, гибель страны, вражда и простой рвут сделку.
import { RULES, TRADE_GOODS, TRADE_SIZES } from './data.js';
import { atWar, opinion, addRel, emit, hooks, inAnyWar, economyPreview } from './state.js';

const fail = (msg) => ({ ok: false, msg });
const name = (g, id) => g.countries[id].name;
const r1 = (x) => Math.round(x * 10) / 10;

export const dealsOf = (g, id) => (g.trade || []).filter((d) => d.from === id || d.to === id);
export const dealBetween = (g, a, b) => (g.trade || []).filter((d) => (d.from === a && d.to === b) || (d.from === b && d.to === a));
export const tradePartners = (g, a, b) => (g.trade || []).some((d) => (d.from === a && d.to === b) || (d.from === b && d.to === a));
export const stockOf = (g, id, good) => g.countries[id][TRADE_GOODS[good].key];
export const dealCost = (d) => d.amt * d.price;

// Размер поставки: доля дневного дохода продавца (не меньше 0.1 в день).
export function dealAmount(g, seller, good, size) {
  const sh = (TRADE_SIZES.find((s) => s[0] === size) || TRADE_SIZES[1])[2];
  const inc = Math.max(0, g.countries[seller].income[TRADE_GOODS[good].inc] || 0);
  return Math.max(0.1, r1(inc * sh));
}

// Цена за единицу: от базовой, дружба удешевляет (до −15%), вражда удорожает (до +30%).
export function dealPrice(g, seller, buyer, good) {
  const op = Math.max(-50, Math.min(100, opinion(g, seller, buyer)));
  return Math.round(TRADE_GOODS[good].price * (1.15 - 0.3 * op / 100) * 100) / 100;
}

export function canTrade(g, a, b) {
  const ca = g.countries[a], cb = g.countries[b];
  if (a === b || !ca.alive || !cb.alive) return fail('Нельзя');
  if (atWar(g, a, b)) return fail('С воюющими странами не торгуют');
  if (Math.min(opinion(g, a, b), opinion(g, b, a)) < RULES.tradeMinOp) return fail('Отношения слишком плохие');
  return { ok: true };
}

const slotsUsed = (g, id) => dealsOf(g, id).length;

// Проверка сделки со стороны ИИ-участника. who — страна, которую спрашиваем.
export function aiWilling(g, who, d) {
  const c = g.countries[who], G = TRADE_GOODS[d.good];
  const other = who === d.from ? d.to : d.from;
  if (opinion(g, who, other) < RULES.tradeAiOp) return fail(`${c.name}: не хотят торговать с вами`);
  if (slotsUsed(g, who) >= RULES.tradeSlots) return fail('У них нет свободных торговых слотов');
  if (who === d.from) {
    const keep = d.amt * (inAnyWar(g, who) ? RULES.tradeKeepWar : RULES.tradeKeep);
    if (c[G.key] < keep) return fail(`${c.name}: нет излишков, продавать нечего`);
  } else {
    if (c.gold < dealCost(d) * 25) return fail(`${c.name}: не хватает денег`);
    if (c[G.key] >= G.cap) return fail(`${c.name}: товар не нужен, склады полны`);
  }
  return { ok: true };
}

function sign(g, d) {
  const deal = { id: g.nextDealId++, day: g.day, until: g.day + RULES.tradeDays, last: 0, moved: 0, miss: 0, ...d };
  g.trade.push(deal);
  addRel(g, d.from, d.to, 4); addRel(g, d.to, d.from, 4);
  economyPreview(g);
  return deal;
}

// Игрок предлагает сделку. dir: 'buy' (игрок покупает) или 'sell' (игрок продаёт).
export function proposeTrade(g, me, other, good, dir, size) {
  if (!TRADE_GOODS[good]) return fail('Нет такого товара');
  const can = canTrade(g, me, other);
  if (!can.ok) return can;
  const c = g.countries[me];
  const seller = dir === 'buy' ? other : me, buyer = dir === 'buy' ? me : other;
  if (g.trade.some((d) => d.from === seller && d.to === buyer && d.good === good)) return fail('Такая сделка уже есть');
  if (slotsUsed(g, me) >= RULES.tradeSlots) return fail(`Не больше ${RULES.tradeSlots} сделок`);
  if (c.pp < RULES.tradePP) return fail(`Не хватает политической власти: нужно ${RULES.tradePP}`);
  const amt = dealAmount(g, seller, good, size);
  const d = { from: seller, to: buyer, good, amt, price: dealPrice(g, seller, buyer, good) };
  if (g.countries[buyer].gold < dealCost(d) * 5) return fail(buyer === me ? 'Не хватает золота для закупки' : `${name(g, buyer)}: не хватает денег`);
  if (dir === 'sell' && c[TRADE_GOODS[good].key] < amt * RULES.tradeKeep) return fail(`На складе мало: нужно хотя бы ${r1(amt * RULES.tradeKeep)} запаса`);
  const w = aiWilling(g, other, d);
  if (!w.ok) { addRel(g, other, me, -1); return w; }
  c.pp -= RULES.tradePP;
  sign(g, d);
  emit(g, `${name(g, seller)} продаёт ${TRADE_GOODS[good].name.toLowerCase()} стране ${name(g, buyer)}`, [seller, buyer], 'alliance');
  return { ok: true, msg: 'Сделка заключена' };
}

export function cancelDeal(g, me, id) {
  const d = (g.trade || []).find((x) => x.id === id && (x.from === me || x.to === me));
  if (!d) return fail('Сделки нет');
  g.trade = g.trade.filter((x) => x !== d);
  const other = d.from === me ? d.to : d.from;
  addRel(g, other, me, -3);
  economyPreview(g);
  return { ok: true, msg: 'Сделка расторгнута' };
}

// Игрок отвечает на предложение ИИ (kind: 'trade').
export function respondTrade(g, o, accept) {
  const me = g.playerId;
  if (!accept) { addRel(g, me, o.from, -1); return { ok: true, msg: 'Отклонено' }; }
  const d = o.deal;
  const can = canTrade(g, d.from, d.to);
  if (!can.ok) return can;
  if (slotsUsed(g, me) >= RULES.tradeSlots) return fail(`Не больше ${RULES.tradeSlots} сделок`);
  if (g.trade.some((x) => x.from === d.from && x.to === d.to && x.good === d.good)) return fail('Такая сделка уже есть');
  if (g.countries[d.to].gold < dealCost(d) * 5) return fail('Не хватает золота');
  if (g.countries[d.from][TRADE_GOODS[d.good].key] < d.amt * RULES.tradeKeep) return fail('На складе мало товара');
  sign(g, { ...d });
  return { ok: true, msg: 'Сделка заключена' };
}

export function tradeOfferText(g, o) {
  const d = o.deal, G = TRADE_GOODS[d.good];
  const me = g.playerId;
  return d.from === o.from
    ? `${name(g, o.from)} предлагает продавать вам ${G.name.toLowerCase()}: ${d.amt}/день по ${d.price} зол. (${r1(dealCost(d))} зол./день)`
    : `${name(g, o.from)} хочет покупать ваше ${G.name.toLowerCase()}: ${d.amt}/день по ${d.price} зол. (+${r1(dealCost(d))} зол./день)`;
}

// Сумма торговли страны за день: золото и товары (по последним поставкам).
export function tradeBalance(g, id) {
  const b = { gold: 0, fuel: 0, ind: 0, res: 0 };
  for (const d of g.trade || []) {
    const gold = d.last * d.price;
    if (d.from === id) { b.gold += gold; b[d.good] -= d.last; }
    if (d.to === id) { b.gold -= gold; b[d.good] += d.last; }
  }
  return b;
}

// Ежедневный расчёт: после экономики.
hooks.trade = (g) => {
  if (!g.trade || !g.trade.length) return;
  const keep = [];
  for (const d of g.trade) {
    const s = g.countries[d.from], b = g.countries[d.to], G = TRADE_GOODS[d.good];
    const human = d.from === g.playerId || d.to === g.playerId;
    const end = (why, rel = 0) => {
      if (rel) { addRel(g, d.from, d.to, rel); addRel(g, d.to, d.from, rel); }
      if (human) emit(g, `Торговля ${s.name} → ${b.name} (${G.name.toLowerCase()}) прекращена: ${why}`, [d.from, d.to], 'info');
    };
    if (!s.alive || !b.alive) continue;
    if (atWar(g, d.from, d.to)) { end('война'); continue; }
    if (g.day >= d.until) { end('срок вышел'); continue; }
    if (Math.min(opinion(g, d.from, d.to), opinion(g, d.to, d.from)) < RULES.tradeMinOp - 25) { end('отношения испортились'); continue; }
    const qty = Math.min(d.amt, s[G.key], b.gold / d.price);
    d.last = qty > 0 ? qty : 0;
    if (qty <= 1e-6) {
      d.last = 0;
      if (++d.miss >= RULES.tradeMiss) { end(b.gold < d.price * d.amt ? 'нечем платить' : 'нечего поставлять', -2); continue; }
      keep.push(d); continue;
    }
    d.miss = 0;
    s[G.key] -= qty; b[G.key] += qty;
    const pay = qty * d.price;
    b.gold -= pay; s.gold += pay;
    d.moved += qty;
    keep.push(d);
  }
  g.trade = keep;
};

// ---------- ИИ ----------
// Раз в какое-то время страна ИИ ищет, что продать из излишков или где докупить нехватку.
export function aiTrade(g, c) {
  if (g.day < 30 || g.rng() > 0.05) return;
  if (slotsUsed(g, c.id) >= RULES.tradeSlots) return;
  const goods = Object.keys(TRADE_GOODS);
  const good = goods[Math.floor(g.rng() * goods.length)];
  const G = TRADE_GOODS[good];
  const stock = c[G.key];
  let role = null;
  if (stock > G.surplus) role = 'sell';
  else if (stock < G.low && c.gold > 150) role = 'buy';
  if (!role) return;
  const size = 'ms'[Math.floor(g.rng() * 2)];
  let best = null, bv = 0;
  for (const o of g.countries) {
    if (!o.alive || o.id === c.id || atWar(g, c.id, o.id)) continue;
    if (!canTrade(g, c.id, o.id).ok) continue;
    if (g.trade.some((d) => d.good === good && ((d.from === c.id && d.to === o.id) || (d.from === o.id && d.to === c.id)))) continue;
    if (role === 'sell' ? o[G.key] >= G.cap / 2 : o[G.key] <= G.surplus * 0.8) continue;
    const v = opinion(g, c.id, o.id) + g.rng() * 10;
    if (v > bv) { bv = v; best = o; }
  }
  if (!best || bv < 0) return;
  const seller = role === 'sell' ? c.id : best.id, buyer = role === 'sell' ? best.id : c.id;
  const d = { from: seller, to: buyer, good, amt: dealAmount(g, seller, good, size), price: dealPrice(g, seller, buyer, good) };
  if (g.countries[buyer].gold < dealCost(d) * 5) return;
  if (best.id === g.playerId) {
    if ((g.offers || []).filter((o) => o.kind === 'trade' && o.to === g.playerId).length >= 2) return;
    if (slotsUsed(g, g.playerId) >= RULES.tradeSlots) return;
    if (g.offers.some((o) => o.kind === 'trade' && o.from === c.id)) return;
    g.offers.push({ id: g.nextOfferId++, day: g.day, kind: 'trade', from: c.id, to: g.playerId, deal: d });
    emit(g, `${c.name} предлагает торговую сделку`, [c.id, g.playerId], 'offer');
    return;
  }
  if (!aiWilling(g, c.id, d).ok || !aiWilling(g, best.id, d).ok) return;
  sign(g, d);
}
