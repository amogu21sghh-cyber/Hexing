// Авиация: самолёты стоят эскадрильями (пачками) на аэродромах и выполняют задания в радиусе.
// Данные лежат в провинции: p.props.air = { n, owner, mission: { t, r, pid } | null }, поэтому сохраняются вместе с картой.
// Задания: strike — наземный удар (небольшой урон, главное — организация), bomb — разрушение зданий,
// recon — разведка (показывает вражеские армии и их точную численность), intercept — перехват (прикрывает зону, воздушные бои).
import { RULES } from './data.js';
import { BUILDINGS } from './data.js';
import { prov, atWar, friendly, hooks, emit, levelOf, mobAvail } from './state.js';

export const AIR_MISSIONS = [['strike', 'Наземный удар'], ['bomb', 'Разрушение зданий'], ['recon', 'Разведка'], ['intercept', 'Перехват']];
export const AIR_HINT = {
  strike: 'Небольшой урон армиям врага, сильно снижает их организацию',
  bomb: 'Накапливает разрушение: сбивает уровень здания во вражеской провинции',
  recon: 'Показывает вражеские армии и их точную численность в радиусе',
  intercept: 'Прикрывает зону радиуса: сбивает вражескую авиацию, идущую на задание',
};

export const airOf = (p) => (p.props.air && p.props.air.n > 0 ? p.props.air : null);
export const airPacks = (p) => (p.props.air ? p.props.air.n : 0);

// Радиус заданий и вместимость аэродрома с учётом технологий
export function airRadius(g, owner, level) {
  if (!level) return 0;
  return RULES.airRadius[Math.min(level, RULES.airRadius.length) - 1] + Math.round(g.countries[owner].mod.airRange || 0);
}
export function airCapacity(g, owner, level) {
  if (!level) return 0;
  return Math.floor(RULES.airCap[Math.min(level, RULES.airCap.length) - 1] * (g.countries[owner].mod.airCap || 1));
}

// Провинции в радиусе r шагов от pid: Map id → расстояние (0 — сама база)
export function airZone(g, pid, r) {
  const dist = new Map([[pid, 0]]);
  let frontier = [pid];
  for (let d = 1; d <= r; d++) {
    const next = [];
    for (const id of frontier) for (const nb of prov(g, id).neighbors) if (!dist.has(nb)) { dist.set(nb, d); next.push(nb); }
    frontier = next;
  }
  return dist;
}

export const airPackCost = (g, owner) => {
  const k = g.countries[owner].mod.recruit;
  return { gold: Math.round(RULES.airGold * k), men: RULES.airMen, ind: RULES.airInd };
};

// Призыв n эскадрилий на аэродром: дневной лимит мобилизации общий с сухопутными войсками
export function recruitAir(g, owner, pid, n = 1) {
  n = Math.max(1, Math.floor(n));
  const p = prov(g, pid), c = g.countries[owner];
  if (!p || p.props.owner !== owner) return { ok: false, msg: 'Не ваша провинция' };
  const lv = levelOf(p, 'airfield');
  if (!lv) return { ok: false, msg: 'Здесь нет аэродрома' };
  const cap = airCapacity(g, owner, lv), have = airPacks(p);
  if (have + n > cap + 1e-9) return { ok: false, msg: `Аэродром вмещает ${cap} эск.` };
  if (g.armies.some((a) => a.at === pid && a.owner !== owner && atWar(g, owner, a.owner))) return { ok: false, msg: 'Идёт бой' };
  if (mobAvail(g, owner) < n) return { ok: false, msg: 'Исчерпан дневной лимит призыва' };
  const cost = airPackCost(g, owner);
  if (c.gold < cost.gold * n) return { ok: false, msg: 'Не хватает золота' };
  if (c.manpower < cost.men * n) return { ok: false, msg: 'Не хватает людей' };
  if (c.industry < cost.ind * n) return { ok: false, msg: 'Не хватает промышленности' };
  c.mobBank = (c.mobBank != null ? c.mobBank : mobAvail(g, owner)) - n;
  c.gold -= cost.gold * n; c.manpower -= cost.men * n; c.industry -= cost.ind * n;
  const air = p.props.air || (p.props.air = { n: 0, owner, mission: null });
  air.n += n; air.owner = owner;
  return { ok: true, amount: n };
}

// Задание аэродрома. t = null снимает его; r — радиус; pid — конкретная цель в радиусе (null — вся зона)
export function setMission(g, owner, pid, t, r, target = null) {
  const p = prov(g, pid);
  if (!p || p.props.owner !== owner) return { ok: false, msg: 'Не ваша провинция' };
  const lv = levelOf(p, 'airfield');
  if (!lv) return { ok: false, msg: 'Здесь нет аэродрома' };
  const air = p.props.air || (p.props.air = { n: 0, owner, mission: null });
  if (!t) { air.mission = null; return { ok: true }; }
  if (!AIR_MISSIONS.some(([k]) => k === t)) return { ok: false, msg: 'Неизвестное задание' };
  const R = airRadius(g, owner, lv);
  const rr = Math.max(1, Math.min(R, Math.round(r || R)));
  if (target != null && !(airZone(g, pid, rr).has(target) && target !== pid)) return { ok: false, msg: 'Цель вне радиуса' };
  air.mission = { t, r: rr, pid: target };
  return { ok: true };
}

const orgOf = (a) => (a.org == null ? 100 : a.org);

// Что здание стоит: самое дорогое из построенных (его уровень и сбивает бомбардировка)
function destroyBuilding(g, p) {
  const built = p.props.built || [];
  if (!built.length) return null;
  let best = built[0];
  for (const id of built) if (BUILDINGS[id] && BUILDINGS[best] && BUILDINGS[id].cost > BUILDINGS[best].cost) best = id;
  built.splice(built.lastIndexOf(best), 1);
  if (best === 'port') g._portsDirty = true;
  return best;
}

// армии по провинциям: в течение дня runAir строит свежую таблицу за один проход, иначе приходится фильтровать все армии
const armiesAt = (g, pid) => (g._airAtDay === g.day && g._airAt ? g._airAt.get(pid) || [] : g._atDay === g.day && g._at ? g._at.get(pid) || [] : g.armies.filter((a) => a.at === pid));
function indexArmies(g) {
  const m = new Map();
  for (const a of g.armies) { const l = m.get(a.at); if (l) l.push(a); else m.set(a.at, [a]); }
  g._airAt = m; g._airAtDay = g.day;
}

// Ежедневный расчёт авиации (вызывается из stepDay)
export function runAir(g) {
  indexArmies(g);
  // 0. список аэродромов с самолётами; потерянные при захвате провинции самолёты пропадают
  const bases = [];
  const list = [], fields = [], building = [];
  for (const p of g.world.provinces.values()) {
    const air = p.props.air;
    if (p.props.bombed > 0) p.props.bombed = Math.max(0, p.props.bombed - RULES.airRepair);
    if (p.props.built && p.props.built.length && p.props.built.includes('airfield')) fields.push(p.id);
    if (p.props.project && p.props.project.id === 'airfield') building.push(p.id);
    if (!air) continue;
    if (air.owner !== p.props.owner || !levelOf(p, 'airfield')) { p.props.air = null; continue; }
    const cap = airCapacity(g, p.props.owner, levelOf(p, 'airfield'));
    if (air.n > cap) air.n = cap;
    if (air.n < 0.05 && !air.mission) { p.props.air = null; continue; }
    list.push(p.id);
    if (air.n >= 0.05) bases.push(p);
  }
  g._air = list; g._fields = fields; g._fieldsWip = building;
  g._recon = new Set();
  if (!bases.length) return;
  const mods = (o) => g.countries[o].mod;
  const flying = (o) => g.countries[o].alive && !g.countries[o].noFuel;
  const spend = (o, packs) => { const c = g.countries[o]; c.fuel = Math.max(0, c.fuel - packs * RULES.airFuel * mods(o).airFuel); };

  // 1. покрытие перехватом: pid → [{ air, owner, eff }]
  const cover = new Map();
  for (const p of bases) {
    const air = p.props.air, o = p.props.owner, m = air.mission;
    if (!m || m.t !== 'intercept' || !flying(o)) continue;
    const eff = air.n * mods(o).air * mods(o).airIntercept;
    for (const [pid] of airZone(g, p.id, m.r)) {
      if (!cover.has(pid)) cover.set(pid, []);
      cover.get(pid).push({ air, owner: o, eff });
    }
    spend(o, air.n * 0.5);
  }
  const me = g.playerId;

  // 2. задания ударной авиации и разведки
  for (const p of bases) {
    const air = p.props.air, o = p.props.owner, m = air.mission;
    if (!m || m.t === 'intercept' || air.n < 0.05 || !flying(o)) continue;
    const zone = airZone(g, p.id, m.r);
    // цели по типу задания
    const cands = [];
    for (const [pid] of zone) {
      if (pid === p.id || (m.pid != null && pid !== m.pid)) continue;
      const q = prov(g, pid), qo = q.props.owner;
      if (m.t === 'strike') {
        let str = 0;
        for (const a of armiesAt(g, pid)) if (a.owner !== o && !a.rebel && atWar(g, o, a.owner)) str += a.strength;
        if (str > 0) cands.push({ pid, v: str });
      } else if (m.t === 'bomb') {
        if (qo != null && qo !== o && atWar(g, o, qo) && (q.props.built || []).length) cands.push({ pid, v: (q.props.built || []).length * 10 + (q.props.wealth || 0) });
      } else if (m.t === 'recon') {
        if (qo !== o && !(qo != null && friendly(g, o, qo))) cands.push({ pid, v: 1 + armiesAt(g, pid).length });
      }
    }
    if (!cands.length) continue;
    cands.sort((a, b) => b.v - a.v || a.pid - b.pid);
    const ntar = Math.min(cands.length, 1 + Math.floor(air.n / 3));
    const w = air.n / ntar;
    const tm = mods(o);
    const kind = m.t === 'strike' ? tm.airStrike : m.t === 'bomb' ? tm.airBomb : 1;
    const wEff = w * tm.air * kind;
    let lost = 0;
    spend(o, air.n);
    for (const t of cands.slice(0, ntar)) {
      // воздушный бой: вражеские перехватчики, прикрывающие цель
      const def = (cover.get(t.pid) || []).filter((x) => x.owner !== o && atWar(g, o, x.owner) && x.air.n >= 0.05);
      const S = def.reduce((s, x) => s + x.eff, 0);
      const defRatio = S > 0 ? S / (S + wEff) : 0;
      const e = 1 - defRatio;
      if (S > 0) {
        lost += w * Math.min(0.4, RULES.airLoss * (1 + 2 * defRatio));
        const fd = Math.min(0.35, RULES.airLoss * (1 + e) * Math.min(1, wEff / S));
        for (const x of def) x.air.n = Math.max(0, x.air.n * (1 - fd));
      } else lost += w * RULES.airFlak;
      const P = wEff * e;
      const q = prov(g, t.pid);
      if (m.t === 'strike') {
        const foes = armiesAt(g, t.pid).filter((a) => a.owner !== o && !a.rebel && atWar(g, o, a.owner));
        const k = Math.sqrt(foes.length) || 1;
        for (const a of foes) {
          a.strength = Math.max(1, a.strength - P * RULES.airStrikeDmg / foes.length);
          a.org = Math.max(RULES.airOrgFloor, orgOf(a) - Math.min(RULES.airOrgCap, P * RULES.airStrikeOrg / k));
        }
      } else if (m.t === 'bomb') {
        q.props.bombed = (q.props.bombed || 0) + P * RULES.airBomb;
        while (q.props.bombed >= RULES.airBombNeed) {
          q.props.bombed -= RULES.airBombNeed;
          const id = destroyBuilding(g, q);
          if (!id) { q.props.bombed = 0; break; }
          emit(g, `Бомбардировка: ${g.countries[o].name} разрушила «${BUILDINGS[id].name}», ${q.name}`, [o, q.props.owner].filter((x) => x != null), 'war');
          if (!(q.props.built || []).length) { q.props.bombed = 0; break; }
        }
      } else if (m.t === 'recon' && me != null && (o === me || friendly(g, me, o)) && e > 0.2) {
        g._recon.add(t.pid);
      }
    }
    air.n = Math.max(0, air.n - lost);
  }
}
hooks.air = runAir;

// Сколько эскадрилий у страны всего
export function airTotal(g, owner) {
  let n = 0;
  for (const pid of g._air || []) { const p = prov(g, pid); if (p.props.owner === owner) n += airPacks(p); }
  return n;
}

// ---------- ИИ ----------
// Сколько аэродромов (суммарно уровней) у страны; кэш на день
function fieldsOf(g, c) {
  if (c._afDay === g.day && c._afN != null) return c._afN;
  let n = 0;
  for (const pid of g._fields || []) { const p = prov(g, pid); if (p.props.owner === c.id) n += levelOf(p, 'airfield'); }
  for (const pid of g._fieldsWip || []) if (prov(g, pid).props.owner === c.id) n++; // стройки тоже считаются
  Object.defineProperty(c, '_afN', { value: n, writable: true, configurable: true, enumerable: false });
  Object.defineProperty(c, '_afDay', { value: g.day, writable: true, configurable: true, enumerable: false });
  return n;
}
const atAnyWar = (g, c) => g.countries.some((o) => o.alive && o.id !== c.id && atWar(g, c.id, o.id));

// Выгода постройки (или улучшения) аэродрома для ИИ: у границы и в войне ценнее, число ограничено
export function aiAirfieldValue(g, c, p, lv, front) {
  const war = atAnyWar(g, c);
  const total = fieldsOf(g, c);
  const limit = war ? 7 : 3;
  if (total >= limit) return 0;
  if (lv >= 2 && !war) return 0;
  const border = front || p.neighbors.some((n) => { const o = prov(g, n).props.owner; return o != null && o !== c.id && !friendly(g, c.id, o); });
  if (!border && lv === 0 && total >= 1) return 0; // первый аэродром — где угодно, дальше у границ
  return (war ? 1400 : 700) * (border ? 1.3 : 1);
}

export function aiAir(g, c) {
  if ((g.day + c.id) % 3) return;
  const fields = (g._fields || []).filter((pid) => prov(g, pid).props.owner === c.id);
  if (!fields.length) return;
  const war = atAnyWar(g, c);
  for (const pid of fields) {
    const p = prov(g, pid), lv = levelOf(p, 'airfield');
    const cap = airCapacity(g, c.id, lv), have = airPacks(p);
    // пополнение: в войне до предела, в мире держим около трети
    const want = war ? cap : Math.floor(cap / 3);
    if (have < want && c.gold > (war ? 150 : 500) && !c.noFuel) recruitAir(g, c.id, pid, Math.min(2, want - have));
    const air = p.props.air;
    if (!war) { if (air && air.mission) air.mission = null; continue; }
    if (!air || air.n < 0.5) continue;
    const R = airRadius(g, c.id, lv), zone = airZone(g, pid, R);
    let enemyAir = false, armies = 0, bld = 0;
    for (const [id] of zone) {
      const q = prov(g, id), qo = q.props.owner;
      if (q.props.air && q.props.air.n > 0.5 && qo != null && qo !== c.id && atWar(g, c.id, qo)) enemyAir = true;
      for (const a of armiesAt(g, id)) if (a.owner !== c.id && !a.rebel && atWar(g, c.id, a.owner)) armies += a.strength;
      if (qo != null && qo !== c.id && atWar(g, c.id, qo) && (q.props.built || []).length) bld++;
    }
    const idx = fields.indexOf(pid);
    const t = enemyAir && idx % 2 === 0 ? 'intercept' : armies > 0 ? 'strike' : bld ? 'bomb' : enemyAir ? 'intercept' : 'recon';
    if (!air.mission || air.mission.t !== t || air.mission.r !== R) air.mission = { t, r: R, pid: null };
  }
}
