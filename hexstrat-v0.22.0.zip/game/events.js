// Движок событий: историческая хроника, случайные происшествия, выбор игрока и ветвления по флагам.
// Содержимое (тексты, условия, последствия) лежит в events_data.js; здесь только правила его работы.
import { RULES, TECHS, IDEOS, FOCUSES, BUILDINGS, regimeName } from './data.js';
import { EVENTS, MOD_NAMES } from './events_data.js';
import { whenOk, applyPlagueDelta } from './plague_core.js';
import {
  atWar, prov, emit, recalcMods, economyPreview, joinWar, eliminate, makePeace, addRel, sameFaction, factionOf, ministerTrait, opinion,
  declareWar, addArmy, ensureCountry, hooks, addGuarantee, warScore, vassalize, hasB, levelOf, maxLevel, friendly,
} from './state.js';

const nameIndex = (g) => {
  if (g._names) return g._names;
  const m = new Map(g.countries.map((c) => [c.base || c.name, c.id]));
  Object.defineProperty(g, '_names', { value: m, enumerable: false, writable: true });
  return m;
};
export const byName = (g, n) => { const id = nameIndex(g).get(n); return id == null ? null : g.countries[id]; };
const liveByName = (g, n) => { const c = byName(g, n); return c && c.alive ? c : null; };

// Помощники для условий и последствий в events_data.js
export const H = {
  settle: (g, w, l) => imposeSettlement(g, w, l),
  peace: (g, c, n) => { const o = liveByName(g, n); if (o && atWar(g, c.id, o.id)) makePeace(g, c.id, o.id, true); },
  c: (g, n) => liveByName(g, n),
  flag: (c, f) => !!(c && c.flags && c.flags[f] != null),
  claimed: (g, key) => !!(g.claims && g.claims[key]),
  flagOf: (g, n, f) => { const c = byName(g, n); return !!(c && c.flags[f] != null); },
  tech: (c, id) => c.techs.includes(id),
  techs: (c) => c.techs.length,
  focus: (c, id) => c.focuses.includes(id),
  focuses: (c) => c.focuses.length,
  minister: (c, post, trait) => { const t = ministerTrait(c, post); return !!t && t.id === trait; },
  wars: (g, c) => { let n = 0; for (const k of g.wars.keys()) if (k.split('|').map(Number).includes(c.id)) n++; return n; },
  atWar: (g, c, n) => { const o = byName(g, n); return !!o && atWar(g, c.id, o.id); },
  anyWar: (g, n) => { const o = byName(g, n); return !!o && H.wars(g, o) > 0; },
  alive: (g, n) => !!liveByName(g, n),
  allied: (g, c, n) => { const o = byName(g, n); return !!o && sameFaction(g, c.id, o.id); },
  inFaction: (c) => c.faction != null,
  org: (c, id) => c.orgs.includes(id),
  rel: (g, c, n) => { const o = byName(g, n); return o ? opinion(g, c.id, o.id) : 0; },
  size: (g, c) => g.stats[c.id] ? g.stats[c.id].provinces : 0,
  troops: (g, c) => g.stats[c.id] ? g.stats[c.id].troops : 0,
  neighbors: (g, c, n) => { const o = byName(g, n); return !!o && bordering(g, c.id, o.id); },
  day: (g) => g.day,
  splitSpain: (g, c) => splitSpain(g, c),
  endSpanishWar: (g, c) => endSpanishWar(g, c),
};

// Гражданская война в Испании: появляется новая страна, мятежники получают север, запад и юг-запад, начинается война
const REBEL_PARTS = ['Ла-Корунья', 'Виго', 'Галисия', 'Леон', 'Бургос', 'Вальядолид', 'Саламанка', 'Гуарда', 'Касерес', 'Бадахос', 'Эстремадура', 'Севилья', 'Уэльва', 'Кадис', 'Наварра', 'Памплона', 'Сарагоса', 'Тетуан', 'Танжер', 'Тлемсен', 'Ифни', 'Тиндуф', 'Майорка'];
const REBEL_NAME = 'Националисты';
function splitSpain(g, spain) {
  if (!spain || byName(g, REBEL_NAME)) return;
  const mine = [...g.world.provinces.values()].filter((p) => p.props.owner === spain.id);
  const taken = mine.filter((p) => REBEL_PARTS.some((n) => p.name.startsWith(n)));
  if (taken.length < 5) return;
  const cap = taken.find((p) => p.name === 'Бургос') || taken[0];
  const id = g.countries.length;
  const reb = { id, name: REBEL_NAME, color: '#8a6d3b', capital: cap.id, alive: true, power: 0.8 };
  g.countries.push(reb);
  g.nameCache = null; g._names = null;
  reb.techs = [...spain.techs]; reb.focuses = [];
  reb.gold = Math.round(spain.gold * 0.4); spain.gold = Math.round(spain.gold * 0.6);
  reb.manpower = Math.round(spain.manpower * 0.4); spain.manpower = Math.round(spain.manpower * 0.6);
  reb.research = Math.round(spain.research * 0.3); reb.industry = Math.round(spain.industry * 0.3); reb.fuel = Math.round(spain.fuel * 0.3); reb.pp = 50;
  reb.slots = { eco: null, pol: null, mil: null, sci: null }; reb.orgs = []; reb.faction = null; reb.tax = 2; reb.stability = 50;
  reb.flags = { civil_war: g.day }; reb.ideo = 'fas';
  ensureCountry(reb, g);
  const ids = new Set(taken.map((p) => p.id));
  for (const p of taken) p.props.owner = id;
  cap.props.capital = true;
  for (const a of g.armies) if (a.owner === spain.id && ids.has(a.at)) a.owner = id;
  addArmy(g, id, cap.id, 30);
  addRel(g, id, spain.id, -60);
  const de = byName(g, 'Германия'), it = byName(g, 'Италия'), su = byName(g, 'СССР');
  for (const o of [de, it]) if (o) addRel(g, id, o.id, 25);
  if (su) addRel(g, id, su.id, -40);
  declareWar(g, id, spain.id);
  economyPreview(g);
  emit(g, `Испания раскололась: ${REBEL_NAME} захватили ${taken.length} провинций`, [spain.id, id], 'war');
}

// Конец войны: сильнейшая сторона поглощает другую
function endSpanishWar(g, spain) {
  const reb = byName(g, REBEL_NAME);
  if (!reb || !reb.alive || !spain.alive) return;
  const nS = g.stats[spain.id].provinces, nR = g.stats[reb.id].provinces;
  // в историческом режиме побеждают националисты, если Испанией не играет человек
  const winner = (g.historical && spain.id !== g.playerId) || nR >= nS ? reb : spain, loser = winner === spain ? reb : spain;
  for (const p of g.world.provinces.values()) if (p.props.owner === loser.id) p.props.owner = winner.id;
  eliminate(g, loser.id, winner.id);
  if (winner === reb) { reb.name = 'Испания'; loser.name = 'Испанская республика'; g._names = null; }
  emit(g, `Гражданская война в Испании окончена: победа ${winner === spain ? 'республиканцев' : 'националистов'}`, [winner.id], 'war');
  economyPreview(g);
}

function bordering(g, a, b) {
  for (const p of g.world.provinces.values()) {
    if (p.props.owner !== a) continue;
    for (const nb of p.neighbors) { const q = prov(g, nb); if (q && q.props.owner === b) return true; }
  }
  return false;
}

// Передаёт n провинций страны from стране to, начиная с приграничных к to.
// Какие провинции перейдут (без изменения мира): сначала приграничные к получателю
export function pickCede(g, from, to, n) {
  // сначала то, что победитель уже занял (оно и закрепляется договором), затем приграничные земли проигравшего
  const held = [...g.world.provinces.values()].filter((p) => p.props.owner === to && p.props.core === from && !p.props.capital && !p.props.treaty).map((p) => p.id);
  if (held.length >= n) return held.slice(0, n);
  const rest = pickCedeOwn(g, from, to, n - held.length);
  return [...held, ...rest];
}
function pickCedeOwn(g, from, to, n) {
  // Связный кусок у границы получателя: зерно — ближайшая к его столице провинция уступающего,
  // дальше добавляется ближайшая к зерну из соседних с уже выбранными (приграничные к получателю чуть предпочтительнее).
  // Так уступка — один район, а не разбросанные по границе клетки.
  const mine = [...g.world.provinces.values()].filter((p) => p.props.owner === from && !p.props.capital);
  const owned = new Set(mine.map((p) => p.id));
  const theirs = [...g.world.provinces.values()].filter((p) => p.props.owner === to);
  if (!theirs.length || !mine.length) return [];
  const d = (a, b) => Math.hypot(a.center.x - b.center.x, a.center.y - b.center.y);
  const cap = theirs.find((p) => p.props.capital) || theirs[0];
  const touch = new Set();
  for (const p of theirs) for (const nb of p.neighbors) if (owned.has(nb)) touch.add(nb);
  const pool = touch.size ? mine.filter((p) => touch.has(p.id)) : mine;
  const seed = pool.reduce((m, p) => (d(p, cap) < d(m, cap) ? p : m), pool[0]);
  const picked = [seed.id], inSet = new Set(picked);
  const step = Math.hypot(seed.center.x - (prov(g, seed.neighbors[0]) || seed).center.x, seed.center.y - (prov(g, seed.neighbors[0]) || seed).center.y) || 40;
  while (picked.length < n) {
    let best = null, bs = Infinity;
    for (const id of picked) for (const nb of prov(g, id).neighbors) {
      if (!owned.has(nb) || inSet.has(nb)) continue;
      const q = prov(g, nb);
      const sc = d(q, seed) - (touch.has(nb) ? step * 0.6 : 0);
      if (sc < bs) { bs = sc; best = nb; }
    }
    if (best == null) break;
    picked.push(best); inSet.add(best);
  }
  return picked;
}

export function cedeProvinces(g, from, to, n, ids) {
  // ids — заранее названные в предложении провинции (свои у уступающего или уже занятые получателем);
  // если часть уже недоступна, добираем по правилам pickCede
  const valid = (id) => { const q = prov(g, id); return q && !q.props.capital && (q.props.owner === from || (q.props.owner === to && q.props.core === from && !q.props.treaty)); };
  let picked = (ids || []).filter(valid);
  const want = ids ? ids.length : n;
  if (picked.length < want) picked = [...picked, ...pickCede(g, from, to, want - picked.length).filter((x) => !picked.includes(x))].slice(0, want);
  for (const id of picked) {
    const q = prov(g, id);
    const held = q.props.owner === to;
    q.props.owner = to; q.props.treaty = true; // закреплено договором: мир не вернёт
    if (q.props.core !== to && !held) q.props.comp = 40;
  }
  g.armies = g.armies.filter((a) => !(a.owner === from && picked.includes(a.at)));
  return picked.length;
}

export function annexCountry(g, to, fromName) {
  if (Array.isArray(fromName)) { let ok = false; for (const n of fromName) ok = annexCountry(g, to, n) || ok; return ok; }
  const f = liveByName(g, fromName);
  if (!f || f.id === to) return false;
  for (const p of g.world.provinces.values()) if (p.props.owner === f.id) { p.props.owner = to; p.props.treaty = true; if (p.props.core !== to) p.props.comp = 60; }
  eliminate(g, f.id, to);
  return true;
}

// ---------- постройки от фокусов ----------
// Сколько построек даёт фокус стране такого размера: base для страны примерно в 100 провинций, дальше растёт с корнем
export function buildCount(g, c, base) {
  let n = 0;
  for (const p of g.world.provinces.values()) if (p.props.owner === c.id) n++;
  return Math.max(2, Math.round(base * Math.sqrt(n / 100)));
}
// Бесплатно строит n зданий bid в лучших для него провинциях страны; возвращает число построенных
export function buildForFree(g, c, bid, base) {
  const b = BUILDINGS[bid];
  if (!b) return 0;
  const n = buildCount(g, c, base);
  const foreign = (p) => p.neighbors.filter((x) => { const o = g.world.provinces.get(x).props.owner; return o != null && o !== c.id && !friendly(g, c.id, o); }).length;
  const mine = [...g.world.provinces.values()].filter((p) => p.props.owner === c.id && levelOf(p, bid) < maxLevel(bid) && !p.props.project
    && (!b.terrain || b.terrain.includes(p.props.terrain)) && (!b.deposit || p.props.deposit)
    && !g.armies.some((a) => a.at === p.id && a.owner !== c.id && atWar(g, c.id, a.owner)));
  const border = new Set(mine.filter((p) => foreign(p) > 0).map((p) => p.id));
  const score = (p) => {
    const w = p.props.wealth || 0;
    if (bid === 'fort') return foreign(p) * 10 + w * 0.1;                       // граница
    if (bid === 'road') return (border.has(p.id) ? 0 : p.neighbors.some((x) => border.has(x)) ? 6 : 0) + w * 0.1; // вторая линия
    if (bid === 'pump') return (p.props.deposit === 'O' ? 6 : p.props.deposit === 'o' ? 3 : 1.2) + w * 0.01;
    return w - (foreign(p) ? w * 0.3 : 0);                                       // богатые, лучше не на границе
  };
  // сначала новые здания, повышение уровня — когда свободных мест не хватает
  const list = mine.filter((p) => bid !== 'fort' || border.has(p.id)).sort((x, y) => levelOf(x, bid) - levelOf(y, bid) || score(y) - score(x)).slice(0, n);
  for (const p of list) (p.props.built = p.props.built || []).push(bid);
  if (list.length) emit(g, `${c.name}: построено — ${b.name}, ${list.length} шт. (новые или уровнем выше)`, [c.id], 'build');
  return list.length;
}

// ---------- применение последствий ----------
const clamp0 = (v) => Math.max(0, v);
// Суммы можно задавать в днях дохода (goldD, menD): так событие одинаково весомо для большой и малой страны.
const DAYS_K = 0.4; // дни дохода в событиях считаются с коэффициентом: ресурсы страны копятся быстрее, чем кажется
const goldOf = (eff, c) => (eff.gold || 0) + (eff.goldD ? Math.round(eff.goldD * DAYS_K * Math.max(5, (c.income && c.income.gold) || 0)) : 0);
const menOf = (eff, c) => (eff.men || 0) + (eff.menD ? Math.round(eff.menD * DAYS_K * Math.max(2, (c.income && c.income.men) || 0)) : 0);

export function applyEffect(g, c, eff, ctxLabel) {
  if (!eff) return;
  const gd = goldOf(eff, c), md = menOf(eff, c);
  if (gd) c.gold = clamp0(c.gold + gd);
  if (md) c.manpower = clamp0(c.manpower + md);
  if (eff.pp) c.pp = clamp0(c.pp + eff.pp);
  if (eff.res) c.research = clamp0(c.research + eff.res);
  if (eff.ind) c.industry = clamp0(c.industry + eff.ind);
  if (eff.fuel) c.fuel = clamp0(c.fuel + eff.fuel);
  if (eff.stab) c.stability = Math.max(0, Math.min(100, c.stability + eff.stab));
  if (eff.mod) {
    const { name, days, ...mod } = eff.mod;
    c.timed.push({ name: name || ctxLabel, until: g.day + (days || 365), mod });
    recalcMods(c);
  }
  for (const f of eff.flags || []) c.flags[f] = g.day;
  for (const f of eff.clear || []) delete c.flags[f];
  for (const [n, delta] of eff.rel || []) { const o = n === '$' ? null : liveByName(g, n); if (o && o.id !== c.id) addRel(g, c.id, o.id, delta); }
  for (const n of eff.war || []) { const o = liveByName(g, n); if (o) joinWar(g, c.id, o.id); }
  for (const n of eff.peace || []) { const o = liveByName(g, n); if (o && atWar(g, c.id, o.id)) makePeace(g, c.id, o.id); }
  if (eff.annex) annexCountry(g, c.id, eff.annex);
  if (eff.annex) g.tension = Math.min(100, g.tension + 8);
  // cede: [страна, n, ключ]: с ключом n — общий размер притязания; событие и фокус с одним ключом вместе дают не больше n
  let cedeN = 0;
  if (eff.cede) {
    const [, n, key] = eff.cede;
    g.claims = g.claims || {};
    cedeN = key ? Math.max(0, n - (g.claims[key] || 0)) : n;
    if (key) g.claims[key] = (g.claims[key] || 0) + cedeN;
    if (cedeN) g.tension = Math.min(100, g.tension + 5);
  }
  if (eff.tension) g.tension = Math.max(0, Math.min(100, g.tension + eff.tension));
  for (const n of eff.guar || []) { const o = liveByName(g, n); if (o && o.id !== c.id) addGuarantee(g, c.id, o.id); }
  if (eff.cede && cedeN) {
    const o = liveByName(g, eff.cede[0]);
    if (o) {
      // cedeNames — заранее названный район: берём эти провинции (если ещё у уступающего), остальное добирается по правилам
      let ids;
      if (eff.cedeNames) ids = [...g.world.provinces.values()].filter((q) => eff.cedeNames.includes(q.name) && q.props.owner === o.id && !q.props.capital).map((q) => q.id).slice(0, cedeN);
      cedeProvinces(g, o.id, c.id, cedeN, ids && ids.length ? ids : undefined);
    }
  }
  if (eff.plague) { applyPlagueDelta(c, eff.plague); recalcMods(c); }
  if (eff.build) buildForFree(g, c, eff.build[0], eff.build[1]);
  if (eff.ally) allyWith(g, c, eff.ally);
  if (eff.org && !c.orgs.includes(eff.org)) { c.orgs.push(eff.org); recalcMods(c); }
  if (eff.title) setTitle(g, c, eff.title);
  if (eff.ideo) setIdeology(g, c, eff.ideo);
  if (eff.fn) eff.fn(g, c, H);
}

// Громкое название («Великая X»): остаётся при смене строя
export function setTitle(g, c, title) {
  const old = c.name;
  c.title = title; c.name = title;
  emit(g, `${old} теперь «${title}»`, [c.id], 'event');
}

// Смена режима: идеология, название страны, временное падение стабильности, реакция мира
// Вероятность гражданской войны при смене строя c.ideo -> to. Резкий переход и низкая стабильность увеличивают риск.
export function civilWarChance(g, c, to) {
  const from = c.ideo;
  if (!RULES.civilWar || !IDEOS[to] || from === to || c.overlord != null) return 0;
  if (g.historical && c.id !== g.playerId) return 0; // в исторической хронике перевороты у ИИ идут по сценарию
  if (c.civilDay != null && g.day - c.civilDay < RULES.civilCooldown) return 0;
  if (!g.stats || (g.stats[c.id] && g.stats[c.id].provinces < 8)) return 0;
  let base = to === 'aut' ? 0.15 : from === 'aut' ? 0.2 : (from === 'dem' || to === 'dem') ? 0.45 : 0.4;
  base *= Math.max(0.3, Math.min(1.5, 1.6 - (c.stability ?? 50) / 70));
  if ([...g.wars.keys()].some((k) => k.split('|').map(Number).includes(c.id))) base *= 0.75;
  return Math.min(0.8, base);
}

const IDEO_COLOR = { fas: '#6b3a3a', dem: '#3a6bb0', com: '#b03030', aut: '#7a7a42' };
// Гражданская война: мятежники под прежним строем забирают связную область вдали от столицы и воюют с новым режимом.
function civilWar(g, c, oldIdeo) {
  const mine = [...g.world.provinces.values()].filter((p) => p.props.owner === c.id);
  const cap = mine.find((p) => p.props.capital) || mine[0];
  if (!cap || mine.length < 8) return null;
  const own = new Map(mine.map((p) => [p.id, p]));
  const dist = new Map([[cap.id, 0]]);
  const q = [cap.id];
  for (let i = 0; i < q.length; i++) for (const nb of own.get(q[i]).neighbors) if (own.has(nb) && !dist.has(nb)) { dist.set(nb, dist.get(q[i]) + 1); q.push(nb); }
  const seed = [...dist.entries()].filter(([id]) => id !== cap.id).sort((a, b) => b[1] - a[1] || b[0] - a[0])[0];
  if (!seed) return null;
  const n = Math.max(3, Math.min(mine.length - 3, Math.round(mine.length * 0.35)));
  const take = new Set([seed[0]]);
  const qq = [seed[0]];
  for (let i = 0; i < qq.length && take.size < n; i++) for (const nb of own.get(qq[i]).neighbors) if (own.has(nb) && nb !== cap.id && !take.has(nb) && take.size < n) { take.add(nb); qq.push(nb); }
  const taken = [...take].map((id) => own.get(id));
  const rcap = taken.slice().sort((a, b) => b.props.wealth - a.props.wealth)[0];
  const base = c.base || c.name;
  let name = oldIdeo === 'aut' ? `${base} (повстанцы)` : regimeName(base, oldIdeo);
  if (g.countries.some((o) => o.name === name || (o.base || o.name) === name)) name += ' (повстанцы)';
  for (let k = 2; g.countries.some((o) => o.name === name); k++) name = `${base} (повстанцы ${k})`;
  const id = g.countries.length;
  const color = IDEO_COLOR[oldIdeo] === c.color ? '#8a6d3b' : IDEO_COLOR[oldIdeo];
  const reb = { id, name, base: name, color, capital: rcap.id, alive: true, power: 0.8 };
  g.countries.push(reb);
  g.nameCache = null; g._names = null;
  reb.techs = [...c.techs]; reb.focuses = [];
  const sh = 0.35;
  reb.gold = Math.round(c.gold * sh); c.gold -= reb.gold;
  reb.manpower = Math.round(c.manpower * sh); c.manpower -= reb.manpower;
  reb.research = Math.round(c.research * 0.2); reb.industry = Math.round(c.industry * sh); c.industry -= reb.industry;
  reb.fuel = Math.round(c.fuel * sh); c.fuel -= reb.fuel; reb.pp = 40;
  reb.slots = { eco: null, pol: null, mil: null, sci: null }; reb.orgs = []; reb.faction = null; reb.tax = 2; reb.stability = 40;
  reb.ideo = oldIdeo; reb.ideo0 = oldIdeo; reb.flags = { civil_war: g.day, parent: c.id };
  ensureCountry(reb, g);
  for (const p of taken) p.props.owner = id;
  rcap.props.capital = true;
  for (const a of g.armies) if (a.owner === c.id && take.has(a.at)) a.owner = id;
  addArmy(g, id, rcap.id, Math.max(12, Math.round(reb.manpower / 25)));
  addRel(g, id, c.id, -60);
  for (const o of g.countries) if (o.alive && o.id !== id && o.id !== c.id && o.ideo === oldIdeo) addRel(g, id, o.id, 15);
  c.stability = Math.max(0, (c.stability ?? 50) - 10);
  c.civilDay = g.day;
  declareWar(g, id, c.id);
  g.tension = Math.min(100, (g.tension || 0) + 3);
  economyPreview(g);
  emit(g, `Гражданская война в стране «${c.name}»: мятежники («${name}») захватили ${taken.length} провинций`, [c.id, id, ...(g.playerId != null ? [g.playerId] : [])], 'war');
  if (c.id === g.playerId) g.pending.push({ id: g.nextPendingId++, eid: null, cid: c.id, day: g.day, info: { kind: 'defeat', title: 'Гражданская война', text: `Резкая смена строя расколола страну: сторонники прежних порядков подняли мятеж и провозгласили «${name}». Они удерживают ${taken.length} провинций вдали от столицы и воюют с вами.`, lines: [`Мятежники: ${taken.length} провинций`, 'Стабильность −10'], pic: 'ev_war', own: true } });
  return reb;
}

export function setIdeology(g, c, id) {
  if (c.ideo === id || !IDEOS[id]) return;
  const chance = civilWarChance(g, c, id), oldIdeo = c.ideo;
  const old = c.name;
  c.ideo = id;
  c.name = c.title || regimeName(c.base || old, id);
  c.timed.push({ name: 'Смена режима', until: g.day + 90, mod: { stab: -8 } });
  recalcMods(c);
  g.tension = Math.min(100, (g.tension || 0) + (id === 'fas' ? 6 : id === 'com' ? 4 : 0));
  emit(g, `${old}: смена режима. Теперь это ${c.name} (${IDEOS[id].name.toLowerCase()})`, [c.id], 'event');
  if (chance > 0 && g.rng() < chance) civilWar(g, c, oldIdeo);
}

// Союз с названными странами: основывает блок или вступает в блок дружественной страны, если нет войны с членами.
function allyWith(g, c, names) {
  for (const n of names) {
    const o = liveByName(g, n);
    if (!o || o.id === c.id || sameFaction(g, c.id, o.id)) continue;
    let f = factionOf(g, c), of = factionOf(g, o);
    if (f && of) continue;
    if (!f && !of) {
      const L = (o.power ?? 1) > (c.power ?? 1) ? o : c;   // блок возглавляет более сильная держава
      f = { id: g.nextFactionId++, name: `Блок «${L.name}»`, leader: L.id, members: [L.id], founded: g.day };
      g.factions.push(f); L.faction = f.id;
    }
    f = factionOf(g, c) || factionOf(g, o);
    const joiner = f.members.includes(c.id) ? o : c;
    if (f.members.some((m) => atWar(g, joiner.id, m))) continue;
    joiner.faction = f.id; f.members.push(joiner.id);
    addRel(g, joiner.id, f.leader, 10);
    emit(g, `${joiner.name} вступила в ${f.name}`, [joiner.id, f.leader], 'alliance');
  }
}

// Короткое описание последствий для кнопки выбора
export function describeEffect(eff, c) {
  if (!eff) return [];
  const out = [];
  const sg = (v) => (v > 0 ? '+' : '') + Math.round(v * 100) / 100;
  const gd = c ? goldOf(eff, c) : eff.gold, md = c ? menOf(eff, c) : eff.men;
  if (gd) out.push(`Золото ${sg(gd)}`);
  if (md) out.push(`Люди ${sg(md)}`);
  if (eff.pp) out.push(`Власть ${sg(eff.pp)}`);
  if (eff.res) out.push(`Очки технологий ${sg(eff.res)}`);
  if (eff.ind) out.push(`Промышленность ${sg(eff.ind)}`);
  if (eff.fuel) out.push(`Топливо ${sg(eff.fuel)}`);
  if (eff.stab) out.push(`Стабильность ${sg(eff.stab)}`);
  if (eff.plague) { if (eff.plague.inf) out.push(`Заражённость ${sg(eff.plague.inf)}%`); if (eff.plague.vaccine) out.push(`Вакцина ${sg(eff.plague.vaccine)}`); }
  if (eff.mod) {
    const { name, days, ...mod } = eff.mod;
    for (const [k, v] of Object.entries(mod)) {
      const pct = ['gold', 'men', 'res', 'ind', 'fuel', 'attack', 'speed', 'recruit', 'upkeep', 'build', 'war', 'loot', 'fuelUse'].includes(k);
      out.push(`${MOD_NAMES[k] || k} ${v > 0 ? '+' : ''}${pct ? Math.round(v * 100) + '%' : v} на ${days || 365} дн.`);
    }
  }
  if (eff.war) out.push(`Война: ${eff.war.join(', ')}`);
  if (eff.peace) out.push(`Мир: ${eff.peace.join(', ')}`);
  if (eff.guar) out.push(`Гарантирует независимость: ${eff.guar.join(', ')}`);
  if (eff.annex) out.push(`Присоединяет: ${[].concat(eff.annex).join(', ')}`);
  if (eff.cede) out.push(`Получает землю: ${eff.cede[0]}`);
  if (eff.build) out.push(`Строит бесплатно: ${BUILDINGS[eff.build[0]].name} — ${eff.build[1]} на каждые 100 провинций (не меньше 2)`);
  if (eff.ally) out.push(`Союз: ${eff.ally.join(', ')}`);
  if (eff.rel) for (const [n, d] of eff.rel) out.push(`Отношения с ${n} ${sg(d)}`);
  if (eff.note) out.push(eff.note);
  return out;
}

export function canAfford(c, eff) {
  if (!eff) return true;
  return !(goldOf(eff, c) < 0 && c.gold < -goldOf(eff, c)) && !(eff.pp < 0 && c.pp < -eff.pp) && !(menOf(eff, c) < 0 && c.manpower < -menOf(eff, c)) && !(eff.res < 0 && c.research < -eff.res);
}

// ---------- ход событий ----------
const D0 = Date.UTC(1936, 0, 1);
const dayOf = (y, m, d) => Math.round((Date.UTC(y, m - 1, d) - D0) / 864e5);
const histByCountry = new Map(), randomList = [];
export const EVENT_BY_ID = {};
// Индексы событий; вызывается при загрузке и после применения модов (они меняют EVENTS)
export function rebuildEvents() {
  histByCountry.clear(); randomList.length = 0;
  for (const k of Object.keys(EVENT_BY_ID)) delete EVENT_BY_ID[k];
  for (const e0 of EVENTS) {
    const e = { ...e0, _day: e0.date ? dayOf(...e0.date) : null };
    EVENT_BY_ID[e.id] = e;
    if (e._day != null) for (const n of e.countries || []) { if (!histByCountry.has(n)) histByCountry.set(n, []); histByCountry.get(n).push(e); }
    else randomList.push(e);
  }
}
rebuildEvents();
// Оформление окна: style — news (газета), letter (письмо), report (донесение), telegram (телеграмма);
// pic — тема иллюстрации (ev_* в icons.js, если картинки нет, показывается значок).
const LOOK = {
  strike: ['report', 'ev_crowd'], unions: ['report', 'ev_crowd'], harvest: ['telegram', 'ev_farm'], science_leap: ['report', 'ev_lab'],
  military_science: ['report', 'ev_lab'], epidemic: ['report', 'ev_medic'], volunteers: ['telegram', 'ev_army'], industry_boom: ['report', 'ev_factory'],
  reform_success: ['telegram', 'ev_politics'], investors: ['letter', 'ev_money'], refugees: ['news', 'ev_refugees'], scandal: ['news', 'ev_politics'],
  financier_reform: ['letter', 'ev_money'], mutiny: ['report', 'ev_army'], legitimacy: ['news', 'ev_politics'], fuel_crisis: ['report', 'ev_oil'],
  bankruptcy: ['report', 'ev_money'], recognition: ['telegram', 'ev_diplo'], spain: ['news', 'ev_war'], purge: ['report', 'ev_army'],
  abdication: ['news', 'ev_politics'], maginot: ['report', 'ev_border'], rearm_gb: ['report', 'ev_factory'], montreux: ['letter', 'ev_border'],
  rhine: ['news', 'ev_army'], iron_guard: ['news', 'ev_crowd'], metaxas: ['news', 'ev_politics'], ireland: ['letter', 'ev_politics'],
};
export function lookOf(e) {
  if (e.look) return e.look;
  if (LOOK[e.id]) return LOOK[e.id];
  const effs = e.kind === 'minor' ? [e.effect] : (e.options || []).map((o) => o.effect);
  const has = (k) => effs.some((f) => f && f[k]);
  if (has('war')) return ['news', 'ev_war'];
  if (has('annex') || has('cede')) return ['news', 'ev_border'];
  if (has('ally') || has('peace')) return ['letter', 'ev_diplo'];
  return [e._day != null ? 'letter' : 'report', e._day != null ? 'ev_diplo' : 'ev_politics'];
}


const fireKey = (e, c) => `${e.id}:${c.id}`;
const MIN_GAP = 20;

function eligible(g, e, c) {
  if (g.evFired[fireKey(e, c)] != null) return false;
  if (e.scenario && e.scenario !== g.scenario) return false;
  if (e._day != null) {
    if (g.day < e._day || g.day > e._day + (e.window || 240)) return false;
  } else if (e.p == null) return false;
  if (e.when && !whenOk(g, c, e.when)) return false;
  try { return !e.cond || !!e.cond(g, c, H); } catch (_) { return false; }
}

function visibleOptions(g, e, c) {
  return (e.options || []).map((o, i) => ({ o, i })).filter(({ o }) => !o.show || o.show(g, c, H));
}

function chooseAI(g, e, c) {
  const opts = visibleOptions(g, e, c).filter(({ o }) => canAfford(c, o.effect) && (!o.req || o.req(g, c, H)));
  if (!opts.length) return null;
  let total = 0;
  const w = opts.map(({ o }) => { const v = typeof o.ai === 'function' ? o.ai(g, c, H) : (o.ai ?? 1); total += Math.max(0, v); return Math.max(0, v); });
  // в историческом режиме ИИ идёт по истории: берёт вариант с наибольшим весом (при равных — первый)
  if (g.historical && g.scenario === 'europe1936' && e.scenario === 'europe1936') {
    let bi = 0;
    for (let i = 1; i < opts.length; i++) if (w[i] > w[bi]) bi = i;
    return opts[bi].i;
  }
  let r = g.rng() * total;
  for (let i = 0; i < opts.length; i++) { r -= w[i]; if (r <= 0) return opts[i].i; }
  return opts[opts.length - 1].i;
}

function fire(g, e, c) {
  g.evFired[fireKey(e, c)] = g.day;
  c.lastEv = g.day;
  const isPlayer = c.id === g.playerId;
  const hasChoice = e.options && e.options.length && e.kind !== 'minor';
  if (isPlayer && hasChoice) {
    g.pending.push({ id: g.nextPendingId++, eid: e.id, cid: c.id, day: g.day });
    emit(g, `Событие: ${e.title}`, [c.id], 'event');
    return;
  }
  // мелкое событие или решение ИИ
  let optIdx = null, eff = e.effect || null, label = e.title;
  if (hasChoice) {
    optIdx = chooseAI(g, e, c);
    if (optIdx == null) return;
    eff = e.options[optIdx].effect;
    if (e._day != null && !isPlayer) label = `${e.title}: ${e.options[optIdx].short || e.options[optIdx].text}`;
  }
  applyEffect(g, c, eff, e.title);
  if (isPlayer) emit(g, `${e.title}. ${e.text || ''}`.trim(), [c.id], 'event');
  else if (e._day != null) emit(g, `${c.name}: ${label}`, [c.id], 'event');
}

// Ответ игрока на отложенное событие
// Альтернативные национальные фокусы: по завершении применяют последствия (войны, союзы, присоединения)
hooks.focusDone = (g, c, f) => {
  if (f.act) {
    applyEffect(g, c, f.act, f.name);
    economyPreview(g);
  }
  // уведомление с описанием: игроку о своём фокусе и о важных фокусах других стран
  if (f.news && !g.over && (c.id === g.playerId || f.news.world)) {
    const fid = Object.keys(FOCUSES).find((k) => FOCUSES[k] === f);
    g.pending.push({ id: g.nextPendingId++, eid: null, cid: c.id, day: g.day, info: { title: f.news.title, text: f.news.text, fid, own: c.id === g.playerId } });
  }
};

export function chooseEvent(g, pendingId, optIdx) {
  const i = g.pending.findIndex((p) => p.id === pendingId);
  if (i < 0) return { ok: false, msg: 'Событие уже закрыто' };
  const pe = g.pending[i], e = EVENT_BY_ID[pe.eid], c = g.countries[pe.cid];
  if (pe.info) { g.pending.splice(i, 1); return { ok: true }; } // уведомление: достаточно прочитать
  const o = e.options[optIdx];
  if (!o) return { ok: false, msg: 'Нет такого варианта' };
  if (!canAfford(c, o.effect)) return { ok: false, msg: 'Не хватает ресурсов' };
  if (o.req && !o.req(g, c, H)) return { ok: false, msg: o.reqText || 'Условия не выполнены' };
  g.pending.splice(i, 1);
  applyEffect(g, c, o.effect, e.title);
  economyPreview(g);
  emit(g, `${e.title}: ${o.short || o.text}`, [c.id], 'event');
  return { ok: true };
}

export function progressEvents(g) {
  // истёкшие временные бонусы
  let changed = false;
  for (const c of g.countries) {
    if (!c.alive) continue;
    if (c.timed.length && c.timed.some((t) => t.until <= g.day)) { c.timed = c.timed.filter((t) => t.until > g.day); recalcMods(c); changed = true; }
  }
  if (changed) economyPreview(g);
  // устаревшие незакрытые события (игрок мог закрыть игру на паузе: оставляем, они ждут)
  for (const c of g.countries) {
    if (!c.alive) continue;
    // историческая хроника
    const list = histByCountry.get(c.base || c.name);
    if (list) for (const e of list) if (eligible(g, e, c)) { fire(g, e, c); break; }
    // случайные события: не чаще раза в MIN_GAP дней на страну
    if (g.historical && c.id !== g.playerId) continue; // в историческом режиме случайности только у игрока
    if (g.day - c.lastEv < MIN_GAP) continue;
    if (c.id === g.playerId && g.pending.length) continue;
    for (const e of randomList) {
      if (g.rng() > e.p * 0.7) continue;
      if (e.cd && g.evFired[fireKey(e, c)] != null && g.day - g.evFired[fireKey(e, c)] < e.cd) continue;
      if (e.scenario && e.scenario !== g.scenario) continue;
      if (e.when && !whenOk(g, c, e.when)) continue;
      if (e.cond && !(() => { try { return e.cond(g, c, H); } catch (_) { return false; } })()) continue;
      delete g.evFired[fireKey(e, c)];
      fire(g, e, c);
      break;
    }
  }
}


// ---------- фиксированные итоги войн (исторический режим) ----------
// w побеждает l, когда очки войны достигают min. mode: annex — вся страна; split — раздел по долям;
// cede — n провинций, страна остаётся; vassal — часть земель и вассалитет остатка.
// Раздел идёт по зафиксированным провинциям: [кому, список имён провинций] (имя без уточнения в скобках),
// а ['кому', 'rest'] забирает всё, что не названо. needWar: доля достаётся только тем, кто сам воюет с проигравшим
// (остальные доли уходят получателю 'rest', то есть победителю).
const R = (str) => str.split(/\s*,\s*/);
const PL_DE = R('Гдыня, Польское Поморье, Шнайдемюль, Быдгощ, Торунь, Познань, Великопольша, Куявия, Лодзь, Оппельн, Катовице, Мазовия, Ломжа');
const PL_SU = R('Вильно, Молодечно, Дзукия, Утена, Даугавпилс, Минск, Гродно, Новогрудок, Белосток, Кресы, Барановичи, Полесье, Пинск, Сарны, Волынь, Луцк, Ровно, Галиция, Львов, Тарнополь, Станиславов, Коломыя, Каменец-Подольский, Брест-Литовск, Подляшье');
const FR_DE = R('Кале, Лилль, Амьен, Монс, Руан, Пикардия, Реймс, Арлон, Шербур, Кан, Париж, Верден, Мец, Ренн, Нормандия, Шампань, Нанси, Страсбург, Брест, Бретань, Орлеан, Лотарингия, Эльзас, Тур, Дижон, Мюлуз, Нант, Бурж, Бургундия, Безансон, Пуатье, Ла-Рошель, Бордо, Ландды, Гасконь, Пау');
const FR_IT = R('Ницца, Гренобль, Бастия, Корсика');
const YU_DE = R('Марибор, Словения, Белград, Шабац, Валево, Крагуевац, Сербия, Ниш, Вршац, Тимишоара, Турну-Северин');
const YU_HU = R('Суботица, Сегед, Сомбор, Воеводина, Нови-Сад');
const YU_IT = R('Фиуме, Пола, Книн, Лика, Сплит, Далмация, Дубровник, Цетине, Подгорица, Герцеговина, Мостар, Приштина, Санджак, Нови-Пазар');
const YU_BG = R('Скопье, Охрид, Македония, Битола, Кюстендил');
const GR_DE = R('Салоники, Македония, Козани, Флорина, Ханья, Ираклион');
const GR_BG = R('Серре, Драма, Кавала, Александруполис');
const SETTLE = [
  { w: 'Германия', l: 'Польша', min: 60, mode: 'split', note: 'Польша разделена между Германией и СССР',
    parts: (g, H) => (H.flagOf(g, 'СССР', 'mr_pact') || H.flagOf(g, 'Германия', 'mr_pact') ? [['Германия', PL_DE], ['СССР', PL_SU], ['Германия', 'rest']] : [['Германия', 'rest']]) },
  { w: 'СССР', l: 'Польша', min: 60, mode: 'split', note: 'Польша разделена между СССР и Германией',
    parts: (g, H) => (H.flagOf(g, 'СССР', 'mr_pact') ? [['Германия', PL_DE], ['СССР', PL_SU], ['Германия', 'rest']] : [['СССР', 'rest']]) },
  { w: 'Германия', l: 'Чехословакия', min: 50, mode: 'annex', note: 'Чехословакия присоединена к Германии' },
  { w: 'Германия', l: 'Франция', min: 60, mode: 'vassal', note: 'Перемирие: север и запад Франции оккупированы, остаток подчиняется Германии', needWar: true,
    parts: (g, H) => [['Германия', FR_DE], ...(H.flagOf(g, 'Италия', 'italy_war') ? [['Италия', FR_IT]] : [])] },
  { w: 'Германия', l: 'Дания', min: 40, mode: 'annex', note: 'Дания оккупирована' },
  { w: 'Германия', l: 'Норвегия', min: 50, mode: 'annex', note: 'Норвегия оккупирована' },
  { w: 'Германия', l: 'Нидерланды', min: 40, mode: 'annex', note: 'Нидерланды оккупированы' },
  { w: 'Германия', l: 'Бельгия', min: 40, mode: 'annex', note: 'Бельгия оккупирована' },
  { w: 'Германия', l: 'Люксембург', min: 30, mode: 'annex', note: 'Люксембург оккупирован' },
  { w: 'Германия', l: 'Югославия', min: 50, mode: 'split', note: 'Югославия разделена между державами Оси', needWar: true,
    parts: () => [['Германия', YU_DE], ['Италия', YU_IT], ['Венгрия', YU_HU], ['Болгария', YU_BG], ['Германия', 'rest']] },
  { w: 'Германия', l: 'Греция', min: 50, mode: 'split', note: 'Греция оккупирована державами Оси', needWar: true,
    parts: () => [['Германия', GR_DE], ['Болгария', GR_BG], ['Италия', 'rest']] },
  { w: 'Италия', l: 'Албания', min: 40, mode: 'annex', note: 'Албания присоединена к Италии' },
  { w: 'СССР', l: 'Финляндия', min: 50, mode: 'cede', n: 8, note: 'Финляндия уступила пограничные районы' },
  { w: 'СССР', l: 'Эстония', min: 40, mode: 'annex', note: 'Эстония вошла в состав СССР' },
  { w: 'СССР', l: 'Латвия', min: 40, mode: 'annex', note: 'Латвия вошла в состав СССР' },
  { w: 'СССР', l: 'Литва', min: 40, mode: 'annex', note: 'Литва вошла в состав СССР' },
];

const baseName = (p) => p.name.replace(/ \(.*\)$/, '');

function splitLand(g, loser, parts, winnerName, needWar) {
  const winner = liveByName(g, winnerName);
  const list = [...g.world.provinces.values()].filter((p) => p.props.owner === loser.id || (winner && p.props.core === loser.id && p.props.owner === winner.id && !p.props.treaty));
  // получатель: живая страна; при needWar чужая страна получает землю, только если сама воюет с проигравшим
  const eligible = (to) => to && to.alive && (!needWar || to === winner || atWar(g, to.id, loser.id));
  const rest = parts.find((x) => x[1] === 'rest');
  const restTo = rest && eligible(liveByName(g, rest[0])) ? liveByName(g, rest[0]) : winner;
  const owner = new Map();
  for (const [toName, what] of parts) {
    if (what === 'rest') continue;
    const to = liveByName(g, toName);
    const dest = eligible(to) ? to : restTo;
    if (!dest) continue;
    const names = new Set(what);
    for (const p of list) if (!owner.has(p.id) && names.has(baseName(p))) owner.set(p.id, dest);
  }
  if (rest && restTo) for (const p of list) if (!owner.has(p.id)) owner.set(p.id, restTo);
  const taken = new Set();
  for (const p of list) {
    const to = owner.get(p.id);
    if (!to) continue;
    taken.add(p.id);
    const held = p.props.owner === to.id;
    p.props.owner = to.id; p.props.treaty = true;
    if (p.props.core !== to.id && !held) p.props.comp = 50;
  }
  g.armies = g.armies.filter((a) => !(a.owner === loser.id && taken.has(a.at)));
  return taken.size;
}

// Применяет итог войны r: аннексия / раздел / уступка. Союзники проигравшего в войне остаются (keepHelpers).
function applySettle(g, r, w, l) {
  const onceKey = 'settled_' + r.l;
  if (r.mode === 'cede') w.flags[onceKey] = g.day;
  const parts = r.parts ? r.parts(g, H) : null;
  if (r.mode === 'annex') annexCountry(g, w.id, r.l);
  else if (r.mode === 'cede') { cedeProvinces(g, l.id, w.id, r.n); makePeace(g, w.id, l.id, true); }
  else {
    splitLand(g, l, parts, r.w, r.needWar);
    const left = [...g.world.provinces.values()].some((p) => p.props.owner === l.id);
    if (!left) eliminate(g, l.id, w.id);
    else {
      if (atWar(g, w.id, l.id)) makePeace(g, w.id, l.id, true);
      if (r.mode === 'vassal') vassalize(g, w.id, l.id);
    }
  }
  g.tension = Math.min(100, (g.tension || 0) + 6);
  emit(g, r.note, [w.id, l.id], 'peace');
  economyPreview(g);
}

hooks.settle = (g) => {
  if (!g.historical || g.scenario !== 'europe1936') return;
  for (const r of SETTLE) {
    const w = liveByName(g, r.w), l = liveByName(g, r.l);
    if (!w || !l || !atWar(g, w.id, l.id) || w.overlord != null) continue;
    if (warScore(g, w.id, l.id) < r.min) continue;
    if (r.mode === 'cede' && w.flags['settled_' + r.l] != null) continue; // уступка уже была
    applySettle(g, r, w, l);
  }
};

// Условия победителя навязаны капитулировавшей стороной (перемирие): те же условия, что и при разгроме
export function imposeSettlement(g, winnerName, loserName) {
  const w = liveByName(g, winnerName), l = liveByName(g, loserName);
  if (!w || !l || !atWar(g, w.id, l.id) || w.overlord != null) return false;
  const r = SETTLE.find((x) => x.w === winnerName && x.l === loserName);
  if (!r) return false;
  applySettle(g, r, w, l);
  return true;
}
