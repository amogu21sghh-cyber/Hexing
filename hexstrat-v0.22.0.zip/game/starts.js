// Сценарии «Европа 1939» и «Европа 1941»: готовые снимки истории (создаются tools/make_starts.mjs).
// Карта та же, что в «Европе 1936»; меняются владельцы провинций, страны, армии, войны и союзы.
import { STARTS } from './starts_data.js';

export const START_IDS = ['1939', '1941'];
export const START_LABEL = { 1939: '1 сентября 1939', 1941: '22 июня 1941' };

const clone = (o) => JSON.parse(JSON.stringify(o));

// scen: 'europe1936' | 'europe1939' | 'europe1941' -> { scenario, start }
export function scenarioOf(scen) {
  const m = /^europe(1939|1941)$/.exec(scen || '');
  return m ? { scenario: 'europe1936', start: m[1] } : { scenario: scen, start: null };
}
export const isEurope = (scen) => scen === 'europe1936' || !!scenarioOf(scen).start;

// Накладывает снимок на только что созданную игру «Европа 1936» (до пересчёта статистики)
export function applyStart(g, id, ensureCountry, data) {
  const S = data || STARTS[id];
  if (!S) return false;
  const ps = [...g.world.provinces.values()].sort((a, b) => a.id - b.id);
  if (ps.length !== S.owner.length) return false;
  const extra = new Map(S.extra);
  ps.forEach((p, i) => {
    p.props.owner = S.owner.charCodeAt(i) - 48;
    p.props.core = S.core.charCodeAt(i) - 48;
    p.props.comp = parseInt(S.comp.slice(i * 2, i * 2 + 2), 36);
    p.props.capital = false;
    p.props.built = []; p.props.project = null;
    const e = extra.get(p.id);
    if (e) {
      if (e.built) p.props.built = [...e.built].map((ch) => S.bids[ch.charCodeAt(0) - 48]);
      if (e.project) p.props.project = e.project;
      if (e.air) p.props.air = e.air;
      if (e.treaty) p.props.treaty = e.treaty;
    }
  });
  const old = g.countries; // в снимке бывают страны, возникшие позже (Испания после гражданской войны)
  g.countries = S.countries.map((c, i) => {
    const n = clone(c);
    if (old[i] && old[i].plague) n.plague = old[i].plague;   // эпидемия (мод) живёт своей жизнью с первого дня
    return n;
  });
  for (const c of g.countries) { g.world.provinces.get(c.capital).props.capital = true; ensureCountry(c, g); }
  g.armies = clone(S.armies); g.nextArmyId = S.nextArmyId;
  g.wars = new Map(S.wars); g.warFor = clone(S.warFor);
  g.rel = clone(S.rel); g.factions = clone(S.factions); g.nextFactionId = S.nextFactionId;
  g.evFired = clone(S.evFired); g.claims = clone(S.claims); g.guar = clone(S.guar); g.tension = S.tension;
  g.lend = clone(S.lend); g.trade = []; g.nextDealId = 1; g.justify = []; g.hqs = []; g.offers = [];
  g.pending = clone(S.pending || []); g.nextPendingId = S.nextPendingId || 1; // решения ИИ по событиям дня снимка
  g.log = []; g.logSeq = 0;
  g.day = S.day; g.start = id;
  return true;
}
