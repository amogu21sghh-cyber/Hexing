// Простой ИИ: призыв на границах, объявление войн слабым соседям, наступление там, где перевес.
import { RULES, TERRAIN, ORGS, DIFFICULTY, BUILDINGS, DEPOSITS, TECHS, TECH_BRANCHES, FOCUSES, focusTree, HISTORICAL_FOCUS, LEVEL_EFFECT } from './data.js';
import {
  atWar, prov, peaceRoom, pathCost, inAnyWar, idleArmiesAt, mobAvail, tryDeclareWar, makePeace, startResearch, techState, startDoctrineStep, doctrineStep, setTax, focusState, startFocus, warAge, recruit, orderMove, moveCostFn, refreshStats, canBuild, startBuild, levelOf, maxLevel, buildPrice, provinceDefense, sameFaction, factionOf, opinion, isDemocracy, recalcMods,
} from './state.js';
import { progressEvents } from './events.js';
import { aiTrade } from './trade.js';
import { aiAir, aiAirfieldValue } from './air.js';
import { DEFEATS_READY } from './defeats.js';
import { aiPeace, maybeOfferPeace, foundFaction, inviteToFaction, requestJoin, callToWar, callableEnemies, leaveFaction, joinOrg, orgJoinCheck, joinScore } from './diplomacy.js';

const GARRISON = 4;

// Индексы на время одного хода ИИ: провинции по владельцам и армии по провинциям.
// Без них каждая страна обходила бы все провинции и армии карты.
function buildIndex(g) {
  const own = new Map(), at = new Map();
  for (const p of g.world.provinces.values()) {
    const o = p.props.owner;
    if (o == null) continue;
    let l = own.get(o);
    if (!l) own.set(o, (l = []));
    l.push(p);
  }
  for (const a of g.armies) {
    let l = at.get(a.at);
    if (!l) at.set(a.at, (l = []));
    l.push(a);
  }
  const cnt = new Map();
  for (const a of g.armies) cnt.set(a.owner, (cnt.get(a.owner) || 0) + 1);
  g._own = own; g._at = at; g._atDay = g.day; g._armyCnt = cnt;
}
const ownedBy = (g, id) => g._own.get(id) || [];

export function aiTick(g) {
  refreshStats(g);
  progressEvents(g);
  buildIndex(g);
  for (const c of g.countries) {
    if (!c.alive || c.id === g.playerId) continue;
    if ((g.day + c.id) % 2) continue;
    aiRecruit(g, c);
    aiResearch(g, c);
    aiPolicy(g, c);
    aiBuild(g, c);
    aiAir(g, c);
    aiDiplomacy(g, c);
    aiAlliance(g, c);
    aiTrade(g, c);
    aiOrders(g, c);
  }
}

function neighborsOf(g, owner) {
  // провинции других стран, соседние с нашими
  const out = new Set();
  for (const p of ownedBy(g, owner)) {
    for (const n of p.neighbors) {
      const o = prov(g, n).props.owner;
      if (o != null && o !== owner) out.add(o);
    }
  }
  return out;
}

// Участки границы страны: сколько там угрозы от врагов (вражеские земли рядом + армии у границы) и сколько своих войск.
// Нужен и призыву, и перегруппировке: иначе всё уходит на один фронт, а на втором нет ни одного отряда.
function frontOf(g, c, enemies) {
  const out = [];
  for (const p of ownedBy(g, c.id)) {
    let t = 0;
    for (const n of p.neighbors) {
      const o = prov(g, n).props.owner;
      const es = enemyStrengthAt(g, c.id, n);
      if (o != null && enemies.has(o)) t += 2 + es;
      else if (es > 0) t += es;
    }
    if (t <= 0) continue;
    let have = 0;
    const l = g._at.get(p.id);
    if (l) for (const a of l) if (a.owner === c.id) have += a.strength;
    out.push({ pid: p.id, threat: t, have });
  }
  return out;
}

function aiRecruit(g, c) {
  // потолок числа отрядов: иначе поздняя игра тонет в тысячах мелких армий
  // сверх потолка новых отрядов не создаём, но пополняем уже стоящие: иначе страна, начавшая с большим числом армий
  // (Германия, Польша), навсегда перестаёт призывать и отстаёт от остальных
  const over = (g._armyCnt.get(c.id) || 0) > (25 + ownedBy(g, c.id).length * 0.12) * (inAnyWar(g, c.id) ? 3 : 1);
  let cache = c._spots;
  const enemies = new Set(g.countries.filter((o) => o.alive && atWar(g, c.id, o.id)).map((o) => o.id));
  if (!cache || g.day - cache.day >= 8 || g.day < cache.day || cache.wars !== enemies.size || cache.over !== over) {
    const spots = [];
    // приоритет участкам, где войск меньше всего относительно угрозы: армия не копится на одном фронте
    const have = new Map(), thr = new Map();
    for (const f of frontOf(g, c, enemies)) { have.set(f.pid, f.have); thr.set(f.pid, f.threat); }
    for (const p of ownedBy(g, c.id)) {
      let w = 0;
      for (const n of p.neighbors) {
        const o = prov(g, n).props.owner;
        if (o === c.id || o == null) continue;
        w += enemies.has(o) ? 3 : sameFaction(g, c.id, o) ? 0.1 : 0.6;
      }
      if (over && !idleArmiesAt(g, c.id, p.id).length) continue;
      if (w > 0) spots.push([p.id, w / (1 + (have.get(p.id) || 0) / 6) + (thr.get(p.id) || 0) * 0.05]);
    }
    if (!spots.length && !over) spots.push([c.capital, 1]);
    if (!spots.length) return;
    cache = { day: g.day, wars: enemies.size, over, spots, total: spots.reduce((s, x) => s + x[1], 0) };
    Object.defineProperty(c, '_spots', { value: cache, writable: true, configurable: true, enumerable: false });
  }
  let spots = cache.spots, total = cache.total;
  let guard = 0, fails = 0;
  // для массового призыва один раз считаем остаток лимита, занятые боем места и свободные армии (иначе каждая пачка — проход по всем армиям)
  const busy = new Set(), idle = new Map();
  for (const a of g.armies) {
    if (a.owner !== c.id) { if (atWar(g, c.id, a.owner)) busy.add(a.at); }
    else if (!a.order && !idle.has(a.at)) idle.set(a.at, a);
  }
  const opts = { room: peaceRoom(g, c.id), busy, idle };
  while (c.manpower >= RULES.recruitManpower && c.gold >= RULES.recruitGold + 2 && mobAvail(g, c.id) >= 1 && guard++ < 120 && spots.length) {
    let r = g.rng() * total, pid = spots[0][0];
    for (const [id, w] of spots) { r -= w; if (r <= 0) { pid = id; break; } }
    const res = recruit(g, c.id, pid, 1, opts);
    if (res.ok) continue;
    // место занято боем или недоступно: пробуем другие, а не бросаем призыв (иначе на горящем фронте страна не призывает вовсе)
    if (++fails > 12) break;
    spots = spots.filter(([id]) => id !== pid); total = spots.reduce((s, x) => s + x[1], 0);
    c._spots = null;
  }
}

// ИИ тратит золото на постройки: смотрит на случайную выборку своих провинций и берёт самую выгодную.
function aiBuild(g, c) {
  const reserve = 250;
  if (c.gold < reserve + 200) return;
  const enemies = new Set(g.countries.filter((o) => o.alive && atWar(g, c.id, o.id)).map((o) => o.id));
  const mine = [];
  for (const p of ownedBy(g, c.id)) if (!p.props.project) mine.push(p);
  let best = null, bestScore = 0;
  for (let i = 0; i < 25 && mine.length; i++) {
    const p = mine[Math.floor(g.rng() * mine.length)];
    const front = p.neighbors.some((n) => enemies.has(prov(g, n).props.owner));
    for (const [bid, b] of Object.entries(BUILDINGS)) {
      const lv = levelOf(p, bid);
      if (lv >= maxLevel(bid)) continue;
      const price = buildPrice(g, c.id, bid, p.id)[0];
      if (c.gold - price < reserve) continue;
      const e = b.effect;
      // прирост эффекта от следующего уровня относительно предыдущего
      const dk = LEVEL_EFFECT[Math.min(lv, LEVEL_EFFECT.length - 1)] - (lv ? LEVEL_EFFECT[lv - 1] : 0);
      let value = 0;
      if (e.goldMul) value = p.props.wealth * (e.goldMul - 1) * 365 * dk;
      if (e.goldAdd) value = e.goldAdd * 365 * dk;
      if (e.menAdd) value = e.menAdd * 365 * 5 * dk;
      if (e.indAdd) value = e.indAdd * 365 * 0.5 * dk;
      if (e.resAdd) value = e.resAdd * 365 * 1.2 * dk;
      if (e.fuelMul) value = p.props.deposit ? DEPOSITS[p.props.deposit].fuel * 365 * 0.25 * dk : 0;
      if (e.defAdd) value = front ? 2500 * dk : 0;
      if (e.moveMul) value = front ? 300 * dk : 0;
      if (bid === 'port') {
        // порты нужны немногим: у береговых стран с морскими целями; больше при войне
        const have = (g._ports || []).filter((x) => prov(g, x.pid).props.owner === c.id);
        const cap = enemies.size ? 4 : 2;
        value = g.world.isCoastal(p.id) && (lv > 0 ? have.length >= 1 : have.length < cap) ? (enemies.size ? 900 : 350) * dk : 0;
      }
      if (bid === 'airfield') value = aiAirfieldValue(g, c, p, lv, front) * dk;
      const score = value / price;
      if (score > bestScore && canBuild(g, c.id, p.id, bid).ok) { bestScore = score; best = [p.id, bid]; }
    }
  }
  if (best) startBuild(g, c.id, best[0], best[1]);
}

// ИИ изучает технологии: на войне предпочитает армию, в мире экономику. Слот ветки занят, пока идёт изучение.
function aiResearch(g, c) {
  // доктрина: ступень берётся, как только хватает очков (на войне чаще)
  if (c.doctrine && !c.doctrine.step && c.doctrine.lvl < 3 && doctrineStep(g, c.id).st === 'ready' && g.rng() < 0.5) startDoctrineStep(g, c.id);
  const war = [...g.wars.keys()].some((k) => k.split('|').map(Number).includes(c.id));
  const weight = war ? { eco: 1, pol: 0.7, mil: 1.6, air: 1.1, sci: 0.9 } : { eco: 1.5, pol: 1, mil: 0.7, air: 0.5, sci: 1.2 };
  let enemyTerrain = null;
  for (const [branch] of TECH_BRANCHES) {
    if (c.slots[branch]) continue;
    if (branch === 'mil' && war && !enemyTerrain) {
      // снаряжение для рельефа нужнее, если у врагов много такой земли
      enemyTerrain = { forest: 0, hills: 0, mountains: 0, desert: 0 };
      for (const p of g.world.provinces.values()) {
        const o = p.props.owner;
        if (o != null && o !== c.id && atWar(g, c.id, o) && p.props.terrain in enemyTerrain) enemyTerrain[p.props.terrain]++;
      }
    }
    let best = null, bs = -1;
    for (const [id, t] of Object.entries(TECHS)) {
      if (t.branch !== branch || techState(g, c.id, id).st !== 'ready') continue;
      let k = 1;
      if (enemyTerrain) for (const [terr, n] of Object.entries(enemyTerrain)) if (t.effect[TERRAIN[terr].gear] && n > 3) k = Math.max(k, 1 + Math.min(1.2, n / 25));
      const score = weight[branch] * k * (0.8 + g.rng() * 0.4) / t.tier;
      if (score > bs) { bs = score; best = id; }
    }
    if (best) startResearch(g, c.id, best);
  }
}

// Внутренняя политика ИИ: налог по стабильности и казне, национальные фокусы за запас власти (на войну оставляет резерв).
// Исторический режим: ИИ берёт территориальные фокусы хроники так, чтобы они завершились к исторической дате.
// Недостающие предпосылки засчитываются, текущий обычный фокус прерывается, нехватка власти покрывается.
function aiHistoricalFocus(g, c) {
  const tree = focusTree(c.base || c.name, c.ideo0);
  if (c.focus && HISTORICAL_FOCUS.includes(c.focus.id)) return true; // уже идёт исторический
  for (const id of HISTORICAL_FOCUS) {
    if (!tree.includes(id) || c.focuses.includes(id)) continue;
    const f = FOCUSES[id];
    const saved = c.focus;
    c.focus = null;
    const grant = (fid) => { for (const r of FOCUSES[fid].req) if (!c.focuses.includes(r)) { grant(r); c.focuses.push(r); } };
    let s = focusState(g, c.id, id);
    if (s.st === 'locked' && f.req.some((r) => !c.focuses.includes(r)) && !(f.excl || []).some((x) => c.focuses.includes(x))) {
      const before = c.focuses.length;
      grant(id);
      s = focusState(g, c.id, id);
      if (s.st === 'locked') c.focuses.length = before;
    }
    if (s.st === 'short' || s.st === 'ready') {
      c.pp = Math.max(c.pp, f.cost);
      if (startFocus(g, c.id, id).ok) { recalcMods(c); return true; }
    }
    c.focus = saved;
  }
  return false;
}

function aiPolicy(g, c) {
  if (c.stability < 50 && c.tax > 1) setTax(g, c.id, c.tax - 1);
  else if (c.stability > 75 && c.gold < 400 && c.tax < 3) setTax(g, c.id, c.tax + 1);
  else if (c.stability > 70 && c.tax < 2) setTax(g, c.id, c.tax + 1);
  if (g.plague && g.plague.started && !g.plague.ended && !c.focus && (g.plague.worldI >= 2 || (c.plague && c.plague.i >= 1)) && g.rng() < 0.3) { // эпидемия: ИИ в первую очередь разрабатывает вакцину
    const pf = focusTree(c.base || c.name, c.ideo0).find((id) => FOCUSES[id].act && FOCUSES[id].act.plague && focusState(g, c.id, id).st === 'ready' && c.pp >= FOCUSES[id].cost);
    if (pf) { startFocus(g, c.id, pf); return; }
  }
  if (g.historical && g.scenario === 'europe1936' && aiHistoricalFocus(g, c)) return;
  if (c.focus) return;
  const war = [...g.wars.keys()].some((k) => k.split('|').map(Number).includes(c.id));
  let best = null, bs = -1;
  const ideoOk = !g.historical && g.rng() < 0.004; // смена строя ИИ: редко и только в свободном режиме
  for (const id of focusTree(c.base || c.name, c.ideo0)) {
    const f = FOCUSES[id];
    if (focusState(g, c.id, id).st !== 'ready' || c.pp < f.cost + RULES.warPP * 0.5) continue;
    if (f.ideo && !ideoOk && !c.focuses.some((x) => FOCUSES[x].ideo === f.ideo)) continue;
    if (f.alt && (g.historical || g.rng() > 0.35)) continue; // в историческом режиме ИИ не выбирает альтернативную историю
    const e = f.effect;
    const score = (1 + (war ? (e.attack || 0) * 8 + (e.defense || 0) * 8 : (e.gold || 0) * 6 + (e.ind || 0) * 6) + (e.stab && c.stability < 60 ? 0.5 : 0)) * (0.8 + g.rng() * 0.4);
    if (score > bs) { bs = score; best = id; }
  }
  if (best) startFocus(g, c.id, best);
}

function aiDiplomacy(g, c) {
  if (g.day < 60) return;
  const D = DIFFICULTY[g.difficulty ?? 1];
  const foes = g.countries.filter((o) => o.alive && atWar(g, c.id, o.id));
  const pl = foes.find((o) => o.id === g.playerId);
  if (pl) maybeOfferPeace(g, c, pl);
  // затяжные войны между ИИ иногда заканчиваются миром, чтобы карта не застывала
  for (const o of foes) {
    if (o.id !== g.playerId && warAge(g, c.id, o.id) > 100 && g.rng() < 0.06) { aiPeace(g, c.id, o.id); return; }
  }
  if (c.overlord != null || (isDemocracy(g, c) && g.tension < RULES.demWar)) return;
  if (g.historical) return; // исторический режим: войны начинаются только по хронике событий
  if (foes.length >= 1 || g.rng() > 0.05) return;
  const mine = g.stats[c.id].troops;
  let target = null, tt = Infinity;
  for (const o of neighborsOf(g, c.id)) {
    if (!g.countries[o].alive || sameFaction(g, c.id, o)) continue;
    if (o === g.playerId && g.day < D.warDay) continue;
    const t = g.stats[o].troops;
    if (t < tt) { tt = t; target = o; }
  }
  if (target != null && mine > tt * (target === g.playerId ? D.ratio : 1.1)) tryDeclareWar(g, c.id, target);
}

// Союзы и организации: ИИ вступает в организации, основывает альянсы, приглашает друзей и зовёт их воевать.
// Идеологическая совместимость для блоков: фашисты, демократы и коммунисты в один блок не идут, авторитарные — кроме коммунистов
const ideoMix = (a, b) => a === b || (a === 'aut' && b !== 'com') || (b === 'aut' && a !== 'com');
function aiAlliance(g, c) {
  if (g.day < 20) return;
  const f = factionOf(g, c);
  // призыв союзников в свои войны (лидер)
  if (!g.historical && f && f.leader === c.id && c.pp >= RULES.callPP && g.rng() < 0.3) {
    for (const m of f.members) {
      if (m === c.id || m === g.playerId) continue;
      if (callableEnemies(g, c.id, m).length) { callToWar(g, c.id, m); break; }
    }
  }
  if (g.rng() > (g.historical ? 0.04 : 0.012)) return;
  // организации: вступаем, если есть что взять
  if (c.pp >= RULES.orgPP + 20 && g.scenario === 'europe1936') {
    for (const oid of Object.keys(ORGS)) {
      if (g.historical && oid === 'anticomintern') continue; // в историческом режиме вступления в пакт идут событиями по датам
      if (c.orgs.includes(oid) || !orgJoinCheck(g, c.id, oid).ok) continue;
      joinOrg(g, c.id, oid);
      break;
    }
  }
  // исторический режим: блоки возникают только из событий; в свободном их мало и они небольшие
  if (g.historical) return;
  if (!f) {
    // лучший друг: просимся к нему, либо основываем свой блок при сильной дружбе
    let best = null, bv = RULES.inviteMin;
    for (const o of g.countries) {
      if (!o.alive || o.id === c.id) continue;
      const of = factionOf(g, o);
      if (of && (of.members.length >= 6 || !ideoMix(c.ideo, g.countries[of.leader].ideo))) continue;
      if (!of && !ideoMix(c.ideo, o.ideo)) continue;
      const v = opinion(g, c.id, o.id);
      if (v > bv) { bv = v; best = o; }
    }
    if (!best) return;
    const bf = factionOf(g, best);
    if (bf) requestJoin(g, c.id, bf.id);
    else if (c.pp >= RULES.factionPP + 20 && (c.power ?? 1) >= 1 && g.factions.length < 3 && g.stats[c.id].troops >= g.stats[best.id].troops) {
      if (foundFaction(g, c.id).ok) inviteToFaction(g, c.id, best.id);
    }
  } else if (f.leader === c.id && c.pp >= RULES.invitePP + 10 && f.members.length < 6) {
    for (const o of g.countries) {
      if (!o.alive || o.faction != null || o.id === g.playerId || !ideoMix(o.ideo, c.ideo)) continue;
      if (joinScore(g, o.id, f) >= RULES.inviteMin + 5) { inviteToFaction(g, c.id, o.id); break; }
    }
  } else if (f.leader !== c.id && opinion(g, c.id, f.leader) < -10) leaveFaction(g, c.id);
}

function enemyStrengthAt(g, me, pid) {
  let s = 0;
  const l = g._at.get(pid);
  if (l) for (const a of l) if (atWar(g, me, a.owner)) s += a.strength;
  return s;
}

function aiOrders(g, c) {
  const enemies = new Set(g.countries.filter((o) => o.alive && atWar(g, c.id, o.id)).map((o) => o.id));
  if (!enemies.size) return;
  const cost = moveCostFn(g, c.id);
  const byProv = new Map();
  for (const [at, list] of g._at) {
    for (const a of list) {
      if (a.owner !== c.id || a.order || a.rebel) continue;
      byProv.set(at, (byProv.get(at) || 0) + a.strength);
    }
  }
  const fronts = frontOf(g, c, enemies);
  const holes = fronts.filter((f) => f.have < f.threat * 0.8 + GARRISON).sort((a, b) => (b.threat - b.have) - (a.threat - a.have));
  for (const [pid, total] of byProv) {
    const p = prov(g, pid);
    let best = null, bestScore = -Infinity, onFront = false;
    for (const nid of p.neighbors) {
      const np = prov(g, nid);
      const enemyOwned = enemies.has(np.props.owner);
      const es = enemyStrengthAt(g, c.id, nid);
      if (!enemyOwned && es === 0) continue;
      onFront = true;
      const def = enemyOwned ? provinceDefense(np, g) : 1;
      const need = es * def * 1.25 + 1;
      const free = total - GARRISON;
      if (free > need && cost(np, p) !== Infinity) {
        const score = np.props.wealth + (np.props.capital ? 5 : 0) - es * 0.1;
        if (score > bestScore) { bestScore = score; best = np; }
      }
    }
    if (best) {
      orderMove(g, c.id, pid, best.id, (total - GARRISON) / total);
    } else if (!onFront && total >= 6 && holes.length && (g.day + pid) % 3 === 0 && !holes.some((h) => h.pid === pid)) {
      // переброска в самый слабый участок фронта, пока там пусто (в том числе вторую границу, например запад при войне на востоке)
      for (const h of holes.slice(0, 3)) {
        const res = g.world.findPath(pid, (q) => q.id === h.pid, cost, 60); // слишком далёкие участки не рассматриваем
        if (res && res.path.length >= 2) {
          const sub = res.path.slice(0, Math.min(res.path.length - 1, 3) + 1);
          orderMove(g, c.id, pid, sub[sub.length - 1], 1, { path: sub, cost: pathCost(g, c.id, pid, sub) });
          h.have += total * 0.5;
          break;
        }
      }
    } else if (!onFront && total >= 8 && (g.day + pid) % 5 === 0) {
      // поиск пути через всю карту дорог: для каждой провинции не чаще раза в 5 дней
      const res = g.world.findPath(pid, (q) => enemies.has(q.props.owner), cost);
      if (res && res.path.length >= 2) {
        const sub = res.path.slice(0, -1);
        orderMove(g, c.id, pid, sub[sub.length - 1], 1, { path: sub, cost: pathCost(g, c.id, pid, sub) });
      }
    }
  }
}
