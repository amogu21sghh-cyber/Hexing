// Звук без файлов: эффекты и музыка синтезируются Web Audio прямо в браузере.
// Музыка генеративная: медленные аккорды и редкие ноты мелодии в мирное время, в войне добавляются
// барабаны, тембр темнеет, темп растёт. Настройки хранятся в localStorage (если доступен).

const KEY = 'hexstrat_audio_v1';
const cfg = { music: 0.55, sfx: 0.8, on: true };
try { Object.assign(cfg, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (_) { /* без сохранения */ }
const saveCfg = () => { try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch (_) { /* ничего */ } };

let ctx = null, master = null, musicBus = null, sfxBus = null, verb = null, noiseBuf = null;
let mood = { war: 0, fight: 0, menu: true };   // war 0..1 — напряжённость, fight — идёт бой
let timer = null, nextBeat = 0, beat = 0, bar = 0;

const hz = (m) => 440 * Math.pow(2, (m - 69) / 12);
// Ре минор (гармонический): i, VI, iv, V — как «тревожный марш»
const PROG = [[50, 53, 57], [46, 50, 53], [43, 46, 50], [45, 49, 52]];
const MEL = [62, 64, 65, 67, 69, 70, 73, 74];

export function unlock() {
  if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return;
  try {
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = cfg.on ? 1 : 0; master.connect(ctx.destination);
    musicBus = ctx.createGain(); musicBus.gain.value = cfg.music * 0.5; musicBus.connect(master);
    sfxBus = ctx.createGain(); sfxBus.gain.value = cfg.sfx; sfxBus.connect(master);
    // шумовой буфер и простая реверберация из затухающего шума
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 1.5, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    const ir = ctx.createBuffer(2, ctx.sampleRate * 2.2, ctx.sampleRate);
    for (let c = 0; c < 2; c++) { const a = ir.getChannelData(c); for (let i = 0; i < a.length; i++) a[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / a.length, 2.6); }
    verb = ctx.createConvolver(); verb.buffer = ir;
    const vg = ctx.createGain(); vg.gain.value = 0.55; verb.connect(vg); vg.connect(musicBus);
    nextBeat = ctx.currentTime + 0.2;
    timer = setInterval(schedule, 120);
    document.addEventListener('visibilitychange', () => { if (!ctx) return; if (document.hidden) ctx.suspend(); else ctx.resume(); });
  } catch (_) { ctx = null; }
}

function tone(type, freq, t, dur, vol, dest, opts = {}) {
  const o = ctx.createOscillator(), g = ctx.createGain();
  o.type = type; o.frequency.setValueAtTime(freq, t);
  if (opts.to) o.frequency.exponentialRampToValueAtTime(opts.to, t + dur);
  if (opts.detune) o.detune.value = opts.detune;
  const a = opts.attack ?? 0.01;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(vol, t + a);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  let out = o;
  if (opts.lp) { const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = opts.lp; o.connect(f); out = f; }
  out.connect(g); g.connect(dest);
  if (opts.verb) { const s = ctx.createGain(); s.gain.value = opts.verb; g.connect(s); s.connect(verb); }
  o.start(t); o.stop(t + dur + 0.05);
}

function noise(t, dur, vol, dest, opts = {}) {
  const s = ctx.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
  const f = ctx.createBiquadFilter(); f.type = opts.type || 'bandpass'; f.frequency.value = opts.freq || 1500; f.Q.value = opts.q || 0.8;
  if (opts.sweep) f.frequency.exponentialRampToValueAtTime(opts.sweep, t + dur);
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + (opts.attack ?? 0.005)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  s.connect(f); f.connect(g); g.connect(dest);
  s.start(t, Math.random()); s.stop(t + dur + 0.05);
}

function pad(t, notes, dur, dark) {
  for (const n of notes) {
    for (const dt of [-7, 7]) tone('sawtooth', hz(n), t, dur, 0.05, musicBus, { attack: dur * 0.35, detune: dt, lp: dark ? 520 : 900, verb: 0.5 });
  }
  tone('sine', hz(notes[0] - 12), t, dur, 0.16, musicBus, { attack: dur * 0.2 });
}

function schedule() {
  if (!ctx || ctx.state !== 'running') return;
  const war = mood.war, bpm = 54 + war * 28 + (mood.fight ? 8 : 0);
  const spb = 60 / bpm;
  while (nextBeat < ctx.currentTime + 0.6) {
    const t = nextBeat, chord = PROG[bar % 4];
    if (beat % 4 === 0) pad(t, chord, spb * 4.2, war > 0.3);
    // мелодия: редкие щипковые ноты, ближе к войне — чаще и ниже
    if (!mood.menu || beat % 2 === 0) {
      const p = 0.22 + war * 0.15;
      if (Math.random() < p) {
        const n = MEL[Math.floor(Math.random() * MEL.length)] - (war > 0.5 ? 12 : 0);
        tone('triangle', hz(n), t + Math.random() * spb * 0.4, 1.6, 0.12, musicBus, { attack: 0.01, verb: 0.9 });
      }
    }
    // барабаны в войне: глухой «там-там» каждую долю, акцент на первой, дробь в бою
    if (war > 0.25) {
      tone('sine', 90, t, 0.35, 0.5 * war + 0.15, musicBus, { to: 38, attack: 0.002 });
      if (beat % 2 === 1) noise(t, 0.12, 0.12 * war, musicBus, { freq: 1800, q: 1.2 });
      if (mood.fight) { noise(t + spb / 2, 0.08, 0.09, musicBus, { freq: 2400, q: 1 }); tone('sine', 70, t + spb / 2, 0.25, 0.3, musicBus, { to: 36, attack: 0.002 }); }
    }
    nextBeat += spb; beat++;
    if (beat % 4 === 0) bar++;
  }
}

// ---------- эффекты ----------
const lastAt = {};
function gate(name, ms) { const n = performance.now(); if (lastAt[name] && n - lastAt[name] < ms) return false; lastAt[name] = n; return true; }

const FX = {
  click: (t) => { tone('square', 880, t, 0.05, 0.07, sfxBus, { to: 1200, lp: 3000 }); },
  open: (t) => { tone('triangle', 520, t, 0.12, 0.1, sfxBus, { to: 780 }); },
  back: (t) => { tone('triangle', 640, t, 0.1, 0.09, sfxBus, { to: 400 }); },
  select: (t) => { tone('sine', 700, t, 0.07, 0.08, sfxBus); },
  order: (t) => { tone('square', 330, t, 0.07, 0.07, sfxBus, { lp: 1800 }); tone('square', 495, t + 0.07, 0.09, 0.07, sfxBus, { lp: 1800 }); },
  recruit: (t) => { noise(t, 0.09, 0.2, sfxBus, { freq: 700 }); tone('square', 220, t + 0.05, 0.12, 0.08, sfxBus, { lp: 1200 }); },
  build: (t) => { for (let i = 0; i < 3; i++) { noise(t + i * 0.11, 0.07, 0.25, sfxBus, { freq: 2200, q: 2 }); tone('triangle', 180, t + i * 0.11, 0.08, 0.15, sfxBus, { to: 90 }); } },
  event: (t) => { [0, 4, 7].forEach((n, i) => tone('triangle', hz(67 + n), t + i * 0.12, 0.9, 0.12, sfxBus, { verb: 0.6 })); },
  tech: (t) => { [72, 76, 79, 84].forEach((n, i) => tone('sine', hz(n), t + i * 0.09, 0.5, 0.1, sfxBus, { verb: 0.5 })); },
  focus: (t) => { [67, 72, 76].forEach((n, i) => tone('triangle', hz(n), t + i * 0.14, 0.8, 0.12, sfxBus, { verb: 0.7 })); },
  war: (t) => { tone('sawtooth', hz(38), t, 1.6, 0.25, sfxBus, { to: hz(34), attack: 0.4, lp: 400 }); tone('sawtooth', hz(45), t, 1.6, 0.18, sfxBus, { attack: 0.4, lp: 400 }); noise(t, 1.2, 0.12, sfxBus, { freq: 200, type: 'lowpass', attack: 0.3 }); },
  peace: (t) => { [69, 74, 78].forEach((n, i) => tone('sine', hz(n), t + i * 0.2, 1.4, 0.13, sfxBus, { verb: 0.9 })); },
  alliance: (t) => { tone('triangle', hz(64), t, 0.5, 0.11, sfxBus, { verb: 0.5 }); tone('triangle', hz(71), t + 0.16, 0.7, 0.11, sfxBus, { verb: 0.5 }); },
  capture: (t) => { [62, 66, 69, 74].forEach((n, i) => { tone('sawtooth', hz(n), t + i * 0.1, 0.5, 0.08, sfxBus, { lp: 1500 }); }); noise(t, 0.2, 0.1, sfxBus, { freq: 900 }); },
  fall: (t) => { tone('sawtooth', hz(45), t, 2.4, 0.22, sfxBus, { to: hz(33), lp: 500 }); noise(t, 1.6, 0.1, sfxBus, { freq: 300, type: 'lowpass' }); },
  offer: (t) => { tone('triangle', hz(76), t, 0.3, 0.1, sfxBus, { verb: 0.5 }); tone('triangle', hz(76), t + 0.22, 0.4, 0.1, sfxBus, { verb: 0.5 }); },
  battle: (t) => { noise(t, 0.5, 0.14, sfxBus, { freq: 500, q: 0.6, attack: 0.05 }); tone('sine', 60, t, 0.4, 0.2, sfxBus, { to: 35, attack: 0.01 }); noise(t + 0.2, 0.06, 0.12, sfxBus, { freq: 3000, q: 2 }); },
  error: (t) => { tone('square', 160, t, 0.15, 0.09, sfxBus, { lp: 700 }); },
};
const THROTTLE = { click: 40, select: 60, battle: 1800, build: 400, war: 800 };

export function sfx(name) {
  if (!ctx || !cfg.on || ctx.state !== 'running' || !FX[name]) return;
  if (!gate(name, THROTTLE[name] || 120)) return;
  FX[name](ctx.currentTime + 0.01);
}

// ---------- управление ----------
export function setMood(m) { Object.assign(mood, m); }
const apply = () => {
  if (!ctx) return;
  master.gain.value = cfg.on ? 1 : 0;
  musicBus.gain.value = cfg.music * 0.5;
  sfxBus.gain.value = cfg.sfx;
};
export const audioCfg = () => ({ ...cfg });
export function setAudio(k, v) { cfg[k] = v; saveCfg(); apply(); }
export function stopAudio() { if (timer) clearInterval(timer); timer = null; }
