// Штабы: игрок задаёт армиям тактику, а штаб сам отдаёт приказы. Работает раз в два дня на штаб.
// Задачи: наступление на страну (сосредоточение, выбор слабого места, натиск к столице),
// оборона рубежа (распределение по угрозе, отход и контрудар), гарнизон (подчинение оккупированных земель).
import { RULES } from './data.js';
import { prov, atWar, previewPath, seaGap, provinceDefense, friendly, hooks, emit, addArmy } from './state.js';

export const HQ_MISSIONS = [['attack', 'Наступление'], ['defend', 'Оборона'], ['garrison', 'Гарнизон']];
export const HQ_AGGR = [[0, 'Осторожно', 1.8], [1, 'Взвешенно', 1.2], [2, 'Агрессивно', 0.8]];
export const HQ_RETREAT = [[0, 'Не отступать', 0], [1, 'При 30%', 30], [2, 'При 50%', 50]];
export const HQ_SPLIT = [[1, 'Делить армии'], [0, 'Не делить']];
export const HQ_MAX = 6;
export const MIN_PART = 15;   // меньше такой части штаб от армии не отделяет
const MANUAL_LOCK = 6;   // после ручного приказа штаб не трогает армию столько дней
const orgOf = (a) => (a.org == null ? 100 : a.org);

const fail = (msg) => ({ ok: false, msg });

export function createHQ(g, owner) {
  g.hqs = g.hqs || [];
  const mine = g.hqs.filter((h) => h.owner === owner);
  if (mine.length >= HQ_MAX) return fail(`Не больше ${HQ_MAX} штабов`);
  const id = g.hqs.reduce((m, h) => Math.max(m, h.id), 0) + 1;
  const hq = { id, owner, name: `Штаб ${mine.length + 1}`, mission: 'attack', target: null, aggr: 1, retreat: 1, mass: true, split: 1, phase: 'mass', status: 'Ждёт приказов' };
  g.hqs.push(hq);
  return { ok: true, hq };
}

export function removeHQ(g, id) {
  for (const a of g.armies) if (a.hq === id) delete a.hq;
  g.hqs = (g.hqs || []).filter((h) => h.id !== id);
}

export const hqById = (g, id) => (g.hqs || []).find((h) => h.id === id) || null;
export const hqArmies = (g, id) => g.armies.filter((a) => a.hq === id);
export const hqStrength = (g, id) => hqArmies(g, id).reduce((s, a) => s + a.strength, 0);

export function assignAll(g, id, owner) {
  let n = 0;
  for (const a of g.armies) if (a.owner === owner && a.hq == null) { a.hq = id; n++; }
  return n;
}
export function assignAt(g, id, owner, pid) {
  let n = 0;
  for (const a of g.armies) if (a.owner === owner && a.at === pid) { a.hq = id; n++; }
  return n;
}
export function clearArmies(g, id) { for (const a of g.armies) if (a.hq === id) delete a.hq; }

// ---------- вспомогательное ----------
function enemyMap(g, owner) {
  const m = new Map();
  for (const a of g.armies) {
    if (a.owner === owner || !atWar(g, owner, a.owner)) continue;
    let e = m.get(a.at);
    if (!e) { e = { str: 0, org: 0, dig: 0 }; m.set(a.at, e); }
    e.str += a.strength; e.org += orgOf(a) * a.strength; e.dig += (a.dig || 0) * a.strength;
  }
  for (const e of m.values()) { e.org /= Math.max(1, e.str); e.dig /= Math.max(1, e.str); }
  return m;
}

function step(g, a, toId) {
  const res = previewPath(g, a.owner, a.at, toId);
  if (!res || !res.path.length) return false;
  a.order = { path: res.path.slice(), progress: 0 };
  return true;
}

// один шаг к смежной провинции (для атаки: решение пересматривается каждые два дня)
function stepOne(g, a, toId) {
  const res = previewPath(g, a.owner, a.at, toId);
  if (!res || !res.path.length) return false;
  a.order = { path: [res.path[0]], progress: 0 };
  return true;
}

const neigh = (g, pid) => prov(g, pid).neighbors;
const isMine = (g, owner, pid) => friendly(g, owner, prov(g, pid).props.owner ?? -1) || prov(g, pid).props.owner === owner;

// Ближайшая безопасная провинция для отхода: своя, без врага, лучше без вражеских соседей
function safeSpot(g, a, enemy) {
  let frontier = [a.at];
  const seen = new Set(frontier);
  let fallback = null;
  for (let d = 0; d < 6; d++) {
    const next = [];
    for (const id of frontier) for (const nb of neigh(g, id)) {
      if (seen.has(nb)) continue;
      seen.add(nb); next.push(nb);
      const own = prov(g, nb).props.owner === a.owner || (prov(g, nb).props.owner != null && friendly(g, a.owner, prov(g, nb).props.owner));
      if (!own || enemy.has(nb)) continue;
      if (!neigh(g, nb).some((x) => enemy.has(x))) return nb;
      if (fallback == null) fallback = nb;
    }
    frontier = next;
  }
  return fallback;
}

function capDist(g, capId) {
  const dist = new Map([[capId, 0]]);
  let frontier = [capId];
  while (frontier.length) {
    const next = [];
    for (const id of frontier) for (const nb of neigh(g, id)) if (!dist.has(nb)) { dist.set(nb, dist.get(id) + 1); next.push(nb); }
    frontier = next;
  }
  return dist;
}

function groupsOf(armies) {
  const m = new Map();
  for (const a of armies) {
    let x = m.get(a.at);
    if (!x) { x = { at: a.at, armies: [], str: 0, org: 0 }; m.set(a.at, x); }
    x.armies.push(a); x.str += a.strength; x.org += orgOf(a) * a.strength;
  }
  for (const x of m.values()) x.org /= Math.max(1, x.str);
  return [...m.values()];
}

const defOf = (g, pid, enemy) => {
  const p = prov(g, pid), e = enemy.get(pid);
  return provinceDefense(p, g) * (1 + RULES.digBonus * (e ? e.dig : 0));
};


// ---------- деление армий ----------
const splitOn = (hq) => hq.split !== 0;

// Отделяет от армии часть силой amount и возвращает новую армию с теми же организацией, окопами и штабом.
// Если остаток вышел бы меньше MIN_PART (или часть меньше MIN_PART и берётся минимум), делит без остатка: возвращает саму армию.
function detach(g, a, amount) {
  amount = Math.max(MIN_PART, Math.round(amount));
  if (a.strength - amount < MIN_PART) return a;
  const part = addArmy(g, a.owner, a.at, amount);
  a.strength -= amount;
  part.org = a.org; part.dig = a.dig; part.hq = a.hq; part.coolUntil = a.coolUntil;
  if (a.landed != null) part.landed = a.landed;
  return part;
}

// Набирает из пула армий отряд суммарной силой около force (последнюю армию делит); взятые армии убирает из пула
function takeForce(g, pool, force) {
  const out = [];
  let got = 0;
  while (pool.length && got < force - 0.5) {
    const a = pool[0], need = force - got;
    if (a.strength <= need + MIN_PART) { out.push(a); got += a.strength; pool.shift(); continue; }
    const part = detach(g, a, need);
    out.push(part); got += part.strength;
    if (part === a) pool.shift();
    break;
  }
  return out;
}

// Раздаёт армию по участкам с нехваткой сил (рубеж, граница). С делением отправляет на каждый участок ровно
// нужную часть; без деления — армию целиком, если нехватка не меньше трети её силы. Возвращает число отправленных отрядов.
function deploy(g, hq, a, front, desired, cur, frontIds) {
  const here = a.at, split = splitOn(hq), onFront = frontIds.has(here);
  const surplus = onFront ? cur.get(here) - desired.get(here) : Infinity;
  let movable = a.strength;
  if (split) {
    if (onFront) movable = Math.min(a.strength, surplus);
    if (movable < MIN_PART) return 0;
  } else if (onFront && surplus < a.strength * 0.6) return 0;
  const gaps = front.filter((f) => f.id !== here).map((f) => ({ id: f.id, def: desired.get(f.id) - cur.get(f.id) }))
    .filter((f) => f.def > (split ? MIN_PART : a.strength * 0.35)).sort((x, y) => y.def - x.def);
  let sent = 0;
  for (const f of gaps) {
    if (movable < MIN_PART && sent) break;
    if (!previewPath(g, a.owner, here, f.id)) continue;
    const part = split ? Math.min(movable, f.def) : a.strength;
    const mover = split ? detach(g, a, part) : a;
    if (!step(g, mover, f.id)) { continue; }
    if (onFront) cur.set(here, cur.get(here) - mover.strength);
    cur.set(f.id, cur.get(f.id) + mover.strength);
    movable -= mover.strength; sent++;
    if (mover === a) break;
  }
  return sent;
}

// ---------- задачи ----------
function runAttack(g, hq, ready, all, enemy) {
  const owner = hq.owner;
  let T = hq.target != null && g.countries[hq.target].alive && atWar(g, owner, hq.target) ? hq.target : null;
  if (T == null) {
    const foes = g.countries.filter((c) => c.alive && atWar(g, owner, c.id));
    if (!foes.length) { hq.status = 'Нет войны: цель не выбрана'; return; }
    T = foes.sort((x, y) => (hq.target === x.id ? -1 : 0) - (hq.target === y.id ? -1 : 0))[0].id;
    hq.status = `Цель не задана, наступает на ${g.countries[T].name}`;
  }
  const thr = HQ_AGGR[hq.aggr][2];
  const minOrg = hq.aggr === 2 ? 40 : 60;
  const dist = capDist(g, g.countries[T].capital);
  const groups = groupsOf(ready.filter((a) => orgOf(a) >= minOrg));
  if (!groups.length) { hq.status = 'Армии восстанавливаются'; return; }
  const total = groups.reduce((s, x) => s + x.str, 0);
  // сосредоточение у самой крупной группы, пока не собрано 70% сил
  if (hq.mass && hq.phase === 'mass') {
    const big = groups.reduce((b, x) => (x.str > b.str ? x : b), groups[0]);
    if (big.str >= total * 0.7) hq.phase = 'go';
    else {
      let moved = 0;
      for (const x of groups) if (x !== big) for (const a of x.armies) if (step(g, a, big.at)) moved++;
      hq.status = `Сосредотачивает силы в ${prov(g, big.at).name}`;
      return;
    }
  }
  let acted = 0, holding = 0, parts = 0, waiting = 0, covered = 0;
  const split = splitOn(hq);
  const thrRef = thr;
  // Линия фронта задаётся главными силами (самая крупная группа штаба): малые группы не обгоняют их больше чем на LEAD шагов,
  // чтобы отряды не уходили вглубь вражеской земли, пока основная армия позади. Сама главная группа идёт без ограничения.
  const LEAD = hq.aggr === 2 ? 2 : 1;
  const mainGroup = groupsOf(all).reduce((b, x) => (b == null || x.str > b.str ? x : b), null);
  const ref = mainGroup ? (dist.get(mainGroup.at) ?? 99) : 99;
  const mainStr = mainGroup ? mainGroup.str : 0;
  // Тыл: свои провинции, у которых стоит вражеская армия (или она в соседней), а наших войск нет, прикрывают ближайшие группы.
  const busy = new Set();
  const owned = (pid) => prov(g, pid).props.owner === owner;
  const covers = new Set();
  for (const a of g.armies) if (a.owner === owner) covers.add(a.order ? a.order.path[a.order.path.length - 1] : a.at);
  const threats = [];
  for (const p of g.world.provinces.values()) {
    if (p.props.owner !== owner || covers.has(p.id)) continue;
    let str = (enemy.get(p.id) || { str: 0 }).str;
    if (p.props.capital) for (const nb of p.neighbors) str += (enemy.get(nb) || { str: 0 }).str;
    if (str > 0) threats.push({ id: p.id, str, def: provinceDefense(p, g), cap: p.props.capital ? 1 : 0 });
  }
  threats.sort((u, v) => v.cap - u.cap || v.str - u.str);
  for (const th of threats.slice(0, 4)) {
    const need = Math.max(MIN_PART, th.str * th.def * thrRef * 0.9);
    let best = null, bc = Infinity;
    for (const x of groups) {
      if (busy.has(x) || x.org < minOrg || (!split && x.str < need)) continue;
      const r = previewPath(g, owner, x.at, th.id);
      if (r && r.path.length <= 5 && r.cost < bc && x.str >= (split ? MIN_PART : need)) { bc = r.cost; best = x; }
    }
    if (!best) continue;
    const pool = best.armies.slice();
    const squad = split ? takeForce(g, pool, need) : pool.splice(0);
    let sent = 0;
    for (const a of squad) if (step(g, a, th.id)) sent++;
    if (!sent) continue;
    best.armies = pool; best.str = pool.reduce((s, a) => s + a.strength, 0);
    if (!pool.length) busy.add(best);
    covered++;
  }
  for (const x of groups) {
    if (busy.has(x) || !x.armies.length) continue;
    const cands = [];
    for (const nb of neigh(g, x.at)) {
      const p = prov(g, nb), po = p.props.owner;
      const e = enemy.get(nb);
      const hostile = (po != null && atWar(g, owner, po)) || e;
      if (!hostile) continue;
      if (previewPath(g, owner, x.at, nb) == null) continue;
      if (x.str < mainStr * 0.7 && (dist.get(nb) ?? 99) < ref - LEAD) { waiting++; continue; }
      const force = e ? e.str * defOf(g, nb, enemy) : 0;
      const ratio = e ? x.str / Math.max(1, force) : Infinity;
      if (ratio < thr) continue;
      const toward = (dist.get(x.at) ?? 99) - (dist.get(nb) ?? 99);
      const sc = (e ? Math.min(ratio, 6) : 5) + 0.4 * toward + (po === T ? 1 : 0);
      // нужная сила: у врага — порог риска с запасом, у пустой земли — небольшой отряд
      cands.push({ nb, sc, held: !!e, need: e ? Math.max(MIN_PART, force * thr * 1.15) : MIN_PART });
    }
    // с делением главные силы идут на вражескую армию, пустые провинции занимают отряды
    cands.sort((u, v) => (split ? (v.held - u.held) : 0) || v.sc - u.sc);
    const best = cands[0];
    if (best != null) {
      const plan = [best];
      // тыл: если рядом, помимо цели атаки, стоит вражеская армия, часть остаётся прикрывать провинцию (но не в ущерб атаке)
      let keep = 0;
      if (split && owned(x.at)) {
        const planned = new Set([best.nb]);
        if (neigh(g, x.at).some((nb) => !planned.has(nb) && enemy.has(nb))) keep = Math.min(Math.max(MIN_PART, Math.round(x.str * 0.15)), x.str - best.need);
        if (keep < MIN_PART) keep = 0;
      }
      if (split) {
        let rest = x.str - keep - Math.max(best.need, (x.str - keep) * 0.4);
        for (const c of cands.slice(1)) {
          if (plan.length >= 4 || c.need > rest) continue;
          plan.push(c); rest -= c.need;
        }
      }
      const pool = x.armies.slice();
      if (keep) takeForce(g, pool, keep); // оставшиеся в провинции армии прикрывают тыл
      for (const c of plan.slice(1)) {
        const squad = takeForce(g, pool, c.need);
        for (const a of squad) stepOne(g, a, c.nb);
        if (squad.length) parts++;
      }
      for (const a of pool) stepOne(g, a, best.nb);
      acted++;
      continue;
    }
    // нет подходящего соседа: если рядом нет врага, идём к ближайшей вражеской земле
    const adjacentEnemy = neigh(g, x.at).some((nb) => enemy.has(nb) || (prov(g, nb).props.owner != null && atWar(g, owner, prov(g, nb).props.owner)));
    if (adjacentEnemy) { holding++; continue; }
    let target = null, seen = new Set([x.at]), frontier = [x.at];
    for (let d = 0; d < 14 && target == null; d++) {
      const next = [];
      for (const id of frontier) for (const nb of neigh(g, id)) {
        if (seen.has(nb)) continue;
        seen.add(nb); next.push(nb);
        const po = prov(g, nb).props.owner;
        if (po != null && atWar(g, owner, po) && target == null) target = nb;
      }
      frontier = next;
    }
    if (target != null) { for (const a of x.armies) step(g, a, target); acted++; }
  }
  const extra = `${waiting ? `, равняет строй` : ''}${covered ? `, прикрывает тыл ${covered}` : ''}`;
  hq.status = acted ? `Наступает (${acted} гр.${parts ? `, отрядов ${parts}` : ''}${extra})` : covered ? `Прикрывает тыл (${covered})` : waiting ? 'Равняет строй: ждёт отставших' : holding ? 'Ждёт подкреплений: враг сильнее порога' : 'Нет целей';
}

function runDefend(g, hq, ready, all, enemy) {
  const owner = hq.owner;
  const foes = hq.target != null && g.countries[hq.target].alive ? [hq.target] : g.countries.filter((c) => c.alive && atWar(g, owner, c.id)).map((c) => c.id);
  if (!foes.length) { hq.status = 'Нет противника'; return; }
  const isFoe = (pid) => { const po = prov(g, pid).props.owner; return po != null && foes.includes(po); };
  // рубеж: свои провинции, граничащие с землёй или войсками противника
  const front = [];
  for (const p of g.world.provinces.values()) {
    if (p.props.owner !== owner) continue;
    let threat = (enemy.get(p.id) || { str: 0 }).str, border = false;
    for (const nb of p.neighbors) {
      if (isFoe(nb) || (enemy.has(nb) && foes.includes(g.armies.find((a) => a.at === nb && atWar(g, owner, a.owner))?.owner))) { border = true; threat += (enemy.get(nb) || { str: 0 }).str; }
    }
    if (border) front.push({ id: p.id, w: 1 + threat / 12 + (p.props.capital ? 1.2 : 0) });
  }
  if (!front.length) { hq.status = 'Рубеж спокоен'; return; }
  const S = all.reduce((s, a) => s + a.strength, 0);
  const sumW = front.reduce((s, f) => s + f.w, 0);
  const desired = new Map(front.map((f) => [f.id, S * f.w / sumW]));
  const frontIds = new Set(front.map((f) => f.id));
  const cur = new Map(front.map((f) => [f.id, 0]));
  for (const a of all) { const dest = a.order ? a.order.path[a.order.path.length - 1] : a.at; if (cur.has(dest)) cur.set(dest, cur.get(dest) + a.strength); }
  const thr = HQ_AGGR[hq.aggr][2] + 0.5;
  let moved = 0, countered = 0, fell = 0;
  for (const x of groupsOf(ready)) {
    // контрудар по ослабленному врагу
    if (frontIds.has(x.at) && x.org >= 60) {
      let best = null, bs = -1;
      for (const nb of neigh(g, x.at)) {
        const e = enemy.get(nb);
        if (!e || e.org > 45) continue;
        if (previewPath(g, owner, x.at, nb) == null) continue;
        const ratio = x.str / Math.max(1, e.str * defOf(g, nb, enemy));
        if (ratio >= thr && ratio > bs) { bs = ratio; best = nb; }
      }
      if (best != null) { for (const a of x.armies) stepOne(g, a, best); countered++; continue; }
    }
    // отход при подавляющем превосходстве врага
    if (hq.retreat && frontIds.has(x.at) && !prov(g, x.at).props.capital) {
      let threat = 0;
      for (const nb of neigh(g, x.at)) threat += (enemy.get(nb) || { str: 0 }).str + 0;
      threat += (enemy.get(x.at) || { str: 0 }).str;
      if (threat > 2.5 * x.str * provinceDefense(prov(g, x.at), g)) {
        const spot = safeSpot(g, x.armies[0], enemy);
        if (spot != null && spot !== x.at && !frontIds.has(spot)) { for (const a of x.armies) step(g, a, spot); fell++; continue; }
      }
    }
    // распределение по рубежу
    for (const a of x.armies) moved += deploy(g, hq, a, front, desired, cur, frontIds);
  }
  hq.status = `Держит рубеж: ${front.length} прв.${moved ? `, перебросок ${moved}` : ''}${countered ? `, контрудар ${countered}` : ''}${fell ? `, отход ${fell}` : ''}`;
}

// Мирная позиция: армии штаба стоят на сухопутной границе с нейтральными (не своими и не союзными) странами,
// число войск на участке пропорционально длине границы; столица прикрыта чуть сильнее.
function runBorder(g, hq, ready, all) {
  const owner = hq.owner;
  const front = [];
  for (const p of g.world.provinces.values()) {
    if (p.props.owner !== owner) continue;
    let foreign = 0;
    for (const nb of p.neighbors) {
      if (seaGap(g, p.id, nb) !== undefined) continue; // через пролив границу не держат
      const po = prov(g, nb).props.owner;
      if (po == null || po === owner || friendly(g, owner, po)) continue;
      foreign++;
    }
    if (foreign) front.push({ id: p.id, w: 1 + 0.6 * foreign + (p.props.capital ? 1.2 : 0) });
  }
  if (!front.length) { hq.status = 'Мир: нет сухопутной границы с нейтралами'; return; }
  const S = all.reduce((s, a) => s + a.strength, 0);
  const sumW = front.reduce((s, f) => s + f.w, 0);
  const desired = new Map(front.map((f) => [f.id, S * f.w / sumW]));
  const frontIds = new Set(front.map((f) => f.id));
  const cur = new Map(front.map((f) => [f.id, 0]));
  for (const a of all) { const dest = a.order ? a.order.path[a.order.path.length - 1] : a.at; if (cur.has(dest)) cur.set(dest, cur.get(dest) + a.strength); }
  let moved = 0;
  for (const a of ready.slice()) {
    const here = a.at;
    const n = deploy(g, hq, a, front, desired, cur, frontIds);
    moved += n;
    if (a.order || frontIds.has(here)) continue;
    // остаток армии (или все участки «укомплектованы») вне границы всё равно уходит на ближайший
    let best = null, bestLen = Infinity;
    for (const f of front) { const r = previewPath(g, owner, here, f.id); if (r && r.cost < bestLen) { bestLen = r.cost; best = f.id; } }
    if (best != null && step(g, a, best)) { cur.set(best, cur.get(best) + a.strength); moved++; }
  }
  hq.phase = 'mass';
  hq.status = `Мир: граница с нейтралами, ${front.length} прв.${moved ? `, переброска ${moved}` : ''}`;
}

function runGarrison(g, hq, ready, all) {
  const owner = hq.owner;
  const occ = [];
  for (const p of g.world.provinces.values()) if (p.props.owner === owner && p.props.core != null && p.props.core !== owner && (p.props.comp ?? 100) < 95) occ.push(p);
  if (!occ.length) { runBorder(g, hq, ready, all); return; }
  occ.sort((a, b) => (a.props.comp ?? 100) - (b.props.comp ?? 100));
  const taken = new Set(all.filter((a) => !a.order).map((a) => a.at));
  for (const a of all) if (a.order) taken.add(a.order.path[a.order.path.length - 1]);
  let sent = 0;
  const split = splitOn(hq);
  // размер гарнизона: силы штаба поровну на оккупированные провинции, но не меньше MIN_PART
  const need = Math.max(MIN_PART, Math.ceil(all.reduce((t, a) => t + a.strength, 0) / occ.length));
  for (const a of ready.slice()) {
    const inOcc = occ.some((p) => p.id === a.at);
    if (inOcc && !split) continue; // уже в оккупированной провинции
    for (;;) {
      const spot = occ.find((p) => !taken.has(p.id) && p.id !== a.at && previewPath(g, owner, a.at, p.id));
      if (!spot) break;
      const free = inOcc ? a.strength - need : a.strength;
      if (free < MIN_PART) break;
      const mover = split ? detach(g, a, Math.min(need, free)) : a;
      if (inOcc && mover === a) break; // не оставлять свою провинцию пустой
      if (!step(g, mover, spot.id)) break;
      taken.add(spot.id); sent++;
      if (mover === a) break;
    }
  }
  hq.status = `Гарнизоны: ${occ.length} провинций под присмотром, отправлено ${sent}`;
}

// Отход армий с низкой организацией
function retreatTired(g, hq, free, enemy) {
  const thr = HQ_RETREAT[hq.retreat][2];
  if (!thr) return new Set();
  const out = new Set();
  for (const a of free) {
    if (orgOf(a) >= thr) continue;
    const danger = a.fighting || enemy.has(a.at) || neigh(g, a.at).some((nb) => enemy.has(nb));
    if (!danger) continue;
    const spot = safeSpot(g, a, enemy);
    if (spot != null && spot !== a.at && step(g, a, spot)) out.add(a);
  }
  return out;
}

export function runHQ(g, hq) {
  const owner = hq.owner;
  if (!g.countries[owner].alive) return;
  const all = g.armies.filter((a) => a.hq === hq.id && a.owner === owner);
  if (!all.length) { hq.status = 'Нет армий'; return; }
  const enemy = enemyMap(g, owner);
  const free = all.filter((a) => !a.order && g.day - (a.manual ?? -99) >= MANUAL_LOCK);
  const tired = retreatTired(g, hq, free, enemy);
  const ready = free.filter((a) => !tired.has(a) && !a.order);
  const warring = g.countries.some((c) => c.alive && c.id !== owner && atWar(g, owner, c.id));
  if (!warring && hq.mission !== 'garrison') runBorder(g, hq, ready, all);
  else if (hq.mission === 'attack') runAttack(g, hq, ready, all, enemy);
  else if (hq.mission === 'defend') runDefend(g, hq, ready, all, enemy);
  else runGarrison(g, hq, ready, all);
  if (tired.size) hq.status += ` · отходит на отдых: ${tired.size}`;
}

hooks.hq = (g) => {
  for (const hq of g.hqs || []) if ((g.day + hq.id) % 2 === 0) runHQ(g, hq);
};
