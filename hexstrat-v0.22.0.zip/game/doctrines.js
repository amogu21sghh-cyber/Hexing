// Доктрины: стиль ведения войны страны. Выбирается один; три ступени изучаются за очки технологий и открываются
// по числу изученных военных технологий. Эффекты — те же множители, что у технологий (см. recalcMods в state.js).
export const DOCTRINES = {
  mass: {
    name: 'Пехотные массы', short: 'Массовые армии: дешёвый призыв и устойчивость к потерям',
    base: { recruit: -0.1, upkeep: -0.05 },
    steps: [
      { name: 'Всеобщее обучение', desc: 'Люди +10%', effect: { men: 0.1 } },
      { name: 'Волновые атаки', desc: 'Урон +5%, потери организации −15%', effect: { attack: 0.05, orgLoss: -0.15 } },
      { name: 'Лавина', desc: 'Призыв дешевле на 10%, урон +5%, сопротивление погоде +15%', effect: { recruit: -0.1, attack: 0.05, wthr: 0.15 } },
    ],
  },
  maneuver: {
    name: 'Манёвренная война', short: 'Быстрые клинья и охваты: скорость и организация, но больше топлива',
    base: { speed: 0.08 },
    steps: [
      { name: 'Танковые клинья', desc: 'Скорость +5%, урон +3%', effect: { speed: 0.05, attack: 0.03 } },
      { name: 'Глубокие охваты', desc: 'Восстановление организации +20%', effect: { org: 0.2 } },
      { name: 'Блицкриг', desc: 'Скорость +7%, урон +4%, расход топлива +10%', effect: { speed: 0.07, attack: 0.04, fuelUse: 0.1 } },
    ],
  },
  defense: {
    name: 'Оборона в глубину', short: 'Укрепления и стойкость: оборона, окопы и зимняя устойчивость',
    base: { defense: 0.06, dig: 0.2 },
    steps: [
      { name: 'Полевые укрепления', desc: 'Окапывание +20%', effect: { dig: 0.2 } },
      { name: 'Эшелонированная оборона', desc: 'Оборона провинций +0.08', effect: { defense: 0.08 } },
      { name: 'Зимняя устойчивость', desc: 'Сопротивление погоде +35%, потери организации −10%', effect: { wthr: 0.35, orgLoss: -0.1 } },
    ],
  },
  firepower: {
    name: 'Огневая мощь', short: 'Артиллерия и авиаподдержка: сильный урон за дорогое содержание',
    base: { attack: 0.05, upkeep: 0.05 },
    steps: [
      { name: 'Артиллерийские резервы', desc: 'Урон +3%', effect: { attack: 0.03 } },
      { name: 'Воздушная поддержка', desc: 'Урон +2%, удары авиации +10%', effect: { attack: 0.02, airStrike: 0.1 } },
      { name: 'Огневой вал', desc: 'Урон +5%', effect: { attack: 0.05 } },
    ],
  },
};
export const DOCTRINE_IDS = Object.keys(DOCTRINES);
export const DOCTRINE_STEP = { cost: [300, 500, 800], days: [50, 70, 90], mil: [0, 3, 6] }; // очки, дни, военные технологии
export const DOCTRINE_SWITCH = { pp: 60, gap: 180 };
export const DOCTRINE_START = { 'Германия': 'maneuver', 'СССР': 'mass', 'Франция': 'defense', 'Великобритания': 'firepower', 'Польша': 'defense', 'Италия': 'firepower', 'Финляндия': 'defense', 'Турция': 'mass', 'Чехословакия': 'defense', 'Румыния': 'mass', 'Югославия': 'mass', 'Греция': 'defense' };

// Сумма эффектов доктрины: база и изученные ступени
export function doctrineEffect(d) {
  const D = d && DOCTRINES[d.id];
  if (!D) return null;
  const out = { ...D.base };
  for (let i = 0; i < Math.min(3, d.lvl || 0); i++) for (const [k, v] of Object.entries(D.steps[i].effect)) out[k] = (out[k] || 0) + v;
  return out;
}
