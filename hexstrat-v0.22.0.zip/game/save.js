// Сохранения в localStorage. Если хранилище недоступно, игра просто работает без них.
import { World } from '../engine/index.js';
import { mulberry32 } from './rng.js';
import { modsSignature } from './mods.js';
import { refreshStats, economyPreview, ensureCountry, hooks } from './state.js';

const KEY = 'hexarchy.save.v1';

export function serialize(g) {
  return {
    v: 1, mods: modsSignature(), seed: g.seed, size: g.size, scenario: g.scenario, difficulty: g.difficulty, historical: !!g.historical, tension: g.tension, justify: g.justify, guar: g.guar, lend: g.lend, trade: g.trade, nextDealId: g.nextDealId, hqs: g.hqs, day: g.day, playerId: g.playerId,
    nextArmyId: g.nextArmyId, logSeq: g.logSeq, countries: g.countries, wars: [...g.wars], warFor: g.warFor || {},
    armies: g.armies, world: g.world.toJSON(),
    rel: g.rel, factions: g.factions, nextFactionId: g.nextFactionId, offers: g.offers, nextOfferId: g.nextOfferId, evFired: g.evFired, claims: g.claims || {}, pending: g.pending, nextPendingId: g.nextPendingId, plague: g.plague || null,
  };
}

export function restoreGame(d) {
  const g = {
    seed: d.seed, size: d.size, scenario: d.scenario || 'random', difficulty: d.difficulty, historical: !!d.historical, tension: d.tension || 0, justify: d.justify || [], guar: d.guar || [], lend: d.lend || [], trade: d.trade || [], nextDealId: d.nextDealId || 1, hqs: d.hqs || [], world: World.fromJSON(d.world),
    countries: d.countries, armies: d.armies, wars: new Map(d.wars), warFor: d.warFor || {}, day: d.day, playerId: d.playerId,
    nextArmyId: d.nextArmyId, rel: d.rel || {}, factions: d.factions || [], nextFactionId: d.nextFactionId || 1, offers: d.offers || [], nextOfferId: d.nextOfferId || 1, evFired: d.evFired || {}, claims: d.claims || {}, pending: d.pending || [], nextPendingId: d.nextPendingId || 1, plague: d.plague || null, rng: mulberry32(d.seed * 7919 + 13 + d.day), log: [], logSeq: d.logSeq, over: null, stats: [],
  };
  for (const c of g.countries) ensureCountry(c, g);
  if (!g.plague && hooks.plagueInit) hooks.plagueInit(g); // мод включили после начала игры: эпидемия начнётся сразу
  refreshStats(g);
  economyPreview(g);
  return g;
}

export function saveGame(g) {
  try { localStorage.setItem(KEY, JSON.stringify(serialize(g))); return true; } catch (_) { return false; }
}

export function readSave() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const d = JSON.parse(raw);
    return d && d.v === 1 && d.countries && d.world ? d : null;
  } catch (_) { return null; }
}

export function clearSave() {
  try { localStorage.removeItem(KEY); } catch (_) { /* ничего */ }
}
