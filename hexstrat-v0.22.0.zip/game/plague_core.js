// Эпидемия: данные и чистые функции (без импортов из state.js, чтобы их мог брать recalcMods).
// Система включается модом (systems.plague в файле мода); без мода PLAGUE.cfg === null и эпидемии нет.
export const PLAGUE = { cfg: null };

export const PLAGUE_DEFAULTS = {
  start: 30,          // день начала (30 = февраль 1936)
  origin: 'Египет',   // страна, где появляются первые случаи
  seedRate: 0.004,    // заражение от соседей и мира: пунктов в день на 1% заражённости окружения
  growth: 0.014,      // рост внутри страны (в день, пока не вмешались карантин и вакцина)
  recovery: 0.003,    // естественный спад
  neighborShare: 0.65,// доля влияния соседей (остальное — средняя по миру)
  maxProtection: 0.97,
  quarantine: [0, 0.2, 0.45],   // защита от карантина уровней 0–2
  quarantineGold: [0, 0.03, 0.08], // цена карантина: доход золота
  vaccineProtection: 0.9,       // защита при полной вакцинации
  shareAlly: 0.8,     // доля чужого успеха по вакцине: союзники и вассалы
  sharePeace: 0.5,    // …страны, с которыми нет войны
  collapseAt: 70,     // средняя по миру заражённость, при которой идёт обратный отсчёт гибели
  collapseDays: 150,  // сколько дней она должна продержаться, чтобы все проиграли
  winBelow: 5,        // победа над болезнью: средняя ниже этого значения…
  winDays: 30,        // …столько дней подряд
  severity: 1,        // сила ударов по стране
  eff: { gold: 0.0035, men: 0.004, ind: 0.003, res: 0.002, attack: 0.0015, stab: 0.08 },
};

export const plagueOf = (c) => c.plague || (c.plague = { i: 0, v: 0, q: 0, ap: 0 });

// Последствия заражённости страны для множителей (складываются в recalcMods)
export function plagueEffect(c) {
  const cfg = PLAGUE.cfg;
  if (!cfg || !c.plague) return null;
  const p = c.plague, i = p.i * cfg.severity, q = p.q | 0;
  if (!i && !q) return null;
  return {
    gold: -cfg.eff.gold * i - cfg.quarantineGold[q], men: -cfg.eff.men * i, ind: -cfg.eff.ind * i, res: -cfg.eff.res * i,
    attack: -cfg.eff.attack * i, stab: -cfg.eff.stab * i - (q === 2 ? 1 : 0),
  };
}

// Условия событий мода (when): только данные, без кода
export const WHEN_KEYS = ['infGt', 'infLt', 'worldInfGt', 'worldInfLt', 'vaccGt', 'vaccLt', 'dayGt', 'dayLt', 'quarGt'];
export function whenOk(g, c, w) {
  if (!w) return true;
  if (!PLAGUE.cfg) return false;
  const p = c.plague || { i: 0, v: 0, q: 0 }, wi = (g.plague && g.plague.worldI) || 0;
  if (w.infGt != null && !(p.i > w.infGt)) return false;
  if (w.infLt != null && !(p.i < w.infLt)) return false;
  if (w.worldInfGt != null && !(wi > w.worldInfGt)) return false;
  if (w.worldInfLt != null && !(wi < w.worldInfLt)) return false;
  if (w.vaccGt != null && !(p.v > w.vaccGt)) return false;
  if (w.vaccLt != null && !(p.v < w.vaccLt)) return false;
  if (w.dayGt != null && !(g.day > w.dayGt)) return false;
  if (w.dayLt != null && !(g.day < w.dayLt)) return false;
  if (w.quarGt != null && !((p.q | 0) > w.quarGt)) return false;
  return true;
}

// Изменение заражённости или вакцины (события и фокусы): { inf, vaccine }
export function applyPlagueDelta(c, d) {
  const p = plagueOf(c);
  if (d.inf) p.i = Math.max(0, Math.min(100, p.i + d.inf));
  if (d.vaccine) p.v = Math.max(0, Math.min(100, p.v + d.vaccine));
  p.ap = -1; // пересчёт множителей в ближайший день
}
