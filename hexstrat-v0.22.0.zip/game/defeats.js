// Мировые события о поражении стран: падение столицы, капитуляция (вассалитет) и гибель страны.
// Игрок видит уведомление «Мировые новости», у победителя, союзников и гарантов потерпевшей меняются власть и стабильность,
// сдвигается мировая напряжённость. Вызывается из state.js через hooks.capital / hooks.vassal / hooks.fall.
import { DEFEATS, GENERIC, CONSEQUENCES, MIN_CORE } from './defeats_data.js';
import { hooks, emit, economyPreview, addRel } from './state.js';
import { applyEffect, describeEffect, byName } from './events.js';

const REFIRE = 150; // дней до повторного уведомления о падении той же столицы

const coreCount = (g, id) => { let n = 0; for (const p of g.world.provinces.values()) if (p.props.core === id) n++; return n; };

function texts(g, fallen, kind) {
  const d = DEFEATS[fallen.base || fallen.name];
  if (d && d[kind]) return d[kind];
  if (coreCount(g, fallen.id) < MIN_CORE) return null;
  return GENERIC[kind](fallen.base || fallen.name);
}

const clampT = (g, d) => { g.tension = Math.max(0, Math.min(100, (g.tension || 0) + d)); };

// ctx: { mates: id[] } — союзники и гаранты потерпевшей, собранные до разрыва связей
function defeat(g, kind, fallenId, victorId, ctx) {
  const fallen = g.countries[fallenId];
  const t = texts(g, fallen, kind);
  const base = fallen.base || fallen.name;
  const C = CONSEQUENCES[kind], data = DEFEATS[base] || {};
  const victor = victorId != null && g.countries[victorId] && g.countries[victorId].alive && victorId !== fallenId ? g.countries[victorId] : null;
  const lines = [];
  const note = (c, eff) => { const parts = describeEffect(eff, c).filter((s) => !/^Отношения/.test(s)); if (parts.length) lines.push(`${c.name}: ${parts.join(', ')}`); };
  const apply = (c, eff) => { if (!c || !c.alive || !eff) return; applyEffect(g, c, eff, t ? t[0] : kind); note(c, eff); };
  if (victor) apply(victor, C.victor);
  if (kind !== 'fall' && fallen.alive) apply(fallen, C.fallen);
  for (const m of ctx.mates || []) {
    const c = g.countries[m];
    if (!c || !c.alive || c === victor) continue;
    const { rel, ...eff } = C.mates;
    apply(c, eff);
    if (victor && rel) addRel(g, c.id, victor.id, rel);
  }
  for (const [name, eff] of (data.extra && data.extra[kind]) || []) {
    const c = byName(g, name);
    if (c && c.alive && c.id !== fallenId) apply(c, eff);
  }
  clampT(g, (data.tension && data.tension[kind] != null ? data.tension[kind] : C.tension));
  if (lines.length === 0 && victor == null) lines.push('Мировая напряжённость меняется');
  economyPreview(g);
  if (!t) return;
  const own = fallenId === g.playerId;
  if (own && kind === 'fall') return; // игра и так закончилась
  g.pending.push({ id: g.nextPendingId++, eid: null, cid: fallenId, day: g.day, info: { kind: 'defeat', title: t[0], text: t[1], lines, pic: 'ev_war', own } });
  emit(g, t[0], [fallenId, victor ? victor.id : fallenId], 'fall');
}

hooks.fall = (g, id, by, ctx) => defeat(g, 'fall', id, by, ctx);
hooks.vassal = (g, vassalId, overlordId, ctx) => defeat(g, 'vassal', vassalId, overlordId, ctx);
hooks.capital = (g, id, by) => {
  const c = g.countries[id];
  if (!c || !c.alive) return;
  const last = c.flags.capital_lost;
  if (last != null && g.day - last < REFIRE) return;
  c.flags.capital_lost = g.day;
  const mates = new Set();
  if (c.faction != null) for (const o of g.countries) if (o.alive && o.id !== id && o.faction === c.faction) mates.add(o.id);
  for (const x of g.guar || []) if (x.of === id && g.countries[x.by].alive) mates.add(x.by);
  defeat(g, 'capital', id, by, { mates: [...mates] });
};
export const DEFEATS_READY = true;
