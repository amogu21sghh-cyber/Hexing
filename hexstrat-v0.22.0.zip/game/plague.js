// Эпидемия (динамика). Страна заражается от соседей и от мира, защищают карантин, технологии и вакцина;
// вакцину страны создают фокусами и событиями, а успех союзников и мирных стран частично передаётся.
// Если средняя по миру заражённость долго держится выше порога, проигрывают все; если она падает почти до нуля — болезнь побеждена.
import { hooks, emit, recalcMods, friendly, atWar } from './state.js';
import { PLAGUE, plagueOf } from './plague_core.js';

const alive = (g) => g.countries.filter((c) => c.alive);
// Окно новостей игроку (как уведомление о фокусе)
function notify(g, title, text, pic = 'pl_warn') {
  if (g.over || g.playerId == null || !g.countries[g.playerId] || !g.countries[g.playerId].alive) return;
  g.pending.push({ id: g.nextPendingId++, eid: null, cid: g.playerId, day: g.day, info: { kind: 'plague', title, text, pic, lines: [], own: true } });
}
const everyone = (g) => g.countries.map((c) => c.id); // чтобы сообщение показалось игроку всплывающей подсказкой

function weights(g) {
  let w = 0, wi = 0, wv = 0;
  for (const c of g.countries) {
    if (!c.alive) continue;
    const k = Math.max(1, (g.stats && g.stats[c.id] && g.stats[c.id].provinces) || 1), p = plagueOf(c);
    w += k; wi += p.i * k; wv += p.v * k;
  }
  return { i: w ? wi / w : 0, v: w ? wv / w : 0 };
}

function adjacency(g) {
  const adj = new Map(g.countries.map((c) => [c.id, new Set()]));
  for (const p of g.world.provinces.values()) {
    const a = p.props.owner;
    if (a == null) continue;
    for (const n of p.neighbors) {
      const b = g.world.provinces.get(n).props.owner;
      if (b != null && b !== a) adj.get(a).add(b);
    }
  }
  // морские связи: переправы и порты тоже передают болезнь
  if (g.world._ferryGap) for (const k of g.world._ferryGap.keys()) {
    const a = g.world.provinces.get(Math.floor(k / 65536)), b = g.world.provinces.get(k % 65536);
    if (a && b && a.props.owner != null && b.props.owner != null && a.props.owner !== b.props.owner) { adj.get(a.props.owner).add(b.props.owner); adj.get(b.props.owner).add(a.props.owner); }
  }
  return adj;
}

// Эффективная вакцина: своя или доля лучшего успеха союзников и мирных стран
export function effVaccine(g, c) {
  const cfg = PLAGUE.cfg, p = plagueOf(c);
  let best = p.v;
  for (const o of g.countries) {
    if (!o.alive || o.id === c.id) continue;
    const ov = plagueOf(o).v;
    if (ov <= best) continue;
    const share = friendly(g, c.id, o.id) ? cfg.shareAlly : atWar(g, c.id, o.id) ? 0 : cfg.sharePeace;
    best = Math.max(best, ov * share);
  }
  return best;
}

export function protectionOf(g, c) {
  const cfg = PLAGUE.cfg, p = plagueOf(c);
  const ctl = (c.mod && c.mod.ctl) || 0;
  return Math.min(cfg.maxProtection, ctl + cfg.quarantine[p.q | 0] + cfg.vaccineProtection * effVaccine(g, c) / 100);
}

export function initPlague(g) {
  if (!PLAGUE.cfg) { g.plague = null; return; }
  g.plague = { started: false, ended: false, doom: 0, calm: 0, worldI: 0, worldV: 0, ms: 0, vacc: false };
  for (const c of g.countries) plagueOf(c);
}

const MILESTONES = [10, 25, 40, 55];
function progressPlague(g) {
  const cfg = PLAGUE.cfg, P = g.plague;
  if (!cfg || !P || g.day < cfg.start) return;
  if (!P.started) {
    P.started = true;
    const o = g.countries.find((c) => c.alive && c.name === cfg.origin) || g.countries.find((c) => c.alive);
    plagueOf(o).i = 2;
    P.origin = o.id;
    emit(g, `Неизвестная болезнь: первые случаи в стране «${o.name}». Врачи не знают, как она передаётся.`, everyone(g), 'event');
    notify(g, 'Неизвестная болезнь', `Из страны «${o.name}» приходят тревожные вести: люди массово заболевают неизвестной лихорадкой, врачи не знают, как она передаётся. Откройте раздел «Эпидемия» (значок вируса в панели разделов или плашка болезни вверху): там карантин и сведения о болезни, а вакцину разрабатывают особые фокусы.`);
  }
  if (!g._plAdj || g.day - g._plAdjDay >= 30) { g._plAdj = adjacency(g); g._plAdjDay = g.day; }
  const W = weights(g);
  for (const c of g.countries) {
    if (!c.alive) continue;
    const p = plagueOf(c);
    const nb = g._plAdj.get(c.id);
    let nsum = 0, nn = 0;
    if (nb) for (const id of nb) { const o = g.countries[id]; if (o.alive) { nsum += plagueOf(o).i; nn++; } }
    const E = nn ? cfg.neighborShare * (nsum / nn) + (1 - cfg.neighborShare) * W.i : W.i;
    const prot = protectionOf(g, c);
    const grow = (cfg.seedRate * E + cfg.growth * p.i) * (1 - p.i / 100) * (1 - prot);
    const shrink = cfg.recovery * p.i * (1 + 5 * prot + (P.ended ? 4 : 0));
    p.i = Math.max(0, Math.min(100, p.i + grow - shrink));
    if (p.i < 0.001) p.i = 0;
    // ИИ вводит карантин по заражённости (игрок решает сам)
    if (c.id !== g.playerId && (g.day + c.id) % 7 === 0) p.q = p.i > 55 ? 2 : p.i > 25 ? 1 : p.i < 8 ? 0 : p.q;
    const bucket = Math.round(p.i / 2) * 10 + (p.q | 0);
    if (bucket !== p.ap) { p.ap = bucket; recalcMods(c); }
  }
  const W2 = weights(g);
  P.worldI = W2.i; P.worldV = W2.v;
  // вехи для всех
  for (let k = 0; k < MILESTONES.length; k++) if (!(P.ms & (1 << k)) && P.worldI >= MILESTONES[k]) {
    P.ms |= 1 << k;
    emit(g, `Эпидемия: в среднем по миру заражено ${MILESTONES[k]}% населения.`, everyone(g), 'event');
    if (k === 0) notify(g, 'Болезнь пересекла границы', 'Эпидемия идёт по всему миру. Пора вводить карантин и начинать разработку вакцины: союзники и мирные страны будут делиться успехами.');
    if (k === 2) notify(g, 'Мир в тревоге', `Заражена значительная часть мира. Если средняя заражённость поднимется выше ${cfg.collapseAt}% и продержится ${cfg.collapseDays} дней, погибнут все страны.`);
  }
  if (!P.vacc) { const first = g.countries.find((c) => c.alive && plagueOf(c).v >= 100); if (first) { P.vacc = true; emit(g, `Вакцина создана: страна «${first.name}» завершила разработку. Союзникам и странам, с которыми нет войны, достанется часть успеха.`, everyone(g), 'event'); notify(g, 'Вакцина создана', `Страна «${first.name}» завершила разработку вакцины. Союзники и мирные страны получат часть успеха, остальным придётся разрабатывать свою.`, 'pl_lab'); } }
  if (P.ended) return;
  // обратный отсчёт гибели и победа над болезнью
  if (P.worldI >= cfg.collapseAt) {
    P.doom++;
    if (P.doom === 1) notify(g, 'Пандемия вышла из-под контроля', `Средняя заражённость мира выше ${cfg.collapseAt}%. Если она не упадёт, через ${cfg.collapseDays} дн. проиграют все. Нужны вакцина и строгий карантин.`);
    if (P.doom === 1 || P.doom % 30 === 0) emit(g, `Пандемия выходит из-под контроля. До общего краха: ${cfg.collapseDays - P.doom} дн.`, everyone(g), 'event');
    if (P.doom >= cfg.collapseDays) { g.over = { won: false, plague: true }; emit(g, 'Пандемия победила: человечество не справилось.', everyone(g), 'event'); return; }
  } else P.doom = Math.max(0, P.doom - 2);
  if (P.worldI > (P.peak || 0)) P.peak = P.worldI;
  if (g.day > cfg.start + 150 && P.peak >= 20 && P.worldI <= cfg.winBelow) {
    P.calm++;
    if (P.calm >= cfg.winDays) { P.ended = true; emit(g, 'Пандемия побеждена: болезнь почти исчезла. Страны возвращаются к обычной жизни.', everyone(g), 'event');
      notify(g, 'Пандемия побеждена', 'Болезнь почти исчезла. Страны возвращаются к обычной жизни, а игра идёт дальше: победить можно, как и раньше, силой оружия.', 'pl_tab'); }
  } else P.calm = 0;
}
hooks.plague = progressPlague;
hooks.plagueInit = initPlague;

// Сводка для интерфейса
export function plagueSummary(g, me) {
  const cfg = PLAGUE.cfg, P = g.plague;
  if (!cfg || !P) return null;
  const c = g.countries[me], p = plagueOf(c);
  return {
    started: P.started, ended: P.ended, worldI: P.worldI || 0, worldV: P.worldV || 0, own: p.i, ownV: p.v, effV: effVaccine(g, c), q: p.q | 0,
    prot: protectionOf(g, c), doom: P.doom, doomLeft: Math.max(0, cfg.collapseDays - P.doom), collapseAt: cfg.collapseAt, warn: P.worldI >= cfg.collapseAt, vaccDone: P.vacc,
  };
}

export function setQuarantine(g, owner, q) {
  const c = g.countries[owner], p = plagueOf(c);
  if (!PLAGUE.cfg) return { ok: false, msg: 'Эпидемии нет' };
  if (![0, 1, 2].includes(q)) return { ok: false, msg: 'Нет такого уровня' };
  p.q = q; p.ap = -1;
  recalcMods(c);
  return { ok: true };
}
