// Правила игры: состояние, экономика, приказы, бои, захват, дипломатия. Без DOM.
import { plagueEffect } from './plague_core.js';
import { weatherEffects, weatherCode, seasonStart, SEASONS } from './weather.js';
import { DOCTRINES, DOCTRINE_IDS, DOCTRINE_STEP, DOCTRINE_SWITCH, DOCTRINE_START, doctrineEffect } from './doctrines.js';
import {
  TERRAIN, RULES, SIZES, DIFFICULTY, BUILDINGS, LEVEL_EFFECT, LEVEL_COST, DEPOSITS, TECHS, TECH_BRANCHES, START_TECHS,
  TAX, FOCUSES, focusTree, focusFromDay, focusFromText, MINISTER_POSTS, TRAITS, NAME_POOLS, NAME_CULTURE, NAME_INITIALS, ORGS, HIST_REL, DEMOCRACIES, IDEOS, IDEO_START, START_VASSALS,
} from './data.js';
import { generateMap } from './mapgen.js';
import { buildEurope1936 } from './scenario.js';
import { applyStart, scenarioOf } from './starts.js';
import { mulberry32 } from './rng.js';

export const warKey = (a, b) => (a < b ? a + '|' + b : b + '|' + a);
export const prov = (g, id) => g.world.provinces.get(id);
export const atWar = (g, a, b) => a !== b && a != null && b != null && g.wars.has(warKey(a, b));
const sum = (arr, f) => arr.reduce((s, x) => s + f(x), 0);

// ---------- постройки и свойства провинции ----------
export const hasB = (p, id) => !!(p.props.built && p.props.built.includes(id));
export const levelOf = (p, id) => (p.props.built ? p.props.built.filter((x) => x === id).length : 0);
export const maxLevel = (id) => (BUILDINGS[id] && BUILDINGS[id].max) || 1;

function effects(p) {
  // результат хранится в провинции и пересчитывается только при изменении списка построек
  const bl = p.props.built, n = bl ? bl.length : 0, last = n ? bl[n - 1] : '';
  const c = p._fx;
  if (c && c.ref === bl && c.n === n && c.last === last) return c.e;
  const e = effectsCalc(p);
  Object.defineProperty(p, '_fx', { value: { ref: bl, n, last, e }, writable: true, configurable: true, enumerable: false });
  return e;
}
function effectsCalc(p) {
  const e = { goldMul: 1, goldAdd: 0, menAdd: 0, defAdd: 0, moveMul: 1, indAdd: 0, resAdd: 0, fuelMul: 1 };
  const lv = new Map();
  for (const id of p.props.built || []) lv.set(id, (lv.get(id) || 0) + 1);
  for (const [id, n] of lv) {
    const f = BUILDINGS[id] && BUILDINGS[id].effect;
    if (!f) continue;
    const k = LEVEL_EFFECT[Math.min(n, LEVEL_EFFECT.length) - 1];
    if (f.goldMul) e.goldMul *= 1 + (f.goldMul - 1) * k;
    if (f.moveMul) e.moveMul *= Math.max(0.3, 1 - (1 - f.moveMul) * k);
    if (f.fuelMul) e.fuelMul *= 1 + (f.fuelMul - 1) * k;
    e.goldAdd += (f.goldAdd || 0) * k;
    e.menAdd += (f.menAdd || 0) * k;
    e.defAdd += (f.defAdd || 0) * k;
    e.indAdd += (f.indAdd || 0) * k;
    e.resAdd += (f.resAdd || 0) * k;
  }
  return e;
}

// Доход провинции до множителей страны: золото, люди, очки технологий, промышленность, топливо.
// Доля дохода: оккупированная чужая земля (не своя по ядру) отдаёт 20% и дорастает до 100%, пока растёт подчинение.
export function compFactor(p) {
  const c = p.props.comp;
  if (c == null || c >= 100 || p.props.core === p.props.owner) return 1;
  return 0.2 + 0.8 * Math.max(0, c) / 100;
}

export function provinceIncome(p) {
  const e = effects(p);
  const dep = p.props.deposit ? DEPOSITS[p.props.deposit].fuel : 0;
  const k = compFactor(p);
  return {
    gold: (p.props.wealth * e.goldMul + e.goldAdd) * k,
    men: (p.props.pop * RULES.manpowerRate + e.menAdd) * k,
    res: (p.props.pop * RULES.researchRate + e.resAdd) * k,
    ind: (p.props.wealth * RULES.industryRate + e.indAdd) * k,
    fuel: (p.props.wealth * RULES.fuelRate + dep * e.fuelMul) * k,
  };
}

// Оборона провинции. Если передана игра, добавляется бонус технологий владельца.
// Множитель атаки армий страны по рельефу: нападающие на чужую или ничью землю получают штраф рельефа, снаряжение его снимает.
export function terrainAttack(c, terrain) {
  const T = TERRAIN[terrain];
  if (!T || !T.atk || !T.gear) return 1;
  return Math.max(RULES.gearMin, Math.min(RULES.gearMax, T.atk + (c.mod[T.gear] || 0)));
}

export function provinceDefense(p, g) {
  const tech = g && p.props.owner != null ? g.countries[p.props.owner].mod.defense : 0;
  return TERRAIN[p.props.terrain].defense + (p.props.capital ? RULES.capitalDefenseBonus : 0) + effects(p).defAdd + tech;
}

// ---------- страны: ресурсы и технологии ----------
const MOD_BASE = { gold: 1, men: 1, res: 1, ind: 1, fuel: 1, pp: 0, attack: 1, defense: 0, speed: 1, recruit: 1, upkeep: 1, build: 1, war: 1, loot: 1, fuelUse: 1, stab: 0, org: 1, orgLoss: 1, dig: 1, supply: 0, comp: 1, air: 1, airIntercept: 1, airStrike: 1, airBomb: 1, airRange: 0, airFuel: 1, airCap: 1, tf: 0, th: 0, tm: 0, td: 0, wthr: 0, ctl: 0 };

export const ministerTrait = (c, post) => {
  const cand = c.cands && c.cands[post] && c.cands[post][c.ministers[post]];
  return cand ? TRAITS[post].find((t) => t.id === cand.trait) : null;
};

// Множители страны собираются из технологий, фокусов и министров; пересчитываются при каждом изменении.
export function recalcMods(c) {
  const m = { ...MOD_BASE };
  const add = (effect) => { for (const [k, v] of Object.entries(effect)) m[k] += v; };
  for (const id of c.techs) if (TECHS[id]) add(TECHS[id].effect);
  for (const id of c.focuses || []) if (FOCUSES[id]) add(FOCUSES[id].effect);
  for (const id of c.orgs || []) if (ORGS[id]) add(ORGS[id].effect);
  { const de = c.doctrine && doctrineEffect(c.doctrine); if (de) add(de); }
  { const pe = plagueEffect(c); if (pe) add(pe); }
  if (IDEOS[c.ideo]) add(IDEOS[c.ideo].effect);
  for (const [post] of MINISTER_POSTS) { const t = c.ministers && ministerTrait(c, post); if (t) add(t.effect); }
  for (const t of c.timed || []) add(t.mod);
  c.mod = m;
}

// Кандидаты в министры: по три на должность, имена по культуре страны; на старте один из них уже назначен.
function genMinisters(g, c) {
  const pool = NAME_POOLS[NAME_CULTURE[c.name] || 'xx'];
  const rng = mulberry32((g.seed * 131 + c.id * 17 + 5) | 0);
  c.cands = {}; c.ministers = {};
  for (const [post] of MINISTER_POSTS) {
    const used = new Set(), list = [];
    for (const tr of TRAITS[post]) {
      let nm;
      do { nm = NAME_INITIALS[Math.floor(rng() * NAME_INITIALS.length)] + '. ' + pool[Math.floor(rng() * pool.length)]; } while (used.has(nm));
      used.add(nm);
      list.push({ name: nm, trait: tr.id });
    }
    c.cands[post] = list;
    c.ministers[post] = Math.floor(rng() * list.length);
  }
}

// Заполняет поля, которых может не быть в старых сохранениях.
export function ensureCountry(c, g) {
  if (!c.base) c.base = c.name;
  if (!c.ideo) c.ideo = (g && g.scenario === 'europe1936' && IDEO_START[c.base]) || 'aut';
  if (!c.ideo0) c.ideo0 = c.ideo;
  c.techs = c.techs || [];
  c.focuses = c.focuses || [];
  if (c.focus === undefined) c.focus = null;
  if (typeof c.tax !== 'number') c.tax = 2;
  if (typeof c.stability !== 'number') c.stability = RULES.startStab;
  c.broke = !!c.broke;
  c.orgs = c.orgs || [];
  c.flags = c.flags || {};
  c.timed = c.timed || [];
  if (typeof c.lastEv !== 'number') c.lastEv = -999;
  if (c.faction === undefined) c.faction = null;
  if (c.overlord === undefined) c.overlord = null;
  if (g && (!c.cands || !c.ministers)) genMinisters(g, c);
  c.slots = c.slots || { eco: null, pol: null, mil: null, air: null, sci: null };
  for (const [k, v] of [['research', 0], ['industry', 0], ['fuel', 0], ['pp', 0]]) if (typeof c[k] !== 'number') c[k] = v;
  if (!c.doctrine) c.doctrine = { id: DOCTRINE_START[c.base] || DOCTRINE_IDS[(c.id * 7 + 3) % DOCTRINE_IDS.length], lvl: 0, step: null, changed: null };
  if (!c.plague) c.plague = { i: 0, v: 0, q: 0, ap: 0 };
  c.noFuel = !!c.noFuel;
  recalcMods(c);
  c.income = c.income || { gold: 0, men: 0, res: 0, ind: 0, fuel: 0, pp: 0, net: 0, fuelNet: 0 };
}

// Цель стабильности и из чего она складывается.
export function stabilityInfo(g, c) {
  const lines = [['Основа', RULES.stabBase]];
  const tx = TAX[c.tax];
  if (tx.stab) lines.push([`Налог «${tx.name.toLowerCase()}»`, tx.stab]);
  let wars = 0;
  for (const k of g.wars.keys()) if (k.split('|').map(Number).includes(c.id)) wars++;
  if (wars) lines.push([`Войны: ${wars}`, -Math.min(15, wars * 5)]);
  if (c.noFuel) lines.push(['Нет топлива', -5]);
  if (c.broke) lines.push(['Пустая казна', -8]);
  const un = (g.occUnrest && g.occUnrest[c.id]) || 0;
  if (un >= 1) lines.push(['Сопротивление оккупированных земель', -Math.min(12, Math.round(un * 0.5))]);
  if (c.mod.stab) lines.push(['Технологии, фокусы, министры', c.mod.stab]);
  const target = Math.max(0, Math.min(100, lines.reduce((t, l) => t + l[1], 0)));
  return { lines, target };
}

// Действие стабильности: econ — множитель дохода, combat — множитель урона армий, pp — власть в день.
export function stabilityEffects(s) {
  return {
    econ: s >= 80 ? 1.05 : s >= 60 ? 1 : 1 - (60 - s) / 100,
    combat: s >= 40 ? 1 : 0.8 + s / 200,
    pp: s >= 75 ? 0.2 : s < 30 ? -0.2 : 0,
  };
}

export function moveCostOf(p) {
  const m = TERRAIN[p.props.terrain].move * RULES.moveScale;
  const k = effects(p).moveMul;
  return k === 1 ? m : Math.max(1, m * k);
}

export function emit(g, text, involves = [], kind = 'info') {
  g.log.push({ seq: ++g.logSeq, day: g.day, text, involves, kind });
  if (g.log.length > 80) g.log.shift();
}

export function createGame(seed, opts = {}) {
  const size = opts.size || 'medium';
  const sc = scenarioOf(opts.scenario || 'random');
  const scenario = sc.scenario, start = sc.start;
  const map = scenario === 'europe1936' ? buildEurope1936(seed) : generateMap(seed, SIZES[size]);
  const g = {
    seed: map.seed, world: map.world, countries: map.countries,
    armies: [], wars: new Map(), day: 0, playerId: null, nextArmyId: 1,
    rng: mulberry32(map.seed * 7919 + 13), log: [], logSeq: 0, over: null, stats: [],
    size, scenario, difficulty: opts.difficulty ?? 1, historical: !!opts.historical,
    rel: {}, factions: [], nextFactionId: 1, offers: [], nextOfferId: 1, evFired: {}, claims: {}, pending: [], nextPendingId: 1, plague: null,
  };
  if (hooks.plagueInit) hooks.plagueInit(g);
  for (const c of g.countries) {
    const k = c.power ?? 1;
    c.gold = Math.round(RULES.startGold * k); c.manpower = Math.round(RULES.startManpower * k);
    c.research = Math.round(RULES.startRes * k); c.industry = Math.round(RULES.startInd * k);
    c.fuel = Math.round(RULES.startFuel * k); c.pp = RULES.startPP;
    c.techs = scenario === 'europe1936' ? [...(START_TECHS[c.name] || [])] : [];
    c.slots = { eco: null, pol: null, mil: null, air: null, sci: null };
    c.orgs = [];
    c.faction = null;
    c.overlord = null;
    ensureCountry(c, g);
  }
  initDiplomacy(g);
  if (scenario === 'europe1936') {
    const byName = new Map(g.countries.map((c) => [c.name, c.id]));
    for (const [v, o] of START_VASSALS) if (byName.has(v) && byName.has(o)) { g.countries[byName.get(v)].overlord = byName.get(o); addRel(g, byName.get(v), byName.get(o), 20); }
  }
  g.guar = [];
  if (scenario === 'europe1936') {   // в 1936 Исландия — королевство в унии с Данией
    const ice = g.countries.find((c) => c.base === 'Исландия'), den = g.countries.find((c) => c.base === 'Дания');
    if (ice && den) { ice.overlord = den.id; addRel(g, ice.id, den.id, 20); }
    // исторические обязательства: франко-польский союз и Антанта Франции с Британией
    const fr = g.countries.find((c) => c.base === 'Франция'), pl = g.countries.find((c) => c.base === 'Польша'), gb = g.countries.find((c) => c.base === 'Великобритания');
    const cz = g.countries.find((c) => c.base === 'Чехословакия');
    if (fr && cz) { g.guar.push({ by: fr.id, of: cz.id, day: 0 }, { by: cz.id, of: fr.id, day: 0 }); addRel(g, fr.id, cz.id, 5); }
    if (fr && pl) { g.guar.push({ by: fr.id, of: pl.id, day: 0 }, { by: pl.id, of: fr.id, day: 0 }); addRel(g, fr.id, pl.id, 10); }
    if (fr && gb) {
      const f = { id: g.nextFactionId++, name: 'Антанта', leader: fr.id, members: [fr.id, gb.id], founded: 0 };
      g.factions.push(f); fr.faction = gb.faction = f.id;
    }
  }
  for (const p of g.world.provinces.values()) { p.props.core = p.props.owner; p.props.comp = 100; }
  g.tension = scenario === 'europe1936' ? 10 : 0;
  g.justify = []; g.guar = g.guar || []; g.lend = []; g.hqs = []; g.trade = []; g.nextDealId = 1;
  // стартовые войска: по границам и в столице
  for (const p of g.world.provinces.values()) {
    const border = p.neighbors.some((n) => prov(g, n).props.owner !== p.props.owner);
    const k = g.countries[p.props.owner].power ?? 1;
    if (p.props.capital) addArmy(g, p.props.owner, p.id, Math.round(40 * k));
    else if (border) addArmy(g, p.props.owner, p.id, Math.round((10 + Math.floor(g.rng() * 10)) * k));
  }
  mergeIdle(g);
  // стартовые войска большой страны ограничены (иначе длинная граница даёт нереальную армию)
  const startTotal = g.countries.map(() => 0);
  for (const a of g.armies) startTotal[a.owner] += a.strength;
  for (const a of g.armies) {
    const c = g.countries[a.owner], cap = RULES.startTroopsCap * (c.power ?? 1);
    if (startTotal[a.owner] > cap) a.strength = Math.max(1, Math.round(a.strength * cap / startTotal[a.owner]));
  }
  if (start) applyStart(g, start, ensureCountry);
  refreshStats(g);
  economyPreview(g);
  return g;
}

export function addArmy(g, owner, at, strength) {
  const a = { id: g.nextArmyId++, owner, at, strength, order: null, fighting: false };
  g.armies.push(a);
  return a;
}

export function refreshStats(g) {
  g.stats = g.countries.map(() => ({ provinces: 0, troops: 0 }));
  for (const p of g.world.provinces.values()) if (p.props.owner != null) g.stats[p.props.owner].provinces++;
  for (const a of g.armies) g.stats[a.owner].troops += a.strength;
}

// ---------- дипломатия ----------
export function declareWar(g, a, b) {
  if (a === b || atWar(g, a, b) || !g.countries[a].alive || !g.countries[b].alive) return false;
  g.wars.set(warKey(a, b), g.day);
  g.tension = Math.min(100, (g.tension || 0) + RULES.warTension);
  emit(g, `${g.countries[a].name} объявила войну стране ${g.countries[b].name}`, [a, b], 'war');
  return true;
}

// ---------- вассалы, гарантии, повод к войне, мировая напряжённость ----------
export const isDemocracy = (g, c) => c.ideo === 'dem' && c.overlord == null;
export const vassalLink = (g, a, b) => a !== b && (g.countries[a].overlord === b || g.countries[b].overlord === a);
// ---------- разведданные: точные числа войск видны только у своих, союзников и вассалов ----------
export const knowsTroops = (g, owner) => g.playerId == null || owner === g.playerId || sameFaction(g, g.playerId, owner) || vassalLink(g, g.playerId, owner);
export function approxTroops(g, owner, n, key = 0) {
  if (n <= 0) return 0;
  let h = (owner * 7919 + key * 104729 + Math.floor(g.day / 20) * 15485863) >>> 0;   // оценка меняется раз в 20 дней
  h = Math.imul(h ^ (h >>> 15), 2246822519) >>> 0; h = Math.imul(h ^ (h >>> 13), 3266489917) >>> 0;
  const v = n * (1 + ((h % 1000) / 1000 - 0.5) * 0.36);   // ошибка до ±18%
  const step = v < 30 ? 5 : v < 100 ? 10 : v < 400 ? 25 : v < 1500 ? 100 : 250;
  return Math.max(step, Math.round(v / step) * step);
}
// Сколько войск видит игрок: {n, approx}
export const seenTroops = (g, owner, n, key = 0) => (knowsTroops(g, owner) || (key && g._recon && g._recon.has(key)) ? { n: Math.ceil(n), approx: false } : { n: approxTroops(g, owner, n, key), approx: true });
export function troopText(g, owner, n, key = 0) {
  const t = seenTroops(g, owner, n, key);
  return (t.approx ? '≈' : '') + Math.round(t.n).toLocaleString('ru-RU');
}
// Чужие армии видны игроку только у его границы (в его провинциях и в соседних с ними); свои, союзные и вассальные видны всегда.
export function armyVisible(g, a) {
  const me = g.playerId;
  if (me == null || a.owner === me || friendly(g, me, a.owner)) return true;
  if (g._recon && g._recon.has(a.at)) return true; // разведка с воздуха
  const p = prov(g, a.at);
  return p.props.owner === me || p.neighbors.some((n) => prov(g, n).props.owner === me);
}
export const friendly = (g, a, b) => a === b || sameFaction(g, a, b) || vassalLink(g, a, b);
export const vassalsOf = (g, id) => g.countries.filter((c) => c.alive && c.overlord === id);
export const hasGoal = (g, a, b) => (g.justify || []).some((j) => j.a === a && j.b === b && g.day >= j.end && g.day < j.end + RULES.goalLife);
export const justifying = (g, a, b) => (g.justify || []).find((j) => j.a === a && j.b === b && g.day < j.end) || null;
export const guaranteed = (g, by, of) => (g.guar || []).some((x) => x.by === by && x.of === of);

export function addGuarantee(g, by, of) {
  if (by === of || guaranteed(g, by, of)) return false;
  g.guar.push({ by, of, day: g.day });
  addRel(g, of, by, 10);
  emit(g, `${g.countries[by].name} гарантирует независимость ${g.countries[of].name}`, [by, of], 'alliance');
  return true;
}

// Очки войны a против b: доля занятых ядер b плюс столица.
// Метрополия страны b: провинции её ядра, связанные с столицей по суше (без паромов). Остальное — колонии.
function homeland(g, b) {
  const c = g.countries[b];
  const key = Math.floor(g.day / 30);
  if (c._home && c._home.key === key) return c._home.set;
  const set = new Set();
  const cap = c.capital != null ? prov(g, c.capital) : null;
  if (cap) {
    set.add(cap.id);
    const q = [cap.id];
    for (let i = 0; i < q.length; i++) for (const n of prov(g, q[i]).neighbors) {
      if (set.has(n) || prov(g, n).props.core !== b || seaGap(g, q[i], n) !== undefined) continue;
      set.add(n); q.push(n);
    }
  }
  Object.defineProperty(c, '_home', { value: { key, set }, writable: true, configurable: true, enumerable: false });
  return set;
}

// Очки войны a против b: доля захваченной ценности земель ядра b (золото + люди) плюс захваченная столица.
// Колонии за морем весят вдвое меньше метрополии, чтобы пустыни Сахары не мешали закончить войну.
export function warScore(g, a, b) {
  const home = homeland(g, b);
  let total = 0, held = 0;
  for (const p of g.world.provinces.values()) {
    if (p.props.core !== b) continue;
    const v = (p.props.wealth + p.props.pop / 60) * (home.has(p.id) ? 1 : RULES.colonyWeight);
    total += v;
    if (p.props.owner === a) held += v;
  }
  const cb = g.countries[b], cap = cb.capital != null ? prov(g, cb.capital) : null;
  const capHeld = cap && cap.props.owner === a ? 30 : 0;
  return Math.min(100, Math.round(130 * held / Math.max(1e-9, total) + capHeld));
}

export function vassalize(g, overlord, vassal) {
  const v = g.countries[vassal];
  const ctx = { mates: friendsOf(g, vassal) };
  if (g.wars.has(warKey(overlord, vassal))) makePeace(g, overlord, vassal);
  removeFromFaction(g, vassal);
  v.overlord = overlord;
  g.guar = g.guar.filter((x) => x.by !== vassal && x.of !== vassal);
  addRel(g, vassal, overlord, 20);
  emit(g, `${v.name} стала вассалом страны ${g.countries[overlord].name}`, [vassal, overlord], 'peace');
  if (hooks.vassal) hooks.vassal(g, vassal, overlord, ctx);
  return true;
}

// Сюзерен вступает в войну, и вассалы идут за ним
function bringVassals(g, a, b) {
  for (const v of vassalsOf(g, a)) if (v.id !== b) joinWar(g, v.id, b);
}

// Провинции ядра owner, занятые holder и не закреплённые договором, при мире возвращаются owner
export function returnOccupied(g, holder, owner) {
  if (!g.countries[owner].alive) return 0;
  let n = 0;
  for (const p of g.world.provinces.values()) {
    if (p.props.owner !== holder || p.props.core !== owner || p.props.treaty) continue;
    p.props.owner = owner; p.props.project = null; p.props.comp = 80;
    n++;
  }
  return n;
}

export function makePeace(g, a, b, keepHelpers = false) {
  if (!g.wars.delete(warKey(a, b))) return false;
  // страны, вступившие в эту войну ради защиты одной из сторон, выходят из неё вместе с ней
  const wf = g.warFor;
  if (wf && keepHelpers) delete wf[warKey(a, b)];
  else if (wf) {
    delete wf[warKey(a, b)];
    for (const [k, victim] of Object.entries(wf)) {
      const [x, y] = k.split('|').map(Number);
      const other = victim === a ? b : victim === b ? a : null;
      if (other == null || (x !== other && y !== other)) continue;
      delete wf[k];
      const helper = x === other ? y : x;
      if (g.wars.has(k)) makePeace(g, helper, other);
    }
  }
  // захваченное в этой войне, но не закреплённое договором, возвращается прежнему владельцу
  returnOccupied(g, a, b);
  returnOccupied(g, b, a);
  relocateAfterPeace(g, a, b);
  relocateAfterPeace(g, b, a);
  addRel(g, a, b, 10);
  emit(g, `Мир между ${g.countries[a].name} и ${g.countries[b].name}`, [a, b], 'peace');
  return true;
}

export function warAge(g, a, b) { return g.day - (g.wars.get(warKey(a, b)) ?? g.day); }

// Цена объявления войны в политической власти. Война с членом общей организации с санкциями вдвое дороже.
export function sharedSanction(g, a, b) {
  if (b == null) return false;
  const ca = g.countries[a], cb = g.countries[b];
  return ca.orgs.some((id) => ORGS[id].sanction && cb.orgs.includes(id));
}
export const warCost = (g, a, b) => Math.round(RULES.warPP * g.countries[a].mod.war * (sharedSanction(g, a, b) ? 2 : 1) * (hasGoal(g, a, b) ? 0.5 : 1));

// Объявление войны за политическую власть (игрок и ИИ). Нападение на члена альянса втягивает в войну весь альянс.
export function tryDeclareWar(g, a, b) {
  const c = g.countries[a], cost = warCost(g, a, b);
  if (a === b || atWar(g, a, b)) return { ok: false, msg: 'Война уже идёт' };
  if (sameFaction(g, a, b)) return { ok: false, msg: 'Это член вашего альянса' };
  if (c.overlord != null) return { ok: false, msg: 'Вассал не может объявлять войны' };
  if (vassalLink(g, a, b)) return { ok: false, msg: 'Это ваш вассал или сюзерен' };
  if (c.pp < cost) return { ok: false, msg: `Не хватает политической власти: нужно ${cost}` };
  const sanction = sharedSanction(g, a, b);
  const goal = hasGoal(g, a, b);
  if (!declareWar(g, a, b)) return { ok: false, msg: 'Нельзя объявить войну' };
  c.pp -= cost;
  g.justify = g.justify.filter((j) => !(j.a === a && j.b === b));
  if (!goal && a === g.playerId) {
    c.stability = Math.max(0, c.stability - RULES.unjustStab);
    g.tension = Math.min(100, g.tension + RULES.unjustTension);
    emit(g, `Нападение без повода подорвало стабильность: ${c.name}`, [a], 'war');
  }
  addRel(g, a, b, -40);
  for (const m of factionMates(g, b)) addRel(g, a, m, -15);
  if (sanction) emit(g, `Лига Наций осудила нападение ${c.name} на ${g.countries[b].name}`, [a, b], 'war');
  triggerDefense(g, a, b);
  bringVassals(g, a, b);
  return { ok: true };
}

// Ответ ИИ на предложение мира от игрока.
export function proposePeace(g, from, to) {
  if (!atWar(g, from, to)) return { ok: false, msg: 'Вы не воюете' };
  if (g.countries[from].pp < RULES.peacePP) return { ok: false, msg: `Не хватает политической власти: нужно ${RULES.peacePP}` };
  refreshStats(g);
  const age = warAge(g, from, to);
  const mine = g.stats[from].troops, theirs = g.stats[to].troops;
  if (age < 20) return { ok: false, msg: `${g.countries[to].name} не хочет мира: война только началась` };
  if (theirs > mine * 1.5) return { ok: false, msg: `${g.countries[to].name} считает, что побеждает` };
  g.countries[from].pp -= RULES.peacePP;
  makePeace(g, from, to);
  return { ok: true, msg: 'Мир заключён' };
}

function relocateAfterPeace(g, owner, other) {
  for (const a of [...g.armies]) {
    if (a.owner !== owner || prov(g, a.at).props.owner !== other) continue;
    const res = g.world.findPath(a.at, (p) => p.props.owner === owner, (p) => (TERRAIN[p.props.terrain].passable ? 1 : Infinity));
    a.order = null;
    if (res && res.path.length) a.at = res.path[res.path.length - 1];
    else g.armies.splice(g.armies.indexOf(a), 1);
  }
}

// ---------- отношения, альянсы, организации ----------
export const sameFaction = (g, a, b) => a !== b && g.countries[a].faction != null && g.countries[a].faction === g.countries[b].faction;
export const factionOf = (g, c) => (c.faction == null ? null : g.factions.find((f) => f.id === c.faction) || null);
// Остальные члены альянса страны (без неё самой).
export function factionMates(g, id) {
  const f = factionOf(g, g.countries[id]);
  return f ? f.members.filter((m) => m !== id) : [];
}

export function addRel(g, a, b, delta) {
  if (a === b) return;
  const k = warKey(a, b);
  const v = Math.max(-100, Math.min(100, (g.rel[k] || 0) + delta));
  if (Math.abs(v) < 0.5) delete g.rel[k]; else g.rel[k] = v;
}

// Отношение a к b, от −100 до 100: накопленное, общие организации, один альянс, война, общий враг.
export function opinion(g, a, b) {
  if (a === b) return 100;
  const ca = g.countries[a], cb = g.countries[b];
  let v = g.rel[warKey(a, b)] || 0;
  let shared = 0;
  for (const o of ca.orgs) if (cb.orgs.includes(o)) shared++;
  v += Math.min(3, shared) * 8;
  if (sameFaction(g, a, b)) v += 30;
  if (ca.ideo !== cb.ideo) {
    const k = [ca.ideo, cb.ideo].sort().join('+');
    v += k === 'com+fas' ? -20 : k === 'dem+fas' || k === 'com+dem' ? -8 : 0;
  } else if (ca.ideo !== 'aut') v += 8;
  if (vassalLink(g, a, b)) v += 40;
  if ((g.trade || []).some((d) => (d.from === a && d.to === b) || (d.from === b && d.to === a))) v += RULES.tradeOpinion;
  if (atWar(g, a, b)) v -= 50;
  else v += Math.min(20, 10 * commonEnemies(g, a, b));
  return Math.max(-100, Math.min(100, Math.round(v)));
}

export function commonEnemies(g, a, b) {
  let n = 0;
  for (const k of g.wars.keys()) {
    const [x, y] = k.split('|').map(Number);
    const e = x === a ? y : y === a ? x : null;
    if (e != null && e !== b && atWar(g, b, e)) n++;
  }
  return n;
}

export function initDiplomacy(g) {
  g.rel = {};
  const byName = new Map(g.countries.map((c) => [c.name, c.id]));
  if (g.scenario === 'europe1936') for (const [x, y, v] of HIST_REL) if (byName.has(x) && byName.has(y)) addRel(g, byName.get(x), byName.get(y), v);
  for (const [id, o] of Object.entries(ORGS)) {
    const members = g.scenario === 'europe1936' ? o.members.filter((n) => byName.has(n)).map((n) => byName.get(n)) : [];
    for (const m of members) g.countries[m].orgs.push(id);
  }
  for (const c of g.countries) recalcMods(c);
}

// Страна выходит из альянса. Если уходил лидер, лидером становится самый большой член, а в одиночку альянс распадается.
export function removeFromFaction(g, id) {
  const c = g.countries[id], f = factionOf(g, c);
  if (!f) return;
  c.faction = null;
  f.members = f.members.filter((m) => m !== id);
  if (f.members.length < 2) {
    for (const m of f.members) g.countries[m].faction = null;
    g.factions = g.factions.filter((x) => x !== f);
    emit(g, `${f.name} распался`, [id, ...f.members], 'alliance');
    return;
  }
  if (f.leader === id) {
    const size = (m) => { let n = 0; for (const p of g.world.provinces.values()) if (p.props.owner === m) n++; return n; };
    f.leader = f.members.reduce((best, m) => (size(m) > size(best) ? m : best), f.members[0]);
    emit(g, `${g.countries[f.leader].name} возглавила ${f.name}`, [f.leader], 'alliance');
  }
}

// Нападение на члена альянса: все остальные члены объявляют агрессору войну.
function triggerDefense(g, aggressor, victim) {
  const bound = new Set((g.guar || []).filter((x) => x.of === victim).map((x) => x.by));
  const helpers = new Set([...factionMates(g, victim), ...bound, ...vassalsOf(g, victim).map((v) => v.id)]);
  if (g.countries[victim].overlord != null) helpers.add(g.countries[victim].overlord);
  const joined = [];
  for (const m of helpers) {
    const mc = g.countries[m];
    if (!mc.alive || m === aggressor || atWar(g, m, aggressor) || sameFaction(g, m, aggressor) || vassalLink(g, m, aggressor)) continue;
    // пакт о ненападении: страна не вступает в войны партнёра, даже за гарантированную
    if (g.countries[aggressor].flags && g.countries[aggressor].flags['pact_' + (mc.base || mc.name)] != null) continue;
    // демократии вступаются за блок только при высокой напряжённости (гарантии обязывают всегда)
    if (m !== g.playerId && !bound.has(m) && isDemocracy(g, mc) && g.tension < RULES.demDefense) {
      emit(g, `${mc.name} не решилась вступить в войну`, [m, victim], 'alliance');
      continue;
    }
    if (declareWar(g, m, aggressor)) {
      addRel(g, m, aggressor, -30);
      emit(g, `${mc.name} вступила в войну на стороне ${g.countries[victim].name}`, [m, aggressor, victim], 'alliance');
      joined.push(m);
      (g.warFor = g.warFor || {})[warKey(m, aggressor)] = victim;
    }
  }
  // союзники вступившей страны (Англия за Францией) идут следом: блок воюет вместе
  for (const j of joined) for (const m of factionMates(g, j)) {
    const mc = g.countries[m];
    if (!mc.alive || m === aggressor || atWar(g, m, aggressor) || sameFaction(g, m, aggressor) || vassalLink(g, m, aggressor)) continue;
    if (declareWar(g, m, aggressor)) {
      addRel(g, m, aggressor, -30);
      emit(g, `${mc.name} вступила в войну вслед за ${g.countries[j].name}`, [m, aggressor, j], 'alliance');
      (g.warFor = g.warFor || {})[warKey(m, aggressor)] = victim;
    }
  }
}

// Исторические отношения сценария: к ним со временем возвращаются все накопленные отношения.
function histBase(g) {
  if (g._base) return g._base;
  const base = {};
  if (g.scenario === 'europe1936') {
    const byName = new Map(g.countries.map((c) => [c.base || c.name, c.id]));
    for (const [x, y, v] of HIST_REL) if (byName.has(x) && byName.has(y)) base[warKey(byName.get(x), byName.get(y))] = v;
  }
  Object.defineProperty(g, '_base', { value: base, enumerable: false, writable: true });
  return base;
}

// Ежедневные дела: отношения возвращаются к историческим, устаревшие предложения игроку исчезают.
function progressDiplomacy(g) {
  const base = histBase(g);
  g.tension = Math.max(Math.min(g.tension || 0, RULES.tensionFloor), (g.tension || 0) - RULES.tensionDecay);
  g.justify = (g.justify || []).filter((j) => g.day < j.end + RULES.goalLife);
  for (const k of Object.keys(g.rel)) {
    const b = base[k] || 0, v = g.rel[k];
    if (Math.abs(v - b) <= RULES.relDecay) { if (b) g.rel[k] = b; else delete g.rel[k]; } else g.rel[k] = v - Math.sign(v - b) * RULES.relDecay;
  }
  g.offers = g.offers.filter((o) => g.day - o.day < RULES.offerDays);
}

// Вступление в войну по призыву союзника: без цены власти, но с последствиями для отношений и обороной врага.
export function joinWar(g, a, b) {
  if (a === b || sameFaction(g, a, b) || atWar(g, a, b) || !g.countries[a].alive || !g.countries[b].alive) return false;
  if (!declareWar(g, a, b)) return false;
  addRel(g, a, b, -30);
  triggerDefense(g, a, b);
  bringVassals(g, a, b);
  return true;
}

// ---------- перемещение ----------
const pairKey = (a, b) => (a < b ? a * 65536 + b : b * 65536 + a);
// Морские переходы из портов: g._portGap — пара провинций → ширина моря; g._portNb — добавленные соседства
export function refreshPorts(g) {
  for (const [a, b] of g._portNb || []) {
    const pa = g.world.provinces.get(a), pb = g.world.provinces.get(b);
    if (pa) pa.neighbors = pa.neighbors.filter((x) => x !== b);
    if (pb) pb.neighbors = pb.neighbors.filter((x) => x !== a);
  }
  const gaps = new Map(), nb = [], ports = [];
  for (const p of g.world.provinces.values()) {
    const lv = p.props.built && p.props.built.length ? p.props.built.filter((x) => x === 'port').length : 0;
    if (!lv) continue;
    ports.push({ pid: p.id, level: lv });
    const range = RULES.portRange[Math.min(lv, RULES.portRange.length) - 1];
    for (const [id, gap] of g.world.seaReach(p.id, range)) {
      if (p.neighbors.includes(id) || g.world.ferryGap(p.id, id) !== undefined) continue;
      const k = pairKey(p.id, id);
      if (gaps.has(k)) { if (gap < gaps.get(k)) gaps.set(k, gap); continue; }
      gaps.set(k, gap);
      nb.push([p.id, id]);
      p.neighbors.push(id);
      const q = g.world.provinces.get(id);
      if (!q.neighbors.includes(p.id)) q.neighbors.push(p.id);
    }
  }
  g._portGap = gaps; g._portNb = nb; g._ports = ports; g._portsDirty = false;
}
const ensurePorts = (g) => { if (g._portGap === undefined || g._portsDirty) refreshPorts(g); };
// Ширина моря на шаге a→b: обычная переправа или морской переход из порта (иначе undefined)
export function seaGap(g, a, b) {
  const f = g.world.ferryGap(a, b);
  if (f !== undefined) return f;
  return g._portGap ? g._portGap.get(pairKey(a, b)) : undefined;
}
const portOpen = (g, owner, pid) => { const q = prov(g, pid); return levelOf(q, 'port') > 0 && q.props.owner != null && friendly(g, owner, q.props.owner); };

// Дополнительные дни на морскую переправу (0 для сухопутной границы)
export function ferryExtra(g, a, b) {
  const f = g.world.ferryGap(a, b);
  if (f !== undefined) return RULES.ferryDays + 3 * Math.max(0, f);
  const gap = g._portGap ? g._portGap.get(pairKey(a, b)) : undefined;
  return gap === undefined ? 0 : RULES.ferryDays + RULES.portHex * gap;
}

export function moveCostFn(g, owner) {
  const blocked = new Map(); // чужая страна → закрыта ли её земля для нас (кэш на время поиска)
  const ferry = g.world._ferryGap, portGap = g._portGap;
  return (p, from) => {
    if (!TERRAIN[p.props.terrain].passable) return Infinity;
    const po = p.props.owner;
    if (po !== owner && po != null) {
      let b = blocked.get(po);
      if (b === undefined) { b = !atWar(g, owner, po) && !friendly(g, owner, po); blocked.set(po, b); }
      if (b) return Infinity;
    }
    let extra = 0;
    if (from) {
      const k = pairKey(from.id, p.id);
      const f = ferry.get(k);
      if (f !== undefined) extra = RULES.ferryDays + 3 * Math.max(0, f);
      else if (portGap) {
        const gp = portGap.get(k);
        if (gp !== undefined) {
          // морской переход возможен только из своего (союзного) порта или в него
          if (!portOpen(g, owner, from.id) && !portOpen(g, owner, p.id)) return Infinity;
          extra = RULES.ferryDays + RULES.portHex * gp;
        }
      }
    }
    return moveCostOf(p) + extra;
  };
}

export function previewPath(g, owner, fromId, toId) {
  if (fromId === toId) return null;
  ensurePorts(g);
  return g.world.findPath(fromId, toId, moveCostFn(g, owner));
}

export function idleArmiesAt(g, owner, pid) {
  return g.armies.filter((a) => a.at === pid && a.owner === owner && !a.order);
}
export function armiesAt(g, pid) { return g.armies.filter((a) => a.at === pid); }
export function troopsAt(g, owner, pid) { return sum(g.armies.filter((a) => a.at === pid && a.owner === owner), (a) => a.strength); }

// Армия в анклаве: рядом нет ни одной провинции своей страны или друзей (союзники, вассалы, сюзерен).
// Такая армия не может атаковать: входить в провинцию с врагом или во вражескую землю. Десант первые дни после высадки не считается окружённым.
export function encircled(g, owner, pid, army) {
  if (army && army.landed != null && g.day - army.landed <= RULES.landFreeDays) return false;
  const p = prov(g, pid);
  for (const n of p.neighbors) {
    if (seaGap(g, pid, n) !== undefined) continue; // через пролив соседа нет
    const o = prov(g, n).props.owner;
    if (o != null && friendly(g, owner, o)) return false;
  }
  return true;
}
const isHostileStep = (g, owner, toId) => {
  const o = prov(g, toId).props.owner;
  return (o != null && atWar(g, owner, o)) || g.armies.some((x) => x.at === toId && x.owner !== owner && atWar(g, owner, x.owner));
};

// pre — уже найденный кратчайший путь {path, cost} (ИИ ищет его сам и не считает повторно)
export function orderMove(g, owner, fromId, toId, fraction = 1, pre) {
  ensurePorts(g);
  const res = pre || previewPath(g, owner, fromId, toId);
  if (!res) return { ok: false, msg: 'Туда не пройти' };
  const idle = idleArmiesAt(g, owner, fromId);
  if (!idle.length) return { ok: false, msg: 'Нет свободных войск' };
  if (res.path.length && isHostileStep(g, owner, res.path[0]) && encircled(g, owner, fromId, idle[0])) return { ok: false, msg: 'Армия окружена: без своих земель рядом атаковать нельзя' };
  const main = idle[0];
  for (let i = 1; i < idle.length; i++) {
    main.strength += idle[i].strength;
    g.armies.splice(g.armies.indexOf(idle[i]), 1);
  }
  const total = main.strength;
  const amount = Math.min(total, Math.max(1, Math.round(total * fraction)));
  let mover = main;
  if (amount < total - 0.01) {
    mover = addArmy(g, owner, fromId, amount);
    main.strength -= amount;
  }
  mover.order = { path: res.path.slice(), progress: 0 };
  mover.rebel = false;
  mover.manual = g.day;
  return { ok: true, days: res.cost, amount };
}

export function stopArmies(g, owner, pid) {
  for (const a of g.armies) if (a.owner === owner && a.at === pid && a.order) a.order = null;
}

function moveArmies(g) {
  for (const a of g.armies) {
    const o = a.order;
    if (!o) continue;
    const next = prov(g, o.path[0]);
    const from = prov(g, a.at);
    const cost = moveCostFn(g, a.owner)(next, from);
    if (cost === Infinity) { a.order = null; continue; }
    const me = g.countries[a.owner];
    // атака (вход в провинцию с врагом) возможна не чаще раза в attackCooldown дней: армия перегруппировывается
    const hostile = (id) => g.armies.some((x) => x.at === id && x.owner !== a.owner && atWar(g, a.owner, x.owner));
    if ((a.coolUntil || 0) > g.day && hostile(next.id)) continue;
    if (!a.rebel && isHostileStep(g, a.owner, next.id) && encircled(g, a.owner, a.at, a)) { a.order = null; continue; } // окружённая армия атаковать не может
    if (me.noFuel && !a.rebel && isHostileStep(g, a.owner, next.id)) continue; // без топлива наступать нельзя
    o.progress += me.mod.speed * (me.noFuel ? RULES.noFuelSpeed : me.lowFuel ? RULES.lowFuelSpeed : 1) * (RULES.weather ? weatherEffects(g, from, me).mv : 1);
    if (o.progress >= cost - 1e-9) {
      const attacked = hostile(next.id);
      const sea = seaGap(g, a.at, next.id) !== undefined;
      a.at = next.id;
      if (sea) { a.landed = g.day; a.org = orgOf(a) - RULES.landOrg; }
      if (attacked) a.coolUntil = g.day + RULES.attackCooldown;
      a.dig = 0;
      o.path.shift();
      o.progress = 0;
      if (!o.path.length) a.order = null;
    }
  }
}

function mergeIdle(g) {
  const seen = new Map();
  g.armies = g.armies.filter((a) => {
    if (a.order) return true;
    const k = a.owner + '|' + a.at + '|' + (a.hq || 0) + (a.rebel ? 'r' : '');
    const main = seen.get(k);
    if (main) {
      const t = main.strength + a.strength;
      main.org = (orgOf(main) * main.strength + orgOf(a) * a.strength) / t;
      main.dig = Math.min(digOf(main), digOf(a));
      main.coolUntil = Math.max(main.coolUntil || 0, a.coolUntil || 0);
      main.strength = t; return false;
    }
    seen.set(k, a);
    return true;
  });
}

// ---------- бои и захват ----------
// Враждебны ли две группы войск в провинции: война между странами либо повстанцы против владельца провинции
function groupsHostile(g, x, y, p) {
  if (atWar(g, x.owner, y.owner)) return true;
  const o = p.props.owner;
  return (y.owner === o && x.armies.some((a) => a.rebel)) || (x.owner === o && y.armies.some((a) => a.rebel));
}

function groupsAt(g) {
  const byProv = new Map();
  for (const a of g.armies) {
    let m = byProv.get(a.at);
    if (!m) { m = new Map(); byProv.set(a.at, m); }
    let grp = m.get(a.owner);
    if (!grp) { grp = { owner: a.owner, total: 0, armies: [] }; m.set(a.owner, grp); }
    grp.total += a.strength;
    grp.armies.push(a);
  }
  return byProv;
}

const orgOf = (a) => (a.org == null ? 100 : a.org);
const digOf = (a) => a.dig || 0;

// В снабжении ли армия: свои или союзные земли не дальше supplyRange переходов (считается по сухопутным соседям)
const friendly_ = (g, a, b) => friendly(g, a, b);
function inSupply(g, a, cache) {
  if (a.rebel) return true;
  const key = a.owner + '|' + a.at;
  if (cache.has(key)) return cache.get(key);
  const friendly = (pid) => { const o = prov(g, pid).props.owner; return o === a.owner || (o != null && friendly_(g, a.owner, o)); };
  let ok = friendly(a.at);
  if (!ok) {
    let frontier = [a.at];
    const seen = new Set(frontier);
    const range = RULES.supplyRange + Math.floor(g.countries[a.owner].mod.supply);
    for (let d = 0; d < range && !ok; d++) {
      const next = [];
      for (const id of frontier) for (const nb of prov(g, id).neighbors) {
        if (seen.has(nb)) continue;
        seen.add(nb); next.push(nb);
        if (friendly(nb)) { ok = true; break; }
      }
      frontier = next;
    }
  }
  cache.set(key, ok);
  return ok;
}

// Куда отступает армия: соседняя провинция без вражеских войск, свои и союзные земли предпочтительнее
function retreatTo(g, a, byProv) {
  let best = null, bs = -1;
  for (const nb of prov(g, a.at).neighbors) {
    if (seaGap(g, a.at, nb) !== undefined) continue;
    const m = byProv.get(nb);
    if (m && [...m.values()].some((e) => atWar(g, a.owner, e.owner))) continue;
    const o = prov(g, nb).props.owner;
    const sc = (o === a.owner ? 3 : o != null && friendly(g, a.owner, o) ? 2 : o == null || !atWar(g, a.owner, o) ? 1 : 0.5) + g.rng() * 0.1;
    if (sc > bs) { bs = sc; best = nb; }
  }
  return best;
}

function resolveBattles(g) {
  for (const a of g.armies) a.fighting = false;
  const byProv = groupsAt(g);
  const hits = [];
  const sup = new Map();
  const orgFactor = (x) => RULES.orgMinFactor + (1 - RULES.orgMinFactor) * Math.max(0, orgOf(x)) / 100;
  for (const [pid, m] of byProv) {
    if (m.size < 2) continue;
    const p = prov(g, pid);
    for (const grp of m.values()) {
      let dmg = 0;
      for (const e of m.values()) {
        if (e === grp || !groupsHostile(g, grp, e, p)) continue;
        const ec = g.countries[e.owner];
        // бьют те, у кого есть организация и снабжение; сила армий вклёвывается в урон пропорционально
        let q = 0;
        for (const x of e.armies) q += x.strength * orgFactor(x) * (inSupply(g, x, sup) ? 1 : RULES.supplyAttack) * (x.landed != null && g.day - x.landed < RULES.landDays ? RULES.landAttack : 1);
        dmg += q * RULES.battleRate * (0.85 + g.rng() * 0.3) * ec.mod.attack * (p.props.owner === e.owner ? 1 : terrainAttack(ec, p.props.terrain) * (RULES.weather ? weatherEffects(g, p, ec).atk : 1)) * (ec.noFuel ? RULES.noFuelPenalty : ec.lowFuel ? RULES.lowFuelAttack : 1) * stabilityEffects(ec.stability).combat;
        for (const x of e.armies) x.fighting = true;
      }
      if (dmg <= 0) continue;
      for (const x of grp.armies) x.fighting = true;
      let def = 1;
      if (p.props.owner === grp.owner) def = provinceDefense(p, g);
      let dig = 0;
      for (const x of grp.armies) dig += digOf(x) * x.strength;
      def *= 1 + RULES.digBonus * (dig / Math.max(1, grp.total));
      hits.push({ grp, dmg: Math.max(0.5, dmg / def) });
    }
  }
  const routed = [];
  for (const { grp, dmg } of hits) {
    const frac = Math.min(1, dmg / grp.total);
    const k = Math.max(0, 1 - frac);
    const orgLoss = (RULES.orgBase + RULES.orgLossK * frac) * Math.max(0.3, g.countries[grp.owner].mod.orgLoss);
    for (const a of grp.armies) {
      a.strength *= k;
      a.org = orgOf(a) - orgLoss;
      a.dig = Math.max(0, digOf(a) - 0.5);
      if (a.org <= 0 && a.strength >= 0.5) routed.push(a);
    }
  }
  for (const a of routed) {
    if (a.rebel) { a.strength = 0; continue; }
    const dest = retreatTo(g, a, byProv);
    if (dest != null && !a.order) {
      const from = prov(g, a.at).name;
      a.at = dest; a.order = null; a.org = 20; a.dig = 0; a.strength *= RULES.routKeep; a.fighting = false;
      if (a.owner === g.playerId && a.strength >= 5) emit(g, `Армия отступила из провинции ${from}`, [a.owner], 'war');
    } else if (dest != null) {
      a.at = dest; a.order = null; a.org = 20; a.dig = 0; a.strength *= RULES.routKeep; a.fighting = false;
    } else {
      // отступать некуда: армия уничтожена
      if (a.owner === g.playerId && a.strength >= 3) emit(g, `Армия в ${prov(g, a.at).name} уничтожена: отступать было некуда`, [a.owner], 'war');
      a.strength = 0;
    }
  }
  // восстановление организации и окапывание
  for (const a of g.armies) {
    if (a.fighting) continue;
    const supplied = inSupply(g, a, sup);
    if (RULES.weather && (a.order || (prov(g, a.at).props.owner !== a.owner && !friendly(g, a.owner, prov(g, a.at).props.owner)))) {
      const wa = weatherEffects(g, prov(g, a.at), g.countries[a.owner]).attr;
      if (wa) a.org = orgOf(a) - wa;
    }
    if (!supplied) a.org = orgOf(a) - RULES.supplyOrgLoss;
    else a.org = Math.min(100, orgOf(a) + (a.order ? RULES.orgRegenMove : RULES.orgRegen) * g.countries[a.owner].mod.org * (g.countries[a.owner].noFuel ? 0.5 : 1));
    if (!a.order) a.dig = Math.min(RULES.digMax, digOf(a) + RULES.digStep * g.countries[a.owner].mod.dig);
    else a.dig = 0;
  }
  g.armies = g.armies.filter((a) => a.strength >= 0.5 && orgOf(a) > -50);
  for (const a of g.armies) if (a.org < 0) a.org = 0;
}

// Подчинение оккупированных земель: растёт быстрее при гарнизоне; без гарнизона и при низком подчинении возможно восстание
function progressOccupation(g) {
  const garrison = new Set();
  for (const a of g.armies) if (!a.fighting && !a.order) garrison.add(a.owner + '|' + a.at);
  const unrest = g.countries.map(() => 0);
  for (const p of g.world.provinces.values()) {
    const o = p.props.owner;
    if (o == null) continue;
    let c = p.props.comp;
    if (c == null) { p.props.comp = 100; continue; }
    if (c >= 100) continue;
    const own = p.props.core === o || p.props.core == null;
    const gar = garrison.has(o + '|' + p.id);
    c = Math.min(100, c + (own ? RULES.compCore : gar ? RULES.compGarrison : RULES.compFree) * (own ? 1 : g.countries[o].mod.comp));
    p.props.comp = c;
    if (own || c >= 100) continue;
    if (!gar) {
      unrest[o] += (100 - c) / 100;
      const core = p.props.core;
      if (c < RULES.revoltComp && core != null && g.countries[core].alive && core !== o && g.rng() < RULES.revoltChance * (1 + (RULES.revoltComp - c) / 25)
          && !g.armies.some((a) => a.at === p.id && a.rebel)) {
        const reb = addArmy(g, core, p.id, Math.round((RULES.rebelMin + RULES.rebelMax * (1 - c / 100)) * 10) / 10);
        reb.rebel = true; reb.org = 70;
        emit(g, `Восстание в провинции ${p.name}: повстанцы ${g.countries[core].name} (${Math.ceil(reb.strength)})`, [o, core], 'war');
      }
    }
  }
  Object.defineProperty(g, 'occUnrest', { value: unrest, enumerable: false, writable: true, configurable: true });
}

function resolveOccupation(g) {
  for (const [pid, m] of groupsAt(g)) {
    const groups = [...m.values()];
    // пока на провинции идёт бой, захвата нет
    const p = prov(g, pid);
    if (groups.some((x, i) => groups.some((y, j) => j > i && groupsHostile(g, x, y, p)))) continue;
    const prev = p.props.owner;
    // повстанцы остались одни — провинция освобождена
    const reb = groups.find((x) => x.owner !== prev && x.armies.some((a) => a.rebel) && g.countries[x.owner].alive);
    if (reb) {
      p.props.owner = reb.owner; p.props.project = null; p.props.comp = 70;
      for (const a of reb.armies) a.rebel = false;
      emit(g, `Повстанцы освободили ${p.name}: провинция вернулась к ${g.countries[reb.owner].name}`, [reb.owner, prev], 'capture');
      let left = 0;
      for (const q of g.world.provinces.values()) if (q.props.owner === prev) { left++; break; }
      if (!left) eliminate(g, prev, reb.owner);
      continue;
    }
    // захватывает самая сильная из армий, воюющих с владельцем (союзники вместе, но берёт сильнейший)
    let grp = null;
    for (const x of groups) if (x.owner !== prev && atWar(g, x.owner, prev) && (!grp || x.total > grp.total)) grp = x;
    if (!grp) continue;
    // родная провинция союзника (или вассала, сюзерена) возвращается ему, а не достаётся освободителю
    const home = p.props.core;
    if (home != null && home !== grp.owner && home !== prev && g.countries[home].alive && !atWar(g, grp.owner, home) && friendly(g, grp.owner, home)) {
      p.props.owner = home; p.props.treaty = false; p.props.project = null; p.props.comp = 70;
      g.countries[grp.owner].gold += RULES.captureLoot * 0.5 * g.countries[grp.owner].mod.loot;
      emit(g, `${g.countries[grp.owner].name} освободила ${p.name}${p.props.capital ? ' (столица!)' : ''}: провинция вернулась к ${g.countries[home].name}`, [grp.owner, home, prev], 'capture');
      let left = 0;
      for (const q of g.world.provinces.values()) if (q.props.owner === prev) { left++; break; }
      if (!left) eliminate(g, prev, home);
      continue;
    }
    p.props.owner = grp.owner; p.props.treaty = false;
    p.props.project = null;
    if (p.props.core == null) p.props.core = prev;
    p.props.comp = p.props.core === grp.owner ? 70 : RULES.compStart;
    g.countries[grp.owner].gold += RULES.captureLoot * g.countries[grp.owner].mod.loot;
    emit(g, `${g.countries[grp.owner].name} захватила ${p.name}${p.props.capital ? ' (столица!)' : ''}`, [grp.owner, prev], 'capture');
    let left = 0;
    for (const q of g.world.provinces.values()) if (q.props.owner === prev) { left++; break; }
    if (!left) eliminate(g, prev, grp.owner);
    else if (p.props.capital && hooks.capital) hooks.capital(g, prev, grp.owner);
  }
}

// Союзники и гаранты страны: для мировых новостей о её поражении
function friendsOf(g, id) {
  const c = g.countries[id], s = new Set();
  if (c.faction != null) for (const o of g.countries) if (o.alive && o.id !== id && o.faction === c.faction) s.add(o.id);
  for (const x of g.guar || []) if (x.of === id && g.countries[x.by].alive) s.add(x.by);
  return [...s];
}

export function eliminate(g, id, by) {
  const c = g.countries[id];
  const ctx = { mates: friendsOf(g, id) };
  c.alive = false;
  for (const o of g.countries) if (o.overlord === id) o.overlord = null;
  c.overlord = null;
  g.guar = (g.guar || []).filter((x) => x.by !== id && x.of !== id);
  g.lend = (g.lend || []).filter((x) => x.from !== id && x.to !== id);
  g.trade = (g.trade || []).filter((x) => x.from !== id && x.to !== id);
  g.justify = (g.justify || []).filter((x) => x.a !== id && x.b !== id);
  g.armies = g.armies.filter((a) => a.owner !== id);
  for (const k of [...g.wars.keys()]) if (k.split('|').map(Number).includes(id)) g.wars.delete(k);
  removeFromFaction(g, id);
  c.orgs = [];
  recalcMods(c);
  emit(g, `${c.name} пала`, [id, by], 'fall');
  if (hooks.fall) hooks.fall(g, id, by, ctx);
}

// ---------- экономика ----------
// Множитель дохода от размера страны: до RULES.sprawlFrom провинций 1, дальше падает по степени sprawlExp
export function sprawlFactor(n) {
  return n <= RULES.sprawlFrom ? 1 : Math.pow(RULES.sprawlFrom / n, RULES.sprawlExp);
}

export function economyPreview(g) {
  const inc = g.countries.map(() => ({ gold: 0, men: 0, res: 0, ind: 0, fuel: 0 }));
  const cnt = g.countries.map(() => 0);
  for (const p of g.world.provinces.values()) {
    const o = p.props.owner;
    if (o == null) continue;
    const pi = provinceIncome(p);
    const t = inc[o];
    t.gold += pi.gold; t.men += pi.men; t.res += pi.res; t.ind += pi.ind; t.fuel += pi.fuel;
    cnt[o]++;
  }
  // административные издержки: у огромных стран каждая провинция сверх порога приносит всё меньше
  for (let i = 0; i < inc.length; i++) {
    const f = sprawlFactor(cnt[i]);
    if (f < 1) for (const k in inc[i]) inc[i][k] *= f;
  }
  const troops = g.countries.map(() => 0), moving = g.countries.map(() => 0);
  for (const a of g.armies) {
    troops[a.owner] += a.strength;
    if (a.order || a.fighting) moving[a.owner] += a.strength;
  }
  const boost = DIFFICULTY[g.difficulty ?? 1].income;
  g.countries.forEach((c, i) => {
    const k = i === g.playerId ? 1 : boost, m = c.mod, t = inc[i];
    const se = stabilityEffects(c.stability), tx = TAX[c.tax];
    const gold = t.gold * m.gold * k * tx.gold * se.econ;
    const fuel = t.fuel * m.fuel * k;
    const use = moving[i] * RULES.fuelUse * m.fuelUse + Math.max(0, troops[i] - moving[i]) * RULES.fuelIdle;
    c.income = {
      gold, men: t.men * m.men * k * se.econ, res: (t.res + RULES.researchBase) * m.res * k * se.econ, ind: t.ind * m.ind * k * se.econ, fuel,
      pp: Math.max(0, RULES.ppBase + m.pp + se.pp), net: gold - troops[i] * RULES.upkeep * m.upkeep, fuelNet: fuel - use,
    };
  });
}

function economy(g) {
  economyPreview(g);
  for (const l of g.lend || []) {
    const f = g.countries[l.from], t = g.countries[l.to];
    if (!f.alive || !t.alive) continue;
    const amt = Math.min(f.gold, Math.max(0, f.income.gold) * RULES.lendShare);
    f.gold -= amt; t.gold += amt;
  }
  g.lend = (g.lend || []).filter((l) => g.day < l.until);
  for (const c of g.countries) {
    if (!c.alive) continue;
    const inc = c.income;
    { const r = mobRate(g, c.id); c.mobBank = Math.min(r * RULES.mobBankDays, (c.mobBank != null ? c.mobBank : r * RULES.mobStartDays) + r); }
    c.manpower += inc.men;
    c.gold += inc.net;
    if (c.overlord != null && g.countries[c.overlord].alive) {
      const t = Math.max(0, inc.gold) * RULES.tribute;
      c.gold -= t; g.countries[c.overlord].gold += t;
    }
    c.research += inc.res;
    c.industry += inc.ind;
    c.pp = Math.min(RULES.ppMax, c.pp + inc.pp);
    c.fuel += inc.fuelNet;
    const wasEmpty = c.noFuel;
    c.noFuel = c.fuel < 0;
    if (c.noFuel) c.fuel = 0;
    c.lowFuel = !c.noFuel && c.fuel < RULES.fuelLow;
    if (c.noFuel && !wasEmpty && c.id === g.playerId) emit(g, 'Топливо закончилось: армии не могут наступать на чужую землю, ход медленнее, урон ниже. Нужны нефть, торговля или синтетическое топливо.', [c.id], 'info');
    c.broke = c.gold < 0;
    const st = stabilityInfo(g, c).target;
    c.stability += Math.max(-RULES.stabStep, Math.min(RULES.stabStep, st - c.stability));
    if (c.gold < 0) {
      c.gold = 0;
      for (const a of g.armies) if (a.owner === c.id) a.strength *= 0.99;
    }
  }
}

export function canBuild(g, owner, pid, bid) {
  const p = prov(g, pid), b = BUILDINGS[bid], c = g.countries[owner];
  if (!p || !b) return { ok: false, msg: 'Нельзя построить' };
  if (p.props.owner !== owner) return { ok: false, msg: 'Не ваша провинция' };
  if (levelOf(p, bid) >= maxLevel(bid)) return { ok: false, msg: maxLevel(bid) > 1 ? 'Максимальный уровень' : 'Уже построено' };
  const pr = p.props.project;
  if (pr) return { ok: false, msg: pr.id === bid ? `Строится: ещё ${pr.left} дн.` : 'Здесь уже идёт стройка' };
  if (b.terrain && !b.terrain.includes(p.props.terrain)) return { ok: false, msg: b.terrainHint || 'Не подходит ландшафт' };
  if (g.armies.some((a) => a.at === pid && a.owner !== owner && atWar(g, owner, a.owner))) return { ok: false, msg: 'Идёт бой' };
  if (b.deposit && !p.props.deposit) return { ok: false, msg: b.terrainHint || 'Нужно месторождение' };
  if (b.coastal && !g.world.isCoastal(pid)) return { ok: false, msg: b.terrainHint || 'Нужно побережье' };
  const [pg, pi] = buildPrice(g, owner, bid, pid);
  if (c.gold < pg) return { ok: false, msg: 'Не хватает золота' };
  if (c.industry < pi) return { ok: false, msg: 'Не хватает промышленности' };
  return { ok: true };
}

// Цена постройки с учётом технологий: [золото, промышленность].
export function buildPrice(g, owner, bid, pid) {
  const b = BUILDINGS[bid], k = g.countries[owner].mod.build;
  const lc = pid != null ? LEVEL_COST[Math.min(levelOf(prov(g, pid), bid), LEVEL_COST.length - 1)] : 1; // цена следующего уровня
  return [Math.round(b.cost * k * lc), Math.round(b.ind * k * lc)];
}

export function startBuild(g, owner, pid, bid) {
  const can = canBuild(g, owner, pid, bid);
  if (!can.ok) return can;
  const [gold, ind] = buildPrice(g, owner, bid, pid);
  g.countries[owner].gold -= gold;
  g.countries[owner].industry -= ind;
  const lc = LEVEL_COST[Math.min(levelOf(prov(g, pid), bid), LEVEL_COST.length - 1)];
  prov(g, pid).props.project = { id: bid, left: Math.round(BUILDINGS[bid].days * lc) };
  return { ok: true };
}

function progressBuilds(g) {
  for (const p of g.world.provinces.values()) {
    const pr = p.props.project;
    if (!pr) continue;
    if (--pr.left > 0) continue;
    (p.props.built = p.props.built || []).push(pr.id);
    if (pr.id === 'port') g._portsDirty = true;
    p.props.project = null;
    emit(g, `Построено: ${BUILDINGS[pr.id].name}${maxLevel(pr.id) > 1 ? ' ' + 'I II III'.split(' ')[levelOf(p, pr.id) - 1] : ''}, ${p.name}`, [p.props.owner], 'build');
  }
}

// Сколько пачек (по recruitStack солдат) можно призвать сейчас: хватит людей, золота и промышленности
// Потолок армии в мирное время: растёт с числом провинций (корень — большая страна не вдвое больше при вдвое большей площади)
export function troopCap(g, owner) {
  let n = 0;
  for (const p of g.world.provinces.values()) if (p.props.owner === owner) n++;
  return Math.round(RULES.peaceBase + RULES.peaceK * Math.sqrt(n));
}
export function inAnyWar(g, owner) {
  for (const k of g.wars.keys()) { const [a, b] = k.split('|').map(Number); if ((a === owner && g.countries[b].alive) || (b === owner && g.countries[a].alive)) return true; }
  return false;
}
export function troopsOf(g, owner) {
  let s = 0;
  for (const a of g.armies) if (a.owner === owner) s += a.strength;
  return s;
}
// Сколько пачек влезает под мирный потолок (в войне — без ограничения)
export function peaceRoom(g, owner) {
  if (inAnyWar(g, owner)) return Infinity;
  return Math.max(0, Math.floor((troopCap(g, owner) - troopsOf(g, owner)) / RULES.recruitStack));
}

// Темп мобилизации: страна может призывать не больше mobK·√(провинций) пачек в день; неиспользованное копится
export function mobRate(g, owner) {
  let n = g.stats && g.stats[owner] ? g.stats[owner].provinces : 0;
  if (!n) for (const p of g.world.provinces.values()) if (p.props.owner === owner) n++;
  return RULES.mobK * Math.sqrt(n);
}
export function mobAvail(g, owner) {
  const c = g.countries[owner];
  return Math.floor(c.mobBank != null ? c.mobBank : mobRate(g, owner) * RULES.mobStartDays);
}
export function recruitMax(g, owner) {
  const c = g.countries[owner];
  return Math.max(0, Math.floor(Math.min(mobAvail(g, owner), c.manpower / RULES.recruitManpower, c.gold / recruitGold(g, owner), c.industry / RULES.recruitInd, peaceRoom(g, owner))));
}

// opts (необязательно, для массового призыва ИИ): room — остаток мирного лимита, busy — множество провинций с боем
export function canRecruit(g, owner, pid, n = 1, opts) {
  const p = prov(g, pid);
  const c = g.countries[owner];
  if (!p || p.props.owner !== owner) return { ok: false, msg: 'Не ваша провинция' };
  if (opts && opts.busy ? opts.busy.has(pid) : g.armies.some((a) => a.at === pid && a.owner !== owner && atWar(g, owner, a.owner))) return { ok: false, msg: 'Идёт бой' };
  if ((opts && opts.room !== undefined ? opts.room : peaceRoom(g, owner)) < n) return { ok: false, msg: 'Достигнут лимит армии мирного времени' };
  if (mobAvail(g, owner) < n) return { ok: false, msg: 'Исчерпан дневной лимит призыва' };
  if (c.manpower < RULES.recruitManpower * n) return { ok: false, msg: 'Не хватает людей' };
  if (c.gold < recruitGold(g, owner) * n) return { ok: false, msg: 'Не хватает золота' };
  if (c.industry < RULES.recruitInd * n) return { ok: false, msg: 'Не хватает промышленности' };
  return { ok: true };
}

export const recruitGold = (g, owner) => RULES.recruitGold * g.countries[owner].mod.recruit;

// n — число пачек; призыв идёт одним отрядом (или в уже стоящий на месте)
export function recruit(g, owner, pid, n = 1, opts) {
  n = Math.max(1, Math.floor(n));
  const can = canRecruit(g, owner, pid, n, opts);
  if (!can.ok) return can;
  const c = g.countries[owner];
  c.mobBank = (c.mobBank != null ? c.mobBank : mobRate(g, owner) * RULES.mobStartDays) - n;
  c.manpower -= RULES.recruitManpower * n;
  c.gold -= recruitGold(g, owner) * n;
  c.industry -= RULES.recruitInd * n;
  const idle = opts && opts.idle ? opts.idle.get(pid) : idleArmiesAt(g, owner, pid)[0];
  if (idle) idle.strength += RULES.recruitStack * n;
  else { const na = addArmy(g, owner, pid, RULES.recruitStack * n); if (opts && opts.idle) opts.idle.set(pid, na); }
  if (opts && opts.room !== undefined && opts.room !== Infinity) opts.room -= n;
  return { ok: true, amount: RULES.recruitStack * n };
}

// ---------- технологии ----------
export function techState(g, owner, tid) {
  const c = g.countries[owner], t = TECHS[tid];
  if (c.techs.includes(tid)) return { st: 'known' };
  const slot = c.slots[t.branch];
  if (slot && slot.id === tid) return { st: 'active', left: slot.left };
  const missing = t.req.filter((r) => !c.techs.includes(r));
  if (missing.length) return { st: 'locked', msg: 'Сначала: ' + missing.map((r) => TECHS[r].name).join(', ') };
  if (slot) return { st: 'busy', msg: `Занято: ${TECHS[slot.id].name}` };
  if (c.research < t.cost) return { st: 'short', msg: 'Не хватает очков технологий' };
  return { st: 'ready' };
}

export function startResearch(g, owner, tid) {
  const t = TECHS[tid];
  if (!t) return { ok: false, msg: 'Нет такой технологии' };
  const s = techState(g, owner, tid);
  if (s.st !== 'ready') return { ok: false, msg: s.msg || 'Нельзя изучать' };
  const c = g.countries[owner];
  c.research -= t.cost;
  c.slots[t.branch] = { id: tid, left: t.days };
  return { ok: true };
}

const SEASON_NEWS = [
  'Наступила зима: на севере снег и морозы, армии идут медленнее и теряют организацию в походе, наступать на чужой земле тяжелее.',
  'Наступила весна: тает снег, на дорогах распутица — наступление замедляется.',
  'Наступило лето: самое удобное время для наступления; на юге жара.',
  'Наступила осень: дожди и распутица размывают дороги, скоро зима.',
];

// ---------- доктрины ----------
export function doctrineStep(g, owner) {
  const c = g.countries[owner], d = c.doctrine;
  if (!d || d.lvl >= 3) return { st: 'max' };
  if (d.step) return { st: 'busy', left: d.step.left };
  const mil = c.techs.filter((t) => TECHS[t] && TECHS[t].branch === 'mil').length, need = DOCTRINE_STEP.mil[d.lvl];
  if (mil < need) return { st: 'locked', msg: `Нужно военных технологий: ${need} (сейчас ${mil})` };
  const cost = DOCTRINE_STEP.cost[d.lvl];
  if (c.research < cost) return { st: 'short', cost, msg: `Нужно очков технологий: ${cost}` };
  return { st: 'ready', cost, days: DOCTRINE_STEP.days[d.lvl] };
}
export function startDoctrineStep(g, owner) {
  const s = doctrineStep(g, owner);
  if (s.st !== 'ready') return { ok: false, msg: s.msg || 'Сейчас недоступно' };
  const c = g.countries[owner];
  c.research -= s.cost;
  c.doctrine.step = { left: s.days };
  return { ok: true };
}
export function setDoctrine(g, owner, id) {
  const c = g.countries[owner], d = c.doctrine;
  if (!DOCTRINES[id]) return { ok: false, msg: 'Нет такой доктрины' };
  if (d.id === id) return { ok: false, msg: 'Эта доктрина уже выбрана' };
  if (d.step) return { ok: false, msg: 'Сначала дождитесь окончания изучения' };
  const first = d.changed == null && g.day < 30;
  if (!first) {
    if (d.changed != null && g.day - d.changed < DOCTRINE_SWITCH.gap) return { ok: false, msg: `Менять доктрину можно раз в ${DOCTRINE_SWITCH.gap} дней (ещё ${DOCTRINE_SWITCH.gap - (g.day - d.changed)})` };
    if (c.pp < DOCTRINE_SWITCH.pp) return { ok: false, msg: `Нужно власти: ${DOCTRINE_SWITCH.pp}` };
    c.pp -= DOCTRINE_SWITCH.pp;
  }
  c.doctrine = { id, lvl: 0, step: null, changed: g.day };
  recalcMods(c);
  return { ok: true };
}
function progressDoctrines(g) {
  for (const c of g.countries) {
    const d = c.doctrine;
    if (!c.alive || !d || !d.step || --d.step.left > 0) continue;
    d.step = null; d.lvl++;
    recalcMods(c);
    emit(g, `${c.name}: доктрина «${DOCTRINES[d.id].name}» — «${DOCTRINES[d.id].steps[d.lvl - 1].name}»`, [c.id], 'tech');
  }
}

function progressResearch(g) {
  for (const c of g.countries) {
    if (!c.alive) continue;
    for (const [branch] of TECH_BRANCHES) {
      const sl = c.slots[branch];
      if (!sl || --sl.left > 0) continue;
      c.slots[branch] = null;
      c.techs.push(sl.id);
      recalcMods(c);
      emit(g, `${c.name}: изучено «${TECHS[sl.id].name}»`, [c.id], 'tech');
    }
  }
}

// ---------- внутренняя политика ----------
export function setTax(g, owner, level) {
  if (!TAX[level]) return { ok: false, msg: 'Нет такого налога' };
  g.countries[owner].tax = level;
  economyPreview(g);
  return { ok: true };
}

export const hooks = {};

export function focusState(g, owner, fid) {
  const c = g.countries[owner], f = FOCUSES[fid];
  if (c.focuses.includes(fid)) return { st: 'known' };
  if (c.focus && c.focus.id === fid) return { st: 'active', left: c.focus.left };
  const clash = (f.excl || []).find((x) => c.focuses.includes(x));
  if (clash) return { st: 'locked', msg: `Несовместимо с «${FOCUSES[clash].name}»` };
  const missing = f.req.filter((r) => !c.focuses.includes(r));
  if (missing.length) return { st: 'locked', msg: 'Сначала: ' + missing.map((r) => FOCUSES[r].name).join(', ') };
  if (f.great && f.need && !f.need(g, c)) return { st: 'locked', msg: f.needText || 'Условия не выполнены' };
  if (g.historical && g.scenario === 'europe1936' && (f.from || f.need)) {
    if (f.from && g.day + f.days < focusFromDay(f)) return { st: 'locked', msg: `Исторически не раньше ${focusFromText(f)}` };
    if (f.need && !f.need(g, c)) return { st: 'locked', msg: f.needText || 'Условия не выполнены' };
  }
  if (c.focus) return { st: 'busy', msg: `Идёт: ${FOCUSES[c.focus.id].name}` };
  if (c.pp < f.cost) return { st: 'short', msg: 'Не хватает политической власти' };
  return { st: 'ready' };
}

export function startFocus(g, owner, fid) {
  const c = g.countries[owner], f = FOCUSES[fid];
  if (!f || !focusTree(c.base || c.name, c.ideo0).includes(fid)) return { ok: false, msg: 'У вашей страны нет такого фокуса' };
  const s = focusState(g, owner, fid);
  if (s.st !== 'ready') return { ok: false, msg: s.msg || 'Нельзя начать' };
  c.pp -= f.cost;
  c.focus = { id: fid, left: f.days };
  return { ok: true };
}

const INSTANT = { gold: 'gold', men: 'manpower', ind: 'industry', fuel: 'fuel', res: 'research', pp: 'pp' };

function progressFocus(g) {
  for (const c of g.countries) {
    if (!c.alive || !c.focus || --c.focus.left > 0) continue;
    const f = FOCUSES[c.focus.id];
    c.focuses.push(c.focus.id);
    c.focus = null;
    if (f.instant) for (const [k, v] of Object.entries(f.instant)) c[INSTANT[k]] += v;
    recalcMods(c);
    if (hooks.focusDone) hooks.focusDone(g, c, f);
    emit(g, `${c.name}: завершён фокус «${f.name}»`, [c.id], 'focus');
  }
}

export function appointMinister(g, owner, post, idx) {
  const c = g.countries[owner];
  if (!c.cands || !c.cands[post] || !c.cands[post][idx]) return { ok: false, msg: 'Нет такого кандидата' };
  if (c.ministers[post] === idx) return { ok: false, msg: 'Уже назначен' };
  if (c.pp < RULES.ministerPP) return { ok: false, msg: `Не хватает политической власти: нужно ${RULES.ministerPP}` };
  c.pp -= RULES.ministerPP;
  c.ministers[post] = idx;
  recalcMods(c);
  economyPreview(g);
  return { ok: true };
}

// ---------- день ----------
export function stepDay(g, aiTick) {
  if (g.over) return;
  ensurePorts(g);
  if (aiTick) aiTick(g);
  if (hooks.settle && g.day % 2 === 0) hooks.settle(g);
  if (hooks.hq) hooks.hq(g);
  moveArmies(g);
  mergeIdle(g);
  if (hooks.air) hooks.air(g);
  resolveBattles(g);
  resolveOccupation(g);
  progressOccupation(g);
  economy(g);
  if (hooks.trade) hooks.trade(g);
  progressBuilds(g);
  progressResearch(g);
  progressDoctrines(g);
  progressFocus(g);
  if (RULES.weather) { const ss = seasonStart(g.day); if (ss != null && g.day > 0) emit(g, SEASON_NEWS[ss], [], 'info'); }
  progressDiplomacy(g);
  if (g.plague && hooks.plague) hooks.plague(g);
  refreshStats(g);
  g.day++;
  checkEnd(g);
}

function checkEnd(g) {
  const alive = g.countries.filter((c) => c.alive);
  if (g.playerId != null && !g.countries[g.playerId].alive) g.over = { won: false };
  else if (alive.length === 1) g.over = { won: alive[0].id === g.playerId, winner: alive[0].id };
}

// Стоимость уже известного пути (сумма шагов) для orderMove(..., pre)
export function pathCost(g, owner, fromId, path) {
  const cost = moveCostFn(g, owner);
  let at = prov(g, fromId), sum = 0;
  for (const id of path) { const q = prov(g, id); sum += cost(q, at); at = q; }
  return sum;
}
