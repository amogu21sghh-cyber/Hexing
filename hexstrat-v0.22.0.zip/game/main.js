// Точка входа: связывает движок (карта, часы, ввод) с игрой (правила, ИИ, интерфейс).
import { Clock, HexRenderer, MapInput } from '../engine/index.js';
import { RULES, BUILDINGS, TECHS, FOCUSES } from './data.js';
import {
  createGame, stepDay, recruitMax, tryDeclareWar, startResearch, setTax, startFocus, appointMinister, proposePeace, orderMove, previewPath, recruit, startBuild, stopArmies, idleArmiesAt, economyPreview, prov, setDoctrine, startDoctrineStep,
} from './state.js';
import { aiTick } from './ai.js';
import { createHQ, removeHQ, hqById, assignAll, assignAt, clearArmies } from './hq.js';
import { foundFaction, disbandFaction, leaveFaction, kickMember, inviteToFaction, requestJoin, callToWar, respondOffer, joinOrg, leaveOrg, demandPeace, concede, concedeTribute, startJustify, giveGuarantee, revokeGuarantee, startLend, stopLend, releaseVassal } from './diplomacy.js';
import { chooseEvent, EVENT_BY_ID } from './events.js';
import { proposeTrade, cancelDeal } from './trade.js';
import { recruitAir, setMission, airRadius } from './air.js';
import { createView } from './view.js';
import { initUI, renderAll, toast } from './ui.js';
import { unlock, sfx, setMood, setAudio, audioCfg } from './audio.js';
import { flagSrc } from './flags.js';
import { applyMods, storedMods, importMod, setModOn, moveMod, removeMod, modsSignature } from './mods.js';
import { BUNDLED_MODS } from './bundled_mods.js';
import { setQuarantine } from './plague.js';
import { saveGame, readSave, restoreGame, clearSave } from './save.js';
import { isEurope } from './starts.js';

const ui = {
  game: null, screen: 'main', modal: null, helpFrom: null,
  setup: { scenario: 'europe1936', size: 'medium', difficulty: 0, country: 0, historical: true },
  selected: null, target: null, aiming: false, fraction: 1, mode: 'political', preview: null, confirmWar: null,
  drawerOpen: true, paused: true, saveInfo: null, resumeSpeed: 0, buildTab: 'eco', diploTab: 'c', techTab: 'eco', countryTab: 'own', overview: false, camSaved: null,
};

const clock = new Clock({ speeds: RULES.speeds, start: RULES.start });
let renderer = null;
let lastSeq = 0;
let lastSave = 0;
const isLand = (h) => h.terrain !== 'water';

const randomSeed = () => (Math.floor(Math.random() * 1e9) + Date.now()) % 2147483647;

function refresh() {
  ui.paused = clock.paused;
  renderAll(ui, clock);
  // пока открыто окно, карта под ним не меняется: лишняя перерисовка только тормозит нажатия
  if (renderer && !ui.modal) renderer.requestDraw();
}

const levelOfAirfield = (p) => (p.props.built || []).filter((x) => x === 'airfield').length;

function resetSelection() {
  ui.airAim = null;
  ui.selected = null; ui.target = null; ui.aiming = false; ui.preview = null; ui.confirmWar = null;
}

// Пока открыта любая панель, время стоит; при закрытии скорость возвращается.
function openModal(kind) {
  if (!ui.modal) { ui.resumeSpeed = clock.speed; clock.setSpeed(0); }
  ui.modal = kind;
  ui.confirmWar = null;
  refresh();
}

function closeModal() {
  ui.modal = null;
  clock.setSpeed(ui.resumeSpeed);
  refresh();
}

function newBackdropGame() {
  ui.game = createGame(randomSeed(), { size: ui.setup.size, difficulty: ui.setup.difficulty, scenario: ui.setup.scenario, historical: ui.setup.historical && isEurope(ui.setup.scenario) });
  if (ui.setup.country >= ui.game.countries.length) ui.setup.country = 0;
  renderer.setWorld(ui.game.world);
}

// Вид карты за меню: в настройке карта вписывается в часть экрана рядом с панелью.
function fitMenuView() {
  if (ui.screen === 'main') renderer.fit(isLand);
  else if (ui.screen === 'setup') {
    const p = document.getElementById('setupPanel');
    const r = p ? p.getBoundingClientRect() : { width: 0, height: 0 };
    if (r.width && r.width < renderer.w * 0.9) renderer.fit(isLand, { right: r.width + 4 });
    else renderer.fit(isLand, { bottom: r.height + 4 });
  }
}

function updateSaveInfo() {
  const d = readSave();
  ui.saveInfo = d ? `${d.countries[d.playerId].name} · ${clock.formatDate(d.day)}` : null;
}

// Если панель провинции открыта, сдвигаем карту так, чтобы провинция не пряталась под ней.
function ensureVisible(pid) {
  if (!ui.drawerOpen || ui.aiming) return;
  const el = document.getElementById('drawer');
  const drawerW = (el && el.offsetWidth) || Math.min(renderer.w * 0.44, 280);
  const free = renderer.w - drawerW;
  const c = renderer.provinceScreenCenter(pid);
  if (c.x > free - 30) renderer.panBy(free / 2 - c.x, 0);
}

function goMain() {
  if (ui.screen === 'game' && !ui.game.over) saveGame(ui.game);
  ui.screen = 'main'; ui.modal = null; ui.overview = false;
  resetSelection();
  clock.setSpeed(0);
  newBackdropGame();
  updateSaveInfo();
  refresh();
  requestAnimationFrame(fitMenuView);
}

function openSetup() {
  ui.screen = 'setup'; ui.modal = null;
  resetSelection();
  clock.setSpeed(0);
  newBackdropGame();
  refresh();
  requestAnimationFrame(fitMenuView);
}

// Полный экран (скрывает адресную строку на Android): сам включается при первом касании, дальше — кнопкой в меню
function toggleFull() {
  const el = document.documentElement, d = document;
  try {
    if (d.fullscreenElement || d.webkitFullscreenElement) { (d.exitFullscreen || d.webkitExitFullscreen).call(d); return; }
    const f = el.requestFullscreen || el.webkitRequestFullscreen;
    if (f) { const p = f.call(el, { navigationUI: 'hide' }); if (p && p.catch) p.catch(() => {}); }
  } catch (_) { /* не поддерживается */ }
}
document.addEventListener('pointerup', () => { if (!window._fsTried) { window._fsTried = true; if (!document.fullscreenElement) toggleFull(); } }, { once: false });

// запрет масштабирования страницы жестами (iOS игнорирует user-scalable=no)
['gesturestart', 'gesturechange', 'gestureend'].forEach((n) => document.addEventListener(n, (e) => e.preventDefault()));
document.addEventListener('touchmove', (e) => { if (e.touches.length > 1 && e.target.closest && e.target.closest('#modal, .screen')) e.preventDefault(); }, { passive: false });
let lastTap = 0;
document.addEventListener('touchend', (e) => { const t = Date.now(); if (t - lastTap < 350 && e.target.closest && e.target.closest('#modal')) e.preventDefault(); lastTap = t; }, { passive: false });

function begin() {
  const g = ui.game;
  g.playerId = ui.setup.country;
  g.difficulty = ui.setup.difficulty;
  g.historical = ui.setup.historical && g.scenario === 'europe1936';
  economyPreview(g);
  ui.screen = 'game'; ui.modal = null; ui.overview = false;
  resetSelection();
  clock.dayIndex = g.day;
  clock.setSpeed(0);
  lastSeq = 0;
  ui.selected = g.countries[g.playerId].capital;
  ui.drawerOpen = true;
  // отладка оформления: адрес с #ev=<id> сразу показывает событие
  { const m = /ev=(\w+)/.exec(location.hash || ''); if (m && EVENT_BY_ID[m[1]]) { g.pending.push({ id: g.nextPendingId++, eid: m[1], cid: g.playerId, day: g.day }); openModal('event'); } }
  // отладка: #notice=<id фокуса> показывает уведомление о завершении фокуса
  { const m = /notice=(\w+)/.exec(location.hash || ''); if (m && FOCUSES[m[1]] && FOCUSES[m[1]].news) { const f = FOCUSES[m[1]]; g.pending.push({ id: g.nextPendingId++, eid: null, cid: g.playerId, day: g.day, info: { title: f.news.title, text: f.news.text, fid: m[1], own: true } }); openModal('event'); } }
  // отладка: #to=1 добавляет торговое предложение от соседней страны
  if (/to=1/.test(location.hash || '')) { const e = g.countries.find((c) => c.id !== g.playerId && c.alive); g.offers.push({ id: g.nextOfferId++, day: g.day, kind: 'trade', from: e.id, to: g.playerId, deal: { from: e.id, to: g.playerId, good: 'fuel', amt: 1, price: 3 } }); }
  { const m = /po=(give|take)/.exec(location.hash || ''); if (m) { const nbrs = new Set(); for (const q of g.world.provinces.values()) if (q.props.owner === g.playerId) for (const nb of q.neighbors) { const o = g.world.provinces.get(nb).props.owner; if (o != null && o !== g.playerId) nbrs.add(o); } const e = g.countries.find((c) => nbrs.has(c.id)) || g.countries.find((c) => c.id !== g.playerId); g.offers.push({ id: g.nextOfferId++, day: g.day, kind: 'peace', from: e.id, to: g.playerId, seen: false, dir: m[1], type: 'cede', n: 4 }); }
  }
  refresh();
  renderer.resize();
  renderer.centerOnProvince(ui.selected, 1.0);
  ensureVisible(ui.selected);
}

function continueGame() {
  const d = readSave();
  if (!d) return;
  ui.game = restoreGame(d);
  if ((d.mods || '') !== modsSignature()) setTimeout(() => toast('Набор модов отличается от того, с которым сохранена партия — игра может вести себя иначе.', true), 400);
  renderer.setWorld(ui.game.world);
  ui.screen = 'game'; ui.modal = null; ui.overview = false;
  resetSelection();
  clock.dayIndex = ui.game.day;
  clock.setSpeed(0);
  lastSeq = ui.game.logSeq;
  refresh();
  renderer.resize();
  renderer.centerOnProvince(ui.game.countries[ui.game.playerId].capital, 1.0);
}

function select(pid) {
  sfx('select');
  ui.airAim = null;
  ui.selected = pid === ui.selected ? null : pid;
  ui.target = null; ui.preview = null; ui.confirmWar = null; ui.aiming = false;
  if (ui.selected != null) { ui.drawerOpen = true; ensureVisible(ui.selected); }
  refresh();
}

function setTarget(pid) {
  const g = ui.game;
  ui.target = pid;
  ui.preview = previewPath(g, g.playerId, ui.selected, pid);
  ui.confirmWar = null;
  refresh();
}

function confirmMove() {
  const g = ui.game;
  if (!ui.preview) return;
  const res = orderMove(g, g.playerId, ui.selected, ui.target, ui.fraction);
  toast(res.ok ? `Приказ отдан: ${Math.ceil(res.amount)} войск, около ${res.days} дн.` : res.msg, true);
  sfx(res.ok ? 'order' : 'error');
  ui.aiming = false; ui.target = null; ui.preview = null;
  refresh();
}

function dipl(r, okMsg) {
  toast(r.ok ? r.msg || okMsg : r.msg, true);
  economyPreview(ui.game);
  refresh();
}

const actions = {
  // главное меню и новая игра
  newgame: () => openSetup(),
  mods: () => { ui.modMsg = null; openModal('mods'); },
  modon: (id) => { const s = storedMods().find((x) => x.mod.id === id); if (s) { setModOn(id, !s.on); ui.modsDirty = true; refresh(); } },
  modup: (id) => { moveMod(id, -1); ui.modsDirty = true; refresh(); },
  moddown: (id) => { moveMod(id, 1); ui.modsDirty = true; refresh(); },
  moddel: (id) => { removeMod(id); ui.modsDirty = true; refresh(); },
  modbuiltin: (id) => { const m = BUNDLED_MODS.find((x) => x.id === id); if (!m) return; const r = importMod(JSON.stringify(m)); ui.modMsg = r.msg; if (r.ok) ui.modsDirty = true; refresh(); },
  modapply: () => location.reload(),
  modfile: () => {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = '.json,application/json';
    inp.onchange = () => {
      const f = inp.files && inp.files[0];
      if (!f) return;
      const rd = new FileReader();
      rd.onload = () => { const r = importMod(String(rd.result)); ui.modMsg = r.msg; if (r.ok) ui.modsDirty = true; refresh(); };
      rd.onerror = () => { ui.modMsg = 'Не удалось прочитать файл'; refresh(); };
      rd.readAsText(f);
    };
    inp.click();
  },
  continue: () => withLoading('continue'),
  back: () => goMain(),
  tomain: () => goMain(),
  pick: (a) => { ui.setup.country = Number(a); refresh(); },
  scen: (a) => { ui.setup.scenario = a; ui.setup.country = 0; newBackdropGame(); refresh(); requestAnimationFrame(fitMenuView); },
  size: (a) => { ui.setup.size = a; newBackdropGame(); refresh(); requestAnimationFrame(fitMenuView); },
  hist: (a) => { ui.setup.historical = a === '1'; ui.game.historical = ui.setup.historical && ui.game.scenario === 'europe1936'; refresh(); },
  diff: (a) => { ui.setup.difficulty = Number(a); ui.game.difficulty = ui.setup.difficulty; refresh(); },
  reroll: () => { newBackdropGame(); refresh(); requestAnimationFrame(fitMenuView); },
  begin: () => withLoading('begin'),
  // панели
  full: () => toggleFull(),
  menu: () => openModal('pause'),
  build: () => openModal('build'),
  armies: () => openModal('armies'),
  tech: () => openModal('tech'),
  country: () => openModal('country'),
  plague: () => openModal('plague'),
  diplo: () => openModal('diplo'),
  journal: () => openModal('journal'),
  resume: () => closeModal(),
  save: () => { toast(saveGame(ui.game) ? 'Игра сохранена' : 'Сохранение здесь недоступно'); },
  help: () => { ui.helpFrom = ui.modal === 'pause' ? 'pause' : ui.screen; openModal('help'); },
  privacy: () => openModal('privacy'),
  closemodal: () => {
    if (ui.modal === 'help' && ui.helpFrom === 'pause') { ui.modal = 'pause'; ui.helpFrom = null; refresh(); } else closeModal();
  },
  atab: (a) => { ui.armyTab = a; refresh(); },
  hqnew: () => { const r = createHQ(ui.game, ui.game.playerId); if (r.ok) ui.hqSel = r.hq.id; else toast(r.msg); refresh(); },
  hqsel: (a) => { ui.hqSel = Number(a); refresh(); },
  hqm: (a) => { const h = hqById(ui.game, ui.hqSel); if (h) { h.mission = a; h.phase = 'mass'; } refresh(); },
  hqt: (a) => { const h = hqById(ui.game, ui.hqSel); if (h) h.target = a === '' ? null : Number(a); refresh(); },
  hqa: (a) => { const h = hqById(ui.game, ui.hqSel); if (h) h.aggr = Number(a); refresh(); },
  hqr: (a) => { const h = hqById(ui.game, ui.hqSel); if (h) h.retreat = Number(a); refresh(); },
  hqsplit: (a) => { const h = hqById(ui.game, ui.hqSel); if (h) h.split = Number(a); refresh(); },
  hqmass: (a) => { const h = hqById(ui.game, ui.hqSel); if (h) { h.mass = a === '1'; h.phase = 'mass'; } refresh(); },
  hqaddall: () => { const n = assignAll(ui.game, ui.hqSel, ui.game.playerId); toast(n ? `Назначено армий: ${n}` : 'Свободных армий нет'); refresh(); },
  hqaddsel: () => { const n = ui.selected == null ? 0 : assignAt(ui.game, ui.hqSel, ui.game.playerId, ui.selected); toast(n ? `Назначено армий: ${n}` : 'В выбранной провинции нет ваших армий'); refresh(); },
  hqclear: () => { clearArmies(ui.game, ui.hqSel); refresh(); },
  hqdel: () => { removeHQ(ui.game, ui.hqSel); ui.hqSel = null; refresh(); },
  snd: () => { setAudio('on', !audioCfg().on); refresh(); },
  mus: () => { const v = audioCfg().music; setAudio('music', v >= 0.8 ? 0 : v >= 0.5 ? 0.8 : v > 0.1 ? 0.55 : 0.3); refresh(); },
  fx: () => { const v = audioCfg().sfx; setAudio('sfx', v >= 0.8 ? 0 : v >= 0.5 ? 0.8 : v > 0.1 ? 0.55 : 0.3); refresh(); },
  btab: (a) => { ui.buildTab = a; refresh(); },
  ttab: (a) => { ui.techTab = a; ui.techSel = null; ui._ts = null; refresh(); },
  tnode: (a) => { ui.techSel = a; refresh(); },
  fnode: (a) => { ui.focusSel = a; refresh(); },
  evchoose: (a) => {
    const g = ui.game, [pid, idx] = a.split(':').map(Number);
    const r = chooseEvent(g, pid, idx);
    if (!r.ok) { toast(r.msg, true); refresh(); return; }
    if (g.pending.length) refresh(); else closeModal();
  },
  dtab: (a) => { ui.diploTab = a; refresh(); },
  found: () => dipl(foundFaction(ui.game, ui.game.playerId), 'Альянс основан'),
  leavef: () => dipl(leaveFaction(ui.game, ui.game.playerId), 'Готово'),
  kick: (a) => dipl(kickMember(ui.game, ui.game.playerId, Number(a)), 'Исключена'),
  invite: (a) => dipl(inviteToFaction(ui.game, ui.game.playerId, Number(a)), 'Готово'),
  joinreq: (a) => dipl(requestJoin(ui.game, ui.game.playerId, Number(a)), 'Готово'),
  callwar: (a) => dipl(callToWar(ui.game, ui.game.playerId, Number(a)), 'Готово'),
  tradeoffer: (a) => { ui.tradeOfferId = Number(a); openModal('tradeoffer'); },
  tradeans: (a) => { const [id, yes] = a.split(':'); const r = respondOffer(ui.game, Number(id), yes === '1'); toast(r.ok ? r.msg || 'Готово' : r.msg, true); economyPreview(ui.game); closeModal(); },
  offer: (a) => { const [id, yes] = a.split(':'); dipl(respondOffer(ui.game, Number(id), yes === '1'), 'Готово'); },
  org: (a) => dipl(joinOrg(ui.game, ui.game.playerId, a), 'Вы вступили в организацию'),
  orgleave: (a) => dipl(leaveOrg(ui.game, ui.game.playerId, a), 'Вы вышли из организации'),
  docpick: (id) => { const r = setDoctrine(ui.game, ui.game.playerId, id); toast(r.ok ? 'Доктрина выбрана' : r.msg, true); sfx(r.ok ? 'order' : 'error'); economyPreview(ui.game); refresh(); },
  docstep: () => { const r = startDoctrineStep(ui.game, ui.game.playerId); toast(r.ok ? 'Изучение начато' : r.msg, true); sfx(r.ok ? 'order' : 'error'); refresh(); },
  quar: (a) => { const r = setQuarantine(ui.game, ui.game.playerId, Number(a)); toast(r.ok ? 'Карантин изменён' : r.msg, true); sfx(r.ok ? 'order' : 'error'); economyPreview(ui.game); refresh(); },
  ctab: (a) => { ui.countryTab = a; ui._ts = null; refresh(); },
  tax: (a) => { setTax(ui.game, ui.game.playerId, Number(a)); refresh(); },
  focus: (a) => {
    const g = ui.game;
    const r = startFocus(g, g.playerId, a);
    toast(r.ok ? `Начат фокус: ${FOCUSES[a].name}` : r.msg, true);
    refresh();
  },
  minister: (a) => {
    const g = ui.game, [post, idx] = a.split(':');
    const r = appointMinister(g, g.playerId, post, Number(idx));
    toast(r.ok ? 'Министр назначен' : r.msg, true);
    refresh();
  },
  research: (a) => {
    const g = ui.game;
    const r = startResearch(g, g.playerId, a);
    toast(r.ok ? `Начато изучение: ${TECHS[a].name}` : r.msg, true);
    economyPreview(g);
    refresh();
  },
  construct: (a) => {
    const g = ui.game;
    const r = startBuild(g, g.playerId, ui.selected, a);
    toast(r.ok ? `Стройка начата: ${BUILDINGS[a].name}` : r.msg, true);
    sfx(r.ok ? 'build' : 'error');
    economyPreview(g);
    refresh();
  },
  goto: (a) => {
    const pid = Number(a);
    ui.modal = null;
    clock.setSpeed(ui.resumeSpeed);
    ui.selected = pid; ui.target = null; ui.preview = null; ui.aiming = false; ui.drawerOpen = true;
    refresh();
    renderer.centerOnProvince(pid);
    ensureVisible(pid);
  },
  // время
  slower: () => clock.setSpeed(Math.max(0, clock.speed - 1)),
  faster: () => clock.setSpeed(Math.min(clock.speeds.length - 1, clock.speed + 1)),
  playpause: () => clock.togglePause(),
  // карта
  layers: () => { ui.mode = ui.mode === 'political' ? 'relief' : 'political'; refresh(); },
  zoom: () => {
    const cam = renderer.cam;
    if (!ui.overview) {
      ui.camSaved = { x: cam.x, y: cam.y, zoom: cam.zoom };
      renderer.fit(isLand);
      ui.overview = true;
    } else {
      if (ui.camSaved) Object.assign(cam, ui.camSaved);
      renderer.clampCamera();
      renderer.requestDraw();
      ui.overview = false;
    }
  },
  tab: () => { ui.drawerOpen = !ui.drawerOpen; if (ui.drawerOpen && ui.selected != null) ensureVisible(ui.selected); refresh(); },
  aim: () => { ui.aiming = true; ui.target = null; ui.preview = null; refresh(); },
  cancel: () => { ui.aiming = false; ui.target = null; ui.preview = null; refresh(); },
  go: () => confirmMove(),
  frac: (a) => { ui.fraction = Number(a); refresh(); },
  airrec: (a) => { const r = recruitAir(ui.game, ui.game.playerId, ui.selected, Number(a)); toast(r.ok ? `Призвано эскадрилий: ${r.amount}` : r.msg, true); sfx(r.ok ? 'recruit' : 'error'); refresh(); },
  airmis: (a) => {
    const g = ui.game, p = prov(g, ui.selected), m = p.props.air && p.props.air.mission;
    const R = airRadius(g, g.playerId, levelOfAirfield(p));
    const r = setMission(g, g.playerId, ui.selected, a === 'none' ? null : a, m ? m.r : R, null);
    ui.airAim = null; if (!r.ok) toast(r.msg, true); refresh();
  },
  airrad: (a) => {
    const g = ui.game, p = prov(g, ui.selected), m = p.props.air && p.props.air.mission;
    if (!m) { toast('Сначала выберите задание', true); return; }
    let r = setMission(g, g.playerId, ui.selected, m.t, Number(a), m.pid);
    if (!r.ok) r = setMission(g, g.playerId, ui.selected, m.t, Number(a), null); // цель оказалась вне нового радиуса
    refresh();
  },
  airaim: () => { ui.airAim = ui.selected; toast('Нажмите на клетку в радиусе', true); refresh(); },
  airzone: () => {
    const g = ui.game, p = prov(g, ui.selected), m = p.props.air && p.props.air.mission;
    if (m) setMission(g, g.playerId, ui.selected, m.t, m.r, null);
    ui.airAim = null; refresh();
  },
  recruit: () => {
    const g = ui.game;
    const stk = RULES.recruitStack, mx = recruitMax(g, g.playerId);
    const want = ui.recruitN === 'max' ? Math.max(1, mx) : Math.max(1, Math.round((ui.recruitN || stk) / stk));
    const r = recruit(g, g.playerId, ui.selected, Math.min(want, Math.max(1, mx)));
    if (!r.ok) { toast(r.msg); sfx('error'); } else sfx('recruit');
    refresh();
  },
  rn: (a) => { ui.recruitN = a === 'max' ? 'max' : Number(a); refresh(); },
  stop: () => { stopArmies(ui.game, ui.game.playerId, ui.selected); refresh(); },
  war: (a) => {
    const id = Number(a);
    if (ui.confirmWar !== id) { ui.confirmWar = id; refresh(); return; }
    ui.confirmWar = null;
    const dw = tryDeclareWar(ui.game, ui.game.playerId, id);
    if (!dw.ok) toast(dw.msg, true);
    if (ui.aiming && ui.target != null) ui.preview = previewPath(ui.game, ui.game.playerId, ui.selected, ui.target);
    refresh();
  },
  terms: (a) => { const [id, k] = a.split(':'); dipl(demandPeace(ui.game, ui.game.playerId, Number(id), k), 'Мир'); },
  justify: (a) => { const r = startJustify(ui.game, ui.game.playerId, Number(a)); toast(r.msg || (r.ok ? 'Готово' : 'Нельзя'), !r.ok); refresh(); },
  guar: (a) => { const r = giveGuarantee(ui.game, ui.game.playerId, Number(a)); toast(r.msg || 'Готово', !r.ok); refresh(); },
  unguar: (a) => { const r = revokeGuarantee(ui.game, ui.game.playerId, Number(a)); if (!r.ok) toast(r.msg, true); refresh(); },
  lend: (a) => { const r = startLend(ui.game, ui.game.playerId, Number(a)); toast(r.msg || 'Готово', !r.ok); refresh(); },
  unlend: (a) => { stopLend(ui.game, ui.game.playerId, Number(a)); refresh(); },
  tgood: (a) => { ui.tgood = a; refresh(); },
  tdir: (a) => { ui.tdir = a; refresh(); },
  tsize: (a) => { ui.tsize = a; refresh(); },
  tradego: (a) => { const r = proposeTrade(ui.game, ui.game.playerId, Number(a), ui.tgood || 'fuel', ui.tdir || 'buy', ui.tsize || 'm'); toast(r.msg || 'Готово', !r.ok); refresh(); },
  canceldeal: (a) => { const r = cancelDeal(ui.game, ui.game.playerId, Number(a)); toast(r.msg || 'Готово', !r.ok); refresh(); },
  release: (a) => { const r = releaseVassal(ui.game, ui.game.playerId, Number(a)); if (!r.ok) toast(r.msg, true); refresh(); },
  dipcard: (a) => { ui.dipId = Number(a); openModal('dipcard'); },
  openpeace: (a) => { ui.peaceWith = Number(a); ui.peaceTerm = 'white'; openModal('peace'); },
  pterm: (a) => { ui.peaceTerm = a; refresh(); },
  pgo: () => {
    const g = ui.game, me = g.playerId, e = ui.peaceWith, k = ui.peaceTerm || 'white';
    const r = k === 'white' ? proposePeace(g, me, e) : k === 'give' ? concede(g, me, e) : k === 'givegold' ? concedeTribute(g, me, e, 'gold') : k === 'giveres' ? concedeTribute(g, me, e, 'goods') : demandPeace(g, me, e, k);
    toast(r.msg || (r.ok ? 'Готово' : 'Нельзя'), !r.ok);
    economyPreview(g);
    if (r.ok) { ui.modal = 'diplo'; refresh(); } else refresh();
  },
  peaceans: (a) => {
    const g = ui.game, [id, v] = a.split(':').map(Number);
    const o = g.offers.find((x) => x.id === id);
    if (v === 2 && o) { g.offers = g.offers.filter((x) => x.id !== id); ui.peaceWith = o.from; ui.peaceTerm = 'white'; ui.modal = 'peace'; refresh(); return; }
    const r = respondOffer(g, id, v === 1);
    toast(r.msg || 'Готово', !r.ok);
    economyPreview(g);
    closeModal();
  },
  peace: (a) => {
    toast(proposePeace(ui.game, ui.game.playerId, Number(a)).msg);
    refresh();
  },
};

// Двойной клик по чужой стране открывает её карточку дипломатии
function onDouble(sx, sy) {
  if (ui.modal || ui.screen !== 'game' || ui.game.over || ui.aiming) return false;
  const hex = renderer.hexAtScreen(sx, sy);
  if (!hex || hex.provinceId == null) return false;
  const o = ui.game.world.provinces.get(hex.provinceId).props.owner;
  if (o == null || o === ui.game.playerId || !ui.game.countries[o].alive) return false;
  ui.dipId = o; ui.dipFrom = null;
  openModal('dipcard');
  return true;
}

function onTap(sx, sy) {
  if (ui.modal) return;
  const hex = renderer.hexAtScreen(sx, sy);
  const pid = hex ? hex.provinceId : null;
  if (ui.screen === 'setup') {
    if (pid != null) {
      const o = ui.game.world.provinces.get(pid).props.owner;
      if (o != null) { ui.setup.country = o; refresh(); }
    }
    return;
  }
  if (ui.screen !== 'game' || ui.game.over) return;
  if (ui.airAim != null) {
    const g = ui.game, base = ui.airAim; ui.airAim = null;
    const p = prov(g, base), m = p.props.air && p.props.air.mission;
    if (pid != null && m) { const r = setMission(g, g.playerId, base, m.t, m.r, pid); toast(r.ok ? `Цель: ${prov(g, pid).name}` : r.msg, true); sfx(r.ok ? 'order' : 'error'); }
    refresh();
    return;
  }
  if (ui.aiming) {
    if (pid == null || pid === ui.selected) return;
    if (pid === ui.target) confirmMove();
    else setTarget(pid);
    return;
  }
  if (pid == null) { resetSelection(); refresh(); return; }
  select(pid);
}

function afterTick() {
  const g = ui.game;
  if (ui.aiming && ui.selected != null && !idleArmiesAt(g, g.playerId, ui.selected).length) {
    ui.aiming = false; ui.target = null; ui.preview = null;
  }
  if (ui.aiming && ui.target != null) ui.preview = previewPath(g, g.playerId, ui.selected, ui.target);
  for (const e of g.log) {
    if (e.seq <= lastSeq) continue;
    lastSeq = e.seq;
    const mine = e.involves.includes(g.playerId);
    if (mine || e.kind === 'fall') toast(e.text, mine);
    if (mine || ['war', 'fall', 'capture'].includes(e.kind)) {
      const k = { war: 'war', peace: 'peace', alliance: 'alliance', capture: 'capture', fall: 'fall', tech: 'tech', focus: 'focus', build: 'build', offer: 'offer', event: 'event' }[e.kind];
      if (k && (mine || k === 'war' || k === 'fall')) sfx(k);
    }
  }
  {
    const atWarNow = [...g.wars.keys()].some((k) => k.split('|').map(Number).includes(g.playerId));
    const fight = g.armies.some((a) => a.fighting && a.owner === g.playerId);
    setMood({ war: atWarNow ? (fight ? 1 : 0.6) : 0, fight, menu: ui.screen !== 'game' });
    if (fight) sfx('battle');
  }
  if (g.pending && g.pending.length && !ui.modal && !g.over) { openModal('event'); sfx('event'); }
  const po = !ui.modal && !g.over && g.offers.find((o) => o.kind === 'peace' && o.to === g.playerId && !o.seen);
  if (po) { po.seen = true; ui.offerId = po.id; openModal('peaceoffer'); }
  if (g.over) { clock.setSpeed(0); clearSave(); }
  else if (g.day % 15 === 0 && Date.now() - lastSave > 10000) { lastSave = Date.now(); saveGame(g); }
  refreshSoon();
}

// На быстрой скорости дни идут чаще кадров: интерфейс обновляем не чаще одного раза за кадр.
let refreshQueued = false;
function refreshSoon() {
  if (refreshQueued) return;
  refreshQueued = true;
  requestAnimationFrame(() => { refreshQueued = false; refresh(); });
}

// Заставка движка HexaCore RM и экран загрузки при старте игры.
// В автоматизированном браузере (e2e) всё пропускается, чтобы не мешать тестам.
const FAST = typeof navigator !== 'undefined' && navigator.webdriver;
const TIPS = [
  'Порты позволяют перебрасывать армии через море — но только между своими или союзными портами.',
  'Окружённая армия слабеет: прикрывайте фланги и держите снабжение.',
  'Фокусы дают долгосрочные бонусы — не оставляйте очередь пустой.',
  'Пауза не мешает отдавать приказы: планируйте наступление спокойно.',
  'Авиация лучше всего работает против слабо прикрытых провинций и складов.',
  'Союзы и гарантии независимости меняют расстановку сил задолго до войны.',
  'Мобилизация растёт с уровнем построек: развивайте казармы заранее.',
];
function initSplash() {
  const el = document.getElementById('splash');
  if (!el) return;
  if (FAST) { el.remove(); return; }
  let done = false;
  const hide = () => { if (done) return; done = true; el.classList.add('out'); setTimeout(() => el.remove(), 700); };
  el.addEventListener('pointerdown', hide);
  window.addEventListener('keydown', hide, { once: true });
  setTimeout(hide, 3200);
}
function withLoading(kind) {
  const el = document.getElementById('loading');
  if (!el || FAST) { kind === 'begin' ? begin() : continueGame(); return; }
  const g = ui.game;
  const c = kind === 'begin' ? g.countries[ui.setup.country] : null;
  let title = 'Загрузка партии', sub = '', fl = '';
  if (kind === 'begin') { title = c.name; sub = 'Новая игра · ' + clock.formatDate(0); fl = flagSrc(c) ? `<img src="${flagSrc(c)}" alt="">` : ''; }
  else { const d = readSave(); if (d) { const pc = d.countries[d.playerId]; title = pc.name; sub = 'Продолжение · ' + clock.formatDate(d.day); fl = flagSrc(pc) ? `<img src="${flagSrc(pc)}" alt="">` : ''; } }
  document.getElementById('lFlag').innerHTML = fl;
  document.getElementById('lTitle').textContent = title;
  document.getElementById('lSub').textContent = sub;
  document.getElementById('lTip').textContent = TIPS[Math.floor(Math.random() * TIPS.length)];
  const fill = document.getElementById('lFill'), step = document.getElementById('lStep');
  fill.style.width = '0%';
  el.classList.remove('out'); el.hidden = false;
  const stages = [[8, 'Строим карту…'], [35, 'Расставляем армии…'], [70, 'Считаем экономику…'], [100, 'Готово']];
  let i = 0;
  const next = () => {
    if (i >= stages.length) { setTimeout(() => { el.classList.add('out'); setTimeout(() => { el.hidden = true; }, 400); }, 250); return; }
    const [pct, txt] = stages[i++];
    fill.style.width = pct + '%'; step.textContent = txt;
    // тяжёлая работа — на втором шаге, после того как экран загрузки отрисован
    if (i === 3) requestAnimationFrame(() => setTimeout(() => { kind === 'begin' ? begin() : continueGame(); setTimeout(next, 350); }, 30));
    else setTimeout(next, 380);
  };
  requestAnimationFrame(() => setTimeout(next, 30));
}

function boot() {
  const canvas = document.getElementById('map');
  initUI();
  ui.game = createGame(randomSeed(), { size: ui.setup.size, scenario: ui.setup.scenario });
  renderer = new HexRenderer(canvas, ui.game.world, createView(ui));
  renderer.minZoom = 0.18;
  new MapInput(canvas, renderer, { onTap, onDouble });
  // мышь: число войск показывается у провинции под курсором
  canvas.addEventListener('pointermove', (e) => {
    if (e.pointerType !== 'mouse') return;
    const hex = renderer.hexAtScreen(e.offsetX, e.offsetY);
    const pid = hex ? hex.provinceId : null;
    if (pid !== ui.hover) { ui.hover = pid; renderer.dirty = true; }
  });
  canvas.addEventListener('pointerleave', () => { if (ui.hover != null) { ui.hover = null; renderer.dirty = true; } });
  // правая кнопка мыши: отправить армии выбранной провинции в точку под курсором
  canvas.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    const g = ui.game;
    if (ui.modal || ui.screen !== 'game' || g.over || ui.selected == null) return;
    const hex = renderer.hexAtScreen(e.offsetX, e.offsetY);
    const pid = hex ? hex.provinceId : null;
    if (pid == null || pid === ui.selected || !idleArmiesAt(g, g.playerId, ui.selected).length) return;
    const res = orderMove(g, g.playerId, ui.selected, pid, ui.fraction);
    toast(res.ok ? `Приказ отдан: ${Math.ceil(res.amount)} войск, около ${res.days} дн.` : res.msg, true);
    sfx(res.ok ? 'order' : 'error');
    ui.aiming = false; ui.target = null; ui.preview = null;
    refresh();
  });
  window.addEventListener('pointerdown', unlock, { once: true });
  window.addEventListener('keydown', unlock, { once: true });
  clock.onChange = refresh;
  clock.onTick = () => { stepDay(ui.game, aiTick); afterTick(); };

  document.getElementById('stage').addEventListener('click', (e) => {
    const b = e.target.closest('[data-act]');
    if (!b || b.disabled) return;
    const fn = actions[b.dataset.act];
    unlock();
    const act = b.dataset.act;
    sfx(['back', 'closemodal', 'resume', 'cancel'].includes(act) ? 'back' : ['armies', 'tech', 'country', 'diplo', 'journal', 'build', 'menu'].includes(act) ? 'open' : 'click');
    if (fn) fn(b.dataset.arg);
  });
  // деревья технологий и фокусов: мышью можно таскать, как карту (на сенсорных экранах работает обычная прокрутка)
  {
    let drag = null, moved = false;
    const stage = document.getElementById('stage');
    stage.addEventListener('pointerdown', (e) => {
      if (e.pointerType !== 'mouse' || e.button !== 0) return;
      const w = e.target.closest('.treewrap');
      if (!w) return;
      drag = { w, x: e.clientX, y: e.clientY, sl: w.scrollLeft, st: w.scrollTop };
      moved = false;
    });
    window.addEventListener('pointermove', (e) => {
      if (!drag) return;
      const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      if (!moved && Math.hypot(dx, dy) > 5) { moved = true; drag.w.classList.add('dragging'); }
      if (moved) { drag.w.scrollLeft = drag.sl - dx; drag.w.scrollTop = drag.st - dy; }
    });
    const end = () => { if (drag) { drag.w.classList.remove('dragging'); drag = null; } };
    window.addEventListener('pointerup', end);
    window.addEventListener('pointercancel', end);
    // после перетаскивания клик по узлу не засчитываем
    stage.addEventListener('click', (e) => { if (moved) { e.stopPropagation(); e.preventDefault(); moved = false; } }, true);
  }
  window.addEventListener('keydown', (e) => {
    if (ui.screen !== 'game' || ui.modal) return;
    if (e.code === 'Space') { e.preventDefault(); clock.togglePause(); }
    else if (e.key >= '1' && e.key <= '5') clock.setSpeed(Number(e.key));
    else if (e.key === 'Escape') actions.cancel();
  });

  let last = performance.now();
  const frame = (t) => {
    const dt = Math.min(0.25, (t - last) / 1000);
    last = t;
    if (ui.screen === 'game' && !ui.modal && !ui.game.over) clock.update(dt);
    requestAnimationFrame(frame);
  };
  requestAnimationFrame(frame);

  updateSaveInfo();
  // первый кадр: размеры уже известны, вписываем карту под меню
  requestAnimationFrame(() => { renderer.resize(); fitMenuView(); refresh(); });
}

applyMods();
boot();
initSplash();
