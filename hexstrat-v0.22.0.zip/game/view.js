// Как игра выглядит на карте: цвета гексов, границы, значки армий, приказы, выделение.
// Это слой «игра -> движок»: движок рисует через эти hooks.
import { TERRAIN, RULES } from './data.js';
import { weatherCode, weatherDay } from './weather.js';
import { atWar, prov, moveCostOf, ferryExtra, seaGap, troopText, seenTroops, armyVisible, levelOf, friendly } from './state.js';
import { airZone, airRadius, airPacks } from './air.js';
import { pixelToHex, hexToPixel } from '../engine/hex.js';
import { buildOutline } from '../engine/outline.js';
import { PLAQUE_SRC } from './sprites.js';
import { drawFlag } from './flags.js';

const hexRgb = (h) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
const mixRgb = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
const css = (c) => `rgb(${c[0] | 0},${c[1] | 0},${c[2] | 0})`;

const COAST = { color: 'rgba(6,16,22,0.75)', width: 1.4 };
const THIN = { color: 'rgba(255,255,255,0.13)', width: 0.9 };
const BORDER = { color: 'rgba(8,12,16,0.92)', width: 2.8 };
// как ландшафт подкрашивает цвет страны, и лёгкий разброс яркости, чтобы карта не выглядела плоской
const SHADE = { forest: [[22, 52, 34], 0.22], hills: [[150, 118, 66], 0.14], mountains: [[62, 66, 74], 0.3], desert: [[214, 188, 120], 0.3] };
const FLAT_Z = 0.8;
const VARIANT = [-0.05, 0, 0.04, 0.08];
const tweak = (c, t) => (t >= 0 ? mixRgb(c, [255, 255, 255], t) : mixRgb(c, [0, 0, 0], -t));
const WAR = { color: 'rgba(122,24,18,0.95)', width: 3.2 };
const PREVIEW = '#ffe08a';

function rr(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function glyph(ctx, terrain, x, y, s) {
  ctx.save();
  if (terrain === 'mountains') {
    ctx.fillStyle = 'rgba(55,58,64,0.55)';
    ctx.beginPath();
    ctx.moveTo(x - 9 * s, y + 5 * s); ctx.lineTo(x - 3 * s, y - 6 * s); ctx.lineTo(x + 1 * s, y);
    ctx.lineTo(x + 4 * s, y - 4 * s); ctx.lineTo(x + 10 * s, y + 5 * s);
    ctx.closePath(); ctx.fill();
  } else if (terrain === 'hills') {
    ctx.strokeStyle = 'rgba(86,66,28,0.65)';
    ctx.lineWidth = 1.7 * s;
    ctx.beginPath();
    ctx.arc(x - 5 * s, y + 3 * s, 6 * s, Math.PI, 0); ctx.moveTo(x + 11 * s, y + 3 * s);
    ctx.arc(x + 5 * s, y + 3 * s, 6 * s, 0, Math.PI, true);
    ctx.stroke();
  } else if (terrain === 'forest') {
    ctx.fillStyle = 'rgba(20,50,32,0.62)';
    for (const [dx, dy] of [[-5, 0], [5, 1]]) {
      ctx.beginPath();
      ctx.moveTo(x + dx * s, y + (dy - 7) * s); ctx.lineTo(x + (dx - 5) * s, y + (dy + 4) * s); ctx.lineTo(x + (dx + 5) * s, y + (dy + 4) * s);
      ctx.closePath(); ctx.fill();
    }
  }
  ctx.restore();
}

const WX_TINT = [null, [[70, 90, 120], 0.16], [[120, 92, 58], 0.3], [[240, 244, 250], 0.34], [[225, 236, 252], 0.5], [[240, 205, 110], 0.2]];

export function createView(ui) {
  const G = () => ui.game;
  const fillCache = new Map();

  // Оккупированная земля (чужое ядро, подчинение не завершено) остаётся цвета прежней страны и штрихуется захватчиком
  const isOccupied = (p) => p.props.owner != null && p.props.core != null && p.props.core !== p.props.owner && (p.props.comp ?? 100) < 100;
  const shownOwner = (p) => (isOccupied(p) ? p.props.core : p.props.owner);

  function hexFill(hex, p, z = 1) {
    // издали карта упрощается: плоский цвет страны, без узора и оттенков рельефа
    const flat = z < FLAT_Z;
    const owned = ui.mode === 'political' && p && p.props.owner != null && hex.terrain !== 'water';
    const vi = flat || owned ? 0 : ((hex.q * 73856093) ^ (hex.r * 19349663)) & 3;
    if (!p || hex.terrain === 'water') {
      const wk = 'w' + vi;
      let w = fillCache.get(wk);
      if (!w) { w = css(tweak(hexRgb(TERRAIN.water.color), VARIANT[vi] * 0.6)); fillCache.set(wk, w); }
      return w;
    }
    const own = ui.mode === 'political' ? shownOwner(p) : null;
    const sel = p.id === ui.selected ? 2 : p.id === ui.target ? 1 : 0;
    const dim = ui.screen === 'setup' && ui.setup.country != null && p.props.owner !== ui.setup.country ? 1 : 0;
    const wxc = RULES.weather && ui.screen === 'game' ? weatherCode(G(), p) : 0;
    const key = (flat ? 'f' : hex.terrain) + '|' + own + '|' + sel + '|' + vi + '|' + dim + '|' + wxc;
    let v = fillCache.get(key);
    if (v) return v;
    let c = hexRgb(TERRAIN[flat ? 'plains' : hex.terrain].color);
    if (own != null) {
      c = mixRgb(c, hexRgb(G().countries[own].color), flat ? 0.8 : 0.72);
      const sh = flat ? null : SHADE[hex.terrain];
      if (sh) c = mixRgb(c, sh[0], sh[1] * 0.4);
    }
    c = tweak(c, VARIANT[vi]);
    if (dim) c = mixRgb(c, [19, 48, 63], 0.62);
    if (wxc) c = mixRgb(c, WX_TINT[wxc][0], WX_TINT[wxc][1]);
    if (sel === 2) c = mixRgb(c, [255, 255, 255], 0.3);
    else if (sel === 1) c = mixRgb(c, [255, 255, 255], 0.16);
    v = css(c);
    fillCache.set(key, v);
    return v;
  }

  // Штриховка оккупации: диагональные полосы цвета захватчика поверх цвета прежней страны
  function drawOccupation(ctx, r, z, flat) {
    if (ui.mode !== 'political') return;
    const g = G();
    const groups = new Map();
    const size = r.size, tl = r.screenToWorld(0, 0), br = r.screenToWorld(r.w, r.h), pad = size * 1.5;
    for (const p of g.world.provinces.values()) {
      if (!isOccupied(p)) continue;
      const key = p.props.core + '|' + p.props.owner;
      let gr = groups.get(key);
      if (!gr) { gr = { core: p.props.core, owner: p.props.owner, path: new Path2D(), n: 0, x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity }; groups.set(key, gr); }
      for (const h of p.hexes) {
        const c = hexToPixel(h.q, h.r, size);
        if (c.x < tl.x - pad || c.x > br.x + pad || c.y < tl.y - pad || c.y > br.y + pad) continue;
        const cs = r.corners;
        gr.path.moveTo(c.x + cs[0][0] * 1.04, c.y + cs[0][1] * 1.04);
        for (let k = 1; k < 6; k++) gr.path.lineTo(c.x + cs[k][0] * 1.04, c.y + cs[k][1] * 1.04);
        gr.path.closePath(); gr.n++;
        gr.x0 = Math.min(gr.x0, c.x - size); gr.y0 = Math.min(gr.y0, c.y - size); gr.x1 = Math.max(gr.x1, c.x + size); gr.y1 = Math.max(gr.y1, c.y + size);
      }
    }
    const step = size * 0.6;
    for (const gr of groups.values()) {
      if (!gr.n) continue;
      ctx.save();
      if (flat) { ctx.fillStyle = flatColor(gr.core, g); ctx.fill(gr.path); }
      ctx.clip(gr.path);
      ctx.strokeStyle = g.countries[gr.owner].color; ctx.globalAlpha = 0.95; ctx.lineWidth = size * 0.24; ctx.lineCap = 'butt';
      ctx.beginPath();
      const h = gr.y1 - gr.y0;
      for (let x = gr.x0 - h; x < gr.x1; x += step) { ctx.moveTo(x, gr.y1); ctx.lineTo(x + h, gr.y0); }
      ctx.stroke();
      ctx.restore();
    }
  }

  // Издали карта рисуется гладкими контурами стран (а не гексами): береговая линия и границы сглажены.
  let flatCache = null;
  function flatColor(own, g) {
    if (own < 0) return '#6d7566';
    let c = mixRgb(hexRgb(TERRAIN.plains.color), hexRgb(g.countries[own].color), 0.8);
    if (ui.screen === 'setup' && ui.setup.country != null && own !== ui.setup.country) c = mixRgb(c, [19, 48, 63], 0.62);
    return css(c);
  }
  function drawFlat(ctx, r, z) {
    if (z >= FLAT_Z || ui.mode !== 'political') return false;
    const g = G();
    const sig = [layerSlowSig(), ui.screen, ui.setup.country, r._worldStamp || 0].join('|');
    if (!flatCache || flatCache.g !== g || flatCache.sig !== sig) {
      const out = buildOutline(g.world, r.size, (hex) => {
        if (hex.terrain === 'water' || hex.provinceId == null) return -1;
        const o = prov(g, hex.provinceId).props.owner;
        return o == null ? -2 : o;
      });
      const coast = new Path2D(), borders = new Path2D(), wars = new Path2D();
      for (const ch of out.chains) {
        const target = ch.a === -1 || ch.b === -1 ? coast : (ch.a >= 0 && ch.b >= 0 && atWar(g, ch.a, ch.b) ? wars : (ch.a < 0 || ch.b < 0 ? borders : borders));
        target.moveTo(ch.pts[0][0], ch.pts[0][1]);
        for (let i = 1; i < ch.pts.length; i++) target.lineTo(ch.pts[i][0], ch.pts[i][1]);
      }
      flatCache = { g, sig, fills: out.fills, coast, borders, wars };
    }
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    for (const [rid, path] of flatCache.fills) {
      if (rid === -1) continue;
      ctx.fillStyle = flatColor(rid, g);
      ctx.fill(path);
    }
    ctx.strokeStyle = COAST.color; ctx.lineWidth = 1.5 / z; ctx.stroke(flatCache.coast);
    ctx.strokeStyle = BORDER.color; ctx.lineWidth = 2.2 / z; ctx.stroke(flatCache.borders);
    ctx.strokeStyle = WAR.color; ctx.lineWidth = 3 / z; ctx.stroke(flatCache.wars);
    return true;
  }

  function edgeStyle(a, b, z = 1) {
    const aw = a.terrain === 'water', bw = b ? b.terrain === 'water' : true;
    if (aw && bw) return null;
    if (aw !== bw) return COAST;
    if (a.provinceId === b.provinceId) return null;
    const g = G();
    const oa = prov(g, a.provinceId).props.owner, ob = prov(g, b.provinceId).props.owner;
    if (oa === ob) return z < FLAT_Z ? null : THIN;
    return atWar(g, oa, ob) ? WAR : BORDER;
  }

  // Плашка отряда в духе HoI4: полоска цвета страны, знак пехоты в рамке, над ним знак масштаба
  // (точки, чёрточки, X — по численности), справа число войск, снизу полоска организации.
  const ECH = [12, 30, 60, 120, 240, 480];
  function echelon(ctx, cx, y, s, total, ink) {
    let t = 0;
    for (const v of ECH) if (total >= v) t++;
    ctx.fillStyle = ink; ctx.strokeStyle = ink; ctx.lineWidth = 1.2 * s;
    const kind = t <= 1 ? 'd' : t <= 4 ? 'b' : 'x', n = t <= 1 ? t + 1 : t <= 4 ? t - 1 : t - 4;
    const gap = kind === 'x' ? 5 * s : 3.4 * s;
    for (let i = 0; i < n; i++) {
      const x = cx + (i - (n - 1) / 2) * gap;
      if (kind === 'd') { ctx.beginPath(); ctx.arc(x, y + 1.6 * s, 1.2 * s, 0, 6.3); ctx.fill(); }
      else if (kind === 'b') { ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + 3.4 * s); ctx.stroke(); }
      else { ctx.beginPath(); ctx.moveTo(x - 1.7 * s, y); ctx.lineTo(x + 1.7 * s, y + 3.4 * s); ctx.moveTo(x + 1.7 * s, y); ctx.lineTo(x - 1.7 * s, y + 3.4 * s); ctx.stroke(); }
    }
  }
  const plaqueBg = new Map();
  function unitPlaqueVec(ctx, x, y, w, h, s, color, total, org, own, hl, text) {
    // тёмно-зелёная металлическая плашка с фаской
    let gr = plaqueBg.get(h);
    ctx.save(); ctx.translate(x, y);
    gr = ctx.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, own ? '#46513f' : '#3c4440'); gr.addColorStop(1, own ? '#1f271c' : '#1b201f');
    ctx.fillStyle = gr; ctx.fillRect(0, 0, w, h);
    ctx.lineWidth = Math.max(1, 1.1 * s);
    ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.beginPath(); ctx.moveTo(0.5, h); ctx.lineTo(0.5, 0.5); ctx.lineTo(w, 0.5); ctx.stroke();
    ctx.strokeStyle = 'rgba(0,0,0,0.75)'; ctx.beginPath(); ctx.moveTo(w - 0.5, 0); ctx.lineTo(w - 0.5, h - 0.5); ctx.lineTo(0, h - 0.5); ctx.stroke();
    if (hl) { ctx.lineWidth = 2.2 * s; ctx.strokeStyle = '#ebe07a'; ctx.strokeRect(0, 0, w, h); }
    ctx.restore();
    // флажок страны слева
    const fw = 5 * s;
    ctx.fillStyle = color; ctx.fillRect(x + 1.5 * s, y + 1.5 * s, fw, h - 3 * s);
    ctx.fillStyle = 'rgba(255,255,255,0.32)'; ctx.fillRect(x + 1.5 * s, y + 1.5 * s, fw, (h - 3 * s) / 3);
    ctx.strokeStyle = 'rgba(0,0,0,0.7)'; ctx.lineWidth = 0.9; ctx.strokeRect(x + 1.5 * s, y + 1.5 * s, fw, h - 3 * s);
    // светлая табличка с условным знаком пехоты
    const numW = text ? Math.max(11 * s, text.length * 6.6 * s + 3 * s) : 0;
    const px = x + fw + 3.2 * s, pw = w - fw - 4.7 * s - numW, py = y + 1.5 * s, ph = h - 5.2 * s;
    ctx.fillStyle = '#d9d5bf'; ctx.fillRect(px, py, pw, ph);
    ctx.strokeStyle = 'rgba(0,0,0,0.55)'; ctx.lineWidth = 0.9; ctx.strokeRect(px, py, pw, ph);
    const ink = '#1c211a', cx = px + pw / 2, bw = Math.min(pw - 3 * s, 13 * s), bh = 8 * s, by = py + 6 * s;
    echelon(ctx, cx, py + 1.4 * s, s, total, ink);
    ctx.lineWidth = 1.2 * s; ctx.strokeStyle = ink;
    ctx.strokeRect(cx - bw / 2, by, bw, bh);
    ctx.beginPath(); ctx.moveTo(cx - bw / 2, by); ctx.lineTo(cx + bw / 2, by + bh); ctx.moveTo(cx + bw / 2, by); ctx.lineTo(cx - bw / 2, by + bh); ctx.stroke();
    if (text) {
      ctx.font = `600 ${Math.max(6, Math.round(11.5 * s))}px "Fira Sans", system-ui, sans-serif`;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#fff';
      ctx.shadowColor = 'rgba(0,0,0,0.8)'; ctx.shadowBlur = 2;
      ctx.fillText(text, x + w - numW / 2 - 1.2 * s, y + (h - 3 * s) / 2 + 0.5);
      ctx.shadowBlur = 0;
    }
    const bx = x + fw + 3.2 * s, bwid = w - fw - 4.7 * s;
    ctx.fillStyle = 'rgba(0,0,0,.65)'; ctx.fillRect(bx, y + h - 3.4 * s, bwid, 2.2 * s);
    ctx.fillStyle = org > 0.6 ? '#7ccf5f' : org > 0.3 ? '#e0b43c' : '#e0584c';
    ctx.fillRect(bx, y + h - 3.4 * s, bwid * Math.max(0, Math.min(1, org)), 2.2 * s);
  }

  // Плашка на готовой рамке: флажок-язычок слева, знак пехоты на «пергаменте», число справа, снизу организация
  let plaqueImg = null;
  if (typeof Image !== 'undefined') { plaqueImg = new Image(); plaqueImg.src = PLAQUE_SRC; plaqueImg.onload = () => window.dispatchEvent(new Event('resize')); }
  const PR = 200 / 147;
  function plaqueSize(s, text) {
    const h = 19 * s, tw = h * PR, flag = 11 * s;
    const numW = text ? text.length * 6.8 * s + 6 * s : 0;
    return { h, tw, flag, numW, w: flag + tw + numW };
  }
  function unitPlaque(ctx, x, y, w, h, s, cn, total, org, own, hl, text) {
    if (!plaqueImg || !plaqueImg.complete || !plaqueImg.naturalWidth) return unitPlaqueVec(ctx, x, y, w, h, s, cn.color, total, org, own, hl, text);
    const { tw, flag, numW } = plaqueSize(s, text);
    const tx = x + flag;
    // номер справа на тёмной подложке
    if (text) {
      const nh = h * 0.62, ny = y + (h - nh) / 2;
      ctx.fillStyle = 'rgba(14,18,12,0.92)'; ctx.fillRect(tx + tw - 2 * s, ny, numW + 2 * s, nh);
      ctx.strokeStyle = own ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.2)'; ctx.lineWidth = Math.max(1, s); ctx.strokeRect(tx + tw - 2 * s, ny, numW + 2 * s, nh);
    }
    ctx.drawImage(plaqueImg, tx, y, tw, h);
    if (!own) { ctx.fillStyle = 'rgba(0,0,0,0.22)'; ctx.fillRect(tx + tw * 0.04, y + h * 0.06, tw * 0.92, h * 0.88); }
    if (hl) { ctx.lineWidth = 2.2 * s; ctx.strokeStyle = '#ebe07a'; ctx.strokeRect(tx - 1, y - 1, tw + 2 + (text ? numW : 0), h + 2); }
    // флаг страны слева от плашки
    const fw = flag - 1.2 * s, fh = fw / 1.6, fx = x + 0.4 * s, fy = y + (h - fh) / 2;
    drawFlag(ctx, cn, fx, fy, fw, fh);
    // знак на пергаменте
    const px = tx + tw * 0.14, pw = tw * 0.72, py = y + h * 0.16, ph = h * 0.68, cx = px + pw / 2;
    const ink = '#1c211a', bw = Math.min(pw - 2 * s, 12.5 * s), bh = 6.2 * s, by = py + ph * 0.46;
    echelon(ctx, cx, py + ph * 0.12, s, total, ink);
    ctx.lineWidth = 1.3 * s; ctx.strokeStyle = ink;
    ctx.strokeRect(cx - bw / 2, by, bw, bh);
    ctx.beginPath(); ctx.moveTo(cx - bw / 2, by); ctx.lineTo(cx + bw / 2, by + bh); ctx.moveTo(cx + bw / 2, by); ctx.lineTo(cx - bw / 2, by + bh); ctx.stroke();
    if (text) {
      ctx.font = `600 ${Math.max(6, Math.round(11.5 * s))}px "Fira Sans", system-ui, sans-serif`;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#fff';
      ctx.fillText(text, tx + tw + numW / 2 - 1.2 * s, y + h / 2 + 0.5);
    }
    // организация: полоска по нижней рамке
    const ob = px, ow = pw;
    ctx.fillStyle = 'rgba(0,0,0,.7)'; ctx.fillRect(ob, y + h - 2.7 * s, ow, 1.7 * s);
    ctx.fillStyle = org > 0.6 ? '#7ccf5f' : org > 0.3 ? '#e0b43c' : '#e0584c';
    ctx.fillRect(ob, y + h - 2.7 * s, ow * Math.max(0, Math.min(1, org)), 1.7 * s);
  }

  // Стрелка приказа: тёмная линия с наконечником и числом войск посередине.
  function arrow(ctx, pts, s, amount, preview) {
    if (pts.length < 2) return;
    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = preview ? PREVIEW : 'rgba(8,8,8,0.9)';
    ctx.lineWidth = (preview ? 3 : 2.2) * Math.max(0.8, s);
    if (preview) ctx.setLineDash([8, 5]);
    ctx.beginPath();
    pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.stroke();
    ctx.setLineDash([]);
    const b = pts[pts.length - 1], a = pts[pts.length - 2];
    const ang = Math.atan2(b.y - a.y, b.x - a.x), hs = 9 * Math.max(0.8, s);
    ctx.fillStyle = preview ? PREVIEW : 'rgba(8,8,8,0.95)';
    ctx.beginPath();
    ctx.moveTo(b.x, b.y);
    ctx.lineTo(b.x - hs * Math.cos(ang - 0.45), b.y - hs * Math.sin(ang - 0.45));
    ctx.lineTo(b.x - hs * Math.cos(ang + 0.45), b.y - hs * Math.sin(ang + 0.45));
    ctx.closePath();
    ctx.fill();
    if (amount != null) {
      const m = pts[Math.floor((pts.length - 1) / 2)], n = pts[Math.floor((pts.length - 1) / 2) + 1] || m;
      const mx = (m.x + n.x) / 2, my = (m.y + n.y) / 2;
      const txt = String(amount);
      ctx.font = `500 ${Math.round(10.5 * s)}px "Fira Sans", system-ui, sans-serif`;
      const tw = ctx.measureText(txt).width + 8 * s;
      ctx.fillStyle = 'rgba(8,8,8,0.88)';
      ctx.fillRect(mx - tw / 2, my - 7 * s, tw, 14 * s);
      ctx.fillStyle = '#fff';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(txt, mx, my + 0.5);
    }
    ctx.restore();
  }

  function polyline(ctx, pts, color, width, dash) {
    ctx.save();
    ctx.setLineDash(dash);
    ctx.lineWidth = width;
    ctx.strokeStyle = color;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.stroke();
    ctx.restore();
  }

  // Морские переправы: открытые — голубой пунктир с якорем, закрытые для армий (слишком далеко) — бледные точки
  function drawFerries(ctx, r, z, s) {
    const g = G();
    ctx.save();
    ctx.lineCap = 'round';
    for (const [a, b, gap, open] of g.world.ferries || []) {
      const pa = r.provinceScreenCenter(a), pb = r.provinceScreenCenter(b);
      if (!pa || !pb) continue;
      ctx.beginPath(); ctx.moveTo(pa.x, pa.y); ctx.lineTo(pb.x, pb.y);
      if (open) { ctx.strokeStyle = 'rgba(150,210,255,0.85)'; ctx.lineWidth = Math.max(1.2, 1.8 * s); ctx.setLineDash([6 * s, 5 * s]); }
      else { ctx.strokeStyle = 'rgba(210,130,120,0.5)'; ctx.lineWidth = Math.max(1, 1.4 * s); ctx.setLineDash([1.5 * s, 7 * s]); }
      ctx.stroke();
      if (open && z >= 0.7) {
        const mx = (pa.x + pb.x) / 2, my = (pa.y + pb.y) / 2;
        ctx.setLineDash([]);
        ctx.fillStyle = 'rgba(10,30,45,0.85)'; ctx.beginPath(); ctx.arc(mx, my, 7 * s, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = 'rgba(150,210,255,0.9)'; ctx.lineWidth = Math.max(1, 1.2 * s); ctx.stroke();
        ctx.fillStyle = '#bfe3ff'; ctx.font = `${Math.max(8, Math.round(9 * s))}px system-ui, sans-serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('⚓', mx, my + 0.5);
      }
    }
    ctx.restore();
  }

  function drawOverlay(ctx, r, t) {
    const g = G();
    const z = r.cam.zoom;
    const s = Math.max(0.42, Math.min(1.35, z * 1.05));
    const me = g.playerId;

    const by = new Map();
    for (const a of g.armies) {
      if (!armyVisible(g, a)) continue;
      let m = by.get(a.at);
      if (!m) { m = new Map(); by.set(a.at, m); }
      let x = m.get(a.owner);
      if (!x) { x = { owner: a.owner, total: 0, fighting: false, idle: false, orgSum: 0 }; m.set(a.owner, x); }
      x.total += a.strength;
      x.orgSum += a.strength * (a.org == null ? 100 : Math.max(0, a.org));
      x.fighting = x.fighting || a.fighting;
      if (!a.order) x.idle = true;
    }

    if (z >= 0.8) {
      for (const v of r.visible) {
        const h = v.hex;
        if (h.terrain === 'water' || h.terrain === 'plains') continue;
        const sc = r.worldToScreen(v.x, v.y);
        // значок рельефа сдвигается вниз только в той клетке, где стоит плашка армии
        let dy = 2 * s;
        if (by.has(h.provinceId)) { const pc = r.provinceScreenCenter(h.provinceId); if (Math.hypot(sc.x - pc.x, sc.y - pc.y) < 10 * s) dy = 11 * s; }
        glyph(ctx, h.terrain, sc.x, sc.y + dy, s * 0.9);
      }
    }

    if (ui.selected != null && prov(g, ui.selected)) r.strokeProvince(ui.selected, '#ffffff', 3);
    if (ui.modal === 'peaceoffer') {
      const o = (g.offers || []).find((x) => x.id === ui.offerId);
      if (o && o.ids) for (const id of o.ids) r.strokeProvince(id, '#ffd24a', 3.5);
    }

    drawFerries(ctx, r, z, s);

    if (ui.screen === 'game' && me != null) {
      for (const a of g.armies) {
        if (a.owner !== me || !a.order || a.at !== ui.selected) continue; // приказы видны только у выбранной клетки
        const pts = [a.at, ...a.order.path].map((id) => r.provinceScreenCenter(id));
        arrow(ctx, pts, s, Math.ceil(a.strength), false);
        const next = prov(g, a.order.path[0]);
        const f = a.order.progress / (moveCostOf(next) + ferryExtra(g, a.at, next.id));
        const px = pts[0].x + (pts[1].x - pts[0].x) * f, py = pts[0].y + (pts[1].y - pts[0].y) * f;
        ctx.beginPath(); ctx.arc(px, py, 4.5, 0, Math.PI * 2);
        ctx.fillStyle = '#ebe07a'; ctx.fill();
        ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(0,0,0,0.8)'; ctx.stroke();
      }
    }

    if (ui.aiming && ui.selected != null && ui.target != null) {
      if (ui.preview) arrow(ctx, [ui.selected, ...ui.preview.path].map((id) => r.provinceScreenCenter(id)), s, null, true);
      r.strokeProvince(ui.target, ui.preview ? PREVIEW : '#ff9a8c', 3, [6, 4]);
    }

    // аэродром выбран: зона радиуса задания и цель
    if (ui.screen === 'game' && ui.selected != null && me != null) {
      const sp = prov(g, ui.selected);
      if (sp.props.owner === me && levelOf(sp, 'airfield')) {
        const am = sp.props.air && sp.props.air.mission;
        const R = am ? am.r : airRadius(g, me, levelOf(sp, 'airfield'));
        for (const [id, d] of airZone(g, ui.selected, R)) if (d > 0) r.strokeProvince(id, 'rgba(120,200,255,0.75)', 1.2, [3, 4]);
        if (am && am.pid != null) r.strokeProvince(am.pid, '#ff9a8c', 3, [6, 4]);
      }
    }

    // порт выбран: провинции, куда можно плыть
    if (ui.screen === 'game' && ui.selected != null && me != null && g._portGap) {
      const sp = prov(g, ui.selected);
      if (sp.props.owner === me && levelOf(sp, 'port')) {
        for (const nb of sp.neighbors) if (seaGap(g, ui.selected, nb) !== undefined) r.strokeProvince(nb, 'rgba(90,170,255,0.8)', 1.2, [2, 4]);
      }
    }

    drawCountryLabels(ctx, r, z, t);

    if (ui.screen !== 'game') return;

    // при отдалении значки армий уменьшаются вдвое (z≤0.5 → ×0.5, z≥1 → ×1)
    const ps = s * Math.max(0.5, Math.min(1, 0.5 + (z - 0.5)));
    for (const [pid, m] of by) {
      const c = r.provinceScreenCenter(pid);
      if (c.x < -50 || c.y < -50 || c.x > r.w + 50 || c.y > r.h + 50) continue;
      // мелкие чужие отряды при отдалении скрываем, чтобы карта не превращалась в кашу из цифр
      const groups = [...m.values()]
        .filter((grp) => (z >= 0.45 && grp.owner === me) || grp.fighting || (z >= 1 ? true : z >= 0.7 ? grp.total >= 12 : z >= 0.45 ? grp.total >= 40 : grp.total >= 100))
        .sort((a, b) => (a.owner === me ? -1 : b.owner === me ? 1 : b.total - a.total))
        .slice(0, z < 0.9 ? 1 : 2);
      if (!groups.length) continue;
      const focus = pid === ui.selected || pid === ui.target || pid === ui.hover;
      if (focus) {
        // у выбранной провинции или под курсором — плашки с числом войск по центру
        const h = 19 * ps;
        const items = groups.map((grp) => {
          const text = troopText(g, grp.owner, grp.total, pid);
          return { grp, text, w: plaqueSize(ps, text).w };
        });
        const total = items.reduce((sum, i) => sum + i.w, 0) + (items.length - 1) * 2 * ps;
        let x = c.x - total / 2;
        const y = c.y - h / 2;
        for (const it of items) {
          const hl = it.grp.owner === me && pid === ui.selected && it.grp.idle;
          unitPlaque(ctx, x, y, it.w, h, ps, g.countries[it.grp.owner], seenTroops(g, it.grp.owner, it.grp.total, pid).n, it.grp.orgSum / Math.max(1, it.grp.total) / 100, it.grp.owner === me, hl, it.text);
          if (it.grp.fighting) fightRing(ctx, x, y, it.w, h, ps, t);
          x += it.w + 2 * ps;
        }
        continue;
      }
      // иначе — компактный значок-флажок строго по центру провинции, без числа
      const chips = groups.slice(0, z >= 1.3 ? 2 : 1);
      const cw = plaqueSize(ps, '').w, ch = 19 * ps, gap = 2 * ps;
      const total = chips.length * cw + (chips.length - 1) * gap;
      let x = c.x - total / 2;
      const y = c.y - ch / 2;
      for (const grp of chips) {
        unitPlaque(ctx, x, y, cw, ch, ps, g.countries[grp.owner], seenTroops(g, grp.owner, grp.total, pid).n, grp.orgSum / Math.max(1, grp.total) / 100, grp.owner === me, false, '');
        if (grp.fighting) fightRing(ctx, x, y, cw, ch, ps, t);
        x += cw + gap;
      }
    }
    // значки авиации: число эскадрилий над аэродромом (свои и союзные)
    if (z >= 0.6 && g._air) {
      for (const pid of g._air) {
        const p = prov(g, pid), n = airPacks(p);
        if (n < 0.5 || p.props.owner == null || !(p.props.owner === me || friendly(g, me, p.props.owner))) continue;
        const c = r.provinceScreenCenter(pid);
        if (c.x < -50 || c.y < -50 || c.x > r.w + 50 || c.y > r.h + 50) continue;
        const txt = `\u2708 ${Math.round(n)}`;
        ctx.font = `${Math.round(11 * ps)}px system-ui, sans-serif`;
        const w = ctx.measureText(txt).width + 8 * ps, h = 14 * ps, x = c.x - w / 2, y = c.y + 11 * ps;
        ctx.fillStyle = 'rgba(10,14,20,0.82)'; ctx.fillRect(x, y, w, h);
        ctx.strokeStyle = p.props.air.mission ? '#8fd0ff' : '#6b7280'; ctx.lineWidth = 1; ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
        ctx.fillStyle = '#dbeeff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(txt, c.x, y + h / 2 + 0.5);
      }
    }
  }

  // Названия государств: у каждой связной части страны строится «хребет» (кривая по её середине),
  // и подпись раскладывается по нему буква за буквой: изгибается, поворачивается, вмещается по толщине.
  function components(g, hw) {
    const byOwner = new Map();
    for (const p of g.world.provinces.values()) {
      const o = p.props.owner;
      if (o == null) continue;
      let a = byOwner.get(o); if (!a) { a = []; byOwner.set(o, a); }
      a.push(p);
    }
    const res = [];
    const cell = hw * 1.3;
    for (const [o, list] of byOwner) {
      const grid = new Map();
      list.forEach((p, i) => { const k = Math.round(p.center.x / cell) + ',' + Math.round(p.center.y / cell); (grid.get(k) || grid.set(k, []).get(k)).push(i); });
      const seen = new Uint8Array(list.length);
      for (let i = 0; i < list.length; i++) {
        if (seen[i]) continue;
        const comp = [list[i]], q = [i]; seen[i] = 1;
        for (let h = 0; h < q.length; h++) {
          const pc = list[q[h]].center, gx = Math.round(pc.x / cell), gy = Math.round(pc.y / cell);
          for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) {
            const arr = grid.get((gx + dx) + ',' + (gy + dy)); if (!arr) continue;
            for (const j of arr) {
              if (seen[j]) continue;
              const c2 = list[j].center;
              if (Math.hypot(c2.x - pc.x, c2.y - pc.y) <= hw * 1.25) { seen[j] = 1; comp.push(list[j]); q.push(j); }
            }
          }
        }
        res.push({ owner: o, pts: comp.map((p) => p.center) });
      }
    }
    return res;
  }

  // хребет: ось главной вытянутости + средняя линия по корзинам вдоль неё
  function spineOf(pts, hw) {
    let mx = 0, my = 0;
    for (const p of pts) { mx += p.x; my += p.y; }
    mx /= pts.length; my /= pts.length;
    let sxx = 0, syy = 0, sxy = 0;
    for (const p of pts) { const dx = p.x - mx, dy = p.y - my; sxx += dx * dx; syy += dy * dy; sxy += dx * dy; }
    const tr = sxx + syy, det = sxx * syy - sxy * sxy, disc = Math.sqrt(Math.max(0, tr * tr / 4 - det));
    const l1 = tr / 2 + disc, l2 = Math.max(1e-6, tr / 2 - disc);
    const compact = l1 / l2 < 2.2;
    let th = compact ? 0 : 0.5 * Math.atan2(2 * sxy, sxx - syy);
    let ux = Math.cos(th), uy = Math.sin(th);
    if (ux < -1e-6 || (Math.abs(ux) < 1e-6 && uy > 0)) { ux = -ux; uy = -uy; }
    const vx = -uy, vy = ux;
    const bw = hw * 0.85;
    const bins = new Map();
    let kMin = 1e9, kMax = -1e9;
    for (const p of pts) {
      const dx = p.x - mx, dy = p.y - my, t = dx * ux + dy * uy, s2 = dx * vx + dy * vy, k = Math.round(t / bw);
      let b = bins.get(k); if (!b) { b = { n: 0, sum: 0, lo: 1e9, hi: -1e9 }; bins.set(k, b); }
      b.n++; b.sum += s2; b.lo = Math.min(b.lo, s2); b.hi = Math.max(b.hi, s2);
      kMin = Math.min(kMin, k); kMax = Math.max(kMax, k);
    }
    // непрерывные отрезки корзин; разрывы в одну корзину заполняем интерполяцией
    const arr = [];
    for (let k = kMin; k <= kMax; k++) arr.push(bins.get(k) || null);
    for (let i = 1; i < arr.length - 1; i++) if (!arr[i] && arr[i - 1] && arr[i + 1]) arr[i] = { n: 0, sum: 0, interp: true, a: arr[i - 1], b: arr[i + 1] };
    const mean = arr.map((b) => (b ? (b.interp ? (b.a.sum / b.a.n + b.b.sum / b.b.n) / 2 : b.sum / b.n) : null));
    const thick = arr.map((b) => (b ? (b.interp ? Math.min(b.a.hi - b.a.lo, b.b.hi - b.b.lo) : b.hi - b.lo) + hw * 0.9 : 0));
    // сглаживание средней линии
    const sm = mean.map((m, i) => {
      if (m == null) return null;
      if (compact) return 0; // у «круглых» стран подпись идёт прямо через центр
      let a = 0, c = 0;
      for (let d = -4; d <= 4; d++) { const v = mean[i + d]; if (v != null) { const w = 5 - Math.abs(d); a += v * w; c += w; } }
      return a / c;
    });
    return { mx, my, ux, uy, vx, vy, bw, kMin, sm, thick };
  }

  // раскладывает текст по хребту; возвращает буквы с позицией и углом (мировые координаты) и кегль
  function layoutLabel(ctx, txt, comp, hw, rowH, n, inside) {
    const sp = spineOf(comp.pts, hw);
    ctx.font = `20px ${LABEL_FONT}`;
    const cw20 = [...txt].map((ch) => ctx.measureText(ch).width);
    const len20 = cw20.reduce((a, c) => a + c, 0) + (txt.length - 1) * SPACING * 20;
    const fsMax = Math.min(rowH * 2.8, hw * Math.sqrt(n) * 0.32, 64);
    const { sm, thick, bw, kMin } = sp;
    const N = sm.length;
    const pt = (i) => ({ x: sp.mx + sp.ux * (kMin + i) * bw + sp.vx * sm[i], y: sp.my + sp.uy * (kMin + i) * bw + sp.vy * sm[i] });
    // раскладка букв по длине дуги хребта в окне [i0, i0+need)
    const build = (i0, need, fs, L) => {
      const pts = [];
      for (let i = i0; i < i0 + need; i++) pts.push(pt(i));
      const cum = [0];
      for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y));
      const total = cum[cum.length - 1];
      const at = (a) => {
        a = Math.max(0, Math.min(total, a));
        let j = 1; while (j < cum.length - 1 && cum[j] < a) j++;
        const f = (a - cum[j - 1]) / ((cum[j] - cum[j - 1]) || 1);
        return { x: pts[j - 1].x + (pts[j].x - pts[j - 1].x) * f, y: pts[j - 1].y + (pts[j].y - pts[j - 1].y) * f };
      };
      const k = fs / 20, letters = [];
      let a = (total - L) / 2;
      [...txt].forEach((ch, i) => {
        const w = cw20[i] * k, c = a + w / 2, p0 = at(c - w / 2 - 1), p1 = at(c + w / 2 + 1), pc = at(c);
        letters.push({ ch, x: pc.x, y: pc.y, ang: Math.atan2(p1.y - p0.y, p1.x - p0.x), w });
        a += w + SPACING * fs;
      });
      return letters;
    };
    // каждая буква (её рамка) должна целиком лежать на территории этой страны
    const fits = (letters, fs) => {
      for (const l of letters) {
        const c = Math.cos(l.ang), sn = Math.sin(l.ang), hx = l.w / 2 + fs * 0.06, hy = fs * 0.42;
        for (const [dx, dy] of [[0, 0], [-hx, -hy], [hx, -hy], [-hx, hy], [hx, hy], [0, -hy], [0, hy]]) {
          if (!inside(l.x + dx * c - dy * sn, l.y + dx * sn + dy * c)) return false;
        }
      }
      return true;
    };
    // подбираем кегль и окно вдоль хребта; сначала ищем окно у центра страны, и лишь потом — где угодно
    const span = N * bw;
    const search = (maxOff) => {
      for (let fs = fsMax; fs > hw * 0.28; fs *= 0.94) {
        const L = len20 * fs / 20, need = Math.max(2, Math.ceil(L / bw) + 1);
        const cands = [];
        for (let i0 = 0; i0 + need <= N; i0++) {
          const mid = Math.abs((i0 + need / 2 - N / 2) * bw);
          if (mid > maxOff) continue;
          let ok = true, minT = 1e9, len = 0;
          for (let i = i0; i < i0 + need; i++) { if (sm[i] == null) { ok = false; break; } minT = Math.min(minT, thick[i]); if (i > i0) { const a = pt(i - 1), b = pt(i); len += Math.hypot(b.x - a.x, b.y - a.y); } }
          if (!ok || len < L * 1.04 || minT < fs * 1.0) continue;
          cands.push({ mid, i0, need, fs, L });
        }
        cands.sort((a, b) => a.mid - b.mid);
        for (const c of cands) {
          const letters = build(c.i0, c.need, c.fs, c.L);
          if (fits(letters, c.fs)) return { ...c, letters };
        }
      }
      return null;
    };
    const any = search(1e9);
    let best = any;
    if (any) {
      for (const [off, keep] of [[0.06, 0.8], [0.14, 0.68], [0.26, 0.55]]) {
        const c = search(span * off);
        if (c && c.fs >= any.fs * keep) { best = c; break; }
      }
    }
    if (!best) return null;
    return { letters: best.letters, fs: best.fs, owner: comp.owner };
  }

  const LABEL_FONT = '"Forum", "Cormorant SC", Georgia, "Times New Roman", serif';
  const SPACING = 0.34; // межбуквенный интервал в долях кегля
  let fontAsked = false;
  let labelCache = null;
  function drawCountryLabels(ctx, r, z, t) {
    if (z >= 1.0) return;
    if (!fontAsked && typeof document !== 'undefined' && document.fonts && document.fonts.load) {
      fontAsked = true;
      document.fonts.load('20px "Forum"', 'АБВ').then(() => { labelCache = null; r.dirty = true; }).catch(() => {});
    }
    const gm = G();
    let sig = 0;
    if (labelCache && t - labelCache.t > 2500) { let i = 1; for (const p of gm.world.provinces.values()) sig = (sig * 31 + (p.props.owner + 2) * (i++ & 255)) | 0; if (sig === labelCache.sig) labelCache.t = t; }
    if (!labelCache || (t - labelCache.t > 2500) || labelCache.world !== gm) {
      const hw = r.size * Math.sqrt(3), rowH = r.size * 1.5;
      const list = [];
      const comps = components(gm, hw).sort((a, b) => b.pts.length - a.pts.length);
      const seenOwner = new Set();
      for (const comp of comps) {
        const first = !seenOwner.has(comp.owner);
        if (comp.pts.length < (first ? 2 : 8)) continue;
        seenOwner.add(comp.owner);
        const L = layoutLabel(ctx, gm.countries[comp.owner].name.toUpperCase(), comp, hw, rowH, comp.pts.length, (x, y) => {
          const { q, r: rr2 } = pixelToHex(x, y, r.size), h = gm.world.getHex(q, rr2);
          return !!h && h.provinceId != null && prov(gm, h.provinceId).props.owner === comp.owner;
        });
        if (L) list.push(L);
      }
      let sg = 0, ii = 1; for (const p of gm.world.provinces.values()) sg = (sg * 31 + (p.props.owner + 2) * (ii++ & 255)) | 0;
      labelCache = { t, world: gm, list, sig: sg };
    }
    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0,0,0,0.75)';
    ctx.shadowBlur = 4;
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    for (const L of labelCache.list) {
      const px = L.fs * z;
      if (px < 7) continue;
      const f = L.letters[Math.floor(L.letters.length / 2)], mid = r.worldToScreen(f.x, f.y);
      if (mid.x < -300 || mid.y < -300 || mid.x > r.w + 300 || mid.y > r.h + 300) continue;
      ctx.font = `${px.toFixed(1)}px ${LABEL_FONT}`;
      for (const c of L.letters) {
        const sc = r.worldToScreen(c.x, c.y);
        ctx.save();
        ctx.translate(sc.x, sc.y);
        ctx.rotate(c.ang);
        ctx.fillText(c.ch, 0, 0);
        ctx.restore();
      }
    }
    ctx.restore();
  }

  function fightRing(ctx, x, y, w, h, s, t) {
    ctx.beginPath();
    rr(ctx, x - 3 * s, y - 3 * s, w + 6 * s, h + 6 * s, 2 * s);
    ctx.lineWidth = 2;
    ctx.strokeStyle = `rgba(255,96,76,${0.55 + 0.4 * Math.sin(t / 170)})`;
    ctx.stroke();
  }

  // Подпись состояния, от которого зависит фон карты: пока она не меняется, фон не перерисовывается.
  function layerSig() {
    if (RULES.weather && ui.screen === 'game') weatherDay(G());
    return [ui.mode, ui.screen, ui.setup.country, ui.selected, ui.target, G().seed, RULES.weather && ui.screen === 'game' ? G()._wxSig : ''].join('~');
  }
  function layerSlowSig() {
    const g = G();
    let h = 0;
    for (const p of g.world.provinces.values()) h = (Math.imul(h, 31) + (p.props.owner ?? -1) + 2 + (isOccupied(p) ? 977 + p.props.core * 13 : 0)) | 0;
    let wars = '';
    for (const k of g.wars.keys()) wars += k + ',';
    return h + '~' + wars;
  }

  return {
    background: TERRAIN.water.color,
    layerSig,
    drawFlat,
    layerSlowSig,
    drawOccupation,
    hexFill,
    edgeStyle,
    drawOverlay,
    animating: () => ui.screen === 'game' && !G().over && G().armies.some((a) => a.fighting),
  };
}
